VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} soorathesab 
   Caption         =   "���� ���� �ј� ��"
   ClientHeight    =   11070
   ClientLeft      =   105
   ClientTop       =   405
   ClientWidth     =   16335
   OleObjectBlob   =   "soorathesab.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "soorathesab"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False







Option Explicit

'====================================================================================================
'                                           TYPE DEFINITIONS
'====================================================================================================
Private Type BankChequeData
    chequeNumber As Long
    companyName As String
    companyNationalID As String
    chequeAmount As String
    chequeDate As String
    Code16Digit As String
    Code_Part1 As String
    Code_Part2 As String
    Code_Part3 As String
    Code_Part4 As String
End Type

Private Type ChequeData
    amount As String
    chequeDate As String
    serialNumber As String
    SixteenDigitCode As String
End Type

Private Type CompanyInfo
    Name As String
    NationalID As String
End Type

'====================================================================================================
'                                        MODULE-LEVEL VARIABLES
'====================================================================================================
Private m_isUpdating As Boolean
Private m_skipSerialEntry As Boolean
Private lastSerial_First4 As String
Private lastSerial_Middle6 As String
Private m_ChequeSchedule As Collection
Private m_IsOptimizing As Boolean
Private m_PendingMergeReservations As Collection
Private m_NextMergeID As Long
Private m_NextListBox2RowID As Long
Private Const CONFIG_HOLIDAY_FLAG_COL As String = "S"
Private Const CONFIG_DATE_LIST_COL As String = "U"
Private Const CONFIG_REAL_TOTAL_COL As String = "V"
Private Const CONFIG_RESERVED_TOTAL_COL As String = "W"
Private Const CONFIG_TRUE_CHEQUE_COL As String = "X"
Private Const CONFIG_BANK_CLEARING_COL As String = "Y"
Private Const CONFIG_SHEET_NAME As String = "�������"

'====================================================================================================
'                                    CONFIGURATION & HELPER FUNCTIONS
'====================================================================================================

'----------------------------------------
' Read a configuration value from a named range
'----------------------------------------
Private Function ReadConfigValue(configName As String) As Long
    On Error Resume Next
    Dim val As Variant
    val = ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range(configName).value
    ReadConfigValue = IIf(IsNumeric(val), CLng(val), 0)
    On Error GoTo 0
End Function

'----------------------------------------
' Alias for FindSheet (used by capacity functions)
'----------------------------------------
Private Function FindSheetByYM(ym As String) As Worksheet
    Set FindSheetByYM = FindSheet(ym)
End Function

'----------------------------------------
' Find a worksheet by year/month in B1
'----------------------------------------
Private Function FindSheet(ym As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If CStr(ws.Range("B1").value) = ym Then
            Set FindSheet = ws
            Exit Function
        End If
    Next ws
    Set FindSheet = Nothing
End Function

'----------------------------------------
' Find the starting row for a specific day
'----------------------------------------
Private Function FindDayRow(ws As Worksheet, dayNum As Long, totalRowsPerDayBlock As Long) As Long
    Dim dayStartRow As Long
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
    If ws.Cells(dayStartRow, "A").value = dayNum Then
        FindDayRow = dayStartRow
    Else
        FindDayRow = 0
    End If
End Function
  '----------------------------------------
  ' Build a unique hidden row ID for every ListBox2 row
  '----------------------------------------
  Private Function CreateListBox2RowID() As String
      m_NextListBox2RowID = m_NextListBox2RowID + 1
      CreateListBox2RowID = "ROW_" & Format(Now, "yyyymmddhhnnss") & "_" & CStr(m_NextListBox2RowID)
  End Function
 '----------------------------------------
  ' Find a ListBox2 row by hidden unique row ID
  ' Returns -1 if not found
  '----------------------------------------
  Private Function FindListBox2RowByRowID(ByVal rowID As String) As Long
      Dim i As Long

      FindListBox2RowByRowID = -1

      For i = 0 To Me.ListBox2.ListCount - 1
          If Trim(CStr(Me.ListBox2.List(i, 4))) = Trim(rowID) Then
              FindListBox2RowByRowID = i
              Exit Function
          End If
      Next i
  End Function
   '----------------------------------------
  ' Read real bank-clearing cheque amount from �������!Y
  '----------------------------------------
Private Function GetBankClearingAmountByPersianDate(ByVal persianDate As String) As Double
      Dim wsInfo As Worksheet
      Dim rowNum As Long

      rowNum = FindConfigDateRow(persianDate)
      If rowNum = 0 Then Exit Function

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      If wsInfo Is Nothing Then
          On Error GoTo 0
          Exit Function
      End If

     If IsNumeric(wsInfo.Cells(rowNum, CONFIG_BANK_CLEARING_COL).value) Then
          GetBankClearingAmountByPersianDate = CDbl(wsInfo.Cells(rowNum, CONFIG_BANK_CLEARING_COL).value)
      Else
          GetBankClearingAmountByPersianDate = 0
      End If

      On Error GoTo 0
  End Function

'====================================================================================================
'                                    PERSIAN CALENDAR FUNCTIONS
'====================================================================================================

'----------------------------------------
' Get days in a Persian month
'----------------------------------------
Private Function GetPersianMonthDays(pYear As Long, pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        GetPersianMonthDays = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        GetPersianMonthDays = 30
    ElseIf pMonth = 12 Then
        ' Leap year check
        If ((pYear - 1403) Mod 4 = 0) Then
            GetPersianMonthDays = 30
        Else
            GetPersianMonthDays = 29
        End If
    Else
        GetPersianMonthDays = 0
    End If
End Function
 '====================================================================================================
  '                             MERGE RESERVATION / CAPACITY HELPERS
  '====================================================================================================

  '----------------------------------------
  ' Ensure pending merge reservation collection exists
  ' Each item format:
  '   Array(mergeID As String, persianDate As String, reserveAmount As Double)
  '----------------------------------------
  Private Sub EnsurePendingMergeReservations()
      If m_PendingMergeReservations Is Nothing Then
          Set m_PendingMergeReservations = New Collection
      End If
  End Sub

  '----------------------------------------
  ' Clear all pending merge reservations
  ' Use this whenever ListBox2 is rebuilt from scratch
  '----------------------------------------
  Private Sub ClearPendingMergeReservations()
      Set m_PendingMergeReservations = New Collection
      m_NextMergeID = 0
  End Sub

  '----------------------------------------
  ' Build a unique merge ID for hidden ListBox2 column
  '----------------------------------------
  Private Function CreateMergeID() As String
      m_NextMergeID = m_NextMergeID + 1
      CreateMergeID = "MERGE_" & Format(Now, "yyyymmddhhnnss") & "_" & CStr(m_NextMergeID)
  End Function

  '----------------------------------------
  ' Find row of a Persian date in ������� column U
  ' Returns 0 if not found
  '----------------------------------------
  Private Function FindConfigDateRow(ByVal persianDate As String) As Long
      Dim wsInfo As Worksheet
      Dim matchRow As Variant

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      On Error GoTo 0

      If wsInfo Is Nothing Then Exit Function

      matchRow = Application.Match(persianDate, wsInfo.Columns(CONFIG_DATE_LIST_COL), 0)
      If Not IsError(matchRow) Then
          FindConfigDateRow = CLng(matchRow)
      End If
  End Function

  '----------------------------------------
  ' Read already-saved reserved capacity from �������!W
  '----------------------------------------
  Private Function GetSavedReservedCapacityByPersianDate(ByVal persianDate As String) As Double
      Dim wsInfo As Worksheet
      Dim rowNum As Long

      rowNum = FindConfigDateRow(persianDate)
      If rowNum = 0 Then Exit Function

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      If wsInfo Is Nothing Then Exit Function

      If IsNumeric(wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value) Then
          GetSavedReservedCapacityByPersianDate = CDbl(wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value)
      Else
          GetSavedReservedCapacityByPersianDate = 0
      End If
      On Error GoTo 0
  End Function
'----------------------------------------
  ' Read saved true merged cheque amount from �������!X
  ' This is used to remove the physical cheque amount from capacity calculation,
  ' because the real daily usage is represented by W reservations.
  '----------------------------------------
  Private Function GetSavedTrueChequeAmountByPersianDate(ByVal persianDate As String) As Double
      Dim wsInfo As Worksheet
      Dim rowNum As Long

      rowNum = FindConfigDateRow(persianDate)
      If rowNum = 0 Then Exit Function

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      If wsInfo Is Nothing Then Exit Function

      If IsNumeric(wsInfo.Cells(rowNum, CONFIG_TRUE_CHEQUE_COL).value) Then
          GetSavedTrueChequeAmountByPersianDate = CDbl(wsInfo.Cells(rowNum, CONFIG_TRUE_CHEQUE_COL).value)
      Else
          GetSavedTrueChequeAmountByPersianDate = 0
      End If
      On Error GoTo 0
  End Function

  '----------------------------------------
  ' Save true merged cheque amount into �������!X
  ' Amounts are added, not overwritten.
  '----------------------------------------
  Private Sub SaveTrueChequeAmountToSheet(ByVal persianDate As String, ByVal chequeAmount As Double)
      Dim wsInfo As Worksheet
      Dim rowNum As Long
      Dim currentVal As Double

      If chequeAmount <= 0 Then Exit Sub

      rowNum = FindConfigDateRow(persianDate)

      If rowNum = 0 Then
          MsgBox "����� " & persianDate & " �� ���� " & CONFIG_DATE_LIST_COL & _
                 " ��� ������� ���� ��Ϻ �������� ���� ����� �� �� ���� X ����� ���.", _
                 vbExclamation, "��� ���� ����� ��"
          Exit Sub
      End If

      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)

      If IsNumeric(wsInfo.Cells(rowNum, CONFIG_TRUE_CHEQUE_COL).value) Then
          currentVal = CDbl(wsInfo.Cells(rowNum, CONFIG_TRUE_CHEQUE_COL).value)
      Else
          currentVal = 0
      End If

      wsInfo.Cells(rowNum, CONFIG_TRUE_CHEQUE_COL).value = currentVal + chequeAmount
  End Sub
  '----------------------------------------
  ' Read not-yet-saved pending reservations from in-memory merge list
  ' Optional excludeMergeID is useful when needed in future extensions
  '----------------------------------------
  Private Function GetPendingReservedCapacityByPersianDate(ByVal persianDate As String, _
                                                           Optional ByVal excludeMergeID As String = "") As Double
      Dim item As Variant

      EnsurePendingMergeReservations

      For Each item In m_PendingMergeReservations
          If CStr(item(1)) = persianDate Then
              If excludeMergeID = "" Or CStr(item(0)) <> excludeMergeID Then
                  GetPendingReservedCapacityByPersianDate = GetPendingReservedCapacityByPersianDate + CDbl(item(2))
              End If
          End If
      Next item
  End Function

  '----------------------------------------
  ' Total reserved capacity for a Persian date
  ' = saved W amount + pending merge reservations
  '----------------------------------------
  Private Function GetReservedCapacityByPersianDate(ByVal persianDate As String, _
                                                    Optional ByVal excludeMergeID As String = "") As Double
      GetReservedCapacityByPersianDate = _
          GetSavedReservedCapacityByPersianDate(persianDate) + _
          GetPendingReservedCapacityByPersianDate(persianDate, excludeMergeID)
  End Function

  '----------------------------------------
  ' Add a new pending reservation entry
  '----------------------------------------
  Private Sub AddPendingMergeReservation(ByVal mergeID As String, ByVal persianDate As String, ByVal reserveAmount As Double)
      If reserveAmount <= 0 Then Exit Sub
      EnsurePendingMergeReservations
      m_PendingMergeReservations.Add Array(mergeID, persianDate, reserveAmount)
  End Sub

  '----------------------------------------
  ' Move all pending reservations from one merge ID to another
  ' This is needed when an already-merged cheque is merged again
  '----------------------------------------
  Private Sub ReassignPendingMergeReservations(ByVal oldMergeID As String, ByVal newMergeID As String)
      Dim newCollection As Collection
      Dim item As Variant

      If Trim(oldMergeID) = "" Then Exit Sub
      If oldMergeID = newMergeID Then Exit Sub

      EnsurePendingMergeReservations
      Set newCollection = New Collection

      For Each item In m_PendingMergeReservations
          If CStr(item(0)) = oldMergeID Then
              newCollection.Add Array(newMergeID, CStr(item(1)), CDbl(item(2)))
          Else
              newCollection.Add item
          End If
      Next item

      Set m_PendingMergeReservations = newCollection
  End Sub

  '----------------------------------------
  ' Remove all pending reservations of one merge ID
  '----------------------------------------
  Private Sub RemovePendingMergeReservations(ByVal mergeID As String)
      Dim newCollection As Collection
      Dim item As Variant

      EnsurePendingMergeReservations
      Set newCollection = New Collection

      For Each item In m_PendingMergeReservations
          If CStr(item(0)) <> mergeID Then
              newCollection.Add item
          End If
      Next item

      Set m_PendingMergeReservations = newCollection
  End Sub

  '----------------------------------------
  ' Save reservations of one merge ID into �������!W
  ' The amounts are ADDED to W, never overwritten
  '----------------------------------------
  Private Sub SavePendingMergeReservationsToSheet(ByVal mergeID As String)
      Dim wsInfo As Worksheet
      Dim item As Variant
      Dim agg As Object
      Dim key As Variant
      Dim rowNum As Long
      Dim currentVal As Double

      EnsurePendingMergeReservations
      Set agg = CreateObject("Scripting.Dictionary")

      For Each item In m_PendingMergeReservations
          If CStr(item(0)) = mergeID Then
              If agg.exists(CStr(item(1))) Then
                  agg(CStr(item(1))) = CDbl(agg(CStr(item(1)))) + CDbl(item(2))
              Else
                  agg.Add CStr(item(1)), CDbl(item(2))
              End If
          End If
      Next item

      If agg.count = 0 Then Exit Sub

      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)

      For Each key In agg.Keys
          rowNum = FindConfigDateRow(CStr(key))

          If rowNum = 0 Then
              MsgBox "����� " & CStr(key) & " �� ���� " & CONFIG_DATE_LIST_COL & _
                     " ��� ������� ���� ��Ϻ �������� ���� ����� ���� �� ����� ���.", _
                     vbExclamation, "���� �����"
          Else
              If Not IsError(wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value) Then
      If IsNumeric(wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value) Then
          currentVal = CDbl(wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value)
      End If
  End If

  wsInfo.Cells(rowNum, CONFIG_RESERVED_TOTAL_COL).value = currentVal + CDbl(agg(key))
          End If
      Next key

      Call RemovePendingMergeReservations(mergeID)
  End Sub

  '----------------------------------------
  ' Renumber ListBox2 first column after add/remove/merge
  '----------------------------------------
  Private Sub RenumberListBox2Rows()
      Dim i As Long

      For i = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.List(i, 0) = i + 1
      Next i
  End Sub

  '----------------------------------------
  ' Get the real cheque total written in monthly sheets only
  ' This does NOT include reserved capacity
  '----------------------------------------
  Private Function GetDayRealChequeTotal(checkDate As Date, firstCol As Long, lastCol As Long, _
                                         totalRowsPerDayBlock As Long, lowerOffset As Long) As Double
      Dim ws As Worksheet
      Dim persianDate As String
      Dim parts() As String
      Dim dayRow As Long
      Dim c As Long
      Dim total As Double

      persianDate = GregorianToPersian(checkDate)
      parts = Split(persianDate, "/")

      Set ws = FindSheetByYM(parts(0) & "/" & parts(1))
      If ws Is Nothing Then
          GetDayRealChequeTotal = 0
          Exit Function
      End If

      dayRow = 2 + (CLng(parts(2)) - 1) * totalRowsPerDayBlock

      For c = firstCol To lastCol Step 2
          If IsNumeric(ws.Cells(dayRow + lowerOffset, c).value) Then
              total = total + CDbl(ws.Cells(dayRow + lowerOffset, c).value)
          End If
      Next c

      GetDayRealChequeTotal = total
  End Function

  '----------------------------------------
  ' Get real + reserved usage for a day
  ' Reserved includes �������!W plus pending in-memory merge reservations
  '----------------------------------------
Private Function GetEffectiveDayUsedAmount(checkDate As Date, firstCol As Long, lastCol As Long, _
                                             totalRowsPerDayBlock As Long, lowerOffset As Long, _
                                             Optional ByVal excludeMergeID As String = "") As Double
      Dim persianDate As String
      Dim realChequeTotal As Double
      Dim trueMergedChequeTotal As Double
      Dim reservedTotal As Double

      persianDate = GregorianToPersian(checkDate)

      realChequeTotal = GetDayRealChequeTotal(checkDate, firstCol, lastCol, _
                                              totalRowsPerDayBlock, lowerOffset)

      trueMergedChequeTotal = GetSavedTrueChequeAmountByPersianDate(persianDate)

      reservedTotal = GetReservedCapacityByPersianDate(persianDate, excludeMergeID)

      GetEffectiveDayUsedAmount = Application.Max(realChequeTotal - trueMergedChequeTotal, 0) + reservedTotal
  End Function

  '----------------------------------------
  ' Ask user for target fill amount used during merge
  ' If spread mode is ON, TextBox3 is used automatically
  ' If spread mode is OFF, user is prompted
  ' Returns True if valid, False if cancelled/invalid
  '----------------------------------------
  Private Function GetMergeTargetFillAmount(ByRef targetAmount As Double) As Boolean
      Dim inputValue As String
      Dim result As Variant

      GetMergeTargetFillAmount = False
      targetAmount = 0

      If Me.ToggleButton1.value Then
          result = EvaluateExpression(Me.TextBox3.value)
          If Not IsNumeric(result) Or CDbl(result) <= 0 Then
              MsgBox "��� ���� ��� ���� ��ʡ ����� ����� ������ �� TextBox3 ���� ����� � ��ѐ�� �� ��� ����.", _
                     vbExclamation, "����� �����"
              Exit Function
          End If

          targetAmount = CDbl(result)
          GetMergeTargetFillAmount = True
          Exit Function
      End If

      inputValue = InputBox( _
          "���� ��� ����� ���." & vbCrLf & vbCrLf & _
          "����� ����� �� ���� ���� �� �������� ������ ������ �������� �� �� ��ݡ" & vbCrLf & _
          "�� � ���� ��� ����� ����." & vbCrLf & vbCrLf & _
          "����: 45000000", _
          "���� ���� �����")

      If Trim(inputValue) = "" Then Exit Function

      result = EvaluateExpression(inputValue)
      If Not IsNumeric(result) Or CDbl(result) <= 0 Then
          MsgBox "���� ���� ����� ����� ����.", vbExclamation, "����� �����"
          Exit Function
      End If

      targetAmount = CDbl(result)
      GetMergeTargetFillAmount = True
  End Function
'----------------------------------------
' Convert Persian date (year, month, day) to Gregorian date
'----------------------------------------
Private Function PersianToGregorianDate(pYear As Long, pMonth As Long, pDay As Long) As Date
    Dim i As Long, total_days As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 21) ' 1403/01/01
    
    total_days = 0
    
    ' Add days for complete months
    For i = 1 To pMonth - 1
        total_days = total_days + GetPersianMonthDays(pYear, i)
    Next i
    
    ' Add remaining days
    total_days = total_days + pDay - 1
    
    ' Adjust for year difference
    If pYear > 1403 Then
        For i = 1403 To pYear - 1
            total_days = total_days + IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    ElseIf pYear < 1403 Then
        For i = pYear To 1402
            total_days = total_days - IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    End If
    
    PersianToGregorianDate = ref_g_date + total_days
End Function

'----------------------------------------
' Convert Persian date string to Gregorian date
'----------------------------------------
Private Function PersianToGregorian(persianDateStr As String) As Date
    Dim parts() As String
    Dim cleanDate As String
    
    ' Clean the date string but preserve slashes
    cleanDate = Trim(persianDateStr)
    cleanDate = ConvertPersianNumsToEnglishKeepSlash(cleanDate)
    
    If InStr(cleanDate, "/") = 0 Then
        PersianToGregorian = Date ' Return today as fallback
        Exit Function
    End If
    
    parts = Split(cleanDate, "/")
    
    If UBound(parts) <> 2 Then
        PersianToGregorian = Date
        Exit Function
    End If
    
    On Error Resume Next
    PersianToGregorian = PersianToGregorianDate(CLng(parts(0)), CLng(parts(1)), CLng(parts(2)))
    If Err.Number <> 0 Then
        PersianToGregorian = Date
    End If
    On Error GoTo 0
End Function

'----------------------------------------
' Convert Gregorian date to Persian date string
'----------------------------------------
Private Function GregorianToPersian(gDate As Date) As String
    Dim days_diff As Long, p_y As Long, p_m As Long, p_d As Long, days_in_p_year As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 21)
    
    days_diff = gDate - ref_g_date
    p_y = 1403
    
    If days_diff < 0 Then
        Do
            p_y = p_y - 1
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            days_diff = days_diff + days_in_p_year
            If days_diff >= 0 Then Exit Do
        Loop
    Else
        Do
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            If days_diff >= days_in_p_year Then
                days_diff = days_diff - days_in_p_year
                p_y = p_y + 1
            Else
                Exit Do
            End If
        Loop
    End If
    
    p_m = 1
    Do While p_m <= 12
        Dim p_days_in_month As Long
        p_days_in_month = GetPersianMonthDays(p_y, p_m)
        If days_diff < p_days_in_month Then Exit Do
        days_diff = days_diff - p_days_in_month
        p_m = p_m + 1
    Loop
    
    p_d = days_diff + 1
    GregorianToPersian = p_y & "/" & Format(p_m, "00") & "/" & Format(p_d, "00")
End Function

'----------------------------------------
' Validate Persian date format
'----------------------------------------
Private Function IsValidPersianDate(dateStr As String) As Boolean
    Dim parts() As String
    Dim cleanDate As String
    
    On Error GoTo InvalidDate
    
    ' Clean the date but preserve slashes
    cleanDate = Trim(dateStr)
    cleanDate = ConvertPersianNumsToEnglishKeepSlash(cleanDate)
    
    If InStr(cleanDate, "/") = 0 Then GoTo InvalidDate
    
    parts = Split(cleanDate, "/")
    If UBound(parts) <> 2 Then GoTo InvalidDate
    
    Dim y As Long, m As Long, d As Long
    y = CLng(Trim(parts(0)))
    m = CLng(Trim(parts(1)))
    d = CLng(Trim(parts(2)))
    
    ' Validate year range
    If y < 1300 Or y > 1500 Then GoTo InvalidDate
    
    ' Validate month range
    If m < 1 Or m > 12 Then GoTo InvalidDate
    
    ' Validate day range
    If d < 1 Or d > 31 Then GoTo InvalidDate
    
    ' Check days in specific months
    If m >= 1 And m <= 6 And d > 31 Then GoTo InvalidDate
    If m >= 7 And m <= 11 And d > 30 Then GoTo InvalidDate
    If m = 12 Then
        Dim maxDay As Long
        maxDay = IIf(((y - 1403) Mod 4 = 0), 30, 29)
        If d > maxDay Then GoTo InvalidDate
    End If
    
    IsValidPersianDate = True
    Exit Function
    
InvalidDate:
    IsValidPersianDate = False
End Function

'====================================================================================================
'                                    NUMBER CONVERSION FUNCTIONS
'====================================================================================================

'----------------------------------------
' Convert Persian/Arabic digits to English (keeps other characters)
'----------------------------------------
Public Function ConvertPersianNumsToEnglish(ByVal s As Variant) As String
    Dim i As Long
    Dim out As String
    Dim ch As String
    Dim code As Long

    If IsNull(s) Or IsEmpty(s) Then
        ConvertPersianNumsToEnglish = ""
        Exit Function
    End If

    s = CStr(s)
    out = ""
    
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
           
        Select Case code
            Case 1776 To 1785  ' Persian digits
                out = out & CStr(code - 1776)
            Case 1632 To 1641  ' Arabic-Indic digits
                out = out & CStr(code - 1632)
            Case 48 To 57      ' ASCII digits
                out = out & ch
            Case 1569 To 1578  ' Eastern Arabic digits
                out = out & CStr(code - 1569)
            Case 32            ' Space
                out = out & " "
            Case 63            ' Skip corrupted character
                ' Skip
            Case Else
                If ch >= "0" And ch <= "9" Then
                    out = out & ch
                End If
        End Select
    Next i

    ConvertPersianNumsToEnglish = out
End Function

'----------------------------------------
' Convert Persian/Arabic digits to English (KEEPS slashes for dates)
'----------------------------------------
Private Function ConvertPersianNumsToEnglishKeepSlash(ByVal s As Variant) As String
    Dim i As Long
    Dim out As String
    Dim ch As String
    Dim code As Long

    If IsNull(s) Or IsEmpty(s) Then
        ConvertPersianNumsToEnglishKeepSlash = ""
        Exit Function
    End If

    s = CStr(s)
    out = ""
    
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
           
        Select Case code
            Case 1776 To 1785  ' Persian digits
                out = out & CStr(code - 1776)
            Case 1632 To 1641  ' Arabic-Indic digits
                out = out & CStr(code - 1632)
            Case 48 To 57      ' ASCII digits
                out = out & ch
            Case 47            ' Forward slash "/"
                out = out & "/"
            Case 32            ' Space
                out = out & " "
            Case Else
                If ch >= "0" And ch <= "9" Then
                    out = out & ch
                ElseIf ch = "/" Then
                    out = out & "/"
                End If
        End Select
    Next i

    ConvertPersianNumsToEnglishKeepSlash = out
End Function

'----------------------------------------
' Evaluate mathematical expression
'----------------------------------------
Private Function EvaluateExpression(ByVal expr As String) As Variant
    Dim cleanedExpr As String
    Dim result As Variant
    
    cleanedExpr = Trim(expr)
    If cleanedExpr = "" Then
        EvaluateExpression = expr
        Exit Function
    End If
    
    ' Remove commas first
    cleanedExpr = Replace(cleanedExpr, ",", "")
    
    ' Convert Persian digits but KEEP operators
    cleanedExpr = ConvertPersianDigitsKeepOperators(cleanedExpr)
  
    ' Check if it's just a number (no operators)
    If IsNumeric(cleanedExpr) Then
        EvaluateExpression = CDbl(cleanedExpr)
        Exit Function
    End If
    
    ' Check if expression contains any operator
    If InStr(cleanedExpr, "+") = 0 And _
       InStr(cleanedExpr, "-") = 0 And _
       InStr(cleanedExpr, "*") = 0 And _
       InStr(cleanedExpr, "/") = 0 And _
       InStr(cleanedExpr, "^") = 0 Then
        ' No operators found, return as number if possible
        If IsNumeric(cleanedExpr) Then
            EvaluateExpression = CDbl(cleanedExpr)
        Else
            EvaluateExpression = expr
        End If
        Exit Function
    End If
    
    ' Evaluate the expression
    On Error Resume Next
    result = Application.Evaluate(cleanedExpr)
    
    If Err.Number <> 0 Or IsError(result) Then
        ' Try with "=" prefix
        Err.Clear
        result = Application.Evaluate("=" & cleanedExpr)
    End If
    
    If Err.Number <> 0 Or IsError(result) Then
        ' Evaluation failed, return original
        EvaluateExpression = expr
    Else
        EvaluateExpression = result
    End If
    On Error GoTo 0
End Function
'----------------------------------------
' Keep only digit characters
'----------------------------------------
Private Function KeepOnlyDigits(ByVal s As String) As String
    Dim i As Long
    Dim result As String
    Dim ch As String
    
    result = ""
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then
            result = result & ch
        End If
    Next i
    
    KeepOnlyDigits = result
End Function

'----------------------------------------
' Clean amount text by removing separators
'----------------------------------------
Private Function CleanAmountText(amountText As String) As String
    Dim result As String
    result = ConvertPersianNumsToEnglish(amountText)
    
    result = Replace(result, ",", "")
    result = Replace(result, ChrW(1644), "")   ' Persian comma
    result = Replace(result, ChrW(1548), "")   ' Arabic comma
    result = Replace(result, " ", "")
    result = Replace(result, ".", "")
    result = Replace(result, "'", "")
    result = Replace(result, "`", "")
    
    Dim cleanResult As String
    Dim j As Integer
    For j = 1 To Len(result)
        Dim charCode As Integer
        charCode = Asc(Mid(result, j, 1))
        If charCode >= 48 And charCode <= 57 Then
            cleanResult = cleanResult & Mid(result, j, 1)
        End If
    Next j
    
    CleanAmountText = cleanResult
End Function

'====================================================================================================
'                                    FORMATTING FUNCTIONS
'====================================================================================================

'----------------------------------------
' Format cheque serial number with spaces
'----------------------------------------
Public Function FormatChequeSerial(ByVal raw As Variant) As String
    Dim digits As String
    digits = ConvertPersianNumsToEnglish(raw)
    digits = Right$("000000000000" & digits, 12)
    FormatChequeSerial = Left$(digits, 4) & " " & Mid$(digits, 5, 6) & " " & Right$(digits, 2)
End Function

'----------------------------------------
' Convert Persian date string to Farsi words
'----------------------------------------
Private Function FormatPersianDateWords(persianDateString As String) As String
    Dim dateParts As Variant
    Dim pYear As Long, pMonth As Long, pDay As Long
    Dim monthNames As Variant
    
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    
    dateParts = Split(persianDateString, "/")
    If UBound(dateParts) <> 2 Then
        FormatPersianDateWords = "����� �������"
        Exit Function
    End If
    
    pYear = CLng(dateParts(0))
    pMonth = CLng(dateParts(1))
    pDay = CLng(dateParts(2))
    
    FormatPersianDateWords = NumberToFarsiWords(pDay) & " " & monthNames(pMonth - 1) & " " & NumberToFarsiWords(pYear)
End Function

'----------------------------------------
' Convert number to Farsi words
'----------------------------------------
Private Function NumberToFarsiWords(ByVal num As Double) As String
    If num = 0 Then
        NumberToFarsiWords = "���"
        Exit Function
    End If

    Dim FarsiUnits(0 To 9) As String
    Dim FarsiTeens(0 To 9) As String
    Dim FarsiTens(0 To 9) As String
    Dim FarsiHundreds(0 To 9) As String
    Dim FarsiScale(0 To 4) As String
    
    FarsiUnits(1) = "�": FarsiUnits(2) = "��": FarsiUnits(3) = "��"
    FarsiUnits(4) = "����": FarsiUnits(5) = "���": FarsiUnits(6) = "��"
    FarsiUnits(7) = "���": FarsiUnits(8) = "���": FarsiUnits(9) = "��"
    
    FarsiTeens(0) = "��": FarsiTeens(1) = "�����": FarsiTeens(2) = "������"
    FarsiTeens(3) = "�����": FarsiTeens(4) = "������": FarsiTeens(5) = "������"
    FarsiTeens(6) = "������": FarsiTeens(7) = "����": FarsiTeens(8) = "����"
    FarsiTeens(9) = "�����"
    
    FarsiTens(2) = "����": FarsiTens(3) = "��": FarsiTens(4) = "���"
    FarsiTens(5) = "�����": FarsiTens(6) = "���": FarsiTens(7) = "�����"
    FarsiTens(8) = "�����": FarsiTens(9) = "���"
    
    FarsiHundreds(1) = "���": FarsiHundreds(2) = "�����": FarsiHundreds(3) = "����"
    FarsiHundreds(4) = "������": FarsiHundreds(5) = "�����": FarsiHundreds(6) = "����"
    FarsiHundreds(7) = "�����": FarsiHundreds(8) = "�����": FarsiHundreds(9) = "����"
    
    FarsiScale(1) = " ����": FarsiScale(2) = " ������"
    FarsiScale(3) = " �������": FarsiScale(4) = " �������"

    Dim temp As String
    Dim result As String
    Dim group As Integer
    Dim numStr As String
    numStr = CStr(Int(num))
    
    Do While Len(numStr) > 0
        If Len(numStr) > 3 Then
            temp = Right(numStr, 3)
            numStr = Left(numStr, Len(numStr) - 3)
        Else
            temp = numStr
            numStr = ""
        End If
        
        Dim h As Integer, t As Integer, u As Integer
        h = val(Left(temp, 1))
        If Len(temp) > 1 Then t = val(Mid(temp, 2, 1)) Else t = 0
        If Len(temp) > 2 Then u = val(Right(temp, 1)) Else u = val(Right(temp, 1))

        If Len(temp) = 2 Then h = 0: t = val(Left(temp, 1)): u = val(Right(temp, 1))
        If Len(temp) = 1 Then h = 0: t = 0: u = val(temp)
        
        Dim groupStr As String
        groupStr = ""
        
        If h > 0 Then groupStr = FarsiHundreds(h)
        
        If t = 1 Then
            If groupStr <> "" Then groupStr = groupStr & " � "
            groupStr = groupStr & FarsiTeens(u)
        Else
            If t > 1 Then
                If groupStr <> "" Then groupStr = groupStr & " � "
                groupStr = groupStr & FarsiTens(t)
            End If
            If u > 0 Then
                If groupStr <> "" And t = 0 Then groupStr = groupStr & " � "
                If t > 1 Then groupStr = groupStr & " � "
                groupStr = groupStr & FarsiUnits(u)
            End If
        End If
        
        If groupStr <> "" Then
            If result <> "" Then
                result = groupStr & FarsiScale(group) & " � " & result
            Else
                result = groupStr & FarsiScale(group)
            End If
        End If
        
        group = group + 1
    Loop
    
    NumberToFarsiWords = result
End Function

'====================================================================================================
'                                    CAPACITY & DAY CHECKING FUNCTIONS
'====================================================================================================

'----------------------------------------
' Check if a date is a holiday
'----------------------------------------
Private Function IsHoliday(d As Date) As Boolean
      Dim ws As Worksheet
      Dim r As Long
      Dim hDate As String

      On Error Resume Next
      Set ws = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      On Error GoTo 0

      If ws Is Nothing Then
          IsHoliday = False
          Exit Function
      End If

      hDate = GregorianToPersian(d)
      r = FindConfigDateRow(hDate)

      If r > 0 Then
          If Trim(ws.Cells(r, CONFIG_HOLIDAY_FLAG_COL).value) = "*" Then
              IsHoliday = True
          End If
      End If
  End Function

'----------------------------------------
' Count cheques on a specific day
'----------------------------------------
Private Function DayChequeCount(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                 totalRowsPerDayBlock As Long) As Long
    Dim ymd() As String
    Dim ws As Worksheet
    Dim dayStartRow As Long
    Dim cnt As Long, c As Long
    
    ymd = Split(GregorianToPersian(d), "/")
    Set ws = FindSheet(ymd(0) & "/" & ymd(1))
    If ws Is Nothing Then Exit Function
    
    dayStartRow = FindDayRow(ws, CLng(ymd(2)), totalRowsPerDayBlock)
    If dayStartRow = 0 Then Exit Function

    For c = firstChequeCol To lastChequeCol Step 2
        If ws.Cells(dayStartRow, c).value <> "" Then cnt = cnt + 1
    Next c
    
    DayChequeCount = cnt
End Function

'----------------------------------------
' Get remaining capacity for a day
'----------------------------------------
  Private Function RemainingCapacity(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                     totalRowsPerDayBlock As Long, lowerHalfStartOffset As Long, _
                                     Optional ByVal capacityLimitOverride As Double = 0) As Double
      Dim limitPerDay As Double
      Dim ymd() As String
      Dim ws As Worksheet
      Dim dayStartRow As Long
      Dim cnt As Long, c As Long
      Dim numCheques As Long
      Dim used As Double

  If capacityLimitOverride > 0 Then
      limitPerDay = capacityLimitOverride
  Else
      limitPerDay = EvaluateExpression(Me.TextBox3.value)
  End If
  If limitPerDay <= 0 Then
          RemainingCapacity = 0
          Exit Function
      End If

      ymd = Split(GregorianToPersian(d), "/")
      Set ws = FindSheet(ymd(0) & "/" & ymd(1))
      If ws Is Nothing Then Exit Function

      dayStartRow = FindDayRow(ws, CLng(ymd(2)), totalRowsPerDayBlock)
      If dayStartRow = 0 Then Exit Function

      For c = firstChequeCol To lastChequeCol Step 2
          If ws.Cells(dayStartRow, c).value <> "" Then
              cnt = cnt + 1
          End If
      Next c

      used = GetEffectiveDayUsedAmount(d, firstChequeCol, lastChequeCol, _
                                       totalRowsPerDayBlock, lowerHalfStartOffset)

      numCheques = ReadConfigValue("cfg_NumCheques")
      If cnt >= numCheques Then
          RemainingCapacity = 0
      Else
          RemainingCapacity = Application.Max(limitPerDay - used, 0)
      End If
  End Function

'----------------------------------------
' Get capacity usage percentage for a day
'----------------------------------------
  Private Function GetCapacityUsagePercent(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                           totalRowsPerDayBlock As Long, lowerHalfStartOffset As Long, _
                                           Optional ByVal capacityLimitOverride As Double = 0) As Double
      Dim limitPerDay As Double
      Dim ymd() As String
      Dim ws As Worksheet
      Dim dayStartRow As Long
      Dim used As Double

  If capacityLimitOverride > 0 Then
      limitPerDay = capacityLimitOverride
  Else
      limitPerDay = EvaluateExpression(Me.TextBox3.value)
  End If
      If limitPerDay <= 0 Then
          GetCapacityUsagePercent = 100
          Exit Function
      End If

      ymd = Split(GregorianToPersian(d), "/")
      Set ws = FindSheet(ymd(0) & "/" & ymd(1))
      If ws Is Nothing Then
          GetCapacityUsagePercent = 0
          Exit Function
      End If

      dayStartRow = FindDayRow(ws, CLng(ymd(2)), totalRowsPerDayBlock)
      If dayStartRow = 0 Then
          GetCapacityUsagePercent = 0
          Exit Function
      End If

      used = GetEffectiveDayUsedAmount(d, firstChequeCol, lastChequeCol, _
                                       totalRowsPerDayBlock, lowerHalfStartOffset)

      GetCapacityUsagePercent = (used / limitPerDay) * 100
  End Function

'----------------------------------------
' Check if day has available cheque slot
'----------------------------------------
Private Function HasAvailableSlot(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                   totalRowsPerDayBlock As Long) As Boolean
    Dim numChequesMax As Long
    Dim currentCount As Long
    
    numChequesMax = ReadConfigValue("cfg_NumCheques")
    currentCount = DayChequeCount(d, firstChequeCol, lastChequeCol, totalRowsPerDayBlock)
    HasAvailableSlot = (currentCount < numChequesMax)
End Function

'----------------------------------------
' Find first completely empty day
'----------------------------------------
  Private Function FirstEmptyDay(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                  totalRowsPerDayBlock As Long) As Date
      Dim dt As Date: dt = d
      Dim maxIterations As Long: maxIterations = 365
      Dim iterations As Long: iterations = 0

      Do
          iterations = iterations + 1
          If iterations > maxIterations Then
              FirstEmptyDay = d
              Exit Function
          End If

          If DayChequeCount(dt, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) = 0 _
             And Not IsHoliday(dt) _
             And Not HasReservedCapacity(dt) Then
              FirstEmptyDay = dt
              Exit Function
          End If

          dt = dt + 1
      Loop
  End Function







'----------------------------------------
  ' Build a stable key for comparing generated cheque dates
  '----------------------------------------
  Private Function ScheduleDateKey(ByVal d As Date) As String
      ScheduleDateKey = CStr(CLng(Int(CDbl(d))))
  End Function

  '----------------------------------------
  ' Find first empty day, excluding dates already used in the current generated schedule
  '----------------------------------------
  Private Function FirstEmptyDayExcludingGenerated(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                                    totalRowsPerDayBlock As Long, _
                                                    ByVal generatedDateKeys As Object) As Date
      Dim dt As Date: dt = d
      Dim maxIterations As Long: maxIterations = 365
      Dim iterations As Long: iterations = 0
      Dim dateKey As String

      Do
          iterations = iterations + 1
          If iterations > maxIterations Then
              FirstEmptyDayExcludingGenerated = d
              Exit Function
          End If

          dateKey = ScheduleDateKey(dt)

If DayChequeCount(dt, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) = 0 _
     And Not IsHoliday(dt) _
     And Not HasReservedCapacity(dt) _
     And Not generatedDateKeys.exists(dateKey) Then
              FirstEmptyDayExcludingGenerated = dt
              Exit Function
          End If

          dt = dt + 1
      Loop
  End Function











'----------------------------------------
' Find first available day (has capacity below threshold)
'----------------------------------------
Private Function FirstAvailableDay(d As Date, firstChequeCol As Long, lastChequeCol As Long, _
                                    totalRowsPerDayBlock As Long, lowerHalfStartOffset As Long) As Date
    Dim dt As Date: dt = d
    Dim maxIterations As Long: maxIterations = 365
    Dim iterations As Long: iterations = 0
    
    Do
        iterations = iterations + 1
        If iterations > maxIterations Then
            FirstAvailableDay = d
            Exit Function
        End If
        
        If Not IsHoliday(dt) Then
            If HasAvailableSlot(dt, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) Then
                Dim usagePercent As Double
                usagePercent = GetCapacityUsagePercent(dt, firstChequeCol, lastChequeCol, _
                                                        totalRowsPerDayBlock, lowerHalfStartOffset)
                ' Find days with less than 80% used
                If usagePercent < 80 Then
                    FirstAvailableDay = dt
                    Exit Function
                End If
            End If
        End If
        dt = dt + 1
    Loop
End Function

'----------------------------------------
' Get total cheques amount for a specific day
'----------------------------------------
  Private Function GetDayTotalCheques(checkDate As Date, firstCol As Long, lastCol As Long, _
                                       totalRowsPerDayBlock As Long, lowerOffset As Long) As Double
      GetDayTotalCheques = GetEffectiveDayUsedAmount(checkDate, firstCol, lastCol, _
                                                     totalRowsPerDayBlock, lowerOffset)
  End Function

'====================================================================================================
'                                    COMPANY LOOKUP FUNCTIONS
'====================================================================================================

'----------------------------------------
' Get National ID for a company
' Handles companies with beneficiary in parentheses
'----------------------------------------
Private Function GetNationalID(companyName As String) As String
    Dim wsInfo As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    
    On Error Resume Next
    Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
    On Error GoTo 0
    
    If wsInfo Is Nothing Then
        GetNationalID = ""
        Exit Function
    End If
    
    lastRow = wsInfo.Cells(wsInfo.rows.count, "A").End(xlUp).Row
    
    ' Loop through and compare using GetCompanyName
    For Each cell In wsInfo.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If GetCompanyName(cell.value) = companyName Then
                GetNationalID = cell.Offset(0, 1).value
                Exit Function
            End If
        End If
    Next cell
    
    GetNationalID = ""
End Function

'====================================================================================================
'                                    UI UPDATE FUNCTIONS
'====================================================================================================

'----------------------------------------
' Update factor totals (Label33, Label34)
'----------------------------------------
Private Sub UpdateFactorTotals()
    m_isUpdating = True
    
    Dim i As Long
    Dim totalSelected As Double
    
    ' Calculate sum of selected factors
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            totalSelected = totalSelected + EvaluateExpression(Me.ListBox1.List(i, 1))
        End If
    Next i
    
    Me.Label33.Caption = Format(totalSelected, "#,##0")
    
    ' Apply manual adjustment (TextBox8)
    Dim manualAdjustment As Double
    Dim manualResult As Variant
    manualResult = EvaluateExpression(Me.TextBox8.value)
    If IsNumeric(manualResult) Then
        manualAdjustment = CDbl(manualResult)
    Else
        manualAdjustment = 0
    End If
    
    Dim adjustedTotal As Double
    adjustedTotal = totalSelected - manualAdjustment
    
    ' Apply rounding if toggle is ON
    
    If Me.ToggleButton2.value Then
        Dim requiredAdjustment As Double
        Dim remainder As Double
        
        remainder = adjustedTotal - (10000 * Int(adjustedTotal / 10000))
        
        If remainder = 0 Then
            requiredAdjustment = 0
        Else
            requiredAdjustment = 10000 - remainder   ' FIXED: was "remainder - 10000"
        End If
        
        Me.TextBox7.value = Format(requiredAdjustment, "#,##0")
    End If
    
    ' Calculate final total
    Dim roundingAdjustment As Double
    Dim roundingResult As Variant
    roundingResult = EvaluateExpression(Me.TextBox7.value)
    If IsNumeric(roundingResult) Then
        roundingAdjustment = CDbl(roundingResult)
    Else
        roundingAdjustment = 0
    End If
    
    Me.Label34.Caption = Format(totalSelected - manualAdjustment + roundingAdjustment, "#,##0")
    
    m_isUpdating = False
End Sub

'----------------------------------------
' Update cheque schedule's weighted average date (Label23)
'----------------------------------------
Private Sub UpdateChequeAverageDate()
    Me.Label23.Caption = ""
    
    If Me.ListBox2.ListCount = 0 Then Exit Sub

    Dim i As Long
    Dim totalAmount As Double
    Dim weightedSum As Double
    Dim chequeAmt As Double
    Dim chequeDate As Date
    Dim pDateParts() As String

    For i = 0 To Me.ListBox2.ListCount - 1
        chequeAmt = EvaluateExpression(Me.ListBox2.List(i, 1))
        pDateParts = Split(Me.ListBox2.List(i, 2), "/")
        
        On Error Resume Next
        chequeDate = PersianToGregorianDate(CLng(pDateParts(0)), CLng(pDateParts(1)), CLng(pDateParts(2)))
        On Error GoTo 0
        
        totalAmount = totalAmount + chequeAmt
        weightedSum = weightedSum + (chequeAmt * CDbl(chequeDate))
    Next i
    
    If totalAmount > 0 Then
        Dim avgDate As Date
        avgDate = CDate(weightedSum / totalAmount)
        Me.Label23.Caption = GregorianToPersian(avgDate)
    End If
End Sub



'----------------------------------------
' Show capacity for 6 days before and after selected date
'----------------------------------------
Private Sub ShowSurroundingDaysCapacity(persianDate As String)
    Dim gDate As Date
    Dim i As Long
    Dim checkDate As Date
    Dim dayUsage As Double
    Dim usagePercent As Double
    Dim capacityLimit As Double
    Dim statusText As String
    
    ' Text for 3 columns
    Dim colDates As String
    Dim colStatus As String
    Dim colAmounts As String
    
    On Error Resume Next
    gDate = PersianToGregorian(persianDate)
    If Err.Number <> 0 Then Exit Sub
    On Error GoTo 0
    
    ' Get capacity limit
    capacityLimit = EvaluateExpression(Me.TextBox3.value)
    If capacityLimit <= 0 Then capacityLimit = 100000000
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Initialize column texts
    colDates = "�����" & vbCrLf & String(10, "-") & vbCrLf
    colStatus = "����" & vbCrLf & String(12, "-") & vbCrLf
    colAmounts = "����" & vbCrLf & String(12, "-") & vbCrLf
    
    ' Loop 6 days before to 6 days after
    For i = -6 To 6
        checkDate = gDate + i
        
        Dim dateDisplay As String
        Dim persianDateStr As String
        persianDateStr = GregorianToPersian(checkDate)
        Dim bankClearingAmount As Double
        bankClearingAmount = GetActualBankClearingAmount(checkDate)
        ' Show only month/day for cleaner display
        Dim dateParts() As String
        dateParts = Split(persianDateStr, "/")
         dateDisplay = dateParts(1) & "/" & dateParts(2)
        
          If IsHoliday(checkDate) Then
              dateDisplay = dateDisplay & "*"
          End If
        ' Mark current day
        If i = 0 Then
            dateDisplay = ">" & dateDisplay & "<"
        End If
        
  If IsHoliday(checkDate) Then
      dayUsage = GetDayTotalCheques(checkDate, firstChequeCol, lastChequeCol, _
                                    totalRowsPerDayBlock, lowerHalfStartOffset)

      colDates = colDates & dateDisplay & vbCrLf
      colStatus = colStatus & Format(bankClearingAmount / 1000000, "#,##0") & "M" & vbCrLf
      colAmounts = colAmounts & Format(dayUsage / 1000000, "#,##0") & "M" & vbCrLf
  Else
            ' Get sum of cheques for this day
            dayUsage = GetDayTotalCheques(checkDate, firstChequeCol, lastChequeCol, _
                                          totalRowsPerDayBlock, lowerHalfStartOffset)
            usagePercent = (dayUsage / capacityLimit) * 100
            
            ' Determine status text
            If usagePercent >= 100 Then
                statusText = "��"
            ElseIf usagePercent >= 75 Then
                statusText = "����"
           ElseIf usagePercent >= 50 Then
                statusText = "�����"
                   ElseIf usagePercent >= 25 Then
                statusText = "��"
            Else
                statusText = "����"
            End If
            
            colDates = colDates & dateDisplay & vbCrLf
            colStatus = colStatus & Format(bankClearingAmount / 1000000, "#,##0") & "M" & vbCrLf
            colAmounts = colAmounts & Format(dayUsage / 1000000, "#,##0") & "M" & vbCrLf
        End If
    Next i
    
    ' Display in 3 labels
    On Error Resume Next
    Me.lblCapacityDates.Caption = colDates
    Me.lblCapacityStatus.Caption = colStatus
    Me.lblCapacityAmounts.Caption = colAmounts
    On Error GoTo 0
End Sub

'----------------------------------------
' Recalculate cheque totals after editing
'----------------------------------------
Private Sub RecalculateTotals()
    Dim i As Long
    Dim total As Double
    
    total = 0
    For i = 0 To Me.ListBox2.ListCount - 1
        total = total + EvaluateExpression(Me.ListBox2.List(i, 1))
    Next i
    
    ' Update Label34 to reflect new cheque total
    Me.Label34.Caption = Format(total, "#,##0")
End Sub

'====================================================================================================
'                                    CHEQUE SCHEDULING FUNCTIONS
'====================================================================================================

'----------------------------------------
' Spread a cheque across days based on capacity
' LOGIC: Find days with < 80% usage, then fill up to 100% capacity
'----------------------------------------
Private Sub SpreadChequeWithCapacity(ByVal targetDate As Date, ByVal chequeAmount As Double, _
                                      ByRef schedule As Collection, _
                                      ByVal firstChequeCol As Long, ByVal lastChequeCol As Long, _
                                      ByVal totalRowsPerDayBlock As Long, ByVal lowerHalfStartOffset As Long, _
                                      ByVal capacityLimit As Double)
    
    Dim remainingAmount As Double: remainingAmount = chequeAmount
    Dim currentDate As Date: currentDate = targetDate
    Dim maxIterations As Long: maxIterations = 365
    Dim iterations As Long: iterations = 0
    Dim accumulatedRemainder As Double: accumulatedRemainder = 0
    
    ' Constants for capacity logic
    ' Days with LESS than 80% are candidates for new cheques
    ' But once selected, they can be filled UP TO 100% (with 10% overflow allowed)
    Const ENTRY_THRESHOLD As Double = 80     ' Only consider days below 80% usage
    Const OVERFLOW_ALLOWANCE As Double = 0.1 ' Allow 10% overflow to avoid tiny remainders
    
    Do While remainingAmount > 0.01 And iterations < maxIterations
        iterations = iterations + 1
        
        ' Skip holidays
        If IsHoliday(currentDate) Then
            currentDate = currentDate + 1
            GoTo ContinueLoop
        End If
        
        ' Check if day has an available slot (not full on count)
        If Not HasAvailableSlot(currentDate, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) Then
            currentDate = currentDate + 1
            GoTo ContinueLoop
        End If
        
        ' Get current capacity usage for this day
        Dim usagePercent As Double
  usagePercent = GetCapacityUsagePercent(currentDate, firstChequeCol, lastChequeCol, _
                                          totalRowsPerDayBlock, lowerHalfStartOffset, capacityLimit)
        
        ' Only START using days with less than 80% capacity used
        If usagePercent >= ENTRY_THRESHOLD Then
            currentDate = currentDate + 1
            GoTo ContinueLoop
        End If
        
        ' Calculate available capacity (up to 100%, not just 80%)
        Dim availableCapacity As Double
  availableCapacity = RemainingCapacity(currentDate, firstChequeCol, lastChequeCol, _
                                         totalRowsPerDayBlock, lowerHalfStartOffset, capacityLimit)
        
        If availableCapacity <= 0 Then
            currentDate = currentDate + 1
            GoTo ContinueLoop
        End If
        
        ' Determine how much to allocate to this day
        Dim allocAmount As Double
        Dim roundedAmount As Double
        
        ' Check if remaining amount can fit here (with overflow allowance)
        If remainingAmount <= availableCapacity * (1 + OVERFLOW_ALLOWANCE) Then
            ' Last piece - add accumulated remainder and put it all here
            allocAmount = remainingAmount + accumulatedRemainder
            accumulatedRemainder = 0
        Else
            ' Take up to full capacity, round down to nearest 10,000
            allocAmount = Application.Min(remainingAmount, availableCapacity)
            roundedAmount = Application.WorksheetFunction.RoundDown(allocAmount, -4)
            accumulatedRemainder = accumulatedRemainder + (allocAmount - roundedAmount)
            allocAmount = roundedAmount
        End If
        
        ' Add to schedule if meaningful amount
        If allocAmount > 0 Then
            schedule.Add Array(currentDate, allocAmount)
            remainingAmount = remainingAmount - allocAmount
        End If
        
        ' Move to next day
        currentDate = currentDate + 1
        
ContinueLoop:
    Loop
    
    ' Handle any remaining amount
    If (remainingAmount > 0.01 Or accumulatedRemainder > 0.01) And schedule.count > 0 Then
        ' Add to the last cheque
        Dim lastEntry As Variant
        lastEntry = schedule.item(schedule.count)
        schedule.Remove schedule.count
        schedule.Add Array(lastEntry(0), lastEntry(1) + remainingAmount + accumulatedRemainder)
    ElseIf remainingAmount > 0.01 Or accumulatedRemainder > 0.01 Then
        ' Create new entry on target date if schedule is empty
        schedule.Add Array(targetDate, remainingAmount + accumulatedRemainder)
    End If
End Sub


 '----------------------------------------
  ' CommandButton8 - Merge selected cheques in ListBox2
  '----------------------------------------
  Private Sub CommandButton8_Click()
      On Error GoTo ErrorHandler

      Dim selectedIndexes As Collection
      Dim sourceDates As Object
  Dim selectedCount As Long
  Dim i As Long
  Dim idx As Variant
  Dim mergedDate As String
  Dim mergedAmount As Double
  Dim targetFillAmount As Double
  Dim mergeID As String
  Dim oldMergeID As String
  Dim dateKey As Variant
  Dim normalReserveRemaining As Double

      If Me.ListBox2.ListCount = 0 Then
          MsgBox "�� ��� ���� ����� ���� �����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      Set selectedIndexes = New Collection
      Set sourceDates = CreateObject("Scripting.Dictionary")

      For i = 0 To Me.ListBox2.ListCount - 1
          If Me.ListBox2.Selected(i) Then
              selectedIndexes.Add i
              selectedCount = selectedCount + 1
          End If
      Next i

      If selectedCount < 2 Then
          MsgBox "����� ����� �� �� �� ���� ����� ������ ����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      mergedDate = InputBox( _
          "����� �� ����� �������� �� ���� ����." & vbCrLf & _
          "����: 1404/03/15", _
          "����� �� ��������", _
          Me.ListBox2.List(selectedIndexes(selectedIndexes.count), 2))

      If Trim(mergedDate) = "" Then Exit Sub

      mergedDate = ConvertPersianNumsToEnglishKeepSlash(Trim(mergedDate))
      If Not IsValidPersianDate(mergedDate) Then
          MsgBox "����� ������� ����� ����." & vbCrLf & "���� ����: 1404/03/15", _
                 vbExclamation, "����� �����"
          Exit Sub
      End If

      Dim md() As String
      md = Split(mergedDate, "/")
      mergedDate = CLng(md(0)) & "/" & Format(CLng(md(1)), "00") & "/" & Format(CLng(md(2)), "00")

      If Not GetMergeTargetFillAmount(targetFillAmount) Then Exit Sub

      mergeID = CreateMergeID()

      ' First pass:
      ' 1) total selected amount
      ' 2) carry old merge reservations into the new merge ID
      ' 3) collect source dates of normal cheques (rows without merge ID)
For Each idx In selectedIndexes
      Dim rowAmount As Double
      rowAmount = CDbl(EvaluateExpression(Me.ListBox2.List(CLng(idx), 1)))

      mergedAmount = mergedAmount + rowAmount

      oldMergeID = Trim(CStr(Me.ListBox2.List(CLng(idx), 3)))

      If oldMergeID <> "" Then
          ' Existing merged rows already have their own pending W reservations.
          ' Move those reservations to the new merge ID.
          Call ReassignPendingMergeReservations(oldMergeID, mergeID)
      Else
          ' Ordinary cheques need new W reservations, but only up to their actual amount.
          normalReserveRemaining = normalReserveRemaining + rowAmount

          If Not sourceDates.exists(CStr(Me.ListBox2.List(CLng(idx), 2))) Then
              sourceDates.Add CStr(Me.ListBox2.List(CLng(idx), 2)), True
          End If
      End If
  Next idx

      ' Add new reservations for source dates that were ordinary cheques
      Dim numChequesConf As Long: numChequesConf = ReadConfigValue("cfg_NumCheques")
      Dim firstChequeCol As Long: firstChequeCol = 14
      Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numChequesConf * 2) - 2
      Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
      Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
      Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
      Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
      Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    Dim sortedDates As Variant
  Dim mergedGDate As Date
  Dim allocAmount As Double

  mergedGDate = PersianToGregorian(mergedDate)
  sortedDates = GetSortedPersianDateKeys(sourceDates)

  ' Fill only previous/source days up to capacity, and never exceed the selected ordinary cheque total.
  If normalReserveRemaining > 0 Then
      For i = LBound(sortedDates) To UBound(sortedDates)
          Dim sourceDate As Date
          Dim currentUsed As Double
          Dim reserveNeeded As Double

          dateKey = CStr(sortedDates(i))
          sourceDate = PersianToGregorian(CStr(dateKey))
          ' Allocate across every selected source date, including dates after
          ' the merged-cheque date.  The old sourceDate < mergedGDate test
          ' incorrectly stopped allocation at the merged date.
          currentUsed = GetEffectiveDayUsedAmount(sourceDate, firstChequeCol, lastChequeCol, _
                                                  totalRowsPerDayBlock, lowerHalfStartOffset)
          reserveNeeded = Application.Max(targetFillAmount - currentUsed, 0)
          If reserveNeeded > 0 Then
              allocAmount = Application.Min(reserveNeeded, normalReserveRemaining)
              Call AddPendingMergeReservation(mergeID, CStr(dateKey), allocAmount)
              normalReserveRemaining = normalReserveRemaining - allocAmount
          End If

          If normalReserveRemaining <= 0 Then Exit For
      Next i
  End If
  ' Put the exact remaining amount on the merged cheque date in W.
  ' This prevents filling the cheque day to full capacity and keeps W total equal to the cheque amount.
  If normalReserveRemaining > 0 Then
      Call AddPendingMergeReservation(mergeID, mergedDate, normalReserveRemaining)
      normalReserveRemaining = 0
  End If
      ' Remove selected rows from bottom to top
      For i = Me.ListBox2.ListCount - 1 To 0 Step -1
          If Me.ListBox2.Selected(i) Then
              Me.ListBox2.RemoveItem i
          End If
      Next i

      ' Add merged row
  Dim mergedRowID As String
  mergedRowID = CreateListBox2RowID()

  Me.ListBox2.AddItem
  i = Me.ListBox2.ListCount - 1
  Me.ListBox2.List(i, 0) = i + 1
  Me.ListBox2.List(i, 1) = Format(mergedAmount, "#,##0")
  Me.ListBox2.List(i, 2) = mergedDate
  Me.ListBox2.List(i, 3) = mergeID
  Me.ListBox2.List(i, 4) = mergedRowID

      Call SortListBox2ByDate

      ' Select only the merged cheque after sorting
  Call SelectOnlyListBox2Row(FindListBox2RowByRowID(mergedRowID))

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption
      Call ShowSurroundingDaysCapacity(mergedDate)

      MsgBox "����� �� ������ ����� ����." & vbCrLf & vbCrLf & _
             "���� �� ����: " & Format(mergedAmount, "#,##0") & vbCrLf & _
             "����� �� ����: " & mergedDate, _
             vbInformation, "����� �����"
      Exit Sub

ErrorHandler:
      MsgBox "��� �� ����� �����: " & Err.description, vbCritical, "����� �����"
  End Sub
 '----------------------------------------
  ' CommandButton9 - Toggle select/deselect all in ListBox2
  '----------------------------------------
  Private Sub CommandButton9_Click()
      Dim i As Long
      Dim allSelected As Boolean

      If Me.ListBox2.ListCount = 0 Then
          MsgBox "�� ��� �� ���� ���� �����.", vbExclamation, "������ �����"
          Exit Sub
      End If

      allSelected = True
      For i = 0 To Me.ListBox2.ListCount - 1
          If Not Me.ListBox2.Selected(i) Then
              allSelected = False
              Exit For
          End If
      Next i

      If allSelected Then
          For i = 0 To Me.ListBox2.ListCount - 1
              Me.ListBox2.Selected(i) = False
          Next i
          Me.CommandButton9.Caption = "������ ���"
      Else
          For i = 0 To Me.ListBox2.ListCount - 1
              Me.ListBox2.Selected(i) = True
          Next i
          Me.CommandButton9.Caption = "��� ������ ���"
      End If
  End Sub
'----------------------------------------
  ' Refresh CommandButton9 caption based on ListBox2 selection state
  '----------------------------------------
  Private Sub UpdateListBox2SelectToggleCaption()
      Dim i As Long
      Dim allSelected As Boolean

      If Me.ListBox2.ListCount = 0 Then
          Me.CommandButton9.Caption = "������ ���"
          Exit Sub
      End If

      allSelected = True
      For i = 0 To Me.ListBox2.ListCount - 1
          If Not Me.ListBox2.Selected(i) Then
              allSelected = False
              Exit For
          End If
      Next i

      If allSelected Then
          Me.CommandButton9.Caption = "��� ������ ���"
      Else
          Me.CommandButton9.Caption = "������ ���"
      End If
  End Sub
Private Sub CommandButton10_Click()
      Dim frm As frmManualChequeDatePicker

      If Trim(Me.TextBox6.value) = "" Then
          MsgBox "����� ����� TextBox6 ���� ���� ����.", vbExclamation, "������ ���� ��"
          Exit Sub
      End If

      Set frm = New frmManualChequeDatePicker
      frm.InitializePicker Me.TextBox6.value
      frm.Show vbModal

      If frm.WasCancelled Then
          Unload frm
          Exit Sub
      End If

      If frm.selectedDates Is Nothing Or frm.selectedDates.count = 0 Then
          Unload frm
          Exit Sub
      End If

      Call BuildManualChequeListFromSelectedDates(frm.selectedDates)

      Unload frm
  End Sub
'----------------------------------------
' TextBox5 Enter - Show surrounding days for average date
'----------------------------------------
Private Sub TextBox5_Enter()
    If Trim(Me.TextBox5.value) <> "" Then
        Call ShowSurroundingDaysCapacity(Me.TextBox5.value)
    End If
End Sub

'----------------------------------------
' TextBox6 Enter - Show surrounding days for adjusted average date
'----------------------------------------
Private Sub TextBox6_Enter()
    If Trim(Me.TextBox6.value) <> "" Then
        Call ShowSurroundingDaysCapacity(Me.TextBox6.value)
    End If
End Sub





'====================================================================================================
'                                    USERFORM EVENT HANDLERS
'====================================================================================================

'----------------------------------------
' Form Initialize
'----------------------------------------
Private Sub UserForm_Initialize()
    Dim wsInfo As Worksheet
    Dim i As Long
    
    On Error Resume Next
    Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
    On Error GoTo 0
    
    If wsInfo Is Nothing Then
        MsgBox "���: ��� '" & CONFIG_SHEET_NAME & "' ���� ���.", vbCritical
        Exit Sub
    End If

    Call PopulateCompanyComboBox
    Call ClearPendingMergeReservations
    ' Populate ComboBox2 (Years)
    On Error Resume Next
    Me.ComboBox2.RowSource = "cfg_YearList"
    If Err.Number <> 0 Then MsgBox "���: ������ 'cfg_YearList' ���� ���.", vbCritical
    On Error GoTo 0
    
    ' Populate ComboBox3 (Months)
    Me.ComboBox3.Clear
    For i = 1 To 12
        Me.ComboBox3.AddItem CStr(i)
    Next i
    
           
    Dim maxCap As Double
    maxCap = CDbl(Range("cfg_maxcap").value)
    
    ' Initialize UI controls
    With Me
        .ListBox1.ColumnCount = 4
        .ListBox1.ColumnWidths = "100;100;80;100"
        .ListBox2.ColumnCount = 5
        .ListBox2.ColumnWidths = "30;80;80;0;0"
        .TextBox1.value = "1"
        .TextBox2.value = "30"
        .TextBox4.value = "0"
        .TextBox7.value = "0"
        .TextBox8.value = "0"
        .SpinButton1.Min = -365
        .SpinButton1.Max = 365
        .SpinButton1.value = 0
        .SpinButton2.Min = 1
        .SpinButton2.Max = 365
        .SpinButton2.value = 30
        .SpinButton3.Min = 1
        .SpinButton3.Max = 100
        .SpinButton3.value = 1
        .SpinButton4.Min = 0
        .SpinButton4.Max = 1000
        .SpinButton4.value = maxCap
        .ListBox1.ControlTipText = " ��� ����� ������ �ǘ��ѡ ��� �� ���� ��� ����. "
        .ListBox2.ControlTipText = "��� = ������ ������ ��� � ��� *** ���� ��� = ������ *** + � - = ����� ����� � ���"
        .TextBox5.ControlTipText = " ��� ������ ������ ��� � ��� ��� ����. "
        .TextBox6.ControlTipText = " ��� ������ ������ ��� � ��� ��� ����. "

    End With
    
    ' Set default year from config
    On Error Resume Next
    Dim defaultYear As String
    defaultYear = CStr(wsInfo.Range("cfg_DefaultYear").value)
    If defaultYear <> "" Then
        Me.ComboBox2.value = defaultYear
    ElseIf Me.ComboBox2.ListCount > 0 Then
        Me.ComboBox2.listIndex = 0
    End If
    On Error GoTo 0
    
    ' Set default month from config
    On Error Resume Next
    Dim defaultMonth As Long
    defaultMonth = CLng(wsInfo.Range("cfg_DefaultMonth").value)
    If defaultMonth >= 1 And defaultMonth <= 12 Then
        Me.ComboBox3.listIndex = defaultMonth - 1  ' 0-based index
    ElseIf Me.ComboBox3.ListCount > 0 Then
        Me.ComboBox3.listIndex = 0
    End If
    On Error GoTo 0
    
    ' Set default day (today) from config
    On Error Resume Next
    Dim defaultDay As Long
    defaultDay = CLng(wsInfo.Range("cfg_DefaultDay").value)
    If defaultDay >= 1 And defaultDay <= 31 Then
        Me.Label28.Caption = CStr(defaultDay)
    Else
        Me.Label28.Caption = "1"  ' Fallback
    End If
    On Error GoTo 0
    
    ' Set initial state for ToggleButton1 and TextBox3
    Me.ToggleButton1.value = False
    Call ToggleButton1_Click
    Call UpdateFactorTotals
    Call UpdateListBox2SelectToggleCaption
      
  m_NextListBox2RowID = 0
  Me.ToggleButton4.value = True
  Call ToggleButton4_Click
  
  
  
  
  
        
        On Error Resume Next
    Dim savedRound As Variant
    savedRound = wsInfo.Range("cfg_Rounding").value
    If savedRound = 1 Then
        Me.ToggleButton2.value = True
        Else
Me.ToggleButton2.value = False
    End If
        
        
        
        
        
        
    ' Load saved CheckBox1 state
    On Error Resume Next
    Dim savedOption As Variant
    savedOption = wsInfo.Range("cfg_SkipSerial").value
    If IsNumeric(savedOption) Then
        Me.CheckBox1.value = CBool(savedOption)
        m_skipSerialEntry = CBool(savedOption)
    Else
        Me.CheckBox1.value = False
        m_skipSerialEntry = False
    End If
    On Error GoTo 0
    Call UpdateChequeModeUI
End Sub
Private Sub ComboBox1_Enter()
    SetKeyboardPersian
End Sub
Private Sub TextBox1_Enter()
    SetKeyboardEnglish
End Sub
Private Sub TextBox2_Enter()
    SetKeyboardEnglish
End Sub
Private Sub textbox3_Enter()
    SetKeyboardEnglish
End Sub
Private Sub TextBox4_Enter()
    SetKeyboardEnglish
End Sub
Private Sub textbox8_Enter()
    SetKeyboardEnglish
End Sub

'----------------------------------------
' Populate ComboBox1 with company names
' Skip empty cells, sort alphabetically, handle *** separator
'----------------------------------------
Private Sub PopulateCompanyComboBox()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim i As Long, j As Long
    Dim tempVal As String
    Dim foundSeparator As Boolean
    
    ' Arrays for companies and others
    Dim companyArr() As String
    Dim otherArr() As String
    Dim companyCount As Long
    Dim otherCount As Long
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        MsgBox "���: ��� ������� ���� ���.", vbCritical
        Exit Sub
    End If
    
    Me.ComboBox1.Clear
    
    ' Find last row
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).Row
    If lastRow < 2 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' First pass: count items
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
            Else
                otherCount = otherCount + 1
            End If
        End If
    Next cell
    
    ' Initialize arrays
    If companyCount > 0 Then ReDim companyArr(1 To companyCount)
    If otherCount > 0 Then ReDim otherArr(1 To otherCount)
    
    ' Second pass: fill arrays
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
                companyArr(companyCount) = GetCompanyName(cell.value)
            Else
                otherCount = otherCount + 1
                otherArr(otherCount) = GetCompanyName(cell.value)
            End If
        End If
    Next cell
    
    ' Sort company array (Bubble Sort)
    If companyCount > 1 Then
        For i = 1 To companyCount - 1
            For j = i + 1 To companyCount
                If StrComp(companyArr(i), companyArr(j), vbTextCompare) > 0 Then
                    tempVal = companyArr(i)
                    companyArr(i) = companyArr(j)
                    companyArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Sort other array (Bubble Sort)
    If otherCount > 1 Then
        For i = 1 To otherCount - 1
            For j = i + 1 To otherCount
                If StrComp(otherArr(i), otherArr(j), vbTextCompare) > 0 Then
                    tempVal = otherArr(i)
                    otherArr(i) = otherArr(j)
                    otherArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Add companies to ComboBox
    For i = 1 To companyCount
        Me.ComboBox1.AddItem companyArr(i)
    Next i
    
    ' Add separator and others if exists
    If otherCount > 0 Then
        Me.ComboBox1.AddItem "-------------"
        For i = 1 To otherCount
            Me.ComboBox1.AddItem otherArr(i)
        Next i
    End If
    
    If Me.ComboBox1.ListCount = 0 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical
    End If
End Sub

'----------------------------------------
' ComboBox1 Change - Company Selection
'----------------------------------------
Private Sub ComboBox1_Change()
    ' Prevent selecting the separator line
    If Me.ComboBox1.value = "-------------" Then
        Me.ComboBox1.value = ""
        Me.ComboBox1.DropDown  ' Re-open dropdown
        Exit Sub
    End If
    
    If Me.ComboBox1.value <> "" Then
        Me.Label37.Caption = GetNationalID(Me.ComboBox1.value)
        
        Call CommandButton1_Click  ' Search for unpaid factors
        Call CommandButton7_Click  ' Select all results
        
          Call ClearPendingMergeReservations
        m_NextListBox2RowID = 0
        Me.ListBox2.Clear
        Call UpdateChequeAverageDate
        
        If Me.ListBox1.ListCount > 0 Then
            Call CommandButton2_Click
        End If
    Else
        Me.Label37.Caption = ""
        Me.ListBox1.Clear
          Call ClearPendingMergeReservations
        Me.ListBox2.Clear
        Call UpdateFactorTotals
        Call UpdateChequeAverageDate
          Call UpdateListBox2SelectToggleCaption
    End If
End Sub

'----------------------------------------
' TextBox7 Change - Manual rounding adjustment
'----------------------------------------
Private Sub TextBox7_Change()
    If m_isUpdating Then Exit Sub
    
    If ToggleButton2.value Then
        ToggleButton2.value = False
    End If
End Sub

'----------------------------------------
' TextBox8 Change - Manual adjustment
'----------------------------------------
Private Sub TextBox8_Change()
    If m_isUpdating Then Exit Sub
    Call UpdateFactorTotals
End Sub

'====================================================================================================
'                                    BUTTON EVENT HANDLERS
'====================================================================================================

'----------------------------------------
' CommandButton1 - Show Unpaid Factors
'----------------------------------------
Private Sub CommandButton1_Click()
    Dim ws As Worksheet, c As Long
    Dim compName As String
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim status As String, amount As Double, days As Integer
    
    Me.ListBox1.Clear
    Call UpdateFactorTotals
    
    compName = Me.ComboBox1.value
    If compName = "" Then
        MsgBox "����� � �ј� ������ ����.", vbExclamation
        Exit Sub
    End If

    ' Read Dynamic Configuration
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")

    ' Calculate Dynamic Layout
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    Application.ScreenUpdating = False
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name <> CONFIG_SHEET_NAME And ws.Name <> "�������" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = 0
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0

            If yearNum >= startYear And yearNum <= endYear Then
                Dim dayStartRow As Long
                For dayNum = 1 To 31
                    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                    If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For

                    For c = firstFactorCol To lastFactorCol Step 2
                        If ws.Cells(dayStartRow, c).value = compName Then
                            status = Trim(ws.Cells(dayStartRow, c + 1).value)
                            If status = "" Then ' Unpaid
                                amount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, c).value)
                                days = val(ws.Cells(dayStartRow + lowerHalfStartOffset, c + 1).value)
                                
                                Dim factorDate As Date: factorDate = PersianToGregorianDate(yearNum, monthNum, dayNum)
                                Dim chequeDate As Date: chequeDate = factorDate + days
                                
                                With Me.ListBox1
                                    .AddItem GregorianToPersian(factorDate)
                                    .List(.ListCount - 1, 1) = Format(amount, "#,##0")
                                    .List(.ListCount - 1, 2) = days
                                    .List(.ListCount - 1, 3) = GregorianToPersian(chequeDate)
                                End With
                            End If
                        End If
                    Next c
                Next dayNum
            End If
        End If
    Next ws
    Application.ScreenUpdating = True
End Sub

'----------------------------------------
' CommandButton2 - Calculate Cheque Schedule
'----------------------------------------
Private Sub CommandButton2_Click()
    ' Validation
    If Not IsNumeric(TextBox1.value) Or Not IsNumeric(TextBox2.value) Then
        MsgBox "����� � ����� ����� ���� ���� �����.", vbExclamation
        Exit Sub
    End If
    
    Dim numChqs As Long: numChqs = CLng(TextBox1.value)
    Dim interval As Long: interval = CLng(TextBox2.value)
    
    If numChqs <= 0 Or interval < 0 Then
        MsgBox "����� ������� ���� ��� ���.", vbExclamation
        Exit Sub
    End If
    
    If ListBox1.ListCount = 0 Then
        MsgBox "����� �ǘ����� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    Dim selectedFactorCount As Long
    Dim i As Long
    For i = 0 To ListBox1.ListCount - 1
        If ListBox1.Selected(i) Then selectedFactorCount = selectedFactorCount + 1
    Next i
    
    If selectedFactorCount = 0 Then
        MsgBox "�� �ǘ���� ���� ������ ������ ���� ���.", vbExclamation
        Exit Sub
    End If
    
    Call UpdateFactorTotals
      Call ClearPendingMergeReservations
        m_NextListBox2RowID = 0
      
    ' Read Dynamic Layout
    Dim numChequesConf As Long: numChequesConf = ReadConfigValue("cfg_NumCheques")
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numChequesConf * 2) - 2
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ' Capacity Check
  Dim capacityTotal As Double
  If ToggleButton1.value Then
      Dim capacityResult As Variant
      capacityResult = EvaluateExpression(Me.TextBox3.value)

      If Not IsNumeric(capacityResult) Or CDbl(capacityResult) <= 0 Then
          MsgBox "����� ������ (TextBox3) ����� ����.", vbExclamation
          Exit Sub
      End If

      capacityTotal = CDbl(capacityResult)
  End If
    
    ' Weighted Average Calculation
    Dim totalAmt As Double, wSum As Double
    Dim factorAmt As Double, factorDate As Date
    
    For i = 0 To ListBox1.ListCount - 1
        If ListBox1.Selected(i) Then
            factorAmt = EvaluateExpression(ListBox1.List(i, 1))
            Dim pDateParts() As String: pDateParts = Split(ListBox1.List(i, 3), "/")
            factorDate = PersianToGregorianDate(CLng(pDateParts(0)), CLng(pDateParts(1)), CLng(pDateParts(2)))
            totalAmt = totalAmt + factorAmt
            wSum = wSum + (factorAmt * CDbl(factorDate))
        End If
    Next i
    
    ' Apply adjustments
    Dim manualAdjustment As Double: manualAdjustment = EvaluateExpression(Me.TextBox8.value)
    Dim roundingAdjustment As Double: roundingAdjustment = EvaluateExpression(Me.TextBox7.value)
    Dim totalAdjustment As Double: totalAdjustment = roundingAdjustment - manualAdjustment

    ' Calculate average using ORIGINAL total
    Dim avgTarget As Date: avgTarget = CDate(wSum / totalAmt)

    ' Apply adjustments for cheque distribution
    totalAmt = totalAmt + totalAdjustment
    If totalAmt <= 0 Then
        MsgBox "���� ����� �� �� ��� ������� ��� �� ���� ���.", vbExclamation
        Exit Sub
    End If
    
    Dim adjAvgDate As Date: adjAvgDate = avgTarget + CLng(TextBox4.value)
    Me.TextBox5.value = GregorianToPersian(avgTarget)
    Me.TextBox6.value = GregorianToPersian(adjAvgDate)

    ' Build Cheque Schedule
    Dim schedule As New Collection
    Dim currentChequeDate As Date

    If numChqs = 1 Then
        If Not ToggleButton1.value Then
            currentChequeDate = FirstEmptyDay(adjAvgDate, firstChequeCol, lastChequeCol, totalRowsPerDayBlock)
            schedule.Add Array(currentChequeDate, totalAmt)
        Else
            Call SpreadChequeWithCapacity(adjAvgDate, totalAmt, schedule, _
                                          firstChequeCol, lastChequeCol, totalRowsPerDayBlock, _
                                          lowerHalfStartOffset, capacityTotal)
        End If
        
 Else
          If Me.ToggleButton4.value = False Then
              '==============================
              ' Method 1: original sequential method
              '==============================
              Dim method1IdealFirstChequeDate As Date
              Dim method1RemainingTotal As Double
              Dim method1PieceAmt As Double
              Dim method1IdealNextDate As Date

              method1IdealFirstChequeDate = adjAvgDate - ((interval * (numChqs - 1)) / 2)
              method1RemainingTotal = totalAmt

              For i = 1 To numChqs
                  If i < numChqs Then
                      method1PieceAmt = Application.WorksheetFunction.RoundDown(totalAmt / numChqs, -5)
                  Else
                      method1PieceAmt = method1RemainingTotal
                  End If

                  If i = 1 Then
                      method1IdealNextDate = method1IdealFirstChequeDate
                  Else
                      method1IdealNextDate = currentChequeDate + interval
                  End If

                  If Not ToggleButton1.value Then
                      currentChequeDate = FirstEmptyDay(method1IdealNextDate, firstChequeCol, lastChequeCol, totalRowsPerDayBlock)
                      schedule.Add Array(currentChequeDate, method1PieceAmt)
                  Else
                      Call SpreadChequeWithCapacity(method1IdealNextDate, method1PieceAmt, schedule, _
                                                    firstChequeCol, lastChequeCol, totalRowsPerDayBlock, _
                                                    lowerHalfStartOffset, capacityTotal)

                      If schedule.count > 0 Then
                          currentChequeDate = CDate(schedule.item(schedule.count)(0))
                      End If
                  End If

                  method1RemainingTotal = method1RemainingTotal - method1PieceAmt
              Next i

          Else
              '==============================
              ' Method 2: mirrored around adjusted average date
              '==============================
              Dim chequeAmounts() As Double
              Dim chequeDates() As Date
              Dim hasChequeDate() As Boolean
              Dim method2RemainingTotal As Double
              Dim pairLeft As Long
              Dim pairRight As Long
              Dim centerIndex As Long
              Dim idealOffset As Double
              Dim idealLeftDate As Date
              Dim actualLeftDate As Date
              Dim mirroredRightTarget As Date
              Dim actualDistanceFromCenter As Double
              Dim generatedDateKeys As Object

              ReDim chequeAmounts(1 To numChqs)
              ReDim chequeDates(1 To numChqs)
              ReDim hasChequeDate(1 To numChqs)
              Set generatedDateKeys = CreateObject("Scripting.Dictionary")

              method2RemainingTotal = totalAmt

              For i = 1 To numChqs
                  If i < numChqs Then
                      chequeAmounts(i) = Application.WorksheetFunction.RoundDown(totalAmt / numChqs, -5)
                  Else
                      chequeAmounts(i) = method2RemainingTotal
                  End If

                  method2RemainingTotal = method2RemainingTotal - chequeAmounts(i)
              Next i

              If Not ToggleButton1.value Then
                  For pairLeft = 1 To numChqs \ 2
                      pairRight = numChqs + 1 - pairLeft

                      idealOffset = interval * (((numChqs + 1) / 2) - pairLeft)
                      idealLeftDate = adjAvgDate - idealOffset

                      actualLeftDate = FirstEmptyDayExcludingGenerated(idealLeftDate, firstChequeCol, lastChequeCol, _
                                                                       totalRowsPerDayBlock, generatedDateKeys)
                      chequeDates(pairLeft) = actualLeftDate
                      hasChequeDate(pairLeft) = True
                      generatedDateKeys.Add ScheduleDateKey(actualLeftDate), True

                      actualDistanceFromCenter = CDbl(adjAvgDate) - CDbl(actualLeftDate)
                      mirroredRightTarget = adjAvgDate + actualDistanceFromCenter

                      chequeDates(pairRight) = FirstEmptyDayExcludingGenerated(mirroredRightTarget, firstChequeCol, lastChequeCol, _
                                                                               totalRowsPerDayBlock, generatedDateKeys)
                      hasChequeDate(pairRight) = True
                      generatedDateKeys.Add ScheduleDateKey(chequeDates(pairRight)), True
                  Next pairLeft

                  If numChqs Mod 2 = 1 Then
                      centerIndex = (numChqs + 1) \ 2

chequeDates(centerIndex) = FirstEmptyDayExcludingGenerated(adjAvgDate, firstChequeCol, lastChequeCol, _
                                                             totalRowsPerDayBlock, generatedDateKeys)
                                                             hasChequeDate(centerIndex) = True
                      generatedDateKeys.Add ScheduleDateKey(chequeDates(centerIndex)), True
                  End If

                  For i = 1 To numChqs
                      If hasChequeDate(i) Then
                          schedule.Add Array(chequeDates(i), chequeAmounts(i))
                      End If
                  Next i

              Else
                  Dim method2IdealFirstChequeDate As Date
                  Dim method2IdealNextDate As Date
                  method2IdealFirstChequeDate = adjAvgDate - ((interval * (numChqs - 1)) / 2)

                  For i = 1 To numChqs
                      If i = 1 Then
                          method2IdealNextDate = method2IdealFirstChequeDate
                      Else
                          method2IdealNextDate = currentChequeDate + interval
                      End If

                      Call SpreadChequeWithCapacity(method2IdealNextDate, chequeAmounts(i), schedule, _
                                                    firstChequeCol, lastChequeCol, totalRowsPerDayBlock, _
                                                    lowerHalfStartOffset, capacityTotal)

                      If schedule.count > 0 Then
                          currentChequeDate = CDate(schedule.item(schedule.count)(0))
                      End If
                  Next i
              End If
          End If
      End If










' Display Schedule
  Call DisplayScheduleInListBox(schedule)
  Call UpdateChequeAverageDate
      Call SortListBox2ByDate
      
    ' Select all cheques by default
    Dim k As Long
    For k = 0 To Me.ListBox2.ListCount - 1
        Me.ListBox2.Selected(k) = True
    Next k
    
    Call UpdateChequeAverageDate
    
    ' SMART MODE: Check if optimization is needed
    Call UpdateChequeAverageDate
    
    ' SMART MODE: Check if optimization is needed (skip if already optimizing)
    If Me.ToggleButton1.value = True And Me.ToggleButton3.value = True And Not m_IsOptimizing Then
        ' Compare actual cheques created vs requested cheques
        Dim requestedCheques As Long
        requestedCheques = CLng(Me.TextBox1.value)
        
        If Me.ListBox2.ListCount > requestedCheques Then
            Dim optimizeChoice As VbMsgBoxResult
            optimizeChoice = MsgBox("����� �� ����� ��� (" & Me.ListBox2.ListCount & ") ����� �� ������� (" & requestedCheques & ") ���." & vbCrLf & vbCrLf & _
                             "��� �������� ���� ������ ������� ����� ���� ��Ͽ", _
                             vbYesNo + vbQuestion, "���� ������")
            
  If optimizeChoice = vbYes Then
      If FindOptimalConfiguration Then Exit Sub
  End If
        End If
    End If



'    ' Display Schedule
'  Call DisplayScheduleInListBox(schedule)
'  Call UpdateChequeAverageDate
'
'    ' Select all cheques by default
'    Dim y As Long
'    For y = 0 To Me.ListBox2.ListCount - 1
'        Me.ListBox2.Selected(y) = True
'    Next y
'
'    Call UpdateChequeAverageDate
End Sub

'----------------------------------------
' CommandButton3 - Mark Selected Factors as Paid
'----------------------------------------
Private Sub CommandButton3_Click()
    Dim i As Long, c As Long, marked As Boolean
    Dim compName As String, statusVal As String, ftDateStr As String
    Dim ws As Worksheet, yearNum As Long, monthNum As Long, dayNum As Long
    Dim markedCount As Long

    compName = Trim(Me.ComboBox1.value)
    
    On Error Resume Next
    statusVal = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("D1").value)
    On Error GoTo 0
    
    If compName = "" Then
        MsgBox "����� �ј� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    If statusVal = "" Then
        MsgBox "���� D1 �� ��� ������� ����� �����.", vbExclamation
        Exit Sub
    End If

    ' Read Dynamic Config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1

    markedCount = 0
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            ftDateStr = Me.ListBox1.List(i, 0)
            yearNum = CLng(Split(ftDateStr, "/")(0))
            monthNum = CLng(Split(ftDateStr, "/")(1))
            dayNum = CLng(Split(ftDateStr, "/")(2))

            Set ws = FindSheet(yearNum & "/" & Format(monthNum, "00"))
            If ws Is Nothing Then GoTo NextFactor

            Dim dayStartRow As Long: dayStartRow = FindDayRow(ws, dayNum, totalRowsPerDayBlock)
            If dayStartRow = 0 Then GoTo NextFactor

            marked = False
            For c = firstFactorCol To lastFactorCol Step 2
                If Trim(ws.Cells(dayStartRow, c).value) = compName And Trim(ws.Cells(dayStartRow, c + 1).value) = "" Then
                    ws.Cells(dayStartRow, c + 1).value = statusVal
                    marked = True
                    markedCount = markedCount + 1
                    
                    Call WriteLog("frmChequeManagement", "����ʐ���� �����ʝ���", compName, _
                                 CStr(yearNum), CStr(monthNum), CStr(dayNum), _
                                 Me.ListBox1.List(i, 1), "", "�����: " & statusVal)
                    Exit For
                End If
            Next c
        End If
NextFactor:
    Next i
    
    Call WriteLog("frmChequeManagement", "����� ����ʐ����", compName, "", "", "", "", "", _
                  "����� ����ʝ������: " & markedCount)
    
    MsgBox "������ ��������� ����� ����� ����.", vbInformation
    Call CommandButton1_Click
End Sub

'----------------------------------------
' CommandButton4 - Write Cheques to Sheet
'----------------------------------------
Private Sub CommandButton4_Click()
    If Me.CheckBox2.value Then
        Call ImportLatestElectronicCheques
        Exit Sub
    End If
    Dim i As Long, c As Long, writtenCount As Long
    Dim chequeDateStr As String, amount As Variant
    Dim compName As String, ym As String, dayNum As Long
    Dim ws As Worksheet, dayStartRow As Long
    Dim serialNumber As String
    Dim pureDigits As String
      Dim mergeID As String
    compName = ComboBox1.value
    If compName = "" Then
        MsgBox "����� �ј� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    If ListBox2.ListCount = 0 Then
        MsgBox "�� ��� �� ���� ����� ����.", vbExclamation
        Exit Sub
    End If

    ' Read Dynamic Config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    For i = 0 To ListBox2.ListCount - 1
        chequeDateStr = ListBox2.List(i, 2)
        amount = EvaluateExpression(ListBox2.List(i, 1))
          mergeID = Trim(CStr(ListBox2.List(i, 3)))
        ym = Left(chequeDateStr, 7)
        dayNum = CLng(Mid(chequeDateStr, 9))

        ' Serial Number Logic
        If Me.CheckBox1.value Then
            pureDigits = "000000000000"
        Else
            If i = 0 Then
                On Error Resume Next
                lastSerial_First4 = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AC3").value)
                lastSerial_Middle6 = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AD3").value)
                On Error GoTo 0
                
                If lastSerial_First4 = "" Then lastSerial_First4 = ""
                If lastSerial_Middle6 = "" Then lastSerial_Middle6 = ""
            End If
            
            With frmSerialInput
                .Initialize lastSerial_First4, lastSerial_Middle6
                
                .Label1.Caption = "�� " & (i + 1) & " �� " & ListBox2.ListCount & vbCrLf & _
                                  "����: " & Format(amount, "#,##0") & vbCrLf & _
                                  "�����: " & chequeDateStr
                .Show
                
                If .WasCancelled Then
                    Dim response As VbMsgBoxResult
                    response = MsgBox("����� ����� ���� ���� ���. ������ ����:" & vbCrLf & vbCrLf & _
                                      "YES = ��� �� �� ���� ���" & vbCrLf & _
                                      "NO = ��ѡ ������ �� ��� ��" & vbCrLf & _
                                      "CANCEL = ��Ґ�� ���� ���� ���� ����", _
                                      vbYesNoCancel + vbQuestion, "����� �����")
                    Select Case response
                        Case vbYes
                            GoTo NextCheque
                        Case vbNo
                            Call WriteLog("frmChequeManagement", "������ ��� ��", compName, "", "", "", "", "", _
                                          "��� ��. ����� ���: " & writtenCount)
                            MsgBox "������ ��� ��. ����� ����� ���: " & writtenCount, vbInformation
                            Exit Sub
                        Case vbCancel
                            i = i - 1
                            GoTo NextCheque
                    End Select
                End If
                
                serialNumber = .serialNumber
                
                lastSerial_First4 = Left(serialNumber, 4)
                lastSerial_Middle6 = Mid(serialNumber, 5, 6)
                
                On Error Resume Next
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AC3").value = lastSerial_First4
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AD3").value = lastSerial_Middle6
                On Error GoTo 0
            End With
            
            pureDigits = serialNumber
            
            If Trim(pureDigits) = "" Then
                MsgBox "����� ����� ���� ���!", vbExclamation
                i = i - 1
                GoTo NextCheque
            End If
            
            If Len(pureDigits) <= 12 Then
                pureDigits = Right("000000000000" & pureDigits, 12)
            Else
                pureDigits = Right(pureDigits, 12)
            End If
        End If

      ' Write to Excel Sheet
        ' --- ��� ����: ����� ʘ���� ���� �� ---
        Set ws = FindSheet(ym)
        If Not ws Is Nothing Then
            dayStartRow = FindDayRow(ws, dayNum, totalRowsPerDayBlock)
            If dayStartRow > 0 Then
                Dim isDuplicate As Boolean: isDuplicate = False
                Dim dupCol As Long
                
                ' ����� ������� �� �� �� ��� ���
                For dupCol = firstChequeCol To lastChequeCol Step 2
                    Dim existingComp As String: existingComp = ws.Cells(dayStartRow, dupCol).value
                    Dim existingAmount As Double: existingAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, dupCol).value)
                    Dim existingSerial As String: existingSerial = CStr(ws.Cells(dayStartRow + lowerHalfStartOffset, dupCol + 1).value)

                    ' ������ 1: ǐ� ����� ����� ���� ��� ���� (�� CheckBox1 ��� ���� ����)
                    If Not Me.CheckBox1.value Then
                        If existingSerial = pureDigits And pureDigits <> "000000000000" Then
                            isDuplicate = True
                            Exit For
                        End If
                    End If

                    ' ������ 2: ����� �ј�� ��� �ј� � ���� �� �� ���
                    If existingComp = compName And existingAmount = CDbl(amount) Then
                        isDuplicate = True
                        Exit For
                    End If
                Next dupCol

                ' ����� ����� �� ���� ���� ��� ���� �����
                If isDuplicate Then
                    Dim msgText As String
                    msgText = "�����: ��� �� ������ ����� �� ����� " & chequeDateStr & " ����� ��� ��� ���." & vbCrLf & _
                              "�ј�: " & compName & vbCrLf & _
                              "����: " & Format(amount, "#,##0")
                    
                    If Not Me.CheckBox1.value Then msgText = msgText & vbCrLf & "�����: " & pureDigits
                    
                    msgText = msgText & vbCrLf & vbCrLf & "��� ���� �� ��� ���� ����Ͽ"
                    
                    If MsgBox(msgText, vbYesNo + vbExclamation + vbDefaultButton2, "�� ʘ����") = vbNo Then
                        GoTo NextCheque
                    End If
                End If
            End If
        End If
        ' --- ����� ��� ���� ---


  If Not ws Is Nothing Then
      dayStartRow = FindDayRow(ws, dayNum, totalRowsPerDayBlock)

      If dayStartRow > 0 Then
          Dim chequeWritten As Boolean
          chequeWritten = False

          For c = firstChequeCol To lastChequeCol Step 2
              If ws.Cells(dayStartRow, c).value = "" Then
                  ws.Cells(dayStartRow, c).value = compName
                  ws.Cells(dayStartRow + lowerHalfStartOffset, c).value = amount
                  ws.Cells(dayStartRow + lowerHalfStartOffset, c + 1).value = CDbl(pureDigits)

                  writtenCount = writtenCount + 1
                  chequeWritten = True

                  Dim pDateParts() As String
                  pDateParts = Split(chequeDateStr, "/")

                  Call WriteLog("frmChequeManagement", "����� ��", compName, pDateParts(0), pDateParts(1), pDateParts(2), CStr(amount), "", "�����: " & pureDigits)

                  If mergeID <> "" Then
                      Call SaveTrueChequeAmountToSheet(chequeDateStr, CDbl(amount))
                      Call LogMergeReservationsToSystemLog(mergeID, chequeDateStr, CDbl(amount), compName, pureDigits)
                      Call SavePendingMergeReservationsToSheet(mergeID)
                  End If

                  Exit For
              End If
          Next c

          If Not chequeWritten Then
              MsgBox "���� �� ����� " & chequeDateStr & " ��� ���� ���� ���.", vbExclamation
          End If
      End If
  End If

NextCheque:
    Next i

    Call WriteLog("frmChequeManagement", "����� ����� ��", compName, "", "", "", "", "", _
                  "����� ����� ���: " & writtenCount & " �� " & ListBox2.ListCount)

    MsgBox writtenCount & " �� ����� ��.", vbInformation
    Me.SubmitButton.SetFocus
    
End Sub

'----------------------------------------
' CommandButton5 - Day Picker
'----------------------------------------
Private Sub CommandButton5_Click()
    On Error GoTo ErrDayPicker

    If Me.ComboBox2.value = "" Or Me.ComboBox3.value = "" Then
        MsgBox "����� ��� � ��� �� ������ ����.", vbExclamation, "����� ����"
        Exit Sub
    End If

    With frmDayPicker
        .currentYear = CLng(Me.ComboBox2.value)
        .currentMonth = CInt(Me.ComboBox3.value)
        .selectedDay = ""
        .Show
    
        If Len(.selectedDay) > 0 Then
            Me.Label28.Caption = .selectedDay
        End If
    End With
    
    Exit Sub

ErrDayPicker:
    MsgBox "��� �� ������ ���: " & Err.description, vbCritical
End Sub


'----------------------------------------
' CommandButton6 - Move Factor(s) to Direct Pay
'----------------------------------------
Private Sub CommandButton6_Click()
    If ComboBox1.value = "" Then MsgBox "�ј� �� ������ ����.": Exit Sub
    If ComboBox2.value = "" Or ComboBox3.value = "" Or Label28.Caption = "" Then
        MsgBox "����� ���� (��� ��� ���) �� ���� ����.", vbExclamation
        Exit Sub
    End If
    
    ' Check if any factor is selected
    Dim selectedCount As Long
    Dim i As Long
    For i = 0 To ListBox1.ListCount - 1
        If ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i
    
    If selectedCount = 0 Then
        MsgBox "����� � �ǘ��� �� ���� ������ ����.", vbExclamation
        Exit Sub
    End If

    ' Read Dynamic Config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim numDirectPays As Long: numDirectPays = ReadConfigValue("cfg_NumDirectPays")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim firstDirectPayCol As Long: firstDirectPayCol = lastFactorCol + 2 + 1
    Dim lastDirectPayCol As Long: lastDirectPayCol = firstDirectPayCol + numDirectPays - 1
    
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    Dim company As String: company = Trim(ComboBox1.value)
    Dim targetYear As String: targetYear = ComboBox2.value
    Dim targetMonth As String: targetMonth = ComboBox3.value
    Dim targetDay As String: targetDay = Label28.Caption
    
    Dim statusVal As String
    On Error Resume Next
    statusVal = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("D1").value)
    On Error GoTo 0
    
    ' Find target sheet
    Dim wsTgt As Worksheet
    Set wsTgt = FindSheet(targetYear & "/" & Format(CLng(targetMonth), "00"))
    If wsTgt Is Nothing Then
        MsgBox "��� ���� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' Get target day row
    Dim dayRowTgt As Long
    dayRowTgt = FindDayRow(wsTgt, CLng(targetDay), totalRowsPerDayBlock)
    If dayRowTgt = 0 Then
        MsgBox "��� ���� �� ��� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' Track results
    Dim movedCount As Long: movedCount = 0
    Dim failedCount As Long: failedCount = 0
    Dim noSlotCount As Long: noSlotCount = 0
    
    ' Process all selected factors
    For i = 0 To ListBox1.ListCount - 1
        If ListBox1.Selected(i) Then
            ' Get Source Data
            Dim factorDate As String: factorDate = Trim(ListBox1.List(i, 0))
            Dim amount As Double: amount = EvaluateExpression(ListBox1.List(i, 1))
            Dim dateParts() As String: dateParts = Split(factorDate, "/")
            Dim daySrc As Long: daySrc = CLng(dateParts(2))
            
            ' Find Source Sheet
            Dim wsSrc As Worksheet
            Set wsSrc = FindSheet(dateParts(0) & "/" & dateParts(1))
            
            If wsSrc Is Nothing Then
                failedCount = failedCount + 1
                GoTo NextFactor6
            End If
            
            ' Find source day row
            Dim dayRowSrc As Long
            dayRowSrc = FindDayRow(wsSrc, daySrc, totalRowsPerDayBlock)
            If dayRowSrc = 0 Then
                failedCount = failedCount + 1
                GoTo NextFactor6
            End If
            
            ' Mark Source as Paid
            Dim c As Long
            Dim foundBlock As Boolean: foundBlock = False
            
            For c = firstFactorCol To lastFactorCol Step 2
                If Trim(wsSrc.Cells(dayRowSrc, c).value) = company And _
                   Abs(val(wsSrc.Cells(dayRowSrc + lowerHalfStartOffset, c).value) - amount) < 0.01 Then
                    If Trim(wsSrc.Cells(dayRowSrc, c + 1).value) = "" Then
                        wsSrc.Cells(dayRowSrc, c + 1).value = statusVal
                        foundBlock = True
                        Exit For
                    End If
                End If
            Next c
            
            If Not foundBlock Then
                failedCount = failedCount + 1
                GoTo NextFactor6
            End If
            
            ' Insert into Target Direct Pay Area
            Dim insertedOK As Boolean: insertedOK = False
            
            For c = firstDirectPayCol To lastDirectPayCol
                If Trim(wsTgt.Cells(dayRowTgt, c).value) = "" Then
                    wsTgt.Cells(dayRowTgt, c).value = company
                    wsTgt.Cells(dayRowTgt + lowerHalfStartOffset, c).value = amount
                    
                    Call WriteLog("frmChequeManagement", "������ �ǘ��� �� ����", company, _
                                 dateParts(0), dateParts(1), dateParts(2), _
                                 CStr(amount), "", _
                                 "����: " & targetYear & "/" & targetMonth & "/" & targetDay)
                    
                    movedCount = movedCount + 1
                    insertedOK = True
                    Exit For
                End If
            Next c
            
            If Not insertedOK Then
                ' No slot available - revert the source marking
                wsSrc.Cells(dayRowSrc, c + 1).value = ""
                noSlotCount = noSlotCount + 1
            End If
        End If
NextFactor6:
    Next i
    
    ' Show results
    Dim resultMsg As String
    resultMsg = "����� ������:" & vbCrLf & vbCrLf
    resultMsg = resultMsg & "����� ���: " & movedCount & vbCrLf
    
    If failedCount > 0 Then
        resultMsg = resultMsg & "��� �� ������: " & failedCount & vbCrLf
    End If
    
    If noSlotCount > 0 Then
        resultMsg = resultMsg & "����� �� (����� ����): " & noSlotCount & vbCrLf
    End If
    
    MsgBox resultMsg, vbInformation, "������ �� ����"
    
    ' Refresh the list
    Call CommandButton1_Click
End Sub
'----------------------------------------
' CommandButton7 - Select All in ListBox1
'----------------------------------------
Private Sub CommandButton7_Click()
    Dim i As Long
    With Me.ListBox1
        For i = 0 To .ListCount - 1
            .Selected(i) = True
        Next i
    End With
End Sub

'====================================================================================================
'                                    TOGGLE & SPINBUTTON EVENT HANDLERS
'====================================================================================================

Private Sub ToggleButton1_Click()
    If Me.ToggleButton1.value = True Then
        Me.ToggleButton1.Caption = "���� ��� ����: ����"
        Me.TextBox3.Enabled = True
    Else
        Me.ToggleButton1.Caption = "��� ����"
        Me.TextBox3.Enabled = False
    End If
End Sub

Private Sub ToggleButton2_Click()
    If m_isUpdating Then Exit Sub

    If ToggleButton2.value Then
        ToggleButton2.Caption = "��� ���� ����"
    Else
        ToggleButton2.Caption = "��� ���� �����"
        Me.TextBox7.value = "0"
    End If
    
    Call UpdateFactorTotals
    
    If Me.ListBox1.ListCount > 0 Then
        Call CommandButton2_Click
    End If
End Sub

'----------------------------------------
' Smart Mode Toggle
'----------------------------------------
Private Sub ToggleButton3_Click()
    If Me.ToggleButton3.value = True Then
        Me.ToggleButton3.Caption = "���� ������: ����"
    Else
        Me.ToggleButton3.Caption = "���� ������"
    End If
End Sub
  Private Sub ToggleButton4_Click()
      If Me.ToggleButton4.value = True Then
          Me.ToggleButton4.Caption = "��� ���"
      Else
          Me.ToggleButton4.Caption = "��� ���"
      End If

      If Me.ListBox1.ListCount > 0 And Not m_IsOptimizing Then
          Call CommandButton2_Click
      End If
  End Sub

Private Sub SpinButton1_Change()
    Me.TextBox4.value = CStr(Me.SpinButton1.value)
    If Me.ListBox1.ListCount > 0 And Not m_IsOptimizing Then Call CommandButton2_Click
End Sub

Private Sub SpinButton2_Change()
    Me.TextBox2.value = CStr(Me.SpinButton2.value)
    If Me.ListBox1.ListCount > 0 And Not m_IsOptimizing Then Call CommandButton2_Click
End Sub

Private Sub SpinButton3_Change()
    Me.TextBox1.value = CStr(Me.SpinButton3.value)
    If Me.ListBox1.ListCount > 0 And Not m_IsOptimizing Then Call CommandButton2_Click
End Sub

  Private Sub SpinButton4_Change()
      Dim newValue As Double
      newValue = CDbl(Me.SpinButton4.value) * 5000000#
      Me.TextBox3.value = Format(newValue, "#,##0")

      If Me.ListBox1.ListCount > 0 And Not m_IsOptimizing Then
          Call CommandButton2_Click
      End If
  End Sub

'====================================================================================================
'                                    TEXTBOX EVENT HANDLERS
'====================================================================================================

Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim result As Variant
    result = EvaluateExpression(Me.TextBox1.value)
    
    If IsNumeric(result) And result >= 1 Then
        Me.TextBox1.value = CLng(result)
        On Error Resume Next
        Me.SpinButton3.value = CLng(result)
        On Error GoTo 0
    Else
        MsgBox "����� ����� ���� � ��� ����� � ��ѐ�� �� ��� ����.", vbExclamation
        Me.TextBox1.value = "1"
        Me.SpinButton3.value = 1
    End If
End Sub

Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim result As Variant
    result = EvaluateExpression(Me.TextBox2.value)
    
    If IsNumeric(result) And result > 0 Then
        Me.TextBox2.value = CLng(result)
        On Error Resume Next
        Me.SpinButton2.value = CLng(result)
        On Error GoTo 0
    Else
        MsgBox "����� ��� ����� ���� � ��� ����� � ��ѐ�� �� ��� ����.", vbExclamation
        Me.TextBox2.value = "30"
        Me.SpinButton2.value = 30
    End If
End Sub

Private Sub TextBox3_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim result As Variant
    result = EvaluateExpression(Me.TextBox3.value)
    
    If IsNumeric(result) Then
        Me.TextBox3.value = Format(CDbl(result), "#,##0")
        On Error Resume Next
        Me.SpinButton4.value = CLng(CDbl(result) / 5000000)
        On Error GoTo 0
    Else
        MsgBox "����� ������ ���� � ��� ����� ����.", vbExclamation
        Me.TextBox3.value = "0"
        Me.SpinButton4.value = 0
    End If
End Sub

Private Sub TextBox4_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim result As Variant
    result = EvaluateExpression(Me.TextBox4.value)
    
    If IsNumeric(result) Then
        Me.TextBox4.value = CLng(result)
        On Error Resume Next
        Me.SpinButton1.value = CLng(result)
        On Error GoTo 0
    Else
        MsgBox "����� ������ ����� ���� � ��� ����� ����.", vbExclamation
        Me.TextBox4.value = "0"
        Me.SpinButton1.value = 0
    End If
End Sub

Private Sub TextBox7_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim result As Variant
    result = EvaluateExpression(Me.TextBox7.value)
    
    If IsNumeric(result) Then
        Me.TextBox7.value = Format(CDbl(result), "#,##0")
    Else
        Me.TextBox7.value = "0"
    End If
    
    Call UpdateFactorTotals
    
    If Me.ListBox1.ListCount > 0 Then
        Call CommandButton2_Click
    End If
End Sub

'----------------------------------------
' TextBox8 Exit - Calculate expression
'----------------------------------------
Private Sub TextBox8_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    Dim result As Variant
    
    rawValue = Trim(Me.TextBox8.value)
    If rawValue = "" Then Exit Sub
    
    ' Remove existing formatting (commas)
    rawValue = Replace(rawValue, ",", "")
    
    result = EvaluateExpression(rawValue)
    
    If IsNumeric(result) Then
        Me.TextBox8.value = Format(CDbl(result), "#,##0")
    End If
End Sub

'====================================================================================================
'                                    LISTBOX EVENT HANDLERS
'====================================================================================================

'----------------------------------------
' MouseUp on ListBox2 - Show surrounding days capacity
' (Works even when items are already selected)
'----------------------------------------
Private Sub ListBox2_MouseUp(ByVal Button As Integer, ByVal Shift As Integer, ByVal x As Single, ByVal y As Single)
    ' Only respond to left mouse button
    If Button <> 1 Then Exit Sub
    
    Dim idx As Long
    idx = Me.ListBox2.listIndex
    
    ' If no valid index, try to find first selected item
    If idx < 0 Then
        Dim i As Long
        For i = 0 To Me.ListBox2.ListCount - 1
            If Me.ListBox2.Selected(i) Then
                idx = i
                Exit For
            End If
        Next i
    End If
    
    ' Still no valid index� Exit
    If idx < 0 Or idx >= Me.ListBox2.ListCount Then Exit Sub
    
    Dim currentDate As String
    currentDate = Me.ListBox2.List(idx, 2)
    
    ' Show surrounding days in the 3 labels
    Call ShowSurroundingDaysCapacity(currentDate)
End Sub

 '----------------------------------------
  ' Double-click on ListBox2 - Edit cheque (date or amount)
  ' Safe with sorted rows and merged cheques
  '----------------------------------------
  Private Sub ListBox2_DblClick(ByVal CANCEL As MSForms.ReturnBoolean)
      If Me.ListBox2.listIndex = -1 Then Exit Sub

      Dim idx As Long
      Dim currentDate As String
      Dim currentAmount As String
      Dim newDate As String
      Dim newAmount As String
      Dim editChoice As VbMsgBoxResult

      idx = Me.ListBox2.listIndex
      currentDate = Trim(CStr(Me.ListBox2.List(idx, 2)))
      currentAmount = Trim(CStr(Me.ListBox2.List(idx, 1)))

      editChoice = MsgBox("�� ����� " & CStr(idx + 1) & vbCrLf & _
                          "�����: " & currentDate & vbCrLf & _
                          "����: " & currentAmount & vbCrLf & vbCrLf & _
                          "YES = ����� �����" & vbCrLf & _
                          "NO = ����� ����" & vbCrLf & _
                          "CANCEL = ������", _
                          vbYesNoCancel + vbQuestion, "������ ��")

      Select Case editChoice
          Case vbYes
              Call EditListBox2ChequeDate(idx, currentDate, currentAmount)

          Case vbNo
              Call EditListBox2ChequeAmount(idx, currentDate, currentAmount)

          Case vbCancel
              Exit Sub
      End Select
  End Sub
  
   '----------------------------------------
  ' Edit selected ListBox2 cheque date
  '----------------------------------------
  '----------------------------------------
  ' Edit selected ListBox2 cheque date
  '----------------------------------------
  Private Sub EditListBox2ChequeDate(ByVal idx As Long, ByVal currentDate As String, ByVal currentAmount As String)
      Dim newDate As String
      Dim cleanDate As String
      Dim dParts() As String
      Dim rowID As String
      Dim foundRow As Long

      newDate = InputBox("����� ���� �� ���� ���� (����: 1404/03/15):" & vbCrLf & vbCrLf & _
                         "����� ����: " & currentDate, _
                         "����� �����", currentDate)

      If Trim(newDate) = "" Then Exit Sub

      newDate = Trim(newDate)

      If Not IsValidPersianDate(newDate) Then
          MsgBox "���� ����� ������� ���." & vbCrLf & "���� ����: 1404/03/15", _
                 vbExclamation, "������ ��"
          Exit Sub
      End If

      cleanDate = ConvertPersianNumsToEnglishKeepSlash(newDate)
      dParts = Split(cleanDate, "/")
      newDate = CLng(dParts(0)) & "/" & Format(CLng(dParts(1)), "00") & "/" & Format(CLng(dParts(2)), "00")

      rowID = Trim(CStr(Me.ListBox2.List(idx, 4)))

      Me.ListBox2.List(idx, 2) = newDate

      Call SortListBox2ByDate

      foundRow = FindListBox2RowByRowID(rowID)
      Call SelectOnlyListBox2Row(foundRow)

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption
      Call ShowSurroundingDaysCapacity(newDate)

      MsgBox "����� �� ����� ���.", vbInformation, "������ ��"
  End Sub


   '----------------------------------------
  ' Edit selected ListBox2 cheque amount
  '----------------------------------------
  Private Sub EditListBox2ChequeAmount(ByVal idx As Long, ByVal currentDate As String, ByVal currentAmount As String)
      Dim newAmount As String
      Dim numericAmount As Double
      Dim formattedAmount As String
      Dim rowID As String
      Dim foundRow As Long

      newAmount = InputBox("���� ���� �� ���� ����:" & vbCrLf & vbCrLf & _
                           "���� ����: " & currentAmount, _
                           "����� ����", Replace(currentAmount, ",", ""))

      If Trim(newAmount) = "" Then Exit Sub

      newAmount = ConvertPersianNumsToEnglish(Replace(newAmount, ",", ""))

      If Not IsNumeric(newAmount) Then
          MsgBox "���� ������� ���.", vbExclamation, "������ ��"
          Exit Sub
      End If

      numericAmount = CDbl(newAmount)
      formattedAmount = Format(numericAmount, "#,##0")
      rowID = Trim(CStr(Me.ListBox2.List(idx, 4)))

      Me.ListBox2.List(idx, 1) = formattedAmount

      foundRow = FindListBox2RowByRowID(rowID)
      Call SelectOnlyListBox2Row(foundRow)

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption
      Call ShowSurroundingDaysCapacity(currentDate)

      MsgBox "���� �� ����� ���.", vbInformation, "������ ��"
  End Sub

  '----------------------------------------
  ' Find a row in ListBox2 after sort/edit
  ' For merged rows, merge ID is the primary key
  ' For normal rows, date+amount with blank merge ID is used
  ' Returns -1 if not found
  '----------------------------------------
  Private Function FindListBox2Row(ByVal mergeID As String, ByVal amountText As String, ByVal dateText As String) As Long
      Dim i As Long

      FindListBox2Row = -1

      If Trim(mergeID) <> "" Then
          For i = 0 To Me.ListBox2.ListCount - 1
              If Trim(CStr(Me.ListBox2.List(i, 3))) = Trim(mergeID) Then
                  FindListBox2Row = i
                  Exit Function
              End If
          Next i
      Else
          For i = 0 To Me.ListBox2.ListCount - 1
              If Trim(CStr(Me.ListBox2.List(i, 3))) = "" _
                 And Trim(CStr(Me.ListBox2.List(i, 1))) = Trim(amountText) _
                 And Trim(CStr(Me.ListBox2.List(i, 2))) = Trim(dateText) Then
                  FindListBox2Row = i
                  Exit Function
              End If
          Next i
      End If
  End Function

  '----------------------------------------
  ' Select only one row in ListBox2
  ' If rowIndex = -1, clears selection
  '----------------------------------------
  Private Sub SelectOnlyListBox2Row(ByVal rowIndex As Long)
      Dim i As Long

      For i = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.Selected(i) = (i = rowIndex)
      Next i
  End Sub


 



 
'====================================================================================================
'                                    PRINT & EXPORT FUNCTIONS
'====================================================================================================
Private Sub btnPrintCheques_Click()
    If Me.CheckBox2.value Then Exit Sub
    Dim i As Long
    Dim selectedCount As Long
    
    For i = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(i) Then
            selectedCount = selectedCount + 1
        End If
    Next i
    
    If selectedCount = 0 Then
        MsgBox "����� ����� � �� ��� �� �� �� ���� ������ �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    For i = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(i) Then
            Dim companyName As String: companyName = Me.ComboBox1.value
            Dim BeneficiaryName As String: BeneficiaryName = GetBeneficiaryFromCompany(companyName)
            Dim NationalID As String: NationalID = GetNationalID(companyName)
            Dim amountNumeric As Double: amountNumeric = EvaluateExpression(Me.ListBox2.List(i, 1))
            Dim dateNumeric As String: dateNumeric = Me.ListBox2.List(i, 2)
            
            Dim amountInWords As String: amountInWords = NumberToFarsiWords(amountNumeric) & " ����"
            Dim dateInWords As String: dateInWords = FormatPersianDateWords(dateNumeric)
            
            Call PopulateAndPrintCheque(BeneficiaryName, NationalID, amountNumeric, amountInWords, dateNumeric, dateInWords)
        End If
    Next i
    
    MsgBox "�ǁ ���� ������ ������ ��� �� ����� ����.", vbInformation
    Me.CommandButton4.SetFocus
    
End Sub

Private Sub PopulateAndPrintCheque(payee As String, payeeID As String, amountNum As Double, _
                                    amountWords As String, dateNum As String, dateWords As String)
    Dim wsTemplate As Worksheet
    
    On Error Resume Next
    Set wsTemplate = ThisWorkbook.Sheets("��")
    If wsTemplate Is Nothing Then
        MsgBox "���: ��� ���� �� �� ��� '��' ���� ���.", vbCritical
        Exit Sub
    End If
    On Error GoTo 0
    
    If MsgBox("��� �� ���� '" & payee & "' �� ���� " & FormatNumberWithSlash(amountNum) & " �ǁ ��Ͽ", _
              vbYesNo + vbQuestion, "����� �ǁ") = vbNo Then
        Exit Sub
    End If
    
    wsTemplate.Range("Print_Payee").value = payee
    wsTemplate.Range("Print_Payee_ID").value = payeeID
    wsTemplate.Range("Print_Amount_Words").value = amountWords
    wsTemplate.Range("Print_Amount_Numeric").value = "***" & FormatNumberWithSlash(amountNum) & "***"
    wsTemplate.Range("Print_Date_Numeric").value = dateNum
    wsTemplate.Range("Print_Date_Words").value = dateWords
    
    '--- Set Page Setup for printing from top of page ---
    With wsTemplate.PageSetup
        .TopMargin = Application.CentimetersToPoints(0)      ' 0 cm from top
        .HeaderMargin = Application.CentimetersToPoints(0)   ' No header margin
        .BottomMargin = Application.CentimetersToPoints(0)   ' 0 cm bottom
        .LeftMargin = Application.CentimetersToPoints(0)   ' 0 cm left
        .RightMargin = Application.CentimetersToPoints(2)  ' 0 cm right
    End With
    
            On Error Resume Next
    wsTemplate.PrintOut
    
    If Err.Number <> 0 Then
        Dim errMsg As String
        errMsg = Err.description
        On Error GoTo 0
        
        Dim userChoice As VbMsgBoxResult
        userChoice = MsgBox("��� �� �ǁ: " & errMsg & vbCrLf & vbCrLf & _
                           "�������� ������ ������ ���." & vbCrLf & vbCrLf & _
                           "��� �������� ��ԝ����� �ǁ �� �����Ͽ", _
                           vbYesNo + vbExclamation, "���� ������")
        
        If userChoice = vbYes Then
            On Error Resume Next
            wsTemplate.PrintOut preview:=True
            On Error GoTo 0
        End If
    End If
    On Error GoTo 0
End Sub


'----------------------------------------------------------------------------------------------------
' Format number with slash (/) as thousand separator
' Example: 1234567 � 1/234/567
'----------------------------------------------------------------------------------------------------
Private Function FormatNumberWithSlash(ByVal num As Double) As String
    Dim formatted As String
    formatted = Format(num, "#,##0")
    FormatNumberWithSlash = Replace(formatted, ",", "/")
End Function

Private Sub SubmitButton_Click()
    If Me.CheckBox2.value Then
        Call ExportElectronicChequeCsv
        Exit Sub
    End If
    On Error GoTo ErrorHandler
    
    If Me.ComboBox1.value = "" Then
        MsgBox "����� �ј� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    If Me.ListBox2.ListCount = 0 Then
        MsgBox "�� ��� �� ���� ������ �� ���� �����.", vbExclamation
        Exit Sub
    End If
    
    Dim selectedCount As Long
    Dim i As Long
    For i = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(i) Then
            selectedCount = selectedCount + 1
        End If
    Next i
    
    If selectedCount = 0 Then
        MsgBox "����� ����� � �� �� �� ���� ������ ����.", vbExclamation
        Exit Sub
    End If
    
        Dim companyName As String
        Dim BeneficiaryName As String
        Dim companyNationalID As String

        companyName = Me.ComboBox1.value
        BeneficiaryName = GetBeneficiaryFromCompany(companyName)
        companyNationalID = Me.Label37.Caption
    
    If companyNationalID = "" Then
        MsgBox "����� ��� �ј� ���� ���.", vbCritical
        Exit Sub
    End If
    
    Dim cheques() As BankChequeData
    ReDim cheques(1 To selectedCount)
    
    Dim chequeIndex As Long
    chequeIndex = 1
    
    For i = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(i) Then
            cheques(chequeIndex).chequeNumber = chequeIndex
            cheques(chequeIndex).companyName = BeneficiaryName
            cheques(chequeIndex).companyNationalID = companyNationalID
            cheques(chequeIndex).chequeAmount = CleanAmountText(Me.ListBox2.List(i, 1))
            cheques(chequeIndex).chequeDate = Me.ListBox2.List(i, 2)
            chequeIndex = chequeIndex + 1
        End If
    Next i
    
    Dim Middle8Digits As String
    Dim Last4Digits As String

    On Error Resume Next
    Middle8Digits = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value)
    Last4Digits = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value)
    On Error GoTo 0
    
    For i = 1 To selectedCount
        With frmChequeCodeInput
            If i = 1 Then
                .Initialize Middle8Digits, Last4Digits, True
                .Label1.Caption = "�� ��� (" & i & " �� " & selectedCount & ")" & vbCrLf & _
                                  "����: " & Format(CDbl(cheques(i).chequeAmount), "#,##0") & vbCrLf & _
                                  "�����: " & cheques(i).chequeDate & vbCrLf & vbCrLf & _
                                  "����� �� 16 ���� ���� �� ���� ����:"
                .Show
                
                If .WasCancelled Then
                    MsgBox "������ ��� ��.", vbInformation
                    Exit Sub
                End If
                
                Middle8Digits = .Middle8Digits
                Last4Digits = .Last4Digits
                
                On Error Resume Next
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value = Middle8Digits
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value = Last4Digits
                On Error GoTo 0
                
            Else
                .Initialize Middle8Digits, Last4Digits, False
                .Label1.Caption = "�� " & i & " �� " & selectedCount & vbCrLf & _
                                  "����: " & Format(CDbl(cheques(i).chequeAmount), "#,##0") & vbCrLf & _
                                  "�����: " & cheques(i).chequeDate & vbCrLf & vbCrLf & _
                                  "��� 4 ��� ��� �� ���� ����:"
                .Show
                
                If .WasCancelled Then
                    Dim userChoice As VbMsgBoxResult
                    userChoice = MsgBox("��� �������� ��� �� �� �� ���� � �� �� ���� ����Ͽ" & vbCrLf & vbCrLf & _
                                       "YES = ��� �� ��� � ����� ����" & vbCrLf & _
                                       "NO = ��ѡ ������ ���� ��� ���", _
                                       vbYesNo + vbQuestion, "�����")
                    If userChoice = vbNo Then
                        MsgBox "������ ��� ��.", vbInformation
                        Exit Sub
                    Else
                        GoTo NextChequeSubmit
                    End If
                End If
                
                Middle8Digits = .Middle8Digits
                Last4Digits = .Last4Digits
                
                On Error Resume Next
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value = Middle8Digits
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value = Last4Digits
                On Error GoTo 0
            End If
            
            cheques(i).Code16Digit = .FullCode
            cheques(i).Code_Part1 = .First4Digits
            cheques(i).Code_Part2 = Left(.Middle8Digits, 4)
            cheques(i).Code_Part3 = Right(.Middle8Digits, 4)
            cheques(i).Code_Part4 = .Last4Digits
        End With
        
NextChequeSubmit:
    Next i
    
    Call ExportChequesForBankSubmission(cheques)
    
    Dim successCount As Long
    For i = 1 To selectedCount
        If cheques(i).Code16Digit <> "" Then
            successCount = successCount + 1
        End If
    Next i
    
    MsgBox "������� " & successCount & " �� ��ڝ���� � ����� ��."
    
    Exit Sub
    
ErrorHandler:
    MsgBox "���: " & Err.description, vbCritical
    Me.CommandButton3.SetFocus
    
End Sub

Private Sub ExportChequesForBankSubmission(cheques() As BankChequeData)
    On Error GoTo ErrorHandler
    
    Dim desktopPath As String
    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")
    
    Dim timestamp As String
    timestamp = Format(Now, "yyyymmdd_hhmmss")
    
    Dim fileName As String
    fileName = desktopPath & "\BankCheques_" & timestamp & ".csv"
    
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    
    stream.Type = 2
    stream.Charset = "UTF-8"
    stream.Open
    
    stream.WriteText "Cheque_Number,Company_Name,Company_National_ID,Amount,Date,Code_16Digit,Code_Part1,Code_Part2,Code_Part3,Code_Part4" & vbCrLf
    
    Dim i As Long
    For i = LBound(cheques) To UBound(cheques)
        If cheques(i).Code16Digit <> "" Then
            Dim csvLine As String
            csvLine = cheques(i).chequeNumber & "," & _
                     Chr(34) & cheques(i).companyName & Chr(34) & "," & _
                     cheques(i).companyNationalID & "," & _
                     cheques(i).chequeAmount & "," & _
                     Chr(34) & cheques(i).chequeDate & Chr(34) & "," & _
                     cheques(i).Code16Digit & "," & _
                     cheques(i).Code_Part1 & "," & _
                     cheques(i).Code_Part2 & "," & _
                     cheques(i).Code_Part3 & "," & _
                     cheques(i).Code_Part4
            
            stream.WriteText csvLine & vbCrLf
        End If
    Next i
    
    stream.SaveToFile fileName, 2
    stream.Close
    Set stream = Nothing
    
    Exit Sub
    
ErrorHandler:
    MsgBox "��� �� ����� ����: " & Err.description, vbCritical
    If Not stream Is Nothing Then
        stream.Close
        Set stream = Nothing
    End If
End Sub



'----------------------------------------
' Convert Persian/Arabic digits to English but KEEP operators
'----------------------------------------
Private Function ConvertPersianDigitsKeepOperators(ByVal inputText As String) As String
    Dim i As Long
    Dim code As Long
    Dim char As String
    Dim result As String
    
    result = ""
    
    For i = 1 To Len(inputText)
        char = Mid(inputText, i, 1)
        code = AscW(char)
        
        Select Case code
            ' English digits (0-9)
            Case 48 To 57
                result = result & char
            ' Persian digits (�-�)
            Case 1776 To 1785
                result = result & CStr(code - 1776)
            ' Arabic-Indic digits (�-�)
            Case 1632 To 1641
                result = result & CStr(code - 1632)
            ' Keep operators: + - * / ( ) . ^
            Case 43, 45, 42, 47, 40, 41, 46, 94
                result = result & char
            ' Skip everything else (spaces, letters, etc.)
        End Select
    Next i
    
    ConvertPersianDigitsKeepOperators = result
End Function


'====================================================================================================
'                                    SMART MODE FUNCTIONS
'====================================================================================================

'----------------------------------------
' Smart Mode - Find optimal configuration
'----------------------------------------
Private Function FindOptimalConfiguration() As Boolean
    Dim originalChequeCount As Long
    Dim originalInterval As Long
    Dim originalCapacity As Double
    Dim originalDateAdjust As Long
    
    Dim bestChequeCount As Long
    Dim bestInterval As Long
    Dim bestCapacity As Double
    Dim bestDateAdjust As Long
    Dim bestResultCount As Long
    Dim bestSchedule As Collection
    
    Dim testChequeCount As Long
    Dim testInterval As Long
    Dim testCapacity As Double
    Dim testDateAdjust As Long
    Dim testResultCount As Long
    Dim testSchedule As Collection
    
    Dim chequeVariations As Variant
    Dim intervalVariations As Variant
    Dim capacityVariations As Variant
    Dim dateAdjustVariations As Variant
    
    Dim i As Long, j As Long, k As Long, l As Long
    Dim currentResultCount As Long
    
    ' Store current result count for comparison
    currentResultCount = Me.ListBox2.ListCount
    
    ' Store original values
    originalChequeCount = CLng(Me.TextBox1.value)
    originalInterval = CLng(Me.TextBox2.value)
    originalCapacity = EvaluateExpression(Me.TextBox3.value)
    originalDateAdjust = CLng(Me.TextBox4.value)
    
    ' Define variations
    chequeVariations = Array(1, 0.5, 0.75, 1.25, 1.5, 2)
    intervalVariations = Array(1, 0.5, 0.75, 0.85, 1.15, 1.25)
    capacityVariations = Array(1, 0.9, 1.1, 1.2)
    dateAdjustVariations = Array(0, -5, -10, 5, 10)
    
    bestResultCount = 9999
    bestChequeCount = originalChequeCount
    bestInterval = originalInterval
    bestCapacity = originalCapacity
    bestDateAdjust = originalDateAdjust
    Set bestSchedule = Nothing
    
    Application.ScreenUpdating = False
    Application.StatusBar = "�� ��� ������ ������� �����..."
    
    ' Set flag to prevent re-entry
    m_IsOptimizing = True
    
    ' Try all combinations
    For i = LBound(chequeVariations) To UBound(chequeVariations)
        For j = LBound(intervalVariations) To UBound(intervalVariations)
            For k = LBound(capacityVariations) To UBound(capacityVariations)
                For l = LBound(dateAdjustVariations) To UBound(dateAdjustVariations)
                    
                    testChequeCount = CLng(originalChequeCount * chequeVariations(i))
                    testInterval = CLng(originalInterval * intervalVariations(j))
                    testCapacity = originalCapacity * capacityVariations(k)
                    testDateAdjust = originalDateAdjust + dateAdjustVariations(l)
                    
                    If testChequeCount < 1 Then testChequeCount = 1
                    If testInterval < 1 Then testInterval = 1
                    If testCapacity < 1000000 Then testCapacity = 1000000
                    
                    Set testSchedule = SimulateChequeDistribution(testChequeCount, testInterval, testCapacity, testDateAdjust)
                    
                    If Not testSchedule Is Nothing Then
                        testResultCount = testSchedule.count
                        
                        If testResultCount > 0 And testResultCount < bestResultCount Then
                            bestResultCount = testResultCount
                            bestChequeCount = testChequeCount
                            bestInterval = testInterval
                            bestCapacity = testCapacity
                            bestDateAdjust = testDateAdjust
                            
                            ' Copy the schedule to bestSchedule
                            Set bestSchedule = New Collection
                            Dim idx As Long
                            For idx = 1 To testSchedule.count
                                bestSchedule.Add testSchedule(idx)
                            Next idx
                        End If
                    End If
                    
                Next l
            Next k
        Next j
    Next i
    
    Application.StatusBar = False
    Application.ScreenUpdating = True
    
    ' Check if we found something better than current
    If bestResultCount < 9999 And Not bestSchedule Is Nothing And bestResultCount < currentResultCount Then
        Dim msg As String
        msg = "������ ������� ���� ��:" & vbCrLf & vbCrLf
        msg = msg & "--------------------" & vbCrLf
        msg = msg & "����� �� ��������: " & originalChequeCount & " �� " & bestChequeCount & vbCrLf
        msg = msg & "����� ��� �����: " & originalInterval & " �� " & bestInterval & vbCrLf
        msg = msg & "����� ������: " & Format(originalCapacity, "#,##0") & " �� " & Format(bestCapacity, "#,##0") & vbCrLf
        msg = msg & "����� �����: " & originalDateAdjust & " �� " & bestDateAdjust & vbCrLf
        msg = msg & "--------------------" & vbCrLf
        msg = msg & "����� �� ����: " & currentResultCount & vbCrLf
        msg = msg & "����� �� �����: " & bestResultCount & vbCrLf
        msg = msg & "--------------------" & vbCrLf & vbCrLf
        msg = msg & "��� ��� ������� ����� ��Ͽ"
        
If MsgBox(msg, vbYesNo + vbQuestion, "���� ������") = vbYes Then
            ' Update form controls
            Me.TextBox1.value = CStr(bestChequeCount)
            Me.TextBox2.value = CStr(bestInterval)
            Me.TextBox3.value = Format(bestCapacity, "#,##0")
            Me.TextBox4.value = CStr(bestDateAdjust)
            
            On Error Resume Next
            Me.SpinButton3.value = bestChequeCount
            Me.SpinButton2.value = bestInterval
            Me.SpinButton4.value = CLng(bestCapacity / 5000000)
            Me.SpinButton1.value = bestDateAdjust
            On Error GoTo 0
            
            ' Reset flag FIRST
            m_IsOptimizing = False
            
            ' Turn OFF smart mode temporarily so it won't ask again
            Dim smartModeWasOn As Boolean
            smartModeWasOn = Me.ToggleButton3.value
            Me.ToggleButton3.value = False
            
            ' Now recalculate
            Call CommandButton2_Click
            
            ' Restore smart mode
            Me.ToggleButton3.value = smartModeWasOn
            
            FindOptimalConfiguration = True
        Else
            ' User declined - keep current ListBox2 as is
            m_IsOptimizing = False
            FindOptimalConfiguration = False
        End If
        
    Else
        MsgBox "������� ����� ���� ���." & vbCrLf & _
               "����� �� ����: " & currentResultCount, vbInformation, "���� ������"
        m_IsOptimizing = False
        FindOptimalConfiguration = False
    End If
    
End Function



'----------------------------------------
' Simulate cheque distribution with given parameters
' Returns a Collection of cheques or Nothing if failed
'----------------------------------------
Private Function SimulateChequeDistribution(chequeCount As Long, interval As Long, _
                                             capacityLimit As Double, dateAdjust As Long) As Collection
    Dim schedule As New Collection
    Dim i As Long
    Dim totalAmt As Double
    Dim wSum As Double
    Dim factorAmt As Double
    Dim factorDate As Date
    Dim pDateParts() As String
    
    On Error GoTo ErrHandler
    
    ' Calculate weighted average from selected factors
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            factorAmt = EvaluateExpression(Me.ListBox1.List(i, 1))
            pDateParts = Split(Me.ListBox1.List(i, 3), "/")
            factorDate = PersianToGregorianDate(CLng(pDateParts(0)), CLng(pDateParts(1)), CLng(pDateParts(2)))
            totalAmt = totalAmt + factorAmt
            wSum = wSum + (factorAmt * CDbl(factorDate))
        End If
    Next i
    
    If totalAmt <= 0 Then
        Set SimulateChequeDistribution = Nothing
        Exit Function
    End If
    
    ' Apply adjustments
    Dim manualAdjustment As Double: manualAdjustment = EvaluateExpression(Me.TextBox8.value)
    Dim roundingAdjustment As Double: roundingAdjustment = EvaluateExpression(Me.TextBox7.value)
    totalAmt = totalAmt + roundingAdjustment - manualAdjustment
    
    If totalAmt <= 0 Then
        Set SimulateChequeDistribution = Nothing
        Exit Function
    End If
    
    ' Calculate target date
    Dim avgTarget As Date: avgTarget = CDate(wSum / (totalAmt - roundingAdjustment + manualAdjustment))
    Dim adjAvgDate As Date: adjAvgDate = avgTarget + dateAdjust
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Simulate distribution
    Dim currentChequeDate As Date
    Dim remainingTotal As Double: remainingTotal = totalAmt
    Dim idealFirstChequeDate As Date
    
    If chequeCount = 1 Then
        idealFirstChequeDate = adjAvgDate
    Else
        idealFirstChequeDate = adjAvgDate - ((interval * (chequeCount - 1)) / 2)
    End If
    
    For i = 1 To chequeCount
        Dim pieceAmt As Double
        If i < chequeCount Then
            pieceAmt = Application.WorksheetFunction.RoundDown(totalAmt / chequeCount, -5)
        Else
            pieceAmt = remainingTotal
        End If
        
        Dim idealNextDate As Date
        If i = 1 Then
            idealNextDate = idealFirstChequeDate
        Else
            idealNextDate = currentChequeDate + interval
        End If
        
        ' Simulate spreading this cheque piece with capacity
        Call SimulateSpreadWithCapacity(idealNextDate, pieceAmt, schedule, _
                                         firstChequeCol, lastChequeCol, totalRowsPerDayBlock, _
                                         lowerHalfStartOffset, capacityLimit, currentChequeDate)
        
        remainingTotal = remainingTotal - pieceAmt
    Next i
    
    Set SimulateChequeDistribution = schedule
    Exit Function
    
ErrHandler:
    Set SimulateChequeDistribution = Nothing
End Function

'----------------------------------------
' Simulate spreading a cheque amount across days based on capacity
' Updates currentChequeDate to the last date used
'----------------------------------------
Private Sub SimulateSpreadWithCapacity(ByVal targetDate As Date, ByVal chequeAmount As Double, _
                                        ByRef schedule As Collection, _
                                        ByVal firstChequeCol As Long, ByVal lastChequeCol As Long, _
                                        ByVal totalRowsPerDayBlock As Long, ByVal lowerHalfStartOffset As Long, _
                                        ByVal capacityLimit As Double, ByRef lastDateUsed As Date)
    
    Dim remainingAmount As Double: remainingAmount = chequeAmount
    Dim currentDate As Date: currentDate = targetDate
    Dim maxIterations As Long: maxIterations = 365
    Dim iterations As Long: iterations = 0
    Dim accumulatedRemainder As Double: accumulatedRemainder = 0
    
    Const ENTRY_THRESHOLD As Double = 80
    Const OVERFLOW_ALLOWANCE As Double = 0.1
    
    Do While remainingAmount > 0.01 And iterations < maxIterations
        iterations = iterations + 1
        
        ' Skip holidays
        If IsHoliday(currentDate) Then
            currentDate = currentDate + 1
            GoTo ContinueSimLoop
        End If
        
        ' Check slot availability
        If Not HasAvailableSlot(currentDate, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) Then
            currentDate = currentDate + 1
            GoTo ContinueSimLoop
        End If
        
        ' Check capacity
        Dim usagePercent As Double
  usagePercent = GetCapacityUsagePercent(currentDate, firstChequeCol, lastChequeCol, _
                                          totalRowsPerDayBlock, lowerHalfStartOffset, capacityLimit)
        
        If usagePercent >= ENTRY_THRESHOLD Then
            currentDate = currentDate + 1
            GoTo ContinueSimLoop
        End If
        
        ' Calculate available
        Dim availableCapacity As Double
  availableCapacity = RemainingCapacity(currentDate, firstChequeCol, lastChequeCol, _
                                         totalRowsPerDayBlock, lowerHalfStartOffset, capacityLimit)
        
        If availableCapacity <= 0 Then
            currentDate = currentDate + 1
            GoTo ContinueSimLoop
        End If
        
        ' Allocate
        Dim allocAmount As Double
        If remainingAmount <= availableCapacity * (1 + OVERFLOW_ALLOWANCE) Then
            allocAmount = remainingAmount + accumulatedRemainder
            accumulatedRemainder = 0
        Else
            allocAmount = Application.Min(remainingAmount, availableCapacity)
            Dim roundedAmount As Double
            roundedAmount = Application.WorksheetFunction.RoundDown(allocAmount, -4)
            accumulatedRemainder = accumulatedRemainder + (allocAmount - roundedAmount)
            allocAmount = roundedAmount
        End If
        
        If allocAmount > 0 Then
            schedule.Add Array(currentDate, allocAmount)
            remainingAmount = remainingAmount - allocAmount
            lastDateUsed = currentDate
        End If
        
        currentDate = currentDate + 1
        
ContinueSimLoop:
    Loop
    
    ' Handle remaining
    If (remainingAmount > 0.01 Or accumulatedRemainder > 0.01) And schedule.count > 0 Then
        Dim lastEntry As Variant
        lastEntry = schedule.item(schedule.count)
        schedule.Remove schedule.count
        schedule.Add Array(lastEntry(0), lastEntry(1) + remainingAmount + accumulatedRemainder)
        lastDateUsed = CDate(lastEntry(0))
    ElseIf remainingAmount > 0.01 Or accumulatedRemainder > 0.01 Then
        schedule.Add Array(targetDate, remainingAmount + accumulatedRemainder)
        lastDateUsed = targetDate
    End If
End Sub

'----------------------------------------
' Get cheque count for a specific day
'----------------------------------------
Private Function GetDayChequeCount(checkDate As Date, firstCol As Long, lastCol As Long, _
                                    totalRowsPerDayBlock As Long) As Long
    Dim ws As Worksheet
    Dim persianDate As String
    Dim parts() As String
    Dim dayRow As Long
    Dim c As Long
    Dim cnt As Long
    
    persianDate = GregorianToPersian(checkDate)
    parts = Split(persianDate, "/")
    
    Set ws = FindSheetByYM(parts(0) & "/" & parts(1))
    If ws Is Nothing Then
        GetDayChequeCount = 0
        Exit Function
    End If
    
    dayRow = 2 + (CLng(parts(2)) - 1) * totalRowsPerDayBlock
    
    cnt = 0
    For c = firstCol To lastCol Step 2
        If ws.Cells(dayRow, c).value <> "" Then
            cnt = cnt + 1
        End If
    Next c
    
    GetDayChequeCount = cnt
End Function

 '----------------------------------------
  ' Display schedule in ListBox2
  '----------------------------------------
  Private Sub DisplayScheduleInListBox(schedule As Collection)
      Dim entry As Variant
      Dim i As Long

      Me.ListBox2.Clear

      For i = 1 To schedule.count
          entry = schedule(i)
          Me.ListBox2.AddItem
          Me.ListBox2.List(Me.ListBox2.ListCount - 1, 0) = i
          Me.ListBox2.List(Me.ListBox2.ListCount - 1, 1) = Format(entry(1), "#,##0")
          Me.ListBox2.List(Me.ListBox2.ListCount - 1, 2) = GregorianToPersian(CDate(entry(0)))
          Me.ListBox2.List(Me.ListBox2.ListCount - 1, 3) = ""
          Me.ListBox2.List(Me.ListBox2.ListCount - 1, 4) = CreateListBox2RowID()
      Next i

      Call SortListBox2ByDate

      For i = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.Selected(i) = True
      Next i

      Call UpdateListBox2SelectToggleCaption
  End Sub

'----------------------------------------
' Get total amount from selected items in ListBox1
'----------------------------------------
Private Function GetTotalSelectedAmount() As Double
    Dim i As Long
    Dim total As Double
    
    total = 0
    
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            total = total + CDbl(ConvertPersianNumsToEnglish(Replace(Me.ListBox1.List(i, 1), ",", "")))
        End If
    Next i
    
    GetTotalSelectedAmount = total
End Function

'====================================================================================
' ADD THIS CODE TO THE soorathesab USERFORM MODULE (soorat_hesab)
' ============================================================================
' HOW TO ADD:
'   1. Open Excel -> Press Alt+F11 to open VBA Editor
'   2. In the Project panel on the left, expand your workbook
'   3. Double-click "soorathesab" under Forms
'   4. Click anywhere in the code area of that form
'   5. Paste the Sub below anywhere in the module (e.g. after the last Sub)
'   6. Save and close the VBA editor
'====================================================================================


'------------------------------------------------------------------------------------
' ListBox1_DblClick
' Double-clicking a factor row opens Farsi InputBox dialogs to edit:
'   - �����  (date)
'   - ����   (amount)
'   - ����   (days to pay / forjeh)
' Changes are written directly to the matching cell in the workbook sheet.
' ListBox1 is then refreshed automatically.
'------------------------------------------------------------------------------------
Private Sub ListBox1_DblClick(ByVal CANCEL As MSForms.ReturnBoolean)

    '--- 1. Make sure a row is selected ---
    Dim idx As Long
    idx = Me.ListBox1.listIndex
    If idx < 0 Then Exit Sub

    '--- 2. Read the selected row's current values ---
    Dim oldDateStr  As String   ' col 0 : e.g. "1403/02/15"
    Dim oldAmtStr   As String   ' col 1 : e.g. "10,000,000"
    Dim oldForjeh   As String   ' col 2 : e.g. "30"
    ' col 3 is the computed cheque-due date - displayed only, not stored separately

    oldDateStr = Trim(CStr(Me.ListBox1.List(idx, 0)))
    oldAmtStr = Trim(CStr(Me.ListBox1.List(idx, 1)))
    oldForjeh = Trim(CStr(Me.ListBox1.List(idx, 2)))

    If oldDateStr = "" Or InStr(oldDateStr, "/") = 0 Then
        MsgBox "���� �����ȝ��� ����� ����� �����.", vbExclamation, "���"
        Exit Sub
    End If

    '--- 3. Read company from ComboBox1 ---
    Dim company As String
    company = Trim(Me.ComboBox1.value)
    If company = "" Then
        MsgBox "����� ����� � �ј� ������ ����.", vbExclamation, "���"
        Exit Sub
    End If

    '--- 4. Ask user what to change (Farsi menu via InputBox) ---
    Dim menu As String
    menu = "�ǘ��� �����ȝ���:" & vbCrLf & _
           "  ����� : " & oldDateStr & vbCrLf & _
           "  ����  : " & oldAmtStr & vbCrLf & _
           "  ����  : " & oldForjeh & " ���" & vbCrLf & vbCrLf & _
           "�� ���� �� �������� ����� ���Ͽ" & vbCrLf & _
           "  1 = �����" & vbCrLf & _
           "  2 = ����" & vbCrLf & _
           "  3 = ����" & vbCrLf & _
           "  4 = ���� � ���� (�� ��)" & vbCrLf & _
           "  5 = ��� �ǘ���" & vbCrLf & vbCrLf & _
           "(���� ������ ���� Ȑ����� � OK �����)"

    Dim choice As String
    choice = Trim(InputBox(menu, "������ �ǘ��� - " & company))
    If choice = "" Then Exit Sub
 If choice <> "1" And choice <> "2" And choice <> "3" And choice <> "4" And choice <> "5" Then
 MsgBox "������� �� ���� ����� ����� ����. ����� ��� 1 �� 5 ���� ����.", vbExclamation, "���"
        Exit Sub
    End If

    '--- 5. Ask for new values based on choice ---
    Dim newDateStr  As String: newDateStr = oldDateStr
    Dim newAmtStr   As String: newAmtStr = oldAmtStr
    Dim newForjStr  As String: newForjStr = oldForjeh

    ' ---- ����� ����� ----
    If choice = "1" Then
        newDateStr = Trim(InputBox( _
            "����� ����: " & oldDateStr & vbCrLf & vbCrLf & _
            "����� ���� �� ���� ���� (����: yyyy/mm/dd):" & vbCrLf & _
            "����: 1403/06/20", _
            "����� ����� �ǘ���"))
        If newDateStr = "" Then Exit Sub
        newDateStr = ConvertPersianNumsSH(newDateStr)
        If Not IsValidDateStrSH(newDateStr) Then
            MsgBox "���� ����� ������ ���. ����� �� ���� yyyy/mm/dd ���� ����.", vbExclamation, "���"
            Exit Sub
        End If
    End If

    ' ---- ����� ���� ----
    If choice = "2" Or choice = "4" Then
        newAmtStr = Trim(InputBox( _
            "���� ����: " & oldAmtStr & vbCrLf & vbCrLf & _
            "���� ���� �� ���� ���� (����):" & vbCrLf & _
            "�������� ����� �������� �� ������ϡ �����: 5000000+200000", _
            "����� ���� �ǘ���"))
        If newAmtStr = "" Then Exit Sub
        newAmtStr = ConvertPersianNumsSH(Replace(newAmtStr, ",", ""))
        If Not IsNumericExprSH(newAmtStr) Then
            MsgBox "����� ���� ���ϝ��� ���� ������ ����.", vbExclamation, "���"
            Exit Sub
        End If
    End If

    ' ---- ����� ���� ----
    If choice = "3" Or choice = "4" Then
        newForjStr = Trim(InputBox( _
            "���� ����: " & oldForjeh & " ���" & vbCrLf & vbCrLf & _
            "���� ���� �� ���� ���� (����� ���):", _
            "����� ���� �ǘ���"))
        If newForjStr = "" Then Exit Sub
        newForjStr = ConvertPersianNumsSH(newForjStr)
        If Not IsNumeric(newForjStr) Then
            MsgBox "���� ���� � ��� ���� ����.", vbExclamation, "���"
            Exit Sub
        End If
    End If

    '--- 6. Read workbook config (same pattern as eslahfaktor) ---
    Dim numCheques   As Long: numCheques = ReadConfigValueSH("cfg_NumCheques")
    Dim numFactors   As Long: numFactors = ReadConfigValueSH("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValueSH("cfg_TotalCenters")
    Dim userCenters  As Long: userCenters = ReadConfigValueSH("cfg_ActualUserCenters")

    If numFactors = 0 Or totalCenters = 0 Then
        MsgBox "������ ������� ������ ���. ����� ��� ���� �� ����� ����.", vbCritical, "���"
        Exit Sub
    End If

    Dim firstFactorCol     As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol      As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay         As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlk As Long: totalRowsPerDayBlk = rowsPerDay + 1
    Dim lowerOffset        As Long: lowerOffset = rowsPerDay \ 2

    '--- 7. Locate the factor in the sheet ---
    ' Parse the OLD date (used to find the row)
    Dim dateParts() As String
    dateParts = Split(oldDateStr, "/")
    If UBound(dateParts) <> 2 Then Exit Sub

    Dim pYear  As Long: pYear = CLng(dateParts(0))
    Dim pMonth As Long: pMonth = CLng(dateParts(1))
    Dim pDay   As Long: pDay = CLng(dateParts(2))

    Dim ws As Worksheet
    Set ws = FindSheetSH(pYear & "/" & Format(pMonth, "00"))
    If ws Is Nothing Then
        MsgBox "��� ����� �� ����� " & oldDateStr & " ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Dim r As Long
    r = 2 + (pDay - 1) * totalRowsPerDayBlk

    ' Match by company name + amount + forjeh (same fingerprint as eslahfaktor)
    Dim oldAmtClean As Double
    On Error Resume Next
    oldAmtClean = CDbl(Replace(oldAmtStr, ",", ""))
    On Error GoTo 0

    Dim oldForjClean As Double
    oldForjClean = val(oldForjeh)

    Dim foundCol As Long: foundCol = 0
    Dim c As Long
    For c = firstFactorCol To lastFactorCol Step 2
        If Trim(ws.Cells(r, c).value) = company Then
            Dim cellAmt   As Double
            Dim cellForj  As Double
            On Error Resume Next
            cellAmt = CDbl(ws.Cells(r + lowerOffset, c).value)
            cellForj = val(ws.Cells(r + lowerOffset, c + 1).value)
            On Error GoTo 0
            If cellAmt = oldAmtClean And cellForj = oldForjClean Then
                foundCol = c
                Exit For
            End If
        End If
    Next c

    If foundCol = 0 Then
        MsgBox "�ǘ��� ������ �� ��� ���� ���." & vbCrLf & _
               "��� ��� ������ ����� ���� �����. ���� �� ���� ����.", _
               vbExclamation, "���"
        Exit Sub
    End If
    
    '--- 8. Delete factor ---
  If choice = "5" Then
      If MsgBox("��� �� ��� ��� �ǘ��� ����� ����Ͽ" & vbCrLf & vbCrLf & _
                "�ј�: " & company & vbCrLf & _
                "�����: " & oldDateStr & vbCrLf & _
                "����: " & oldAmtStr & vbCrLf & _
                "����: " & oldForjeh, _
                vbYesNo + vbQuestion, "����� ��� �ǘ���") = vbNo Then
          Exit Sub
      End If

      On Error Resume Next
      ws.Cells(r, foundCol).MergeArea.ClearContents
      ws.Cells(r, foundCol + 1).MergeArea.ClearContents
      ws.Cells(r + lowerOffset, foundCol).MergeArea.ClearContents
      ws.Cells(r + lowerOffset, foundCol + 1).MergeArea.ClearContents
      On Error GoTo 0

      MsgBox "�ǘ��� �� ������ ��� ��.", vbInformation, "��� �ǘ���"

      Call CommandButton1_Click
      Call UpdateFactorTotals

      Me.ListBox2.Clear
      Call ClearPendingMergeReservations
      Call UpdateChequeAverageDate
      Call UpdateListBox2SelectToggleCaption

      Exit Sub
  End If

    '--- 9. Handle date change (move factor to a different row/sheet) ---
    If choice = "1" Then
        ' Moving to a different date means writing to a new row (possibly new sheet)
        Dim newParts() As String: newParts = Split(newDateStr, "/")
        Dim newYear  As Long: newYear = CLng(newParts(0))
        Dim newMonth As Long: newMonth = CLng(newParts(1))
        Dim newDay   As Long: newDay = CLng(newParts(2))

        Dim destWs As Worksheet
        Set destWs = FindSheetSH(newYear & "/" & Format(newMonth, "00"))
        If destWs Is Nothing Then
            MsgBox "��� ���� ���� ����� " & newDateStr & " ���� ���.", vbExclamation, "���"
            Exit Sub
        End If

        Dim destR As Long: destR = 2 + (newDay - 1) * totalRowsPerDayBlk

        ' Find a free factor slot in destination
        Dim destCol As Long: destCol = 0
        For c = firstFactorCol To lastFactorCol Step 2
            If Trim(destWs.Cells(destR, c).value) = "" And _
               Trim(destWs.Cells(destR + lowerOffset, c).value) = "" Then
                destCol = c
                Exit For
            End If
        Next c

        If destCol = 0 Then
            MsgBox "�� ����� " & newDateStr & " ��� ���� ���� �ǘ��� ���� �����.", _
                   vbExclamation, "����� �� ���"
            Exit Sub
        End If

        ' Confirm move
        If MsgBox("�ǘ��� �� ����� " & oldDateStr & " �� ����� " & newDateStr & " ����� �����." & vbCrLf & _
                  "��� ������� ����Ͽ", vbYesNo + vbQuestion, "����� ������ �����") = vbNo Then
            Exit Sub
        End If

        ' Copy to destination
        destWs.Cells(destR, destCol).value = ws.Cells(r, foundCol).value
        destWs.Cells(destR, destCol + 1).value = ws.Cells(r, foundCol + 1).value
        destWs.Cells(destR + lowerOffset, destCol).value = ws.Cells(r + lowerOffset, foundCol).value
        destWs.Cells(destR + lowerOffset, destCol + 1).value = ws.Cells(r + lowerOffset, foundCol + 1).value

        ' Clear source
        On Error Resume Next
        ws.Cells(r, foundCol).MergeArea.ClearContents
        ws.Cells(r, foundCol + 1).MergeArea.ClearContents
        ws.Cells(r + lowerOffset, foundCol).MergeArea.ClearContents
        ws.Cells(r + lowerOffset, foundCol + 1).MergeArea.ClearContents
        On Error GoTo 0

        MsgBox "�ǘ��� �� ������ �� ����� " & newDateStr & " ����� ��.", vbInformation, "������ ����"

    '--- 10. Handle amount and/or forjeh change (in-place edit) ---
    Else
        If choice = "2" Or choice = "4" Then
            Dim newAmt As Double
            On Error Resume Next
            newAmt = Evaluate(newAmtStr)
            If Err.Number <> 0 Or newAmt = 0 Then
                MsgBox "����� ���� ���ϝ��� ���� ������ ����.", vbExclamation, "���"
                On Error GoTo 0
                Exit Sub
            End If
            On Error GoTo 0
            ws.Cells(r + lowerOffset, foundCol).value = newAmt
        End If

        If choice = "3" Or choice = "4" Then
            ws.Cells(r + lowerOffset, foundCol + 1).value = CLng(newForjStr)
        End If

        MsgBox "�ǘ��� �� ������ ������ ��.", vbInformation, "������ ����"
    End If

    '--- 11. Refresh ListBox1 by re-triggering the search ---
    ' This calls whatever Sub populates ListBox1 in your form.
    ' Adjust the name below if your refresh Sub has a different name.
    Call CommandButton1_Click

End Sub


'====================================================================================
' PRIVATE HELPER FUNCTIONS (scoped to this form � no naming conflict)
' These mirror the helpers in eslahfaktor but are prefixed _SH to stay local.
'====================================================================================

'------------------------------------------------------------------------------------
' Read a numeric config value from the ������� sheet
'------------------------------------------------------------------------------------
Private Function ReadConfigValueSH(configName As String) As Long
    On Error Resume Next
    Dim v As Variant
    v = ThisWorkbook.Sheets("�������").Range(configName).value
    If IsNumeric(v) Then ReadConfigValueSH = CLng(v) Else ReadConfigValueSH = 0
    On Error GoTo 0
End Function
'----------------------------------------
  ' Return dictionary date keys sorted by actual Persian/Gregorian date
  '----------------------------------------
  Private Function GetSortedPersianDateKeys(ByVal sourceDates As Object) As Variant
      Dim arr() As String
      Dim key As Variant
      Dim i As Long, j As Long
      Dim temp As String

      If sourceDates.count = 0 Then
          GetSortedPersianDateKeys = Array()
          Exit Function
      End If

      ReDim arr(0 To sourceDates.count - 1)

      i = 0
      For Each key In sourceDates.Keys
          arr(i) = CStr(key)
          i = i + 1
      Next key

      For i = LBound(arr) To UBound(arr) - 1
          For j = i + 1 To UBound(arr)
              If PersianToGregorian(arr(j)) < PersianToGregorian(arr(i)) Then
                  temp = arr(i)
                  arr(i) = arr(j)
                  arr(j) = temp
              End If
          Next j
      Next i

      GetSortedPersianDateKeys = arr
  End Function
'------------------------------------------------------------------------------------
' Find a monthly sheet by its B1 header (e.g. "1403/02")
'------------------------------------------------------------------------------------
Private Function FindSheetSH(ym As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If Trim(ws.Range("B1").value) = ym Then
            Set FindSheetSH = ws
            Exit Function
        End If
    Next ws
    Set FindSheetSH = Nothing
End Function

'------------------------------------------------------------------------------------
' Convert Persian/Arabic/Fullwidth digits to ASCII digits
'------------------------------------------------------------------------------------
Private Function ConvertPersianNumsSH(ByVal s As String) As String
    Dim i As Long
    ' Persian digits U+06F0..U+06F9
    For i = 1776 To 1785
        s = Replace(s, ChrW(i), CStr(i - 1776))
    Next i
    ' Arabic-Indic digits U+0660..U+0669
    For i = 1632 To 1641
        s = Replace(s, ChrW(i), CStr(i - 1632))
    Next i
    ConvertPersianNumsSH = s
End Function

'------------------------------------------------------------------------------------
' Validate a Persian date string (must be yyyy/mm/dd with sane ranges)
'------------------------------------------------------------------------------------
Private Function IsValidDateStrSH(s As String) As Boolean
    IsValidDateStrSH = False
    If InStr(s, "/") = 0 Then Exit Function
    Dim p() As String: p = Split(s, "/")
    If UBound(p) <> 2 Then Exit Function
    If Not IsNumeric(p(0)) Or Not IsNumeric(p(1)) Or Not IsNumeric(p(2)) Then Exit Function
    Dim y As Long: y = CLng(p(0))
    Dim m As Long: m = CLng(p(1))
    Dim d As Long: d = CLng(p(2))
    If y < 1300 Or y > 1500 Then Exit Function
    If m < 1 Or m > 12 Then Exit Function
    If d < 1 Or d > 31 Then Exit Function
    IsValidDateStrSH = True
End Function

'------------------------------------------------------------------------------------
' Check if a string is a valid numeric expression (supports + - * /)
'------------------------------------------------------------------------------------
Private Function IsNumericExprSH(s As String) As Boolean
    On Error Resume Next
    Dim v As Variant
    v = Evaluate(s)
    If Err.Number <> 0 Then
        IsNumericExprSH = False
    Else
        IsNumericExprSH = IsNumeric(v)
    End If
    On Error GoTo 0
End Function
 Private Sub BuildManualChequeListFromSelectedDates(ByVal selectedDates As Collection)
      Dim countDates As Long
      Dim amounts() As Double
      Dim isManual() As Boolean
      Dim i As Long
      Dim inputValue As String
      Dim result As Variant

      Dim labelTotal As Double
      Dim manualTotal As Double
      Dim remainingTotal As Double
      Dim blankCount As Long
      Dim blankIndex As Long
      Dim splitBase As Double
      Dim roundedAmount As Double
      Dim remainingForBlanks As Double

      Dim rowIndex As Long
      Dim pDate As String
      Dim lastDisplayDate As String

      countDates = selectedDates.count
      If countDates = 0 Then Exit Sub

      ReDim amounts(1 To countDates)
      ReDim isManual(1 To countDates)

      labelTotal = 0
      result = EvaluateExpression(Me.Label34.Caption)
      If IsNumeric(result) Then labelTotal = CDbl(result)

      For i = 1 To countDates
          pDate = CStr(selectedDates(i))

          inputValue = InputBox( _
              "���� �� ���� ����� " & pDate & " �� ���� ����." & vbCrLf & vbCrLf & _
              "ǐ� ���� Ȑ����ϡ ��� ��� ����� �� ���� �� Label34 ������ �����.", _
              "���� ��", "")

          If StrPtr(inputValue) = 0 Then Exit Sub

          inputValue = Trim(inputValue)

          If inputValue = "" Then
              isManual(i) = False
              blankCount = blankCount + 1
          Else
              result = EvaluateExpression(inputValue)

              If Not IsNumeric(result) Or CDbl(result) <= 0 Then
                  MsgBox "���� ���� ��� ���� ����� " & pDate & " ����� ����.", vbExclamation, "���� �������"
                  Exit Sub
              End If

              amounts(i) = CDbl(result)
              isManual(i) = True
              manualTotal = manualTotal + amounts(i)
          End If
      Next i

      If blankCount > 0 Then
          remainingTotal = labelTotal - manualTotal

          If remainingTotal <= 0 Then
              MsgBox "���� ��������� ���� ����Ν��� ���� ��� �� ���� ���." & vbCrLf & _
                     "Label34: " & Format(labelTotal, "#,##0") & vbCrLf & _
                     "����� ����� ����: " & Format(manualTotal, "#,##0"), _
                     vbExclamation, "����� ����"
              Exit Sub
          End If

          splitBase = remainingTotal / blankCount
          remainingForBlanks = remainingTotal
          blankIndex = 0

          For i = 1 To countDates
              If Not isManual(i) Then
                  blankIndex = blankIndex + 1

                  If blankIndex < blankCount Then
                      roundedAmount = Application.WorksheetFunction.RoundDown(splitBase, -5)
                      amounts(i) = roundedAmount
                      remainingForBlanks = remainingForBlanks - roundedAmount
                  Else
                      amounts(i) = remainingForBlanks
                  End If
              End If
          Next i
      End If

      ' Refresh ListBox2 completely and add only these manually selected cheques.
      Call ClearPendingMergeReservations
      m_NextListBox2RowID = 0

      Me.ListBox2.Clear
      Me.ListBox2.ColumnCount = 5
      Me.ListBox2.ColumnWidths = "30;80;80;0;0"

      For i = 1 To countDates
          pDate = CStr(selectedDates(i))

          Me.ListBox2.AddItem
          rowIndex = Me.ListBox2.ListCount - 1

          Me.ListBox2.List(rowIndex, 0) = rowIndex + 1
          Me.ListBox2.List(rowIndex, 1) = Format(amounts(i), "#,##0")
          Me.ListBox2.List(rowIndex, 2) = pDate
          Me.ListBox2.List(rowIndex, 3) = ""
          Me.ListBox2.List(rowIndex, 4) = CreateListBox2RowID()

          lastDisplayDate = pDate
      Next i

      Call SortListBox2ByDate
      Call RenumberListBox2Rows

      For i = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.Selected(i) = True
      Next i

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption

      If lastDisplayDate <> "" Then
          Call ShowSurroundingDaysCapacity(lastDisplayDate)
      End If

      MsgBox countDates & " �� �� ���� ����� ��.", vbInformation, "������ ���� ��"
  End Sub

  Private Sub ListBox2_Change()
      On Error Resume Next
      Call UpdateListBox2SelectToggleCaption
      On Error GoTo 0
  End Sub
  Private Sub btnChequeDateMinus_Click()
      Call AdjustSelectedListBox2ChequeDates(-1)
  End Sub

  Private Sub btnChequeDatePlus_Click()
      Call AdjustSelectedListBox2ChequeDates(1)
  End Sub

  Private Sub ListBox2_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
      Select Case KeyCode
          Case vbKeyAdd, 187
              Call AdjustSelectedListBox2ChequeDates(1)
              KeyCode = 0

          Case vbKeySubtract, 189
              Call AdjustSelectedListBox2ChequeDates(-1)
              KeyCode = 0
      End Select
  End Sub

  Private Sub AdjustSelectedListBox2ChequeDates(ByVal dayOffset As Long)
      On Error GoTo ErrorHandler

      If Me.ListBox2.ListCount = 0 Then
          MsgBox "�� ��� �� ���� ���� �����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      Dim targetRowIDs As Collection
      Set targetRowIDs = New Collection

      Dim rowIndex As Long
      Dim rowID As String

      For rowIndex = 0 To Me.ListBox2.ListCount - 1
          If Me.ListBox2.Selected(rowIndex) Then
              rowID = Trim(CStr(Me.ListBox2.List(rowIndex, 4)))

              If rowID = "" Then
                  rowID = CreateListBox2RowID()
                  Me.ListBox2.List(rowIndex, 4) = rowID
              End If

              targetRowIDs.Add rowID
          End If
      Next rowIndex

      If targetRowIDs.count = 0 And Me.ListBox2.listIndex >= 0 Then
          rowID = Trim(CStr(Me.ListBox2.List(Me.ListBox2.listIndex, 4)))

          If rowID = "" Then
              rowID = CreateListBox2RowID()
              Me.ListBox2.List(Me.ListBox2.listIndex, 4) = rowID
          End If

          targetRowIDs.Add rowID
      End If

      If targetRowIDs.count = 0 Then
          MsgBox "����� ����� � �� �� ������ ����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      Dim item As Variant
      Dim foundRow As Long
      Dim currentDate As String
      Dim newDate As String
      Dim lastChangedDate As String

      For Each item In targetRowIDs
          foundRow = FindListBox2RowByRowID(CStr(item))

          If foundRow >= 0 Then
              currentDate = Trim(CStr(Me.ListBox2.List(foundRow, 2)))

              If Not IsValidPersianDate(currentDate) Then
                  MsgBox "����� �� ����� ����: " & currentDate, vbExclamation, "����� �����"
                  Exit Sub
              End If

              newDate = GregorianToPersian(PersianToGregorian(currentDate) + dayOffset)
              Me.ListBox2.List(foundRow, 2) = newDate
              lastChangedDate = newDate
          End If
      Next item

      Call SortListBox2ByDate

      For rowIndex = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.Selected(rowIndex) = False
      Next rowIndex

      For Each item In targetRowIDs
          foundRow = FindListBox2RowByRowID(CStr(item))
          If foundRow >= 0 Then Me.ListBox2.Selected(foundRow) = True
      Next item

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption

      If lastChangedDate <> "" Then
          Call ShowSurroundingDaysCapacity(lastChangedDate)
      End If

      Exit Sub

ErrorHandler:
      MsgBox "��� �� ����� ����� ��: " & Err.description, vbCritical, "����� �����"
  End Sub
  '----------------------------------------
  ' Real bank-clearing amount for the actual clearing day
  ' If checkDate is a working day:
  '   returns Y(checkDate) + Y(previous consecutive holidays)
  ' If checkDate is a holiday:
  '   returns 0 because it will clear on the next working day
  '----------------------------------------
  Private Function GetActualBankClearingAmount(ByVal checkDate As Date) As Double
      Dim dt As Date
      Dim pDate As String
      Dim total As Double
      Dim maxLookBack As Long
      Dim i As Long

      If IsHoliday(checkDate) Then
          GetActualBankClearingAmount = 0
          Exit Function
      End If

      ' Start with the working day itself.
      pDate = GregorianToPersian(checkDate)
      total = GetBankClearingAmountByPersianDate(pDate)

      ' Add all consecutive holiday amounts immediately before this  working day.
      dt = checkDate - 1
      maxLookBack = 20

      For i = 1 To maxLookBack
          If Not IsHoliday(dt) Then Exit For

          pDate = GregorianToPersian(dt)
          total = total + GetBankClearingAmountByPersianDate(pDate)

          dt = dt - 1
      Next i

      GetActualBankClearingAmount = total
  End Function
  Private Sub btnChequeDateEmptyPlus_Click()
      Call AdjustSelectedListBox2ChequeDatesToEmpty(1)
  End Sub

  Private Sub btnChequeDateEmptyMinus_Click()
      Call AdjustSelectedListBox2ChequeDatesToEmpty(-1)
  End Sub

  Private Function FirstEmptyChequeDateInDirection(ByVal startDate As Date, _
                                                   ByVal direction As Long, _
                                                   ByVal firstChequeCol As Long, _
                                                   ByVal lastChequeCol As Long, _
                                                   ByVal totalRowsPerDayBlock As Long, _
                                                   ByVal reservedDateKeys As Object) As Date
      Dim dt As Date
      Dim maxIterations As Long
      Dim iterations As Long
      Dim dateKey As String

      If direction >= 0 Then
          direction = 1
      Else
          direction = -1
      End If

      dt = startDate + direction
      maxIterations = 365

      Do While iterations < maxIterations
          iterations = iterations + 1
          dateKey = ScheduleDateKey(dt)

         If DayChequeCount(dt, firstChequeCol, lastChequeCol, totalRowsPerDayBlock) = 0 _
     And Not IsHoliday(dt) _
     And Not HasReservedCapacity(dt) _
     And Not reservedDateKeys.exists(dateKey) Then

              FirstEmptyChequeDateInDirection = dt
              Exit Function
          End If

          dt = dt + direction
      Loop
  End Function

  Private Sub AdjustSelectedListBox2ChequeDatesToEmpty(ByVal direction As Long)
      On Error GoTo ErrorHandler

      If Me.ListBox2.ListCount = 0 Then
          MsgBox "�� ��� �� ���� ���� �����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      Dim targetRowIDs As Collection
      Dim targetIDLookup As Object
      Dim reservedDateKeys As Object
      Dim rowIndex As Long
      Dim rowID As String

      Set targetRowIDs = New Collection
      Set targetIDLookup = CreateObject("Scripting.Dictionary")
      Set reservedDateKeys = CreateObject("Scripting.Dictionary")

      For rowIndex = 0 To Me.ListBox2.ListCount - 1
          If Me.ListBox2.Selected(rowIndex) Then
              rowID = Trim(CStr(Me.ListBox2.List(rowIndex, 4)))

              If rowID = "" Then
                  rowID = CreateListBox2RowID()
                  Me.ListBox2.List(rowIndex, 4) = rowID
              End If

              targetRowIDs.Add rowID
              targetIDLookup(rowID) = True
          End If
      Next rowIndex

      If targetRowIDs.count = 0 And Me.ListBox2.listIndex >= 0 Then
          rowID = Trim(CStr(Me.ListBox2.List(Me.ListBox2.listIndex, 4)))

          If rowID = "" Then
              rowID = CreateListBox2RowID()
              Me.ListBox2.List(Me.ListBox2.listIndex, 4) = rowID
          End If

          targetRowIDs.Add rowID
          targetIDLookup(rowID) = True
      End If

      If targetRowIDs.count = 0 Then
          MsgBox "����� ����� � �� �� ������ ����.", vbExclamation, "����� �����"
          Exit Sub
      End If

      Dim numChequesConf As Long: numChequesConf = ReadConfigValue("cfg_NumCheques")
      Dim firstChequeCol As Long: firstChequeCol = 14
      Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numChequesConf * 2) - 2
      Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
      Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
      Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
      Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1

      For rowIndex = 0 To Me.ListBox2.ListCount - 1
          rowID = Trim(CStr(Me.ListBox2.List(rowIndex, 4)))

          If Not targetIDLookup.exists(rowID) Then
              If IsValidPersianDate(CStr(Me.ListBox2.List(rowIndex, 2))) Then
                  reservedDateKeys(ScheduleDateKey(PersianToGregorian(CStr(Me.ListBox2.List(rowIndex, 2))))) = True
              End If
          End If
      Next rowIndex

      Dim item As Variant
      Dim foundRow As Long
      Dim currentDate As String
      Dim currentGDate As Date
      Dim newGDate As Date
      Dim newDate As String
      Dim lastChangedDate As String

      For Each item In targetRowIDs
          foundRow = FindListBox2RowByRowID(CStr(item))

          If foundRow >= 0 Then
              currentDate = Trim(CStr(Me.ListBox2.List(foundRow, 2)))

              If Not IsValidPersianDate(currentDate) Then
                  MsgBox "����� �� ����� ����: " & currentDate, vbExclamation, "����� �����"
                  Exit Sub
              End If

              currentGDate = PersianToGregorian(currentDate)

              newGDate = FirstEmptyChequeDateInDirection(currentGDate, direction, _
                                                         firstChequeCol, lastChequeCol, _
                                                         totalRowsPerDayBlock, reservedDateKeys)

              If CDbl(newGDate) = 0 Then
                  MsgBox "�� 365 ��ҡ ��� ���� ����� ���� ���.", vbExclamation, "����� �����"
                  Exit Sub
              End If

              newDate = GregorianToPersian(newGDate)
              Me.ListBox2.List(foundRow, 2) = newDate
              reservedDateKeys(ScheduleDateKey(newGDate)) = True
              lastChangedDate = newDate
          End If
      Next item

      Call SortListBox2ByDate

      For rowIndex = 0 To Me.ListBox2.ListCount - 1
          Me.ListBox2.Selected(rowIndex) = False
      Next rowIndex

      For Each item In targetRowIDs
          foundRow = FindListBox2RowByRowID(CStr(item))
          If foundRow >= 0 Then Me.ListBox2.Selected(foundRow) = True
      Next item

      Call UpdateChequeAverageDate
      Call RecalculateTotals
      Call UpdateListBox2SelectToggleCaption

      If lastChangedDate <> "" Then
          Call ShowSurroundingDaysCapacity(lastChangedDate)
      End If

      Exit Sub

ErrorHandler:
      MsgBox "��� �� ������ �� ��� ����: " & Err.description, vbCritical, "����� �����"
  End Sub
  
   Private Function HasReservedCapacity(ByVal d As Date) As Boolean
      HasReservedCapacity = (GetReservedCapacityByPersianDate(GregorianToPersian(d)) > 0)
  End Function
  
  
  
  
  
 '----------------------------------------
  ' Sort ListBox2 rows by cheque date ascending
  ' Keeps hidden merge ID and row ID intact
  '----------------------------------------
  Private Sub SortListBox2ByDate()
      Dim rowCount As Long
      Dim i As Long, j As Long
      Dim temp0 As Variant, temp1 As Variant, temp2 As Variant, temp3 As Variant, temp4 As Variant
      Dim d1 As Date, d2 As Date

      rowCount = Me.ListBox2.ListCount
      If rowCount <= 1 Then Exit Sub

      For i = 0 To rowCount - 2
          For j = i + 1 To rowCount - 1
              d1 = PersianToGregorian(CStr(Me.ListBox2.List(i, 2)))
              d2 = PersianToGregorian(CStr(Me.ListBox2.List(j, 2)))

              If d2 < d1 Then
                  temp0 = Me.ListBox2.List(i, 0)
                  temp1 = Me.ListBox2.List(i, 1)
                  temp2 = Me.ListBox2.List(i, 2)
                  temp3 = Me.ListBox2.List(i, 3)
                  temp4 = Me.ListBox2.List(i, 4)

                  Me.ListBox2.List(i, 0) = Me.ListBox2.List(j, 0)
                  Me.ListBox2.List(i, 1) = Me.ListBox2.List(j, 1)
                  Me.ListBox2.List(i, 2) = Me.ListBox2.List(j, 2)
                  Me.ListBox2.List(i, 3) = Me.ListBox2.List(j, 3)
                  Me.ListBox2.List(i, 4) = Me.ListBox2.List(j, 4)

                  Me.ListBox2.List(j, 0) = temp0
                  Me.ListBox2.List(j, 1) = temp1
                  Me.ListBox2.List(j, 2) = temp2
                  Me.ListBox2.List(j, 3) = temp3
                  Me.ListBox2.List(j, 4) = temp4
              End If
          Next j
      Next i

      Call RenumberListBox2Rows
  End Sub






 Private Sub EnsureMergeLogHeaders(ByVal wsLog As Worksheet)
      If Trim(CStr(wsLog.Range("BA1").value)) <> "" Then Exit Sub

      wsLog.Range("BA1").value = "MergeID"
      wsLog.Range("BB1").value = "ChequeDate"
      wsLog.Range("BC1").value = "ChequeAmount"
      wsLog.Range("BD1").value = "ReserveDate"
      wsLog.Range("BE1").value = "ReserveAmount"
      wsLog.Range("BF1").value = "Active"
      wsLog.Range("BG1").value = "CreatedAt"
      wsLog.Range("BH1").value = "CompanyName"
      wsLog.Range("BI1").value = "SerialNumber"
  End Sub

  Private Sub LogMergeReservationsToSystemLog(ByVal mergeID As String, ByVal chequeDate As String, ByVal chequeAmount As Double, ByVal companyName As String, ByVal serialNumber As String)
         Dim wsLog As Worksheet
      Dim item As Variant
      Dim NextRow As Long

      If Trim(mergeID) = "" Then Exit Sub
      If m_PendingMergeReservations Is Nothing Then Exit Sub

      On Error Resume Next
      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      On Error GoTo 0

      If wsLog Is Nothing Then
          MsgBox "��� ����� �ǐ ���� ���. ������� ����� ��� ���.", vbExclamation, "�ǐ �����"
          Exit Sub
      End If

      Call EnsureMergeLogHeaders(wsLog)

      For Each item In m_PendingMergeReservations
          If CStr(item(0)) = mergeID Then
              NextRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).Row + 1
              If NextRow < 2 Then NextRow = 2

              wsLog.Cells(NextRow, "BA").value = mergeID
              wsLog.Cells(NextRow, "BB").value = chequeDate
              wsLog.Cells(NextRow, "BC").value = chequeAmount
              wsLog.Cells(NextRow, "BD").value = CStr(item(1))
              wsLog.Cells(NextRow, "BE").value = CDbl(item(2))
              wsLog.Cells(NextRow, "BF").value = True
              wsLog.Cells(NextRow, "BG").value = Now
              wsLog.Cells(NextRow, "BH").value = companyName
              wsLog.Cells(NextRow, "BI").value = serialNumber
          End If
      Next item
  End Sub












Private Sub btnPrintReceipt_Click()
    On Error GoTo ErrorHandler
    
    Dim i As Long
    Dim selectedCount As Long
    Dim receiptText As String
    Dim totalAmount As Double
    Dim companyName As String
    Dim companyId As String
    Dim tempAmount As Variant
    Dim chequeNum As String
    Dim chequeDate As String
    
    ' ����� ����� �����ȝ���
    selectedCount = 0
    For i = 0 To ListBox2.ListCount - 1
        If ListBox2.Selected(i) Then
            selectedCount = selectedCount + 1
        End If
    Next i
    
    If selectedCount = 0 Then
        MsgBox "����� ����� � �� �� ������ ����", vbExclamation
        Exit Sub
    End If
    
    ' ������ ������� �ј� �� ���
    companyName = CStr(Me.ComboBox1.value)
    companyId = CStr(Me.Label37.Caption)
    
    ' ���� ��� ����
    receiptText = "================================" & vbCrLf
    receiptText = receiptText & companyName & vbCrLf
    receiptText = receiptText & "����� ���: " & companyId & vbCrLf
    receiptText = receiptText & "================================" & vbCrLf
    receiptText = receiptText & "���� ������ �����ȝ���" & vbCrLf
    receiptText = receiptText & "--------------------------------" & vbCrLf
    
    totalAmount = 0
    
    ' ������ ������� �� ListBox2
    For i = 0 To ListBox2.ListCount - 1
        If ListBox2.Selected(i) Then
            chequeNum = CStr(ListBox2.List(i, 0))
            tempAmount = ListBox2.List(i, 1)
            chequeDate = CStr(ListBox2.List(i, 2))
            
            receiptText = receiptText & vbCrLf
            receiptText = receiptText & "����� ��: " & chequeNum & vbCrLf
            receiptText = receiptText & "�����: " & chequeDate & vbCrLf
            
            ' ����� ���� ����
            If IsNumeric(tempAmount) Then
                receiptText = receiptText & "����: " & Format(CDbl(tempAmount), "#,##0") & " ����" & vbCrLf
                totalAmount = totalAmount + CDbl(tempAmount)
            Else
                receiptText = receiptText & "����: ������" & vbCrLf
            End If
            
            receiptText = receiptText & "--------------------------------" & vbCrLf
        End If
    Next i
    
    receiptText = receiptText & vbCrLf
    receiptText = receiptText & "����� ��: " & selectedCount & vbCrLf
    receiptText = receiptText & "��� ����: " & Format(totalAmount, "#,##0") & " ����" & vbCrLf
    receiptText = receiptText & "================================" & vbCrLf
    receiptText = receiptText & "����� �ǁ: " & Date & vbCrLf
    
    ' �ǁ ����
    PrintToReceiptPrinter receiptText
    
    Exit Sub
    
ErrorHandler:
    MsgBox "��� �� ��������� ����: " & Err.description, vbCritical
End Sub

Private Sub PrintToReceiptPrinter(receiptText As String)
    Dim wsReceipt As Worksheet
    Dim lines() As String
    Dim i As Long
    Dim lastRow As Long
    Dim cellRow As Long
    Dim lineText As String

    On Error GoTo ErrorHandler

    If Len(Trim(receiptText)) = 0 Then
        MsgBox "��� ���� ���� ���", vbExclamation
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    ' ��� ��� ���� �� ���� ����
    On Error Resume Next
    Application.DisplayAlerts = False
    ThisWorkbook.Worksheets("Receipt_Temp").Delete
    Application.DisplayAlerts = True
    On Error GoTo ErrorHandler

    ' ����� ��� ����
    Set wsReceipt = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
    wsReceipt.Name = "Receipt_Temp"
    wsReceipt.DisplayRightToLeft = True

    ' ����� ��� �� ����
    lines = Split(receiptText, vbCrLf)

    ' ����� ������ - ��� ������ ����
    cellRow = 1
    For i = LBound(lines) To UBound(lines)
        lineText = Trim(lines(i))

        ' �� ���� ������ ������ ����
        If Len(lineText) = 0 Then GoTo NextLine

        On Error Resume Next
        wsReceipt.Range("A" & cellRow).value = lineText
        If Err.Number <> 0 Then
            Debug.Print "��� �� ��� " & cellRow & ": " & Err.description
            Err.Clear
        End If
        On Error GoTo ErrorHandler

        ' ����� ������ ��� - ������ ��ǘ���� �捘���
        If lineText Like "*---*" Or lineText Like "*===*" Then
            wsReceipt.rows(cellRow).RowHeight = 6
        Else
            wsReceipt.rows(cellRow).RowHeight = 14
        End If

        cellRow = cellRow + 1
NextLine:
    Next i

    lastRow = cellRow - 1

    ' ���ʝ����
    With wsReceipt
        With .Range("A1:A" & lastRow)
            .Font.Name = "B Nazanin"
            .Font.Size = 10
            .HorizontalAlignment = xlRight
            .VerticalAlignment = xlCenter
            .WrapText = False
        End With
        .Columns("A:A").ColumnWidth = 30
    End With

    ' ������� ����
    With wsReceipt.PageSetup
        .Orientation = xlPortrait
        .LeftMargin = Application.CentimetersToPoints(0.5)
        .RightMargin = Application.CentimetersToPoints(0.5)
        .TopMargin = Application.CentimetersToPoints(0.5)
        .BottomMargin = Application.CentimetersToPoints(0.5)
        .HeaderMargin = Application.CentimetersToPoints(0)
        .FooterMargin = Application.CentimetersToPoints(0)
        .PrintArea = "A1:A" & lastRow
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
    End With

    ' ����� ����� ������ �ǁ��
    Application.Dialogs(xlDialogPrinterSetup).Show

    ' �ǁ �� ������ ���
    On Error Resume Next
    wsReceipt.PrintOut preview:=False

    If Err.Number <> 0 Then
        Dim userResponse As VbMsgBoxResult
        userResponse = MsgBox("��� �� �ǁ: " & Err.description & vbCrLf & vbCrLf & _
                              "��� �������� ��ԝ����� �ǁ �� �����Ͽ", _
                              vbQuestion + vbYesNo, "���� �ǁ")
        If userResponse = vbYes Then
            Err.Clear
            wsReceipt.PrintPreview
        End If
    End If

    On Error GoTo ErrorHandler

    ' ��� ��� ����
    On Error Resume Next
    Application.DisplayAlerts = False
    ThisWorkbook.Worksheets("Receipt_Temp").Delete
    Application.DisplayAlerts = True
    On Error GoTo ErrorHandler
    
    ' �������� ��� �������
    Worksheets("�������").Activate
    
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Exit Sub

ErrorHandler:
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    MsgBox "��� �� �ǁ ���� (�� " & Erl & "): " & Err.description & " (��: " & Err.Number & ")", vbCritical
End Sub


Private Sub CheckBox2_Click()
    Call UpdateChequeModeUI
End Sub

Private Sub CheckBox1_Click()
    On Error Resume Next
    ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("cfg_SkipSerial").value = IIf(Me.CheckBox1.value, 1, 0)
    m_skipSerialEntry = Me.CheckBox1.value
    On Error GoTo 0
    Call UpdateChequeModeUI
End Sub

Private Function UText(ByVal codeList As String) As String
    Dim a As Variant, x As Variant, s As String
    For Each a In Split(codeList, ",")
        x = Trim$(a)
        If Len(x) > 0 Then s = s & ChrW(CLng("&H" & x))
    Next a
    UText = s
End Function



Private Sub UpdateChequeModeUI()
    On Error Resume Next
    Me.CheckBox1.Caption = UText("0633,0631,06CC,0627,0644,0020,0686,06A9,0020,067E,0631,0633,06CC,062F,0647,0020,0646,0634,0648,062F")
    Me.CheckBox2.Caption = UText("0686,06A9,0020,0627,0644,06A9,062A,0631,0648,0646,06CC,06A9,06CC")
    If Me.CheckBox2.value Then
        Me.btnPrintCheques.Visible = False
        Me.CommandButton4.Visible = True
        Me.SubmitButton.Visible = True
        Me.SubmitButton.Caption = UText("0635,062F,0648,0631,0020,0686,06A9,0020,0627,0644,06A9,062A,0631,0648,0646,06CC,06A9,06CC")
    Else
        Me.btnPrintCheques.Visible = True
        Me.CommandButton4.Visible = True
        Me.SubmitButton.Visible = True
        Me.btnPrintCheques.Caption = UText("0686,0627,067E,0020,0686,06A9,200C,0647,0627,06CC,0020,0627,0646,062A,062E,0627,0628,06CC")
        Me.CommandButton4.Caption = UText("062B,0628,062A,0020,0686,06A9,200C,0647,0627,0020,062F,0631,0020,0627,06A9,0633,0644")
        Me.SubmitButton.Caption = UText("062B,0628,062A,0020,0627,062A,0648,0645,0627,062A,06CC,06A9,0020,0686,06A9,200C,0647,0627")
    End If
    On Error GoTo 0
End Sub

Private Function ReadUtf8Text(ByVal filePath As String) As String
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2: stm.Charset = "utf-8": stm.Open
    stm.LoadFromFile filePath
    ReadUtf8Text = stm.ReadText(-1)
    stm.Close
    Set stm = Nothing
End Function

Private Function CsvParseLine(ByVal lineText As String) As Variant
    Dim result() As String, i As Long, n As Long, ch As String, fieldText As String, quoted As Boolean
    ReDim result(0 To 0): n = 0: fieldText = ""
    For i = 1 To Len(lineText)
        ch = Mid$(lineText, i, 1)
        If ch = """" Then
            If quoted And i < Len(lineText) And Mid$(lineText, i + 1, 1) = """" Then
                fieldText = fieldText & """": i = i + 1
            Else
                quoted = Not quoted
            End If
        ElseIf ch = "," And Not quoted Then
            result(n) = fieldText: n = n + 1: ReDim Preserve result(0 To n): fieldText = ""
        Else
            fieldText = fieldText & ch
        End If
    Next i
    result(n) = fieldText
    CsvParseLine = result
End Function

Private Function CsvHeaderIndex(ByVal headers As Variant, ParamArray names() As Variant) As Long
    Dim i As Long, j As Long
    CsvHeaderIndex = -1
    For i = LBound(headers) To UBound(headers)
        For j = LBound(names) To UBound(names)
            If LCase$(Trim$(CStr(headers(i)))) = LCase$(CStr(names(j))) Then CsvHeaderIndex = i: Exit Function
        Next j
    Next i
End Function

Private Function CsvValue(ByVal fields As Variant, ByVal idx As Long) As String
    If idx >= LBound(fields) And idx <= UBound(fields) Then CsvValue = Trim$(CStr(fields(idx))) Else CsvValue = ""
End Function

Private Function NormalizeElectronicDigits(ByVal inputText As String) As String
    Dim i As Long, code As Long, ch As String, result As String
    For i = 1 To Len(inputText)
        ch = Mid$(inputText, i, 1): code = AscW(ch)
        Select Case code
            Case 48 To 57: result = result & ch
            Case 1776 To 1785: result = result & CStr(code - 1776)
            Case 1632 To 1641: result = result & CStr(code - 1632)
            Case Else
                If ch = "/" Or ch = "-" Then result = result & "/"
        End Select
    Next i
    NormalizeElectronicDigits = result
End Function

Private Function LatestElectronicCsvPath() As String
    Dim candidate As String
    candidate = CreateObject("WScript.Shell").SpecialFolders("Desktop") & "\Cheque Automation Results\electronic_cheques.csv"
    If Len(Dir$(candidate)) = 0 Then candidate = CreateObject("WScript.Shell").SpecialFolders("Desktop") & "\electronic_cheques.csv"
    If Len(Dir$(candidate)) > 0 Then LatestElectronicCsvPath = candidate
End Function

'Private Sub ExportElectronicChequeCsv()
'    On Error GoTo ErrorHandler
'    Dim selectedCount As Long, i As Long, companyName As String, companyNationalID As String
'    Dim desktopPath As String, fileName As String, stream As Object, amountText As String, dateText As String, chequeNumber As Long
'    For i = 0 To Me.ListBox2.ListCount - 1
'        If Me.ListBox2.Selected(i) Then selectedCount = selectedCount + 1
'    Next i
'    If selectedCount = 0 Then MsgBox "لطفاً ابتدا یک یا چند چک را انتخاب کنید.", vbExclamation: Exit Sub
'    companyName = Me.ComboBox1.value: companyNationalID = NormalizeElectronicDigits(Me.Label37.Caption)
'    If companyName = "" Or companyNationalID = "" Then MsgBox "شرکت یا شناسه ملی مشخص نیست.", vbExclamation: Exit Sub
'    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")
'    fileName = desktopPath & "\ChequeAutomation_Electronic_" & Format(Now, "yyyymmdd_hhnnss") & ".csv"
'    Set stream = CreateObject("ADODB.Stream"): stream.Type = 2: stream.Charset = "utf-8": stream.Open
'    stream.WriteText "Cheque_Number,Company_Name,Company_National_ID,Amount,Date" & vbCrLf
'    For i = 0 To Me.ListBox2.ListCount - 1
'        If Me.ListBox2.Selected(i) Then
'            chequeNumber = chequeNumber + 1
'            amountText = CStr(EvaluateExpression(Me.ListBox2.List(i, 1))): dateText = Me.ListBox2.List(i, 2)
'            stream.WriteText CStr(chequeNumber) & "," & Chr(34) & Replace(companyName, Chr(34), Chr(34) & Chr(34)) & Chr(34) & "," & companyNationalID & "," & amountText & "," & Chr(34) & dateText & Chr(34) & vbCrLf
'        End If
'    Next i
'    stream.SaveToFile fileName, 2: stream.Close: Set stream = Nothing
'    MsgBox "فایل چک الکترونیکی ساخته شد:" & vbCrLf & fileName, vbInformation
'    Exit Sub
'ErrorHandler:
'    If Not stream Is Nothing Then stream.Close
'    MsgBox "خطا در ساخت فایل چک الکترونیکی: " & Err.description, vbCritical
'End Sub

Private Sub ExportElectronicChequeCsv()

    On Error GoTo ErrorHandler

    Dim selectedCount As Long
    Dim i As Long
    Dim companyName As String
    Dim companyNationalID As String
    Dim desktopPath As String
    Dim fileName As String
    Dim stream As Object
    Dim amountText As String
    Dim dateText As String
    Dim chequeNumber As Long

    ' Count selected cheques
    For i = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(i) Then
            selectedCount = selectedCount + 1
        End If
    Next i

    If selectedCount = 0 Then
        MsgBox "Please select one or more cheques first.", vbExclamation
        Exit Sub
    End If

    companyName = Trim$(Me.ComboBox1.value)
    companyNationalID = NormalizeElectronicDigits(Me.Label37.Caption)

    If companyName = "" Or companyNationalID = "" Then
        MsgBox "Company name or national ID is missing.", vbExclamation
        Exit Sub
    End If

    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")

    fileName = desktopPath & _
               "\ChequeAutomation_Electronic_" & _
               Format(Now, "yyyymmdd_hhnnss") & ".csv"

    Set stream = CreateObject("ADODB.Stream")

    With stream
        .Type = 2
        .Charset = "utf-8"
        .Open

        ' CSV header
        .WriteText "Cheque_Number,Company_Name,Company_National_ID,Amount,Date" & vbCrLf

        chequeNumber = 0

        For i = 0 To Me.ListBox2.ListCount - 1

            If Me.ListBox2.Selected(i) Then

                chequeNumber = chequeNumber + 1

                amountText = CStr(EvaluateExpression(Me.ListBox2.List(i, 1)))
                dateText = CStr(Me.ListBox2.List(i, 2))

                .WriteText _
                    CStr(chequeNumber) & "," & _
                    Chr(34) & Replace(companyName, Chr(34), Chr(34) & Chr(34)) & Chr(34) & "," & _
                    companyNationalID & "," & _
                    amountText & "," & _
                    Chr(34) & dateText & Chr(34) & vbCrLf

            End If

        Next i

        .SaveToFile fileName, 2
        .Close
    End With

    Set stream = Nothing

    MsgBox "Electronic cheque CSV created:" & vbCrLf & fileName, vbInformation

    Exit Sub

ErrorHandler:

    On Error Resume Next

    If Not stream Is Nothing Then
        stream.Close
        Set stream = Nothing
    End If

    MsgBox "Error creating electronic cheque CSV: " & Err.description, vbCritical

End Sub


Private Sub ImportLatestElectronicCheques()

    Dim importFile As String

    Dim fileText As String, lines() As String, headers As Variant, fields As Variant
    Dim rowsToImport As Collection, seen As Object, rowData As Variant
    Dim idxSayyadi As Long, idxSeries As Long, idxSerial As Long, idxAmount As Long, idxDate As Long, idxCompany As Long, idxCompanyId As Long
    Dim i As Long, readyCount As Long, duplicateCount As Long, otherCount As Long, importedCount As Long
    Dim sayyadi As String, seriesText As String, serialText As String, serial12 As String, amountText As String, chequeDate As String, companyName As String, companyId As String
    Dim statusText As String, rowKey As String, previewText As String

    On Error GoTo ErrorHandler

    importFile = EI_GetLatestImportFile()
    If importFile = "" Then
        MsgBox "No ElectronicCheque_Import_*.csv file was found on the Desktop.", vbExclamation
        Exit Sub
    End If

    fileText = Replace(ReadUtf8Text(importFile), vbCr, "")
    lines = Split(fileText, vbLf)

    If UBound(lines) < 1 Then
        MsgBox "The electronic cheque CSV is empty.", vbExclamation
        Exit Sub
    End If

    headers = CsvParseLine(lines(0))
    headers(0) = Replace(CStr(headers(0)), ChrW(&HFEFF), "")

    idxSayyadi = CsvHeaderIndex(headers, "Sayyadi")
    idxSeries = CsvHeaderIndex(headers, "Series")
    idxSerial = CsvHeaderIndex(headers, "Serial")
    idxAmount = CsvHeaderIndex(headers, "Amount")
    idxDate = CsvHeaderIndex(headers, "Date")
    idxCompany = CsvHeaderIndex(headers, "Company", "Company_Name")
    idxCompanyId = CsvHeaderIndex(headers, "CompanyId", "Company_National_ID")

    If idxSayyadi < 0 Or idxAmount < 0 Or idxDate < 0 Or idxCompany < 0 Then
        MsgBox "Required CSV columns were not found.", vbCritical
        Exit Sub
    End If

    Set rowsToImport = New Collection
    Set seen = CreateObject("Scripting.Dictionary")

    For i = 1 To UBound(lines)
        If Trim$(lines(i)) <> "" Then
            fields = CsvParseLine(lines(i))

            sayyadi = NormalizeElectronicDigits(CsvValue(fields, idxSayyadi))
            amountText = NormalizeElectronicDigits(CsvValue(fields, idxAmount))
            chequeDate = NormalizeElectronicDigits(CsvValue(fields, idxDate))
            companyName = Trim$(CsvValue(fields, idxCompany))
            companyId = NormalizeElectronicDigits(CsvValue(fields, idxCompanyId))
            seriesText = ""
            serialText = ""
            serial12 = ""

            If idxSeries >= 0 Then seriesText = NormalizeElectronicDigits(CsvValue(fields, idxSeries))
            If idxSerial >= 0 Then serialText = NormalizeElectronicDigits(CsvValue(fields, idxSerial))

            ' Excel serial = Series (4 digits) + Serial (8 digits).
            ' Example: 2001 + 36292441 = 200136292441.
            If Len(seriesText) = 4 And Len(serialText) = 8 Then
                serial12 = seriesText & serialText
            ElseIf Len(serialText) = 12 Then
                serial12 = serialText
            End If

            statusText = "READY"

            If Len(sayyadi) <> 16 Then
                statusText = "INVALID SAYYADI"
            ElseIf Len(serial12) <> 12 Then
                statusText = "INVALID SERIES/SERIAL"
            ElseIf companyName = "" Then
                statusText = "INVALID COMPANY"
            ElseIf amountText = "" Or Not IsNumeric(amountText) Or CDbl(amountText) <= 0 Then
                statusText = "INVALID AMOUNT"
            ElseIf Not IsValidPersianDate(chequeDate) Then
                statusText = "INVALID DATE"
            Else
                rowKey = chequeDate & "|" & companyName & "|" & amountText & "|" & serial12
                If seen.exists(rowKey) Then
                    statusText = "DUPLICATE IN CSV"
                ElseIf EI_AlreadyImported(companyName, CDbl(amountText), chequeDate, serial12) Then
                    statusText = "ALREADY IMPORTED"
                ElseIf Not EI_HasFreeSlot(chequeDate) Then
                    statusText = "NO EMPTY SLOT"
                Else
                    seen.Add rowKey, True
                End If
            End If

            If statusText = "READY" Then
                readyCount = readyCount + 1
            ElseIf InStr(1, statusText, "DUPLICATE", vbTextCompare) > 0 Or statusText = "ALREADY IMPORTED" Then
                duplicateCount = duplicateCount + 1
            Else
                otherCount = otherCount + 1
            End If

            rowsToImport.Add Array(sayyadi, serial12, CDbl(val(amountText)), chequeDate, companyName, companyId, statusText)
        End If
    Next i

    If rowsToImport.count = 0 Then
        MsgBox "No cheque records were found in the CSV.", vbExclamation
        Exit Sub
    End If

    previewText = "ELECTRONIC CHEQUE IMPORT PREVIEW" & vbCrLf & String(45, "-") & vbCrLf

    For i = 1 To rowsToImport.count
        rowData = rowsToImport.item(i)
        previewText = previewText & _
            "#" & i & " | " & CStr(rowData(4)) & _
            " | Amount: " & Format(CDbl(rowData(2)), "#,##0") & _
            " | Date: " & CStr(rowData(3)) & vbCrLf & _
            "Sayyadi: " & CStr(rowData(0)) & _
            " | " & CStr(rowData(6)) & vbCrLf
    Next i

    previewText = previewText & String(45, "-") & vbCrLf & _
        "READY: " & readyCount & " | DUPLICATES: " & duplicateCount & " | OTHER: " & otherCount & vbCrLf & vbCrLf & _
        "Only READY cheques will be imported. Continue?"

    If readyCount = 0 Then
        MsgBox previewText, vbExclamation, "Electronic Cheque Import"
        Exit Sub
    End If

    If MsgBox(previewText, vbYesNo + vbQuestion, "Confirm Electronic Cheque Import") <> vbYes Then Exit Sub

    For i = 1 To rowsToImport.count
        rowData = rowsToImport.item(i)
        If CStr(rowData(6)) = "READY" Then
            If EI_WriteToExcel(CStr(rowData(4)), CDbl(rowData(2)), CStr(rowData(3)), CStr(rowData(1))) Then
                importedCount = importedCount + 1
            End If
        End If
    Next i

    If importedCount > 0 Then
        EI_ArchiveCsv importFile
        MsgBox importedCount & " electronic cheque(s) imported. The CSV was moved to Cheque Automation Results.", vbInformation
    Else
        MsgBox "No cheques were imported.", vbExclamation
    End If

    Exit Sub

ErrorHandler:
    MsgBox "Electronic cheque import error: " & Err.description, vbCritical

End Sub

Private Function EI_AlreadyImported(ByVal companyName As String, ByVal amount As Double, ByVal chequeDate As String, ByVal serial12 As String) As Boolean

    Dim ws As Worksheet, dayStartRow As Long, c As Long
    Dim numCheques As Long, firstCol As Long, lastCol As Long, totalCenters As Long, userCenters As Long, rowsPerDay As Long, blockRows As Long, lowerOffset As Long

    numCheques = ReadConfigValue("cfg_NumCheques")
    firstCol = 14
    lastCol = firstCol + (numCheques * 2) - 2
    totalCenters = ReadConfigValue("cfg_TotalCenters")
    userCenters = ReadConfigValue("cfg_ActualUserCenters")
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    blockRows = rowsPerDay + 1
    lowerOffset = rowsPerDay \ 2

    Set ws = FindSheet(Left$(chequeDate, 7))
    If ws Is Nothing Then Exit Function

    dayStartRow = FindDayRow(ws, CLng(Mid$(chequeDate, 9)), blockRows)
    If dayStartRow = 0 Then Exit Function

    For c = firstCol To lastCol Step 2
        If Trim$(CStr(ws.Cells(dayStartRow + lowerOffset, c + 1).value)) = serial12 Then
            EI_AlreadyImported = True
            Exit Function
        End If
        If Trim$(CStr(ws.Cells(dayStartRow, c).value)) = companyName And _
           val(ws.Cells(dayStartRow + lowerOffset, c).value) = amount Then
            EI_AlreadyImported = True
            Exit Function
        End If
    Next c

End Function

Private Function EI_HasFreeSlot(ByVal chequeDate As String) As Boolean

    Dim ws As Worksheet, dayStartRow As Long, c As Long
    Dim numCheques As Long, firstCol As Long, lastCol As Long, totalCenters As Long, userCenters As Long, rowsPerDay As Long, blockRows As Long

    numCheques = ReadConfigValue("cfg_NumCheques")
    firstCol = 14
    lastCol = firstCol + (numCheques * 2) - 2
    totalCenters = ReadConfigValue("cfg_TotalCenters")
    userCenters = ReadConfigValue("cfg_ActualUserCenters")
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    blockRows = rowsPerDay + 1

    Set ws = FindSheet(Left$(chequeDate, 7))
    If ws Is Nothing Then Exit Function

    dayStartRow = FindDayRow(ws, CLng(Mid$(chequeDate, 9)), blockRows)
    If dayStartRow = 0 Then Exit Function

    For c = firstCol To lastCol Step 2
        If Trim$(CStr(ws.Cells(dayStartRow, c).value)) = "" Then
            EI_HasFreeSlot = True
            Exit Function
        End If
    Next c

End Function

Private Function EI_WriteToExcel(ByVal companyName As String, ByVal amount As Double, ByVal chequeDate As String, ByVal serial12 As String) As Boolean

    Dim ws As Worksheet, dayStartRow As Long, c As Long
    Dim numCheques As Long, firstCol As Long, lastCol As Long, totalCenters As Long, userCenters As Long, rowsPerDay As Long, blockRows As Long, lowerOffset As Long

    numCheques = ReadConfigValue("cfg_NumCheques")
    firstCol = 14
    lastCol = firstCol + (numCheques * 2) - 2
    totalCenters = ReadConfigValue("cfg_TotalCenters")
    userCenters = ReadConfigValue("cfg_ActualUserCenters")
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    blockRows = rowsPerDay + 1
    lowerOffset = rowsPerDay \ 2

    Set ws = FindSheet(Left$(chequeDate, 7))
    If ws Is Nothing Then Exit Function

    dayStartRow = FindDayRow(ws, CLng(Mid$(chequeDate, 9)), blockRows)
    If dayStartRow = 0 Then Exit Function

    For c = firstCol To lastCol Step 2
        If Trim$(CStr(ws.Cells(dayStartRow, c).value)) = "" Then
            ws.Cells(dayStartRow, c).value = companyName
            ws.Cells(dayStartRow + lowerOffset, c).value = amount
            ws.Cells(dayStartRow + lowerOffset, c + 1).value = CDbl(serial12)

            Dim dateParts() As String
            dateParts = Split(chequeDate, "/")

            Call WriteLog("frmChequeManagement", "Electronic cheque import", _
                          companyName, dateParts(0), dateParts(1), dateParts(2), _
                          CStr(amount), "", "Electronic serial: " & serial12)

            EI_WriteToExcel = True
            Exit Function
        End If
    Next c

End Function

Private Sub EI_ArchiveCsv(ByVal sourceFile As String)

    Dim folderPath As String, archiveFile As String

    folderPath = CreateObject("WScript.Shell").SpecialFolders("Desktop") & "\Cheque Automation Results"
    If Len(Dir$(folderPath, vbDirectory)) = 0 Then MkDir folderPath

    archiveFile = folderPath & "\ElectronicCheque_Import_" & Format(Now, "yyyymmdd_hhnnss") & ".csv"
    Name sourceFile As archiveFile

End Sub











Private Function EI_GetLatestImportFile() As String

    Dim desktopPath As String
    Dim fileName As String
    Dim candidate As String
    Dim latestFile As String
    Dim latestTime As Date

    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")
    fileName = Dir$(desktopPath & "\ElectronicCheque_Import_*.csv")

    Do While fileName <> ""
        candidate = desktopPath & "\" & fileName

        If FileDateTime(candidate) > latestTime Then
            latestTime = FileDateTime(candidate)
            latestFile = candidate
        End If

        fileName = Dir$()
    Loop

    EI_GetLatestImportFile = latestFile

End Function


