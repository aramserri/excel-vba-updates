Attribute VB_Name = "workbookopen"
Option Explicit

  ' ============================================================
  ' MAIN STARTUP TASKS
  ' ============================================================

  Public Sub RunStartupTasks()
      On Error Resume Next

      ' Create a RAR backup every time the workbook opens.
      CreateRARBackup

      ' Check unpassed cheques only once per day.
      If ShouldCheckChequesToday() Then
          If pascheque.HasUnpassedChequesInLast3Days() Then
              pascheque.Show
          End If

          ' Save today's date as the last cheque check date.
          ThisWorkbook.Sheets("�������").Range("AC5").value = Date
      End If

      On Error GoTo 0
  End Sub


  ' ============================================================
  ' DAILY CHEQUE CHECK
  ' ============================================================

  Private Function ShouldCheckChequesToday() As Boolean
      On Error GoTo SafeExit

      Dim configSheet As Worksheet
      Dim lastCheckValue As Variant

      Set configSheet = ThisWorkbook.Sheets("�������")
      lastCheckValue = configSheet.Range("AC5").value

      ' Check if AC5 is empty, not a valid date, or older than today.
      If Not IsDate(lastCheckValue) Then
          ShouldCheckChequesToday = True
      ElseIf CDate(lastCheckValue) < Date Then
          ShouldCheckChequesToday = True
      Else
          ShouldCheckChequesToday = False
      End If

SafeExit:
  End Function


  ' ============================================================
  ' CREATE RAR BACKUP
  ' ============================================================

  Private Sub CreateRARBackup()
      On Error GoTo ErrorHandler

      Dim backupFolder As String
      Dim tempFilePath As String
      Dim rarFilePath As String
      Dim winrarPath As String
      Dim baseName As String
      Dim fileExtension As String
      Dim timestamp As String
      Dim shellCommand As String
      Dim wsh As Object

      ' Folder where backups will be saved.
      backupFolder = Environ$("USERPROFILE") & "\Desktop\Ziped Backup\"

      ' Create backup folder if it does not exist.
      If Dir$(backupFolder, vbDirectory) = "" Then
          MkDir backupFolder
      End If

      ' Workbook name without extension.
      baseName = Left$(ThisWorkbook.Name, InStrRev(ThisWorkbook.Name, ".") - 1)

      ' Workbook extension, for example .xlsm.
      fileExtension = Mid$(ThisWorkbook.Name, InStrRev(ThisWorkbook.Name, "."))

      ' Backup file timestamp.
      timestamp = Format$(Now, "yyyymmdd_hhnnss")

      ' Temporary Excel copy path.
      tempFilePath = backupFolder & baseName & "_temp_" & timestamp & fileExtension

      ' Final RAR backup path.
      rarFilePath = backupFolder & baseName & "_" & timestamp & ".rar"

      ' Find WinRAR.
      winrarPath = GetWinRARPath()

      ' If WinRAR is not installed, skip backup silently.
      If winrarPath = "" Then Exit Sub

      ' Save temporary copy of the current workbook.
      ThisWorkbook.SaveCopyAs tempFilePath

      ' WinRAR options:
      ' a     = add files to archive
      ' -ibck = run WinRAR in background
      ' -m0   = fastest mode, store only, lowest CPU usage
      ' -ep   = exclude folder path inside archive
      ' -o+   = overwrite without asking
      shellCommand = """" & winrarPath & """ a -ibck -m0 -ep -o+ " & _
                     """" & rarFilePath & """ " & _
                     """" & tempFilePath & """"

      ' Run WinRAR and wait until it finishes.
      ' Waiting is important so the temp file is not deleted too early.
      Set wsh = CreateObject("WScript.Shell")
      wsh.Run shellCommand, 0, True

      ' Delete temporary Excel copy after RAR is created.
      If Dir$(tempFilePath) <> "" Then
          Kill tempFilePath
      End If

      ' Clean old backups after creating the newest backup.
      CleanupOldBackups backupFolder, baseName

      Exit Sub

ErrorHandler:
      ' Silent fail: do not interrupt the user if backup fails.
      On Error Resume Next

      If tempFilePath <> "" Then
          If Dir$(tempFilePath) <> "" Then
              Kill tempFilePath
          End If
      End If

      On Error GoTo 0
  End Sub


  ' ============================================================
  ' FIND WINRAR
  ' ============================================================

  Private Function GetWinRARPath() As String
      Dim path64 As String
      Dim path32 As String

      path64 = "C:\Program Files\WinRAR\WinRAR.exe"
      path32 = "C:\Program Files (x86)\WinRAR\WinRAR.exe"

      If Dir$(path64) <> "" Then
          GetWinRARPath = path64
      ElseIf Dir$(path32) <> "" Then
          GetWinRARPath = path32
      Else
          GetWinRARPath = ""
      End If
  End Function


  ' ============================================================
  ' CLEAN OLD BACKUPS
  ' ============================================================

  Private Sub CleanupOldBackups(ByVal backupFolder As String, ByVal baseName As String)
      On Error GoTo ErrorHandler

      Dim todayText As String
      Dim backupFiles() As String
      Dim fileCount As Long
      Dim currentFile As String
      Dim i As Long
      Dim j As Long
      Dim tempText As String
      Dim fileDateText As String
      Dim todayBackupCount As Long
      Dim olderBackupCount As Long

      todayText = Format$(Date, "yyyymmdd")
      fileCount = 0

      ' Collect all matching backup files.
      ' Expected pattern:
      ' WorkbookName_yyyymmdd_hhnnss.rar
      currentFile = Dir$(backupFolder & baseName & "_????????_??????.rar")

      Do While currentFile <> ""
          fileCount = fileCount + 1
          ReDim Preserve backupFiles(1 To fileCount)
          backupFiles(fileCount) = currentFile
          currentFile = Dir$()
      Loop

      ' Maximum allowed backups:
      ' 3 from today + 1 from older days = 4 total.
      If fileCount <= 4 Then Exit Sub

      ' Sort backup files newest first.
      ' Because filename contains yyyymmdd_hhnnss, text sorting works correctly.
      For i = 1 To fileCount - 1
          For j = i + 1 To fileCount
              If backupFiles(j) > backupFiles(i) Then
                  tempText = backupFiles(i)
                  backupFiles(i) = backupFiles(j)
                  backupFiles(j) = tempText
              End If
          Next j
      Next i

      ' Delete extra backups.
      '
      ' Keep:
      ' - newest 3 backups from today
      ' - newest 1 backup from previous days
      For i = 1 To fileCount

          ' Extract yyyymmdd from:
          ' WorkbookName_yyyymmdd_hhnnss.rar
          fileDateText = Mid$(backupFiles(i), Len(baseName) + 2, 8)

          If fileDateText = todayText Then
              todayBackupCount = todayBackupCount + 1

              If todayBackupCount > 3 Then
                  Kill backupFolder & backupFiles(i)
              End If
          Else
              olderBackupCount = olderBackupCount + 1

              If olderBackupCount > 1 Then
                  Kill backupFolder & backupFiles(i)
              End If
          End If

      Next i

      Exit Sub

ErrorHandler:
      ' Silent fail: cleanup errors should not interrupt workbook opening.
  End Sub

