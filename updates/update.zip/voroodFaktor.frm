VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} voroodFaktor 
   Caption         =   "��� �ǘ���"
   ClientHeight    =   9814.001
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   8442.001
   OleObjectBlob   =   "voroodFaktor.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "voroodFaktor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


'========================================
' UserForm: voroodFactor (WITH LOGGING SYSTEM)
'========================================
Option Explicit

' --- Module-level variables to hold workbook configuration ---
Private m_NumCheques As Long
Private m_NumFactors As Long
Private m_TotalCenters As Long
Private m_UserCenters As Long
Private m_InDayPickerCall As Boolean
Private m_DayPickerCancelled As Boolean
Private m_IsClosing As Boolean
' --- Variables for Undo functionality ---
Private g_UndoSheet As Worksheet
Private g_UndoRow As Long, g_UndoCol As Long
Private g_OriginalCompValue As String
Private g_OriginalAmtValue As String
Private g_OriginalDaysToPayValue As String
' --- Variables for Edit mode (must be declared because of Option Explicit) ---
Private g_IsEditMode As Boolean
Private g_EditSheet As Worksheet
Private g_EditRow As Long
Private g_EditCol As Long

Private g_IsUndoAvailable As Boolean


'----------------------------------------
' Initialize form
'----------------------------------------
Private Sub UserForm_Initialize()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim i As Long
    Dim defaultMonth As Variant
    
    
    ' Read the workbook's configuration first
    If Not ReadConfiguration() Then
        MsgBox "���: ������� ���� ���� ���. ��� �������� ������ ���.", vbCritical, "���� �������"
        Unload Me
        Exit Sub
    End If
    
    On Error GoTo ErrorHandler

    Set configSheet = ThisWorkbook.Sheets("�������")

    On Error Resume Next
    defaultMonth = configSheet.Range("AC2").value
    On Error GoTo 0
    
    Dim defaultMonthstring As String
    If IsNumeric(defaultMonth) And CLng(defaultMonth) >= 1 And CLng(defaultMonth) <= 12 Then
        defaultMonthstring = CStr(CLng(defaultMonth))
    Else
        defaultMonthstring = "1"
    End If
    
' Populate ComboBox1 (CompanyList) - skip empty, sort, handle *** separator
Call PopulateCompanyComboBox
    
    ' Populate ComboBox2 (cfg_YearList)
    Me.ComboBox2.Clear
    For Each cell In configSheet.Range("G31:G34")
        If Trim(cell.value) <> "" Then Me.ComboBox2.AddItem cell.value
    Next cell

    On Error Resume Next
    Me.ComboBox2.value = CStr(ThisWorkbook.Sheets("�������").Range("cfg_DefaultYear").value)
    On Error GoTo 0

    If Me.ComboBox2.value = "" And Me.ComboBox2.ListCount > 0 Then
        Me.ComboBox2.ListIndex = 0
    End If

    ' Populate months 1-12
    Me.ComboBox3.Clear
    For i = 1 To 12
        Me.ComboBox3.AddItem CStr(i)
    Next i
    Me.ComboBox3.value = defaultMonthstring
    
    ' Set defaults and clear labels
    Me.Label7.Caption = ""
    Me.Label12.Caption = ""
    Me.CommandButton3.Enabled = False
    g_IsUndoAvailable = False
    
    ' Initialize edit mode as false
    g_IsEditMode = False
    Set g_EditSheet = Nothing
    g_EditRow = 0
    g_EditCol = 0
    
    ' Initialize ComboBox4 and ComboBox5
    Me.ComboBox4.Clear
    For Each cell In configSheet.Range("G31:G34")
        If Trim(cell.value) <> "" Then Me.ComboBox4.AddItem cell.value
    Next cell
    
    On Error Resume Next
    Me.ComboBox4.value = CStr(ThisWorkbook.Sheets("�������").Range("cfg_DefaultYear").value)
    On Error GoTo 0
    
    If Me.ComboBox4.value = "" And Me.ComboBox4.ListCount > 0 Then
        Me.ComboBox4.ListIndex = 0
    End If
    
    Me.ComboBox5.Clear
    For i = 1 To 12
        Me.ComboBox5.AddItem CStr(i)
    Next i
    Me.ComboBox5.value = defaultMonthstring
    
    ' *** NEW: Load recent activity logs ***
    Call LoadRecentActivity
    
         m_InDayPickerCall = False
         m_DayPickerCancelled = False
         m_IsClosing = False
     
    Exit Sub

ErrorHandler:
    MsgBox "An error occurred during form initialization: " & Err.description, vbCritical

End Sub

'----------------------------------------
' NEW: Load and display recent activity
'----------------------------------------
Private Sub LoadRecentActivity()
    Dim recentLogs As String
    
    On Error Resume Next
    recentLogs = GetRecentLogs("voroodFactor", 5)
    
    ' Try to update the TextBox - check if it exists first
    If Err.Number = 0 Then
        ' Check if txtRecentActivity exists as a control
        Dim ctrl As Control
        Dim found As Boolean
        found = False
        
        For Each ctrl In Me.Controls
            If ctrl.Name = "txtRecentActivity" Then
                found = True
                Exit For
            End If
        Next ctrl
        
        If found Then
            Me.txtRecentActivity.value = recentLogs
            ' Make it unlocked so user can select text
            Me.txtRecentActivity.Locked = False
        Else
            ' Optional: Show in a message box if TextBox doesn't exist
            ' MsgBox recentLogs, vbInformation, "����� �����ʝ��"
        End If
    End If
    On Error GoTo 0
End Sub

'----------------------------------------
' NEW: Load selected log entry into form - WITH EDIT MODE
'----------------------------------------
Private Sub txtRecentActivity_DblClick(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim selectedText As String
    Dim logLine As String
    Dim parts() As String
    Dim datePart As String, detailsPart As String
    Dim CompanyName As String, yearVal As String, monthVal As String, dayVal As String
    Dim amountVal As String, daysToPayVal As String
    Dim targetSheet As Worksheet
    Dim ws As Worksheet
    Dim targetDateString As String
    Dim foundCell As Range, foundRow As Long
    Dim firstFactorCol As Long, lastFactorCol As Long, col As Long
    
    On Error GoTo ErrorHandler
    
    ' Get the currently selected line or the line where cursor is
    selectedText = Me.txtRecentActivity.SelText
    
    If Len(Trim(selectedText)) = 0 Then
        MsgBox "����� � �� �� �ǐ �� ������ ����.", vbInformation, "������ �ǐ"
        Exit Sub
    End If
    
    ' Parse the log line
    ' Expected format: "1404/09/08 14:23:45 - ��� �ǘ���: �ј� | 1403/12/15 | ����: 1,000,000 | ����: 30 ���"
    If InStr(selectedText, " - ") > 0 And InStr(selectedText, ": ") > 0 Then
        ' Split by " - " to separate date/time from details
        parts = Split(selectedText, " - ", 2)
        If UBound(parts) >= 1 Then
            detailsPart = parts(1)
            
            ' Extract company name (between ": " and " | ")
            If InStr(detailsPart, ": ") > 0 And InStr(detailsPart, " | ") > 0 Then
                CompanyName = Trim(Mid(detailsPart, InStr(detailsPart, ": ") + 2, _
                                      InStr(detailsPart, " | ") - InStr(detailsPart, ": ") - 2))
                
                ' Split the rest by " | " to get all parts
                Dim allParts() As String
                allParts = Split(detailsPart, " | ")
                
                If UBound(allParts) >= 2 Then
                    ' Part 1: Date (year/month/day)
                    datePart = Trim(allParts(1))
                    Dim dateParts() As String
                    dateParts = Split(datePart, "/")
                    If UBound(dateParts) >= 2 Then
                        yearVal = dateParts(0)
                        monthVal = dateParts(1)
                        dayVal = dateParts(2)
                    End If
                    
                    ' Part 2: Amount (after "����: ")
                    If UBound(allParts) >= 2 Then
                        Dim amountPart As String
                        amountPart = Trim(allParts(2))
                        If InStr(amountPart, "����: ") > 0 Then
                            amountVal = Trim(Mid(amountPart, InStr(amountPart, "����: ") + 6))
                            ' Remove commas from amount
                            amountVal = Replace(amountVal, ",", "")
                        End If
                    End If
                    
                    ' Part 3: Days to Pay / Forjeh (after "����: ")
                    If UBound(allParts) >= 3 Then
                        Dim forjehPart As String
                        forjehPart = Trim(allParts(3))
                        If InStr(forjehPart, "����: ") > 0 Then
                            daysToPayVal = Trim(Mid(forjehPart, InStr(forjehPart, "����: ") + 6))
                            ' Remove " ���" at the end
                            daysToPayVal = Replace(daysToPayVal, " ���", "")
                            daysToPayVal = Trim(daysToPayVal)
                        End If
                    End If
                End If
            End If
        End If
        
        ' *** NEW: Find the original entry in the sheet to enable edit mode ***
        If CompanyName <> "" And yearVal <> "" And monthVal <> "" And dayVal <> "" Then
            targetDateString = yearVal & "/" & Format(CLng(monthVal), "00")
            
            ' Find the sheet
            Set targetSheet = Nothing
            For Each ws In ThisWorkbook.Worksheets
                If CStr(ws.Range("B1").value) = targetDateString Then
                    Set targetSheet = ws
                    Exit For
                End If
            Next ws
            
            If Not targetSheet Is Nothing Then
                ' Find the row for this day
                Set foundCell = targetSheet.Columns("A").Find(What:=CLng(dayVal), LookIn:=xlFormulas, LookAt:=xlWhole)
                If Not foundCell Is Nothing Then
                    foundRow = foundCell.row
                    
                    ' Find the column where this company's factor is
                    firstFactorCol = 14 + (m_NumCheques * 2) + 1
                    lastFactorCol = firstFactorCol + (m_NumFactors * 2) - 2
                    
                    For col = firstFactorCol To lastFactorCol Step 2
                        If Trim(targetSheet.Cells(foundRow, col).value) = CompanyName Then
                            ' Found the entry - store edit mode information
                            g_IsEditMode = True
                            Set g_EditSheet = targetSheet
                            g_EditRow = foundRow
                            g_EditCol = col
                            Exit For
                        End If
                    Next col
                End If
            End If
        End If
        
        ' Fill the form with extracted data
        If CompanyName <> "" Then Me.ComboBox1.value = CompanyName
        If yearVal <> "" Then Me.ComboBox2.value = yearVal
        If monthVal <> "" Then Me.ComboBox3.value = CStr(CLng(monthVal))
        If dayVal <> "" Then Me.Label7.Caption = dayVal
        If amountVal <> "" Then Me.TextBox1.value = amountVal
        If daysToPayVal <> "" Then
            ' Clean up any line breaks or extra characters
            daysToPayVal = Replace(daysToPayVal, vbCr, "")
            daysToPayVal = Replace(daysToPayVal, vbLf, "")
            daysToPayVal = Replace(daysToPayVal, vbCrLf, "")
            Me.TextBox2.value = Trim(daysToPayVal)
        End If
        
        If g_IsEditMode Then
            MsgBox "������� �ǐ �� ��� ��ѐ���� ��." & vbCrLf & _
                   "�� ��� ��� '��� �ǘ���'� ��� �ǘ��� ������ ����� ��.", vbInformation, "���� ������"
        Else
            MsgBox "������� �ǐ �� ��� ��ѐ���� ��." & vbCrLf & _
                   "�ǘ��� ���� �� ��� ���� ��� - �ǘ��� ���� ����� �����.", vbInformation, "��ѐ���� ����"
        End If
    Else
        MsgBox "���� �ǐ ���� ����� ����.", vbExclamation, "���"
    End If
    
    Exit Sub
    
ErrorHandler:
    MsgBox "��� �� ��ѐ���� �ǐ: " & Err.description, vbCritical, "���"
End Sub

' --- Helper function to read config ---
Private Function ReadConfiguration() As Boolean
    On Error Resume Next
    m_NumCheques = ThisWorkbook.names("cfg_NumCheques").RefersToRange.value
    m_NumFactors = ThisWorkbook.names("cfg_NumFactors").RefersToRange.value
    m_TotalCenters = ThisWorkbook.names("cfg_TotalCenters").RefersToRange.value
    m_UserCenters = ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.value
    
    If Err.Number <> 0 Or m_NumCheques = 0 Or m_NumFactors = 0 Or m_TotalCenters = 0 Or m_UserCenters = 0 Then
        ReadConfiguration = False
    Else
        ReadConfiguration = True
    End If
    On Error GoTo 0
End Function

'----------------------------------------
' Submit factor (CommandButton2) - WITH LOGGING AND EDIT MODE
'----------------------------------------
Private Sub CommandButton2_Click()
    Dim targetSheet As Worksheet
    Dim yy As String, mm As Integer
    Dim ws As Worksheet
    Dim targetDateString As String
    Dim foundCell As Range, foundRow As Long
    Dim comp As String
    Dim amountRaw As String, amountConverted As String
    Dim daysToPayRaw As String, daysToPayConverted As String
    Dim firstFactorCol As Long, lastFactorCol As Long, col As Long

    ' Convert numbers
    amountRaw = Trim(Me.TextBox1.value)
    amountConverted = ConvertPersianNumsToEnglish(Replace(amountRaw, ",", ""))
    
    daysToPayRaw = Trim(Me.TextBox2.value)
    daysToPayConverted = ConvertPersianNumsToEnglish(daysToPayRaw)

    ' Validation
' Validation
If Me.ComboBox1.value = "" Or Me.Label7.Caption = "" Or _
   Not IsNumeric(amountConverted) Or amountRaw = "" Or _
   Not IsNumeric(daysToPayConverted) Or daysToPayRaw = "" Then
    MsgBox "����� ���� ������ �� ���� �� ����.", vbExclamation, "����� ����"
    Exit Sub
End If

' Validate company exists in list
If Not IsValidCompany(Me.ComboBox1.value) Then
    MsgBox "�ј� '" & Me.ComboBox1.value & "' �� ���� ���� �����." & vbCrLf & vbCrLf & _
           "����� �� ���� ������ ���� �� ����� �ј� ���� ����� ����.", vbExclamation, "�ј� �������"
    Me.ComboBox1.SetFocus
    Exit Sub
End If
Call CheckAndRequestNationalID(Me.ComboBox1.value)
    comp = ComboBox1.value
    yy = ComboBox2.value
    mm = CInt(ComboBox3.value)

    ' Find the sheet
    targetDateString = yy & "/" & Format(mm, "00")
    
    Set targetSheet = Nothing
    For Each ws In ThisWorkbook.Worksheets
        If CStr(ws.Range("B1").value) = targetDateString Then
            Set targetSheet = ws
            Exit For
        End If
    Next ws
    
    If targetSheet Is Nothing Then
        MsgBox "���� �� ����� '" & targetDateString & "' �� ���� B1 ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Set foundCell = targetSheet.Columns("A").Find(What:=CLng(Me.Label7.Caption), LookIn:=xlFormulas, LookAt:=xlWhole)
    If foundCell Is Nothing Then
        MsgBox "��� '" & Me.Label7.Caption & "' ���� ���.", vbExclamation, "���"
        Exit Sub
    End If
    foundRow = foundCell.row

    firstFactorCol = 14 + (m_NumCheques * 2) + 1
    lastFactorCol = firstFactorCol + (m_NumFactors * 2) - 2

    Dim amountRowOffset As Long
    Dim rowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    amountRowOffset = rowsPerDayBlock / 2

    ' *** EDIT MODE: Update existing entry ***
    If g_IsEditMode And Not g_EditSheet Is Nothing And g_EditRow > 0 And g_EditCol > 0 Then
        ' Check if we're editing the same sheet and date
        If g_EditSheet.Name = targetSheet.Name And g_EditRow = foundRow Then
            ' Update the existing entry at the stored location
            With targetSheet
                .Cells(foundRow, g_EditCol).value = comp
                .Cells(foundRow + amountRowOffset, g_EditCol).value = CDbl(amountConverted)
                .Cells(foundRow + amountRowOffset, g_EditCol + 1).value = CLng(daysToPayConverted)
            End With
            
            ' Log the edit
            Call WriteLog("voroodFactor", "������ �ǘ���", comp, yy, CStr(mm), Me.Label7.Caption, _
                         amountConverted, daysToPayConverted, "������ ��")
            
            ' Reset edit mode
            g_IsEditMode = False
            Set g_EditSheet = Nothing
            g_EditRow = 0
            g_EditCol = 0
            
            Call LoadRecentActivity
            
            MsgBox "�ǘ��� �� ������ ������ ��.", vbInformation, "������ ��"
            TextBox1.value = "": TextBox2.value = "": TextBox1.SetFocus
            Exit Sub
        Else
            ' Different sheet or date - clear the old entry and create new
            With g_EditSheet
                .Cells(g_EditRow, g_EditCol).value = ""
                .Cells(g_EditRow + amountRowOffset, g_EditCol).value = ""
                .Cells(g_EditRow + amountRowOffset, g_EditCol + 1).value = ""
            End With
            
            g_IsEditMode = False
            Set g_EditSheet = Nothing
            ' Continue to create new entry below
        End If
    End If

    ' *** NORMAL MODE: Find empty slot and write new data ***
    For col = firstFactorCol To lastFactorCol Step 2
        If Len(Trim(targetSheet.Cells(foundRow, col).value)) = 0 Then
            ' Store Undo Information
            Set g_UndoSheet = targetSheet
            g_UndoRow = foundRow
            g_UndoCol = col
            g_OriginalCompValue = ""
            g_OriginalAmtValue = ""
            g_OriginalDaysToPayValue = ""

            ' Write the data
            With targetSheet
                .Cells(foundRow, col).value = comp
                .Cells(foundRow + amountRowOffset, col).value = CDbl(amountConverted)
                .Cells(foundRow + amountRowOffset, col + 1).value = CLng(daysToPayConverted)
            End With
            
            g_IsUndoAvailable = True
            Me.CommandButton3.Enabled = True
            
            ' Write to log
            Call WriteLog("voroodFactor", "��� �ǘ���", comp, yy, CStr(mm), Me.Label7.Caption, _
                         amountConverted, daysToPayConverted, "��� ����")
            
            Call LoadRecentActivity
            
            MsgBox "�ǘ��� �� ������ ��� ��.", vbInformation, "��� ��"
            TextBox1.value = "": TextBox2.value = ""
            Me.Label7.Caption = ""
            ComboBox1.SetFocus
            
            m_DayPickerCancelled = False
            m_InDayPickerCall = False
            
            Exit Sub
        End If
    Next col

    MsgBox "��� ��� ���� ������� �� ������.", vbExclamation, "����� ʘ���"
End Sub

'----------------------------------------
' Undo Button (CommandButton3) - WITH LOGGING
'----------------------------------------
Private Sub CommandButton3_Click()
    If Not g_IsUndoAvailable Or g_UndoSheet Is Nothing Then
        MsgBox "�� ���� ���� ��� ���� ���� �����.", vbExclamation, "���"
        Exit Sub
    End If

    Dim amountRowOffset As Long
    Dim rowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    amountRowOffset = rowsPerDayBlock / 2

    With g_UndoSheet
        .Cells(g_UndoRow, g_UndoCol).value = g_OriginalCompValue
        .Cells(g_UndoRow + amountRowOffset, g_UndoCol).value = g_OriginalAmtValue
        .Cells(g_UndoRow + amountRowOffset, g_UndoCol + 1).value = g_OriginalDaysToPayValue
    End With

    ' *** NEW: Log the undo action ***
    Call WriteLog("voroodFactor", "��� �ǘ���", "", "", "", "", "", "", "����� ������ ��� ��")
    Call LoadRecentActivity

    g_IsUndoAvailable = False
    Me.CommandButton3.Enabled = False
    MsgBox "����� �ǘ��� �� ������ ��� ��.", vbInformation, "��� ��"
End Sub

'========================================
' FIXED: CommandButton1_Click - Day Picker for Factor Date
' Uses proper cleanup pattern to ensure frmDayPicker is always unloaded
'========================================
Private Sub CommandButton1_Click()
    Dim selectedDayValue As String
    Dim yearVal As Long
    Dim monthVal As Integer
    
    ' Validate inputs BEFORE showing day picker
    If Me.ComboBox2.value = "" Or Me.ComboBox3.value = "" Then
        MsgBox "����� ��� � ��� �ǘ��� �� ������ ����.", vbExclamation, "����� ����"
        Exit Sub
    End If
    
    ' Store values locally to avoid errors during form interaction
    On Error Resume Next
    yearVal = CLng(Me.ComboBox2.value)
    monthVal = CInt(Me.ComboBox3.value)
    If Err.Number <> 0 Then
        On Error GoTo 0
        MsgBox "��� �� ������ ��� �� ���.", vbExclamation, "���"
        Exit Sub
    End If
    On Error GoTo 0
    
    ' Initialize day picker
    On Error GoTo CleanupDay
    frmDayPicker.currentYear = yearVal
    frmDayPicker.currentMonth = monthVal
    frmDayPicker.selectedDay = ""
    
    ' Show modal
    frmDayPicker.Show vbModal
    
    ' Get selected value IMMEDIATELY after modal returns
    selectedDayValue = frmDayPicker.selectedDay
    
CleanupDay:
    ' ALWAYS unload the day picker, regardless of how we got here
    On Error Resume Next
    Unload frmDayPicker
    On Error GoTo 0
    
    ' Now process the result (after cleanup is done)
    If Len(selectedDayValue) > 0 Then
        Me.Label7.Caption = selectedDayValue
    End If
End Sub
'----------------------------------------
' Format amount on exit - WITH CALCULATION
'----------------------------------------
Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    Dim result As Variant
    
    rawValue = Trim(Me.TextBox1.value)
    If rawValue = "" Then Exit Sub

    result = EvaluateExpression(rawValue)

    If IsNumeric(result) And Not IsError(result) Then
        Me.TextBox1.value = Format(CDbl(result), "#,##0")
    End If
End Sub

'----------------------------------------
' Submit factor as PAID and move to Direct Pay - WITH LOGGING
'----------------------------------------
Private Sub CommandButton5_Click()
    Dim targetSheet As Worksheet, targetSheet2 As Worksheet
    Dim yy As String, mm As Integer
    Dim yy2 As String, mm2 As Integer
    Dim ws As Worksheet
    Dim targetDateString As String, targetDateString2 As String
    Dim foundCell As Range, foundRow As Long
    Dim foundCell2 As Range, foundRow2 As Long
    Dim comp As String
    Dim amountRaw As String, amountConverted As String
    Dim daysToPayRaw As String, daysToPayConverted As String
    Dim firstFactorCol As Long, lastFactorCol As Long, col As Long
    Dim firstDirectPayCol As Long, lastDirectPayCol As Long
    Dim numCheques As Long, numFactors As Long, numDirectPays As Long
    Dim totalCenters As Long, userCenters As Long
    Dim rowsPerDay As Long, totalRowsPerDayBlock As Long, lowerHalfStartOffset As Long
    Dim statusVal As String
    Dim factorWritten As Boolean
    
    amountRaw = Trim(Me.TextBox1.value)
    amountConverted = ConvertPersianNumsToEnglish(Replace(amountRaw, ",", ""))
    
    daysToPayRaw = Trim(Me.TextBox2.value)
    daysToPayConverted = ConvertPersianNumsToEnglish(daysToPayRaw)

  If Me.ComboBox1.value = "" Or Me.Label7.Caption = "" Or _
   Not IsNumeric(amountConverted) Or amountRaw = "" Or _
   Not IsNumeric(daysToPayConverted) Or daysToPayRaw = "" Or _
   Me.ComboBox4.value = "" Or Me.ComboBox5.value = "" Or Me.Label12.Caption = "" Then
    MsgBox "����� ���� ������ �� ���� �� ���� (���� ����� ��� ���� ����).", vbExclamation, "����� ����"
    Exit Sub
End If

' Validate company exists in list
If Not IsValidCompany(Me.ComboBox1.value) Then
    MsgBox "�ј� '" & Me.ComboBox1.value & "' �� ���� ���� �����." & vbCrLf & vbCrLf & _
           "����� �� ���� ������ ���� �� ����� �ј� ���� ����� ����.", vbExclamation, "�ј� �������"
    Me.ComboBox1.SetFocus
    Exit Sub
End If

    comp = ComboBox1.value
    yy = ComboBox2.value
    mm = CInt(ComboBox3.value)
    targetDateString = yy & "/" & Format(mm, "00")
    
    yy2 = ComboBox4.value
    mm2 = CInt(ComboBox5.value)
    targetDateString2 = yy2 & "/" & Format(mm2, "00")
    
    statusVal = Trim(ThisWorkbook.Sheets("�������").Range("D1").value)
    If statusVal = "" Then
        MsgBox "����� ����� ������ �� ���� D1 ��� ������� ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    numCheques = m_NumCheques
    numFactors = m_NumFactors
    
    On Error Resume Next
    numDirectPays = ThisWorkbook.names("cfg_NumDirectPays").RefersToRange.value
    If Err.Number <> 0 Or numDirectPays = 0 Then
        MsgBox "���: ����� ������ (cfg_NumDirectPays) �� ���� ���� ���.", vbCritical
        Exit Sub
    End If
    On Error GoTo 0
    
    totalCenters = m_TotalCenters
    userCenters = m_UserCenters
    
    firstFactorCol = 14 + (numCheques * 2) + 1
    lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    firstDirectPayCol = lastFactorCol + 2 + 1
    lastDirectPayCol = firstDirectPayCol + numDirectPays - 1
    
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    totalRowsPerDayBlock = rowsPerDay + 1
    lowerHalfStartOffset = rowsPerDay \ 2

    Set targetSheet = Nothing
    For Each ws In ThisWorkbook.Worksheets
        If CStr(ws.Range("B1").value) = targetDateString Then
            Set targetSheet = ws
            Exit For
        End If
    Next ws
    
    If targetSheet Is Nothing Then
        MsgBox "���� �� ����� '" & targetDateString & "' �� ���� B1 ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Set foundCell = targetSheet.Columns("A").Find(What:=CLng(Me.Label7.Caption), LookIn:=xlFormulas, LookAt:=xlWhole)
    If foundCell Is Nothing Then
        MsgBox "��� '" & Me.Label7.Caption & "' �� ��� ��� ���� ���.", vbExclamation, "���"
        Exit Sub
    End If
    foundRow = foundCell.row

    factorWritten = False
    For col = firstFactorCol To lastFactorCol Step 2
        If Len(Trim(targetSheet.Cells(foundRow, col).value)) = 0 Then
            With targetSheet
                .Cells(foundRow, col).value = comp
                .Cells(foundRow, col + 1).value = statusVal
                .Cells(foundRow + lowerHalfStartOffset, col).value = CDbl(amountConverted)
                .Cells(foundRow + lowerHalfStartOffset, col + 1).value = CLng(daysToPayConverted)
            End With
            factorWritten = True
            Exit For
        End If
    Next col
    
    If Not factorWritten Then
        MsgBox "��� ��� ���� ������� �� ������.", vbExclamation, "����� ʘ���"
        Exit Sub
    End If

    Set targetSheet2 = Nothing
    For Each ws In ThisWorkbook.Worksheets
        If CStr(ws.Range("B1").value) = targetDateString2 Then
            Set targetSheet2 = ws
            Exit For
        End If
    Next ws
    
    If targetSheet2 Is Nothing Then
        MsgBox "���� �� ����� '" & targetDateString2 & "' ���� ���� ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Set foundCell2 = targetSheet2.Columns("A").Find(What:=CLng(Me.Label12.Caption), LookIn:=xlFormulas, LookAt:=xlWhole)
    If foundCell2 Is Nothing Then
        MsgBox "��� '" & Me.Label12.Caption & "' �� ��� ��� ���� ���.", vbExclamation, "���"
        Exit Sub
    End If
    foundRow2 = foundCell2.row

    For col = firstDirectPayCol To lastDirectPayCol
        If Trim(targetSheet2.Cells(foundRow2, col).value) = "" Then
            targetSheet2.Cells(foundRow2, col).value = comp
            targetSheet2.Cells(foundRow2 + lowerHalfStartOffset, col).value = CDbl(amountConverted)
            
            ' *** NEW: Write to log ***
            Call WriteLog("voroodFactor", "��� �ǘ��� �����ʝ���", comp, yy, CStr(mm), Me.Label7.Caption, _
                         amountConverted, daysToPayConverted, _
                         "����: " & yy2 & "/" & mm2 & "/" & Me.Label12.Caption)
            
            ' *** NEW: Refresh activity display ***
            Call LoadRecentActivity
            
            MsgBox "�ǘ��� �� ������ ��� �� (�����ʝ���) � �� ����� ���� ����� ��.", vbInformation, "��� ��"
            TextBox1.value = "": TextBox2.value = ""
            Me.Label7.Caption = ""   ' <-- ADD THIS LINE
            Me.Label12.Caption = ""  ' <-- Also clear the second date
'            TextBox1.SetFocus
                        ComboBox1.SetFocus

            m_DayPickerCancelled = False
            m_InDayPickerCall = False
            Exit Sub
        End If
    Next col

    MsgBox "��� ���� ���� ������� �� ������.", vbExclamation, "����� ʘ���"
End Sub
'----------------------------------------
' Add New Company (CommandButton6) - Insert above *** separator
'----------------------------------------
Private Sub CommandButton6_Click()
    Dim configSheet As Worksheet
    Dim lastRow As Long
    Dim cell As Range
    Dim separatorRow As Long
    Dim insertRow As Long
    Dim emptyRowAboveSeparator As Long
    Dim i As Long
    
    With frmNewCompany
        .Show
        
        If .Cancelled Then
            Unload frmNewCompany
            Exit Sub
        End If
        
        Set configSheet = ThisWorkbook.Sheets("�������")
        
        ' Check if company already exists
        lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
        For Each cell In configSheet.Range("A2:A" & lastRow)
            If Len(Trim(cell.value)) > 0 And Trim(cell.value) <> "***" Then
                If LCase(Trim(cell.value)) = LCase(Trim(.CompanyName)) Then
                    MsgBox "��� �ј� ����� �� ���� ���� ����.", vbExclamation, "ʘ����"
                    Me.ComboBox1.value = cell.value
                    Unload frmNewCompany
                    Exit Sub
                End If
            End If
        Next cell
        
        ' Find the *** separator row
        separatorRow = 0
        For Each cell In configSheet.Range("A2:A" & lastRow)
            If Trim(cell.value) = "***" Then
                separatorRow = cell.row
                Exit For
            End If
        Next cell
        
        ' Determine where to insert
        If separatorRow > 0 Then
            ' *** exists - find empty row above it or make space
            emptyRowAboveSeparator = 0
            
            ' Look for empty cell above separator (between row 2 and separator)
            For i = separatorRow - 1 To 2 Step -1
                If Len(Trim(configSheet.Cells(i, "A").value)) = 0 Then
                    emptyRowAboveSeparator = i
                    Exit For
                End If
            Next i
            
            If emptyRowAboveSeparator > 0 Then
                ' Found empty row - use it
                insertRow = emptyRowAboveSeparator
            Else
                ' No empty row - move *** and everything below down 5 rows
                Call MoveDataDown(configSheet, separatorRow, 5)
                ' Insert in the row just before where *** was
                insertRow = separatorRow
            End If
        Else
            ' No *** separator - just add at the end
            insertRow = lastRow + 1
        End If
        
        ' Add the new company
        configSheet.Cells(insertRow, "A").value = .CompanyName
        configSheet.Cells(insertRow, "B").value = .NationalID
        
        ' Refresh ComboBox1
        Call PopulateCompanyComboBox
        
        ' Select the new company
        Me.ComboBox1.value = .CompanyName
        
        ' Log the action
        Call WriteLog("voroodFactor", "������ �ј�", .CompanyName, "", "", "", "", "", "�����: " & .NationalID)
        Call LoadRecentActivity
        
        MsgBox "�ј� '" & .CompanyName & "' �� ������ ����� ��.", vbInformation, "������ �ј�"
    End With
    
    Unload frmNewCompany
End Sub

'----------------------------------------
' Move data down within column A and B (not inserting rows)
' Moves from startRow to end of data, down by numRows
'----------------------------------------
Private Sub MoveDataDown(ws As Worksheet, startRow As Long, numRows As Long)
    Dim lastRow As Long
    Dim i As Long
    Dim colA_Value As Variant
    Dim colB_Value As Variant
    
    ' Find the actual last row with data in column A
    lastRow = ws.Cells(ws.rows.count, "A").End(xlUp).row
    
    ' Move data from bottom to top (to avoid overwriting)
    For i = lastRow To startRow Step -1
        ' Read values
        colA_Value = ws.Cells(i, "A").value
        colB_Value = ws.Cells(i, "B").value
        
        ' Write to new position (numRows below)
        ws.Cells(i + numRows, "A").value = colA_Value
        ws.Cells(i + numRows, "B").value = colB_Value
        
        ' Clear original cells
        ws.Cells(i, "A").ClearContents
        ws.Cells(i, "B").ClearContents
    Next i
End Sub

'========================================
' FIXED: CommandButton4_Click - Day Picker for Cash Payment Date
' Uses proper cleanup pattern to ensure frmDayPicker is always unloaded
'========================================
Private Sub CommandButton4_Click()
    Dim selectedDayValue As String
    Dim yearVal As Long
    Dim monthVal As Integer
    
    ' Validate inputs BEFORE showing day picker
    If Me.ComboBox4.value = "" Or Me.ComboBox5.value = "" Then
        MsgBox "����� ��� � ��� ���� �� ������ ����.", vbExclamation, "����� ����"
        Exit Sub
    End If
    
    ' Store values locally to avoid errors during form interaction
    On Error Resume Next
    yearVal = CLng(Me.ComboBox4.value)
    monthVal = CInt(Me.ComboBox5.value)
    If Err.Number <> 0 Then
        On Error GoTo 0
        MsgBox "��� �� ������ ��� �� ���.", vbExclamation, "���"
        Exit Sub
    End If
    On Error GoTo 0
    
    ' Initialize day picker
    On Error GoTo CleanupDay
    frmDayPicker.currentYear = yearVal
    frmDayPicker.currentMonth = monthVal
    frmDayPicker.selectedDay = ""
    
    ' Show modal
    frmDayPicker.Show vbModal
    
    ' Get selected value IMMEDIATELY after modal returns
    selectedDayValue = frmDayPicker.selectedDay
    
CleanupDay:
    ' ALWAYS unload the day picker, regardless of how we got here
    On Error Resume Next
    Unload frmDayPicker
    On Error GoTo 0
    
    ' Now process the result (after cleanup is done)
    If Len(selectedDayValue) > 0 Then
        Me.Label12.Caption = selectedDayValue
    End If
Me.CommandButton5.SetFocus
End Sub


'----------------------------------------
' ComboBox1 Change - Handle separator and clear days
'----------------------------------------
Private Sub ComboBox1_Change()
    ' Prevent selecting the separator line
    If Me.ComboBox1.value = "-------------" Then
        Me.ComboBox1.value = ""
        Me.ComboBox1.DropDown
        Exit Sub
    End If
    
    ' Clear days and reset cancelled flag when company changes
    Static previousCompany As String
    
    If previousCompany <> "" And previousCompany <> Me.ComboBox1.value Then
        Me.Label7.Caption = ""
        Me.Label12.Caption = ""
        m_DayPickerCancelled = False  ' Reset so auto-open works for new company
    End If
    
    previousCompany = Me.ComboBox1.value
End Sub



'----------------------------------------
' Check if company has National ID, if not ask for it
'----------------------------------------
Private Sub CheckAndRequestNationalID(CompanyName As String)
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim companyRow As Long
    Dim NationalID As String
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then Exit Sub
    If Len(Trim(CompanyName)) = 0 Then Exit Sub
    
    ' Find the company in column A
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
    companyRow = 0
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Trim(cell.value) = CompanyName Then
            companyRow = cell.row
            Exit For
        End If
    Next cell
    
    ' Company not found
    If companyRow = 0 Then Exit Sub
    
    ' Check National ID in column B
    NationalID = Trim(configSheet.Cells(companyRow, "B").value)
    
    ' If empty, ask for it using custom form
    If Len(NationalID) = 0 Then
        With frmNationalID
            .CompanyName = CompanyName
            .Show vbModal
            
            If Not .Cancelled And Len(.NationalID) > 0 Then
                ' Save to sheet (as text to preserve leading zeros)
                configSheet.Cells(companyRow, "B").NumberFormat = "@"
                configSheet.Cells(companyRow, "B").value = .NationalID
                
                MsgBox "����� ��� '" & .NationalID & "' ���� '" & CompanyName & "' ����� ��.", _
                       vbInformation, "����� ��"
            End If
        End With
        
        Unload frmNationalID
    End If
End Sub



Private Sub TextBox1_Enter()
    SetKeyboardEnglish
End Sub
Private Sub TextBox2_Enter()
    SetKeyboardEnglish
End Sub


'----------------------------------------
' Helper functions
'----------------------------------------
Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    result = inputText
    
    result = Replace(result, ChrW(1776), "0")
    result = Replace(result, ChrW(1777), "1")
    result = Replace(result, ChrW(1778), "2")
    result = Replace(result, ChrW(1779), "3")
    result = Replace(result, ChrW(1780), "4")
    result = Replace(result, ChrW(1781), "5")
    result = Replace(result, ChrW(1782), "6")
    result = Replace(result, ChrW(1783), "7")
    result = Replace(result, ChrW(1784), "8")
    result = Replace(result, ChrW(1785), "9")
    
    ConvertPersianNumsToEnglish = result
End Function

Private Function EvaluateExpression(ByVal expr As String) As Variant
    Dim cleanedExpr As String
    
    cleanedExpr = Trim(expr)
    If cleanedExpr = "" Then
        EvaluateExpression = CVErr(xlErrNA)
        Exit Function
    End If
    
    cleanedExpr = ConvertPersianNumsToEnglish(cleanedExpr)
    cleanedExpr = Replace(cleanedExpr, ",", "")
    
    On Error Resume Next
    EvaluateExpression = Application.Evaluate(cleanedExpr)
    On Error GoTo 0
End Function
Private Sub ComboBox1_Enter()
SetKeyboardPersian
    With Me.ComboBox1
        .SelStart = 0
        .SelLength = Len(.Text)
    End With
End Sub

'----------------------------------------
' Populate ComboBox1 with company names
' Skip empty cells, sort alphabetically, handle *** separator
'----------------------------------------
Private Sub PopulateCompanyComboBox()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim i As Long, j As Long
    Dim tempVal As String
    Dim foundSeparator As Boolean
    
    ' Arrays for companies and others
    Dim companyArr() As String
    Dim otherArr() As String
    Dim companyCount As Long
    Dim otherCount As Long
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        MsgBox "���: ��� ������� ���� ���.", vbCritical
        Exit Sub
    End If
    
    Me.ComboBox1.Clear
    
    ' Find last row
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
    If lastRow < 2 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' First pass: count items
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
            Else
                otherCount = otherCount + 1
            End If
        End If
    Next cell
    
    ' Initialize arrays
    If companyCount > 0 Then ReDim companyArr(1 To companyCount)
    If otherCount > 0 Then ReDim otherArr(1 To otherCount)
    
    ' Second pass: fill arrays
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
                companyArr(companyCount) = GetCompanyName(cell.value)
            Else
                otherCount = otherCount + 1
                otherArr(otherCount) = GetCompanyName(cell.value)
            End If
        End If
    Next cell
    
    ' Sort company array (Bubble Sort)
    If companyCount > 1 Then
        For i = 1 To companyCount - 1
            For j = i + 1 To companyCount
                If StrComp(companyArr(i), companyArr(j), vbTextCompare) > 0 Then
                    tempVal = companyArr(i)
                    companyArr(i) = companyArr(j)
                    companyArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Sort other array (Bubble Sort)
    If otherCount > 1 Then
        For i = 1 To otherCount - 1
            For j = i + 1 To otherCount
                If StrComp(otherArr(i), otherArr(j), vbTextCompare) > 0 Then
                    tempVal = otherArr(i)
                    otherArr(i) = otherArr(j)
                    otherArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Add companies to ComboBox
    For i = 1 To companyCount
        Me.ComboBox1.AddItem companyArr(i)
    Next i
    
    ' Add separator and others if exists
    If otherCount > 0 Then
        Me.ComboBox1.AddItem "-------------"
        For i = 1 To otherCount
            Me.ComboBox1.AddItem otherArr(i)
        Next i
    End If
    
    If Me.ComboBox1.ListCount = 0 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical
    End If
End Sub

'----------------------------------------
' Check if company exists in ComboBox1 list
'----------------------------------------
Private Function IsValidCompany(CompanyName As String) As Boolean
    Dim i As Long
    
    IsValidCompany = False
    
    If Len(Trim(CompanyName)) = 0 Then Exit Function
    
    ' Check if it's the separator
    If CompanyName = "-------------" Then Exit Function
    
    ' Check if company exists in the list
    For i = 0 To Me.ComboBox1.ListCount - 1
        If Me.ComboBox1.List(i) = CompanyName Then
            IsValidCompany = True
            Exit Function
        End If
    Next i
End Function

'----------------------------------------
' ComboBox1 Exit - Validate company and check National ID
'----------------------------------------

Private Sub ComboBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    ' *** CRITICAL: Don't do anything if form is closing ***
    If m_IsClosing Then Exit Sub
    
    If Me.ComboBox1.value = "" Then Exit Sub
    
    ' Prevent re-entry from focus changes
    If m_InDayPickerCall Then Exit Sub
    
    ' If user cancelled day picker last time, don't auto-open again
    If m_DayPickerCancelled Then Exit Sub
    
    ' Validate company exists
    If Not IsValidCompany(Me.ComboBox1.value) Then
        MsgBox "�ј� '" & Me.ComboBox1.value & "' �� ���� ���� �����." & vbCrLf & vbCrLf & _
               "����� �� ���� ������ ���� �� ����� �ј� ���� ����� ����.", vbExclamation, "�ј� �������"
        CANCEL = True
        Exit Sub
    End If
    
    ' Open day picker only if day not already selected
    If Me.Label7.Caption = "" Then
        m_InDayPickerCall = True
        DoEvents
        
        Call CommandButton1_Click
        
        DoEvents
        m_InDayPickerCall = False
        
        ' If user closed without selecting, mark as cancelled
        If Me.Label7.Caption = "" Then
            m_DayPickerCancelled = True
        End If
    End If
End Sub

'========================================
' IMPROVED: UserForm_QueryClose - Better cleanup
'========================================
Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
    ' Set flag FIRST - before any cleanup that might trigger events
    m_IsClosing = True
    
    ' Ensure day picker is cleaned up when this form closes
    On Error Resume Next
    If IsFormLoaded("frmDayPicker") Then
        Unload frmDayPicker
    End If
    If IsFormLoaded("frmNationalID") Then
        Unload frmNationalID
    End If
    If IsFormLoaded("frmNewCompany") Then
        Unload frmNewCompany
    End If
    On Error GoTo 0
End Sub

'========================================
' HELPER: Check if a UserForm is loaded
'========================================
Private Function IsFormLoaded(formName As String) As Boolean
    Dim frm As Object
    
    On Error Resume Next
    For Each frm In VBA.UserForms
        If frm.Name = formName Then
            IsFormLoaded = True
            Exit Function
        End If
    Next frm
    On Error GoTo 0
    
    IsFormLoaded = False
End Function

'----------------------------------------
' TextBox2 Exit - Parse forjeh or date format
'----------------------------------------
Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    Dim convertedValue As String
    Dim calculatedDays As Long
    
    rawValue = Trim(Me.TextBox2.value)
    If rawValue = "" Then Exit Sub
    
    ' Convert Persian numbers to English
    convertedValue = ConvertPersianNumsToEnglish(rawValue)
    
    ' Check if it's a date format (contains /)
    If InStr(convertedValue, "/") > 0 Then
        ' Try to parse as date and calculate days
        calculatedDays = CalculateDaysFromDate(convertedValue)
        
        If calculatedDays >= 0 Then
            ' Valid date - show calculated days
            Me.TextBox2.value = CStr(calculatedDays)
        Else
            ' Invalid date format
            MsgBox "���� ����� ������� ���." & vbCrLf & _
                   "����� �� ���� yyyy/mm/dd ������� ���� �� ����� ��� �� ���� ����.", _
                   vbExclamation, "���� ����"
            CANCEL = True
        End If
    ElseIf IsNumeric(convertedValue) Then
        ' It's a number - keep as is
        Me.TextBox2.value = convertedValue
    Else
        ' Invalid input
        MsgBox "����� ����� ��� (���) �� ����� (yyyy/mm/dd) ���� ����.", _
               vbExclamation, "����� �������"
        CANCEL = True
    End If
End Sub

'----------------------------------------
' Calculate days between factor date and payment date
'----------------------------------------
Private Function CalculateDaysFromDate(dateString As String) As Long
    Dim dateParts() As String
    Dim targetYear As Long, targetMonth As Long, targetDay As Long
    Dim factorYear As Long, factorMonth As Long, factorDay As Long
    Dim targetJDN As Long, factorJDN As Long
    
    On Error GoTo ErrorHandler
    
    ' Parse the input date
    dateParts = Split(dateString, "/")
    If UBound(dateParts) <> 2 Then
        CalculateDaysFromDate = -1
        Exit Function
    End If
    
    targetYear = CLng(Trim(dateParts(0)))
    targetMonth = CLng(Trim(dateParts(1)))
    targetDay = CLng(Trim(dateParts(2)))
    
    ' Validate date components
    If targetYear < 1300 Or targetYear > 1500 Or _
       targetMonth < 1 Or targetMonth > 12 Or _
       targetDay < 1 Or targetDay > 31 Then
        CalculateDaysFromDate = -1
        Exit Function
    End If
    
    ' Get factor date from form
    If Me.ComboBox2.value = "" Or Me.ComboBox3.value = "" Or Me.Label7.Caption = "" Then
        MsgBox "����� ����� ����� �ǘ��� �� ������ ����.", vbExclamation, "����� �ǘ���"
        CalculateDaysFromDate = -1
        Exit Function
    End If
    
    factorYear = CLng(Me.ComboBox2.value)
    factorMonth = CLng(Me.ComboBox3.value)
    factorDay = CLng(Me.Label7.Caption)
    
    ' Convert both dates to Julian Day Number for accurate calculation
    targetJDN = JalaliToJDN(targetYear, targetMonth, targetDay)
    factorJDN = JalaliToJDN(factorYear, factorMonth, factorDay)
    
    ' Calculate difference
    CalculateDaysFromDate = targetJDN - factorJDN
    
    ' Validate result
    If CalculateDaysFromDate < 0 Then
        MsgBox "����� ������ �������� ��� �� ����� �ǘ��� ����.", vbExclamation, "���� �����"
        CalculateDaysFromDate = -1
    End If
    
    Exit Function
    
ErrorHandler:
    CalculateDaysFromDate = -1
End Function

'----------------------------------------
' Convert Jalali date to Julian Day Number
'----------------------------------------
Private Function JalaliToJDN(jYear As Long, jMonth As Long, jDay As Long) As Long
    Dim epbase As Long, epyear As Long
    Dim mdays As Long
    
    ' Adjust for leap years
    epbase = jYear - IIf(jYear >= 0, 474, 473)
    epyear = 474 + (epbase Mod 2820)
    
    ' Calculate month days
    If jMonth <= 7 Then
        mdays = (jMonth - 1) * 31
    Else
        mdays = (jMonth - 1) * 30 + 6
    End If
    
    JalaliToJDN = jDay + mdays + _
                  Int((epyear * 682 - 110) / 2816) + _
                  (epyear - 1) * 365 + _
                  Int(epbase / 2820) * 1029983 + _
                  (1948320 - 1)
End Function


