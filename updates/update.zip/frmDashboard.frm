VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmDashboard 
   Caption         =   "���� ��������"
   ClientHeight    =   11403
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   18144
   OleObjectBlob   =   "frmDashboard.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmDashboard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False




Option Explicit

'====================================================================================================
'                                    DASHBOARD FORM - ��� �������
'====================================================================================================
' This form displays:
' - Total factors and cheques (�� �ǘ����� � �����)
' - Unpaid factors and uncleared cheques (�ǘ������ �����ʝ���� � ������ ��ӝ����)
' - Breakdown by company with weighted average due date (������ �� �ݘ� �ј� �� ������ ����� ������)
' - Sort by due date to prioritize payments (���ȝ���� �� ���� ������ ���� �����ʝ���� ������)
'====================================================================================================
'====================================================================================================
'                                    CASH FLOW FORECAST VARIABLES
'====================================================================================================
Private m_AvgDailySales As Double
'====================================================================================================
'                                    CONFIGURATION HELPER
'====================================================================================================

'----------------------------------------
' Read configuration value from named range
' ������ ����� ������� �� ������ ��㝐���� ���
'----------------------------------------
Private Function ReadConfigValue(configName As String) As Long
    On Error Resume Next
    Dim val As Variant
    val = ThisWorkbook.Sheets("�������").Range(configName).value
    If IsNumeric(val) Then
        ReadConfigValue = CLng(val)
    Else
        ReadConfigValue = 0
    End If
    On Error GoTo 0
End Function

'====================================================================================================
'                                    PERSIAN CALENDAR FUNCTIONS
'                                    ����� ����� ����
'====================================================================================================

'----------------------------------------
' Get days in a Persian month
' ����� ������ � ��� ����
'----------------------------------------
Private Function GetPersianMonthDays(pYear As Long, pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        GetPersianMonthDays = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        GetPersianMonthDays = 30
    ElseIf pMonth = 12 Then
        ' Leap year check - ����� ��� �����
        If ((pYear - 1403) Mod 4 = 0) Then
            GetPersianMonthDays = 30
        Else
            GetPersianMonthDays = 29
        End If
    Else
        GetPersianMonthDays = 0
    End If
End Function

'----------------------------------------
' Convert Persian date (year, month, day) to Gregorian date
' ����� ����� ���� �� ������
'----------------------------------------
Private Function PersianToGregorianDate(pYear As Long, pMonth As Long, pDay As Long) As Date
    Dim i As Long, total_days As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 20) ' 1403/01/01
    
    total_days = 0
    
    ' Add days for complete months - ������ ������ ����
    For i = 1 To pMonth - 1
        total_days = total_days + GetPersianMonthDays(pYear, i)
    Next i
    
    ' Add remaining days - ������ ���������
    total_days = total_days + pDay - 1
    
    ' Adjust for year difference - ����� ���� ������ ���
    If pYear > 1403 Then
        For i = 1403 To pYear - 1
            total_days = total_days + IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    ElseIf pYear < 1403 Then
        For i = pYear To 1402
            total_days = total_days - IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    End If
    
    PersianToGregorianDate = ref_g_date + total_days
End Function

'----------------------------------------
' Convert Gregorian date to Persian date string
' ����� ����� ������ �� ����
'----------------------------------------
Private Function GregorianToPersian(gDate As Date) As String
    Dim days_diff As Long, p_y As Long, p_m As Long, p_d As Long, days_in_p_year As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 20)
    
    days_diff = gDate - ref_g_date
    p_y = 1403
    
    If days_diff < 0 Then
        Do
            p_y = p_y - 1
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            days_diff = days_diff + days_in_p_year
            If days_diff >= 0 Then Exit Do
        Loop
    Else
        Do
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            If days_diff >= days_in_p_year Then
                days_diff = days_diff - days_in_p_year
                p_y = p_y + 1
            Else
                Exit Do
            End If
        Loop
    End If
    
    p_m = 1
    Do While p_m <= 12
        Dim p_days_in_month As Long
        p_days_in_month = GetPersianMonthDays(p_y, p_m)
        If days_diff < p_days_in_month Then Exit Do
        days_diff = days_diff - p_days_in_month
        p_m = p_m + 1
    Loop
    
    p_d = days_diff + 1
    GregorianToPersian = p_y & "/" & Format(p_m, "00") & "/" & Format(p_d, "00")
End Function

'----------------------------------------
' Convert Persian date string to sortable Gregorian date
' Returns a very late date for "-" or invalid dates (to put at end of sorted list)
' ����� ���� ����� ���� �� ����� ���� ���ȝ����
'----------------------------------------
Private Function GetSortableDate(dateStr As String) As Date
    On Error GoTo InvalidDate
    
    If dateStr = "-" Or Trim(dateStr) = "" Then
        GetSortableDate = DateSerial(2099, 12, 31)
        Exit Function
    End If
    
    Dim parts() As String
    parts = Split(dateStr, "/")
    
    If UBound(parts) <> 2 Then
        GetSortableDate = DateSerial(2099, 12, 31)
        Exit Function
    End If
    
    GetSortableDate = PersianToGregorianDate(CLng(parts(0)), CLng(parts(1)), CLng(parts(2)))
    Exit Function
    
InvalidDate:
    GetSortableDate = DateSerial(2099, 12, 31)
End Function






Private Sub Textbox_BankBalance_Enter()
SetKeyboardEnglish
End Sub

Private Sub txtoffdays_Enter()
SetKeyboardEnglish
End Sub


Private Sub txtunclearedcheques_Enter()
SetKeyboardEnglish
End Sub

'====================================================================================================
'                                    FORM INITIALIZATION
'                                    �������� ����� ���
'====================================================================================================

Private Sub UserForm_Initialize()
    Dim i As Long
    

    ' --- Populate Year ListBox (multi-select) ---
    ' �� ���� ���� �����
    ListBox1.Clear
    ListBox1.MultiSelect = fmMultiSelectMulti
    On Error Resume Next
    Dim yearList As Variant
    yearList = ThisWorkbook.Sheets("�������").Range("cfg_YearList").value
    If IsArray(yearList) Then
        Dim y As Long
        For y = LBound(yearList) To UBound(yearList)
            If Trim(yearList(y, 1)) <> "" Then
                ListBox1.AddItem yearList(y, 1)
            End If
        Next y
    End If
    On Error GoTo 0
    
    ' --- Populate Month ListBox (multi-select) ---
    ' �� ���� ���� �����
    ListBox2.Clear
    ListBox2.MultiSelect = fmMultiSelectMulti
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    For i = 0 To 11
        ListBox2.AddItem monthNames(i)
    Next i
    
    ' --- Populate Company ListBox (multi-select) ---
    ' �� ���� ���� �јʝ��
    ListBox3.Clear
    ListBox3.MultiSelect = fmMultiSelectMulti
    On Error Resume Next
    Dim wsInfo As Worksheet
    Set wsInfo = ThisWorkbook.Sheets("�������")
    Dim lastRow As Long
    lastRow = wsInfo.Cells(wsInfo.rows.count, "A").End(xlUp).row
    Dim c As Long
    For c = 2 To lastRow
        Dim compName As String
        compName = CleanCompanyName(wsInfo.Cells(c, "A").value)
        If compName <> "" And compName <> "***" Then
            ListBox3.AddItem compName
        End If
    Next c
    On Error GoTo 0
    
    ' --- Initialize result ListBox with 6 columns ---
    ' �������� ���� ����� �� � ����
    ' Columns: Company | Total Factors | Unpaid Factors | Total Cheques | Uncleared Cheques | Avg Due Date
    ' ������: �ј� | �� �ǘ��� | �ǘ��� �����ʝ���� | �� �� | �� ��ӝ���� | ������ ������
    ListBox4.Clear
    ListBox4.ColumnCount = 6
    ListBox4.ColumnWidths = "100;85;85;85;85;75"
    
    ' --- Initialize summary labels ---
    ' �������� �э�ȝ��� �����
    On Error Resume Next
    Label_TotalFactors.Caption = "0"
    Label_TotalUnpaidFactors.Caption = "0"
    Label_TotalCheques.Caption = "0"
    Label_TotalUnclearedCheques.Caption = "0"
    Label_Balance.Caption = "0"
    On Error GoTo 0
    
    '--- Initialize Cash Flow Forecast Controls ---
    ' Set default month selection to current month
    Dim defaultMonth As Long
    On Error Resume Next
    defaultMonth = CLng(ThisWorkbook.Sheets("�������").Range("cfg_DefaultMonth").value)
    On Error GoTo 0
    
    If defaultMonth >= 1 And defaultMonth <= 12 Then
        ListBox2.Selected(defaultMonth - 1) = True
    End If
    
    ' Initialize Listbox_next30days
    On Error Resume Next
    With Listbox_next30days
        .ColumnCount = 2
        .ColumnWidths = "110;180"
        .Clear
    End With
    On Error GoTo 0
    
    ' Initialize Label_MonthAverage
    On Error Resume Next
    Label_MonthAverage.Caption = "0"
    On Error GoTo 0
    
    ' Calculate initial month average
    Call UpdateMonthAverage
    
    '--- Set default date to today's Persian date ---
    Dim todayPersian As String
    todayPersian = GregorianToPersian(Date)
    Me.Textbox_DateForCheque.value = todayPersian
    
    '--- Set Page1 as the active page ---
    On Error Resume Next
    Me.MultiPage1.value = 0  ' 0 = Page1, 1 = Page2
    On Error GoTo 0
    Call LoadExpensesFromSheet
    Me.txtpercent.ControlTipText = "���� ���� �� ������ ����� (�� ���� ������ �� �ǘӡ ���� ���� ��� �� ���� ����. �� ���� ������ � ���� ���� ���� : ���� ��ԝ���: 30)"
    Me.txtoffdays.ControlTipText = "����� ������ ����� ��� �� �� �� � ����� ���� ����. ���� ���� 1 13 19"
    Me.txtsalarydate.ControlTipText = "��� ���� ����"
    Me.txtinstallment1date.ControlTipText = "��� ���� ����"
    Me.txtinstallment2date.ControlTipText = "��� ���� ����"
    Me.txtinsurancedate.ControlTipText = "��� ���� ����"
    Me.txtotherexpensesdate.ControlTipText = "��� ���� ����"
    Me.txtrent1date.ControlTipText = "��� ���� ����"
    Me.txtrent2date.ControlTipText = "��� ���� ����"

End Sub

'====================================================================================================
'                                    HELPER FUNCTIONS
'                                    ����� ���
'====================================================================================================

'----------------------------------------
' Get selected items from ListBox as Collection
' ������ ������� ������ ��� �� ���ʝ�ǘ�
'----------------------------------------
Private Function GetSelectedItems(lb As MSForms.ListBox) As Collection
    Dim col As New Collection
    Dim i As Long
    For i = 0 To lb.ListCount - 1
        If lb.Selected(i) Then
            col.Add lb.List(i)
        End If
    Next i
    Set GetSelectedItems = col
End Function

'----------------------------------------
' Check if value is in collection
' ����� ���� ����� �� �����
'----------------------------------------
Private Function IsInCollection(col As Collection, val As Variant) As Boolean
    Dim item As Variant
    For Each item In col
        If CStr(item) = CStr(val) Then
            IsInCollection = True
            Exit Function
        End If
    Next item
    IsInCollection = False
End Function

'====================================================================================================
'                                    MAIN DASHBOARD FUNCTIONS
'                                    ����� ���� �������
'====================================================================================================

'----------------------------------------
' CommandButton1: Refresh Dashboard - Calculate Totals
' Ϙ�� �: �������� ������� - ������ ��ڝ��
'----------------------------------------
Private Sub CommandButton1_Click()
    Dim ws As Worksheet
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim col As Long
    
    ' --- Read Dynamic Configuration ---
    ' ������ ������� ����
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")
    
    ' Calculate column positions - ������ ������ ������
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    
    ' Calculate row layout - ������ ������ ���ݝ��
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' --- Get selected filters ---
    ' ������ �������� ������ ���
    Dim selectedYears As Collection: Set selectedYears = GetSelectedItems(ListBox1)
    Dim selectedMonths As Collection: Set selectedMonths = GetSelectedItems(ListBox2)
    Dim selectedCompanies As Collection: Set selectedCompanies = GetSelectedItems(ListBox3)
    
    ' If nothing selected, include all - ǐ� ���� ������ ���� ��� �� ���� ��
    Dim filterAllYears As Boolean: filterAllYears = (selectedYears.count = 0)
    Dim filterAllMonths As Boolean: filterAllMonths = (selectedMonths.count = 0)
    Dim filterAllCompanies As Boolean: filterAllCompanies = (selectedCompanies.count = 0)
    
    ' Convert month names to numbers for matching
    ' ����� ��� ����� �� ����� ���� ������
    Dim selectedMonthNums As Collection: Set selectedMonthNums = New Collection
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    Dim m As Variant, mn As Long
    For Each m In selectedMonths
        For mn = 0 To 11
            If m = monthNames(mn) Then
                selectedMonthNums.Add mn + 1
                Exit For
            End If
        Next mn
    Next m
    
    ' --- Initialize Totals ---
    ' �������� ����� ��ڝ��
    Dim totalUnpaidFactors As Double: totalUnpaidFactors = 0
    Dim totalUnclearedCheques As Double: totalUnclearedCheques = 0
    Dim totalFactors As Double: totalFactors = 0
    Dim totalCheques As Double: totalCheques = 0
    
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    Application.ScreenUpdating = False
    
    ' --- Loop through all sheets ---
    ' ���� ��� ���� ��ʝ��
    For Each ws In ThisWorkbook.Worksheets
        ' Skip non-data sheets - �� ���� ��ʝ��� ��� ������
        If ws.Name <> "�������" And ws.Name <> "�������" And ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0
            
            If yearNum >= startYear And yearNum <= endYear Then
                
                ' Check year filter - ����� ����� ���
                Dim matchYear As Boolean
                matchYear = filterAllYears Or IsInCollection(selectedYears, CStr(yearNum))
                
                ' Check month filter - ����� ����� ���
                Dim matchMonth As Boolean
                matchMonth = filterAllMonths Or IsInCollection(selectedMonthNums, monthNum)
                
                If matchYear And matchMonth Then
                    Dim dayStartRow As Long
                    For dayNum = 1 To 31
                        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                        If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For
                        
                        ' --- Count Factors - ����� �ǘ����� ---
                        For col = firstFactorCol To lastFactorCol Step 2
                            Dim factorCompany As String: factorCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim factorStatus As String: factorStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            Dim factorAmount As Double
                            
                            If factorCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchFactorCompany As Boolean
                                matchFactorCompany = filterAllCompanies Or IsInCollection(selectedCompanies, factorCompany)
                                
                                If matchFactorCompany Then
                                    factorAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Add to totals - ������ �� ��ڝ��
                                    totalFactors = totalFactors + factorAmount
                                    
                                    ' If unpaid (status is empty) - ǐ� ������ ���� (����� ����)
                                    If factorStatus = "" Then
                                        totalUnpaidFactors = totalUnpaidFactors + factorAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                        ' --- Count Cheques - ����� ����� ---
                        For col = firstChequeCol To lastChequeCol Step 2
                            Dim chequeCompany As String: chequeCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim chequeStatus As String: chequeStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            Dim chequeAmount As Double
                            
                            If chequeCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchChequeCompany As Boolean
                                matchChequeCompany = filterAllCompanies Or IsInCollection(selectedCompanies, chequeCompany)
                                
                                If matchChequeCompany Then
                                    chequeAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Add to totals - ������ �� ��ڝ��
                                    totalCheques = totalCheques + chequeAmount
                                    
                                    ' If uncleared (status is empty) - ǐ� ��� ���� (����� ����)
                                    If chequeStatus = "" Then
                                        totalUnclearedCheques = totalUnclearedCheques + chequeAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                    Next dayNum
                End If
            End If
        End If
    Next ws
    
    Application.ScreenUpdating = True
    
    ' --- Update summary labels ---
    ' ��������� �э�ȝ��� �����
    On Error Resume Next
    Label_TotalFactors.Caption = Format(totalFactors, "#,##0")
    Label_TotalUnpaidFactors.Caption = Format(totalUnpaidFactors, "#,##0")
    Label_TotalCheques.Caption = Format(totalCheques, "#,##0")
    Label_TotalUnclearedCheques.Caption = Format(totalUnclearedCheques, "#,##0")
    
    ' --- Show balance (Unpaid - Uncleared) ---
    ' ����� ����� (�����ʝ���� - ��ӝ����)
    Dim balance As Double
    balance = totalUnpaidFactors - totalUnclearedCheques
    Label_Balance.Caption = Format(balance, "#,##0")
    
    ' Color code the balance - �䐝���� �����
    If balance > 0 Then
        Label_Balance.ForeColor = RGB(192, 0, 0) ' Red - ����: �������
    ElseIf balance < 0 Then
        Label_Balance.ForeColor = RGB(0, 128, 0) ' Green - ���: ��Ș����
    Else
        Label_Balance.ForeColor = RGB(0, 0, 0)   ' Black - �Ԙ�: ������
    End If
    On Error GoTo 0
    
    MsgBox "������� ��������� ��.", vbInformation, "���������"
End Sub

'----------------------------------------
' CommandButton3: Show Breakdown by Company with Weighted Average Due Date
' Ϙ�� �: ����� ������ �� �ݘ� �ј� �� ������ ����� ������
'----------------------------------------
Private Sub CommandButton3_Click()
    Dim ws As Worksheet
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim col As Long
    
    ' --- Read Dynamic Configuration ---
    ' ������ ������� ����
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")
    
    ' Calculate column positions - ������ ������ ������
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    
    ' Calculate row layout - ������ ������ ���ݝ��
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' --- Get selected filters ---
    ' ������ �������� ������ ���
    Dim selectedYears As Collection: Set selectedYears = GetSelectedItems(ListBox1)
    Dim selectedMonths As Collection: Set selectedMonths = GetSelectedItems(ListBox2)
    Dim selectedCompanies As Collection: Set selectedCompanies = GetSelectedItems(ListBox3)
    
    Dim filterAllYears As Boolean: filterAllYears = (selectedYears.count = 0)
    Dim filterAllMonths As Boolean: filterAllMonths = (selectedMonths.count = 0)
    Dim filterAllCompanies As Boolean: filterAllCompanies = (selectedCompanies.count = 0)
    
    ' Convert month names to numbers
    ' ����� ��� ����� �� �����
    Dim selectedMonthNums As Collection: Set selectedMonthNums = New Collection
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    Dim m As Variant, mn As Long
    For Each m In selectedMonths
        For mn = 0 To 11
            If m = monthNames(mn) Then
                selectedMonthNums.Add mn + 1
                Exit For
            End If
        Next mn
    Next m
    
    ' --- Dictionaries to store company totals ---
    ' �������� ���� ����� ��ڝ��� �� �ј�
    Dim companyFactors As Object: Set companyFactors = CreateObject("Scripting.Dictionary")
    Dim companyCheques As Object: Set companyCheques = CreateObject("Scripting.Dictionary")
    Dim companyUnpaidFactors As Object: Set companyUnpaidFactors = CreateObject("Scripting.Dictionary")
    Dim companyUnclearedCheques As Object: Set companyUnclearedCheques = CreateObject("Scripting.Dictionary")
    
    ' NEW: Dictionaries for weighted average due date calculation
    ' ����: �������� ���� ������ ������ ����� ������
    ' Formula: Weighted Avg Due Date = Sum(Amount * DueDate) / Sum(Amount)
    ' �����: ������ ����� ������ = �����(���� � ����� ������) / �����(����)
    Dim companyWeightedDueDateSum As Object: Set companyWeightedDueDateSum = CreateObject("Scripting.Dictionary")
    Dim companyUnpaidAmountSum As Object: Set companyUnpaidAmountSum = CreateObject("Scripting.Dictionary")
    
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    Application.ScreenUpdating = False
    
    ' --- Loop through all sheets ---
    ' ���� ��� ���� ��ʝ��
    For Each ws In ThisWorkbook.Worksheets
        ' Skip non-data sheets - �� ���� ��ʝ��� ��� ������
        If ws.Name <> "�������" And ws.Name <> "�������" And ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0
            
            If yearNum >= startYear And yearNum <= endYear Then
                ' Check year filter - ����� ����� ���
                Dim matchYear As Boolean
                matchYear = filterAllYears Or IsInCollection(selectedYears, CStr(yearNum))
                
                ' Check month filter - ����� ����� ���
                Dim matchMonth As Boolean
                matchMonth = filterAllMonths Or IsInCollection(selectedMonthNums, monthNum)
                
                If matchYear And matchMonth Then
                    Dim dayStartRow As Long
                    For dayNum = 1 To 31
                        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                        If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For
                        
                        ' --- Process Factors - ������ �ǘ����� ---
                        For col = firstFactorCol To lastFactorCol Step 2
                            Dim factorCompany As String: factorCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim factorStatus As String: factorStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            
                            If factorCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchFactorCompany As Boolean
                                matchFactorCompany = filterAllCompanies Or IsInCollection(selectedCompanies, factorCompany)
                                
                                If matchFactorCompany Then
                                    ' Get factor amount - ������ ���� �ǘ���
                                    Dim factorAmount As Double
                                    factorAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Initialize dictionaries for this company if not exists
                                    ' �������� ����� �������� ���� ��� �ј� ǐ� ���� �����
                                    If Not companyFactors.exists(factorCompany) Then
                                        companyFactors.Add factorCompany, 0
                                        companyUnpaidFactors.Add factorCompany, 0
                                        companyWeightedDueDateSum.Add factorCompany, 0
                                        companyUnpaidAmountSum.Add factorCompany, 0
                                    End If
                                    
                                    ' Add to total factors - ������ �� �� �ǘ�����
                                    companyFactors(factorCompany) = companyFactors(factorCompany) + factorAmount
                                    
                                    ' If unpaid, calculate due date - ǐ� �����ʝ���� ������ ������
                                    If factorStatus = "" Then
                                        companyUnpaidFactors(factorCompany) = companyUnpaidFactors(factorCompany) + factorAmount
                                        
                                        ' Get forjeh (credit period in days) from the cell next to amount
                                        ' ������ ���� (���� ������ �� ���) �� ���� ���� ����
                                        Dim forjeh As Long
                                        forjeh = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col + 1).value)
                                        
                                        ' Calculate factor date - ������ ����� �ǘ���
                                        Dim factorDate As Date
                                        factorDate = PersianToGregorianDate(yearNum, monthNum, dayNum)
                                        
                                        ' Calculate due date = factor date + forjeh
                                        ' ������ ����� ������ = ����� �ǘ��� + ����
                                        Dim dueDate As Date
                                        dueDate = factorDate + forjeh
                                        
                                        ' Add to weighted sum: amount * date (as numeric)
                                        ' ������ �� ����� �����: ���� � ����� (�� ���� ����)
                                        companyWeightedDueDateSum(factorCompany) = companyWeightedDueDateSum(factorCompany) + (factorAmount * CDbl(dueDate))
                                        companyUnpaidAmountSum(factorCompany) = companyUnpaidAmountSum(factorCompany) + factorAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                        ' --- Process Cheques - ������ ����� ---
                        For col = firstChequeCol To lastChequeCol Step 2
                            Dim chequeCompany As String: chequeCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim chequeStatus As String: chequeStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            
                            If chequeCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchChequeCompany As Boolean
                                matchChequeCompany = filterAllCompanies Or IsInCollection(selectedCompanies, chequeCompany)
                                
                                If matchChequeCompany Then
                                    ' Get cheque amount - ������ ���� ��
                                    Dim chequeAmount As Double
                                    chequeAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Initialize dictionaries for this company if not exists
                                    ' �������� ����� �������� ���� ��� �ј� ǐ� ���� �����
                                    If Not companyCheques.exists(chequeCompany) Then
                                        companyCheques.Add chequeCompany, 0
                                        companyUnclearedCheques.Add chequeCompany, 0
                                    End If
                                    
                                    ' Add to total cheques - ������ �� �� �����
                                    companyCheques(chequeCompany) = companyCheques(chequeCompany) + chequeAmount
                                    
                                    ' If uncleared - ǐ� ��� ����
                                    If chequeStatus = "" Then
                                        companyUnclearedCheques(chequeCompany) = companyUnclearedCheques(chequeCompany) + chequeAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                    Next dayNum
                End If
            End If
        End If
    Next ws
    
    Application.ScreenUpdating = True
    
    ' --- Populate ListBox4 with breakdown ---
    ' �� ���� ���ʝ�ǘ�� �� ������
    ListBox4.Clear
    
    ' Get all unique companies - ������ ���� �јʝ��� ���
    Dim allCompanies As Object: Set allCompanies = CreateObject("Scripting.Dictionary")
    Dim k As Variant
    For Each k In companyFactors.Keys
        If Not allCompanies.exists(k) Then allCompanies.Add k, True
    Next k
    For Each k In companyCheques.Keys
        If Not allCompanies.exists(k) Then allCompanies.Add k, True
    Next k
    
    ' Add rows to ListBox4 - ������ ���ݝ�� �� ���ʝ�ǘ��
    For Each k In allCompanies.Keys
        Dim fTotal As Double: fTotal = 0
        Dim fUnpaid As Double: fUnpaid = 0
        Dim cTotal As Double: cTotal = 0
        Dim cUncleared As Double: cUncleared = 0
        Dim avgDueDateStr As String: avgDueDateStr = "-"
        
        ' Get values from dictionaries - ������ ������ �� ��������
        If companyFactors.exists(k) Then fTotal = companyFactors(k)
        If companyUnpaidFactors.exists(k) Then fUnpaid = companyUnpaidFactors(k)
        If companyCheques.exists(k) Then cTotal = companyCheques(k)
        If companyUnclearedCheques.exists(k) Then cUncleared = companyUnclearedCheques(k)
        
        ' Calculate weighted average due date
        ' ������ ������ ����� ������
        If companyUnpaidAmountSum.exists(k) Then
            If companyUnpaidAmountSum(k) > 0 Then
                Dim avgDueDate As Date
                avgDueDate = CDate(companyWeightedDueDateSum(k) / companyUnpaidAmountSum(k))
                avgDueDateStr = GregorianToPersian(avgDueDate)
            End If
        End If
        
        ' Add row to ListBox4 - ������ ���� �� ���ʝ�ǘ��
        With ListBox4
            .AddItem k                                      ' Column 0: Company - �ј�
            .List(.ListCount - 1, 1) = Format(fTotal, "#,##0")      ' Column 1: Total Factors - �� �ǘ���
            .List(.ListCount - 1, 2) = Format(fUnpaid, "#,##0")     ' Column 2: Unpaid Factors - �ǘ��� �����ʝ����
            .List(.ListCount - 1, 3) = Format(cTotal, "#,##0")      ' Column 3: Total Cheques - �� ��
            .List(.ListCount - 1, 4) = Format(cUncleared, "#,##0")  ' Column 4: Uncleared Cheques - �� ��ӝ����
            .List(.ListCount - 1, 5) = avgDueDateStr                ' Column 5: Avg Due Date - ������ ������
        End With
    Next k
    
    MsgBox "������ �� �ݘ� �ј� ��ѐ���� ��." & vbCrLf & _
           "����� �ј�: " & allCompanies.count, vbInformation, "������"
End Sub

'----------------------------------------
' CommandButton7: Sort ListBox4 by Average Due Date (earliest first = most urgent)
' Ϙ�� �: ���ȝ���� ���ʝ�ǘ�� �� ���� ������ ������ (������� = ��������)
'----------------------------------------
Private Sub CommandButton7_Click()
    If ListBox4.ListCount <= 1 Then
        MsgBox "������ ���� ���ȝ���� ���� �����.", vbExclamation, "���ȝ����"
        Exit Sub
    End If
    
    Dim i As Long, j As Long
    Dim itemCount As Long
    itemCount = ListBox4.ListCount
    
    ' Copy ListBox4 data to array - ��� ������� ���ʝ�ǘ� �� �����
    Dim data() As Variant
    ReDim data(0 To itemCount - 1, 0 To 5)
    
    For i = 0 To itemCount - 1
        data(i, 0) = ListBox4.List(i, 0)  ' Company - �ј�
        data(i, 1) = ListBox4.List(i, 1)  ' Total Factors - �� �ǘ���
        data(i, 2) = ListBox4.List(i, 2)  ' Unpaid Factors - �ǘ��� �����ʝ����
        data(i, 3) = ListBox4.List(i, 3)  ' Total Cheques - �� ��
        data(i, 4) = ListBox4.List(i, 4)  ' Uncleared Cheques - �� ��ӝ����
        data(i, 5) = ListBox4.List(i, 5)  ' Avg Due Date - ������ ������
    Next i
    
    ' Bubble sort by date (column 5) - earliest first
    ' ���ȝ���� ����� �� ���� ����� (���� �) - ������� ���
    Dim tempRow(0 To 5) As Variant
    Dim date1 As Date, date2 As Date
    
    For i = 0 To itemCount - 2
        For j = i + 1 To itemCount - 1
            ' Convert dates for comparison - ����� ����Ν�� ���� ������
            date1 = GetSortableDate(CStr(data(i, 5)))
            date2 = GetSortableDate(CStr(data(j, 5)))
            
            ' Sort ascending (earliest first) - ���ȝ���� ����� (������� ���)
            If date1 > date2 Then
                ' Swap rows - ������� ���ݝ��
                Dim colIdx As Long
                For colIdx = 0 To 5
                    tempRow(colIdx) = data(i, colIdx)
                    data(i, colIdx) = data(j, colIdx)
                    data(j, colIdx) = tempRow(colIdx)
                Next colIdx
            End If
        Next j
    Next i
    
    ' Reload ListBox4 with sorted data - ��ѐ���� ���� ���ʝ�ǘ� �� ������� ���� ���
    ListBox4.Clear
    For i = 0 To itemCount - 1
        With ListBox4
            .AddItem data(i, 0)
            .List(.ListCount - 1, 1) = data(i, 1)
            .List(.ListCount - 1, 2) = data(i, 2)
            .List(.ListCount - 1, 3) = data(i, 3)
            .List(.ListCount - 1, 4) = data(i, 4)
            .List(.ListCount - 1, 5) = data(i, 5)
        End With
    Next i
    
    MsgBox "���� �� ���� ����� ������ ���� ��." & vbCrLf & _
           "(�������� �� ����)", vbInformation, "���ȝ����"
End Sub

'----------------------------------------
' CommandButton2: Clear All Filters
' Ϙ�� �: �ǘ ���� ��� �������
'----------------------------------------
Private Sub CommandButton2_Click()
    Dim i As Long
    
    ' Clear year selection - �ǘ ���� ������ ���
    For i = 0 To ListBox1.ListCount - 1
        ListBox1.Selected(i) = False
    Next i
    
    ' Clear month selection - �ǘ ���� ������ ���
    For i = 0 To ListBox2.ListCount - 1
        ListBox2.Selected(i) = False
    Next i
    
    ' Clear company selection - �ǘ ���� ������ �ј�
    For i = 0 To ListBox3.ListCount - 1
        ListBox3.Selected(i) = False
    Next i
    
    ' Clear results - �ǘ ���� �����
    ListBox4.Clear
    
    ' Reset labels - �������� �э�ȝ��
    On Error Resume Next
    Label_TotalFactors.Caption = "0"
    Label_TotalUnpaidFactors.Caption = "0"
    Label_TotalCheques.Caption = "0"
    Label_TotalUnclearedCheques.Caption = "0"
    Label_Balance.Caption = "0"
    Label_Balance.ForeColor = RGB(0, 0, 0)
    On Error GoTo 0
    
    MsgBox "������� �ǘ ����.", vbInformation, "�ǘ ����"
End Sub

'----------------------------------------
' ListBox4 Double-Click: Show details for selected company
' ���᝘�� ��� ���ʝ�ǘ��: ����� ������ �ј� ������ ���
'----------------------------------------
Private Sub ListBox4_DblClick(ByVal CANCEL As MSForms.ReturnBoolean)
    If ListBox4.ListIndex < 0 Then Exit Sub
    
    Dim selectedCompany As String
    selectedCompany = ListBox4.List(ListBox4.ListIndex, 0)
    
    Dim msg As String
    msg = "������ �ј�: " & selectedCompany & vbCrLf & vbCrLf
    msg = msg & "�� �ǘ���: " & ListBox4.List(ListBox4.ListIndex, 1) & vbCrLf
    msg = msg & "�ǘ��� �����ʝ����: " & ListBox4.List(ListBox4.ListIndex, 2) & vbCrLf
    msg = msg & "�� ��: " & ListBox4.List(ListBox4.ListIndex, 3) & vbCrLf
    msg = msg & "�� ��ӝ����: " & ListBox4.List(ListBox4.ListIndex, 4) & vbCrLf
    msg = msg & "������ ������: " & ListBox4.List(ListBox4.ListIndex, 5)
    
    MsgBox msg, vbInformation, "������ �ј�"
End Sub

'====================================================================================================
'                                    CASH FLOW FORECAST FUNCTIONS
'====================================================================================================
'====================================================================================================
'                                    CASH FLOW FORECAST FUNCTIONS
'====================================================================================================

'----------------------------------------
' Update Label_MonthAverage when month/year selection changes
'----------------------------------------
Private Sub UpdateMonthAverage()
    Dim selectedYears As Collection
    Dim selectedMonths As Collection
    Dim useYear As Long
    Dim useMonth As Long
    Dim ws As Worksheet
    Dim ym As String
    Dim totalSales As Double
    Dim daysWithData As Long
    Dim avgSales As Double
    Dim offDays As Long
    Dim offText As String
    
    On Error Resume Next
    
    ' Get selected years - if none, use default year
    Set selectedYears = GetSelectedItems(ListBox1)
    If selectedYears.count = 0 Then
        useYear = ReadConfigValue("cfg_DefaultYear")
        If useYear = 0 Then useYear = 1403
    Else
        useYear = CLng(selectedYears(1))
    End If
    
    ' Get selected months - if none, use default month
    Set selectedMonths = GetSelectedItems(ListBox2)
    If selectedMonths.count = 0 Then
        useMonth = ReadConfigValue("cfg_DefaultMonth")
        If useMonth = 0 Then useMonth = 1
    Else
        ' Convert month name to number
        Dim monthNames As Variant
        monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                           "���", "����", "���", "��", "����", "�����")
        Dim mn As Long
        For mn = 0 To 11
            If selectedMonths(1) = monthNames(mn) Then
                useMonth = mn + 1
                Exit For
            End If
        Next mn
    End If
    
    ' Find the sheet
    ym = useYear & "/" & Format(useMonth, "00")
    Set ws = Nothing
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set ws = sht
            Exit For
        End If
    Next sht
    
    If ws Is Nothing Then
        Label_MonthAverage.Caption = "0"
        m_AvgDailySales = 0
        Exit Sub
    End If
    
    ' Read config
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    
    ' Calculate total sales for the month
    totalSales = 0
    daysWithData = 0
    
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim centerNum As Long
    Dim centerRow As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim dayTotal As Double
    
    For dayNum = 1 To 31
        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
        
        ' Check if day exists
        If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
            If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                dayTotal = 0
                
                ' Sum all centers for this day
                For centerNum = 1 To userCenters
                    If userCenters = 1 Then
                        centerRow = dayStartRow
                    Else
                        centerRow = dayStartRow + (centerNum - 1)
                    End If
                    
                    ' Add Cash (Column C)
                    cashValue = ws.Cells(centerRow, "C").value
                    If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then
                        dayTotal = dayTotal + CDbl(cashValue)
                    End If
                    
                    ' Add Card (Column D)
                    cardValue = ws.Cells(centerRow, "D").value
                    If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then
                        dayTotal = dayTotal + CDbl(cardValue)
                    End If
                Next centerNum
                
                If dayTotal > 0 Then
                    totalSales = totalSales + dayTotal
                    daysWithData = daysWithData + 1
                End If
            End If
        End If
    Next dayNum
    
    ' Calculate average
    If daysWithData > 0 Then
        avgSales = totalSales / daysWithData
    Else
        avgSales = 0
    End If
    

    
    ' Update label and global variable
    Label_MonthAverage.Caption = Format(avgSales, "#,##0")
    m_AvgDailySales = avgSales
End Sub


'

'----------------------------------------
' ListBox1 Click - Year selection changed
'----------------------------------------
Private Sub ListBox1_Click()
    Call UpdateMonthAverage
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' ListBox2 Click - Month selection changed
'----------------------------------------
Private Sub ListBox2_Click()
    Call UpdateMonthAverage
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' Textbox_BankBalance Exit - Format and recalculate
'----------------------------------------

Private Sub Textbox_BankBalance_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    
    rawValue = Trim(Me.Textbox_BankBalance.value)
    If rawValue = "" Then Exit Sub
    
    ' Remove existing formatting
    rawValue = Replace(rawValue, ",", "")
    rawValue = ConvertPersianNumsToEnglishDashboard(rawValue)
    
    If IsNumeric(rawValue) Then
        Me.Textbox_BankBalance.value = Format(CDbl(rawValue), "#,##0")
    End If
    
    Call CalculateCashFlowForecast
End Sub
'----------------------------------------
' Textbox_DateForCheque Exit - Format date and recalculate
'----------------------------------------

Private Sub Textbox_DateForCheque_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    Dim formattedDate As String
    
    rawValue = Trim(Me.Textbox_DateForCheque.value)
    If rawValue = "" Then Exit Sub
    
    formattedDate = FormatPersianDateInput(rawValue)
    
    If formattedDate <> "" Then
        Me.Textbox_DateForCheque.value = formattedDate
        Call CalculateCashFlowForecast
    Else
        MsgBox "���� ����� ������� ���." & vbCrLf & "����: 1404/01/15 �� 14040115", vbExclamation, "���"
        Me.Textbox_DateForCheque.value = ""
    End If
    
End Sub
'----------------------------------------
' Format Persian date input (accepts yyyy/mm/dd or yyyymmdd)
'----------------------------------------
Private Function FormatPersianDateInput(ByVal inputDate As String) As String
    Dim cleanDate As String
    Dim y As Long, m As Long, d As Long
    
    On Error GoTo InvalidDate
    
    ' Clean input
    cleanDate = Trim(inputDate)
    cleanDate = ConvertPersianNumsToEnglishDashboard(cleanDate)
    
    ' Remove any existing slashes to normalize
    cleanDate = Replace(cleanDate, "/", "")
    cleanDate = Replace(cleanDate, "-", "")
    cleanDate = Replace(cleanDate, " ", "")
    
    ' Should be 8 digits now (yyyymmdd)
    If Len(cleanDate) <> 8 Then GoTo InvalidDate
    If Not IsNumeric(cleanDate) Then GoTo InvalidDate
    
    y = CLng(Left(cleanDate, 4))
    m = CLng(Mid(cleanDate, 5, 2))
    d = CLng(Right(cleanDate, 2))
    
    ' Validate ranges
    If y < 1300 Or y > 1500 Then GoTo InvalidDate
    If m < 1 Or m > 12 Then GoTo InvalidDate
    If d < 1 Or d > 31 Then GoTo InvalidDate
    
    ' Validate days in month
    If m >= 1 And m <= 6 And d > 31 Then GoTo InvalidDate
    If m >= 7 And m <= 11 And d > 30 Then GoTo InvalidDate
    If m = 12 Then
        Dim maxDay As Long
        maxDay = IIf(((y - 1403) Mod 4 = 0), 30, 29)
        If d > maxDay Then GoTo InvalidDate
    End If
    
    FormatPersianDateInput = y & "/" & Format(m, "00") & "/" & Format(d, "00")
    Exit Function
    
InvalidDate:
    FormatPersianDateInput = ""
End Function

'----------------------------------------
' Convert Persian/Arabic digits to English
'----------------------------------------
Private Function ConvertPersianNumsToEnglishDashboard(ByVal s As String) As String
    Dim i As Long
    Dim result As String
    result = s
    
    ' Persian digits
    For i = 0 To 9
        result = Replace(result, ChrW(1776 + i), CStr(i))
    Next i
    
    ' Arabic-Indic digits
    For i = 0 To 9
        result = Replace(result, ChrW(1632 + i), CStr(i))
    Next i
    
    ConvertPersianNumsToEnglishDashboard = result
End Function



'----------------------------------------
' Get total cheques clearing on a specific day
'----------------------------------------
Private Function GetDayCheques(persianDate As String) As Double
    Dim ws As Worksheet
    Dim parts() As String
    Dim ym As String
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim total As Double
    Dim c As Long
    
    On Error GoTo ErrHandler
    
    parts = Split(persianDate, "/")
    ym = parts(0) & "/" & parts(1)
    dayNum = CLng(parts(2))
    
    ' Find the sheet
    Set ws = Nothing
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set ws = sht
            Exit For
        End If
    Next sht
    
    If ws Is Nothing Then
        GetDayCheques = 0
        Exit Function
    End If
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Find day row
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
    
    ' Check if day exists
    If ws.Cells(dayStartRow, "A").value <> dayNum Then
        GetDayCheques = 0
        Exit Function
    End If
    
    ' Sum all cheques for this day
    total = 0
    For c = firstChequeCol To lastChequeCol Step 2
        If ws.Cells(dayStartRow, c).value <> "" Then
            Dim chequeAmount As Variant
            chequeAmount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
            If IsNumeric(chequeAmount) And Not IsEmpty(chequeAmount) Then
                total = total + CDbl(chequeAmount)
            End If
        End If
    Next c
    
    GetDayCheques = total
    Exit Function
    
ErrHandler:
    GetDayCheques = 0
End Function

'----------------------------------------
' Get total direct pays on a specific day
'----------------------------------------
Private Function GetDayDirectPays(persianDate As String) As Double
    Dim ws As Worksheet
    Dim parts() As String
    Dim ym As String
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim total As Double
    Dim c As Long
    
    On Error GoTo ErrHandler
    
    parts = Split(persianDate, "/")
    ym = parts(0) & "/" & parts(1)
    dayNum = CLng(parts(2))
    
    ' Find the sheet
    Set ws = Nothing
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set ws = sht
            Exit For
        End If
    Next sht
    
    If ws Is Nothing Then
        GetDayDirectPays = 0
        Exit Function
    End If
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim numDirectPays As Long: numDirectPays = ReadConfigValue("cfg_NumDirectPays")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim firstDirectPayCol As Long: firstDirectPayCol = lastFactorCol + 2 + 1
    Dim lastDirectPayCol As Long: lastDirectPayCol = firstDirectPayCol + numDirectPays - 1
    
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Find day row
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
    
    ' Check if day exists
    If ws.Cells(dayStartRow, "A").value <> dayNum Then
        GetDayDirectPays = 0
        Exit Function
    End If
    
    ' Sum all direct pays for this day
    total = 0
    For c = firstDirectPayCol To lastDirectPayCol
        If ws.Cells(dayStartRow, c).value <> "" Then
            Dim payAmount As Variant
            payAmount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
            If IsNumeric(payAmount) And Not IsEmpty(payAmount) Then
                total = total + CDbl(payAmount)
            End If
        End If
    Next c
    
    GetDayDirectPays = total
    Exit Function
    
ErrHandler:
    GetDayDirectPays = 0
End Function
'----------------------------------------
' Get total planned expenses on a specific day (based on due dates)
'----------------------------------------
Private Function GetDayExpenses(persianDate As String) As Double
    Dim total As Double: total = 0
    
    total = total + CheckExpense(Me.txtrent1, Me.txtrent1date, persianDate)
    total = total + CheckExpense(Me.txtrent2, Me.txtrent2date, persianDate)
    total = total + CheckExpense(Me.txtsalary, Me.txtsalarydate, persianDate)
    total = total + CheckExpense(Me.txtinsurance, Me.txtinsurancedate, persianDate)
    total = total + CheckExpense(Me.txtinstallment1, Me.txtinstallment1date, persianDate)
    total = total + CheckExpense(Me.txtinstallment2, Me.txtinstallment2date, persianDate)
    total = total + CheckExpense(Me.txtotherexpenses, Me.txtotherexpensesdate, persianDate)

    GetDayExpenses = total
End Function

'----------------------------------------
' Calculate 30-day cash flow forecast
'----------------------------------------
Private Sub CalculateCashFlowForecast()
    Dim startDate As String
    Dim bankBalance As Double
    Dim avgSales As Double
    Dim gStartDate As Date
    Dim i As Long
    Dim checkDate As Date
    Dim persianDate As String
    Dim chequesAmount As Double
    Dim directPaysAmount As Double
    Dim expensesAmount As Double
    Dim currentBalance As Double
    Dim dayBalance As Double
    Dim balanceText As String
    Dim unclearedText As String
    Dim unclearedAmount As Double
'    Dim percent As Double
    
    On Error Resume Next
    
    ' Validate inputs
    startDate = Trim(Me.Textbox_DateForCheque.value)
    If startDate = "" Then
        Me.Listbox_next30days.Clear
        Exit Sub
    End If
    
    ' Get bank balance
    balanceText = Trim(Me.Textbox_BankBalance.value)
    balanceText = Replace(balanceText, ",", "")
    balanceText = ConvertPersianNumsToEnglishDashboard(balanceText)
    If IsNumeric(balanceText) Then
        bankBalance = CDbl(balanceText)
    Else
        bankBalance = 0
    End If

    ' Get average sales
    avgSales = m_AvgDailySales

    ' Get uncleared cheques (assumed already past due)
    unclearedText = Trim(Me.txtunclearedcheques.Text)
    unclearedText = Replace(unclearedText, ",", "")
    unclearedText = ConvertPersianNumsToEnglishDashboard(unclearedText)
    If IsNumeric(unclearedText) Then
        unclearedAmount = CDbl(unclearedText)
    Else
        unclearedAmount = 0
    End If

    ' Convert start date to Gregorian
    gStartDate = PersianToGregorianDate( _
        CLng(Split(startDate, "/")(0)), _
        CLng(Split(startDate, "/")(1)), _
        CLng(Split(startDate, "/")(2)))
    
    ' Clear listbox
    Me.Listbox_next30days.Clear
    
    ' Calculate for 30 days
    currentBalance = bankBalance
    
    For i = 0 To 29
        checkDate = gStartDate + i
        persianDate = GregorianToPersian(checkDate)
        
        ' Get cheques clearing on this day
        chequesAmount = GetDayCheques(persianDate)
        
        ' Get direct pays on this day
        directPaysAmount = GetDayDirectPays(persianDate)
        
        ' Get planned expenses on this day (rent, salary, etc.)
        expensesAmount = GetDayExpenses(persianDate)
        
        ' Calculate balance for this day
        ' Start with previous balance, add sales, subtract cheques, direct pays and expenses
dayBalance = currentBalance + GetDaySalesAmount(persianDate, avgSales) - chequesAmount - directPaysAmount - expensesAmount
        
        ' Apply uncleared cheques on first day (they are already overdue)
        If i = 0 And unclearedAmount <> 0 Then
            dayBalance = dayBalance - unclearedAmount
        End If
        
        ' Add to listbox
        With Me.Listbox_next30days
            .AddItem persianDate
            If dayBalance < 0 Then
                .List(.ListCount - 1, 1) = "*** -" & Application.Text(Abs(dayBalance), "#,##0")
            Else
                .List(.ListCount - 1, 1) = Application.Text(dayBalance, "#,##0")
            End If
        End With
        
        ' Update current balance for next day
        currentBalance = dayBalance
    Next i
End Sub
'----------------------------------------
' Helper: if txtDate = persianDate then return numeric amount in txtAmount
'----------------------------------------
Private Function CheckExpense(txtAmount As Object, _
                              txtDate As Object, _
                              persianDate As String) As Double
    Dim amountText As String
    Dim dueDayText As String
    Dim dueDay As Long
    Dim currentDay As Long

    CheckExpense = 0

    ' Current forecast day (dd)
    currentDay = CLng(Split(persianDate, "/")(2))

    ' Read user due-day (dd format)
    dueDayText = Trim(txtDate.Text)
    dueDayText = ConvertPersianNumsToEnglishDashboard(dueDayText)

    If Not IsNumeric(dueDayText) Then Exit Function
    dueDay = CLng(dueDayText)

    ' Match exact day number
    If currentDay = dueDay Then
        amountText = Trim(txtAmount.Text)
        amountText = Replace(amountText, ",", "")
        amountText = ConvertPersianNumsToEnglishDashboard(amountText)
        If IsNumeric(amountText) Then
            CheckExpense = CDbl(amountText)
        End If
    End If
End Function


'----------------------------------------
' Color negative balances in Listbox_next30days red
' Note: ListBox doesn't support per-row coloring, so we'll add a marker
'----------------------------------------

Private Sub ColorNegativeBalances()
    Dim i            As Long
    Dim balanceText  As String
    Dim cleanText    As String
    Dim j            As Long

    On Error Resume Next

    For i = 0 To Me.Listbox_next30days.ListCount - 1
        balanceText = Me.Listbox_next30days.List(i, 1)

        ' Already marked by Fix 1 � nothing to do
        If Left(balanceText, 4) = "*** " Then GoTo nextRow

        ' Remove commas and thousand separators to get a raw number string
        cleanText = Replace(balanceText, ",", "")

        ' Convert Persian/Arabic digits to ASCII (safety net)
        For j = 0 To 9
            cleanText = Replace(cleanText, ChrW(1776 + j), CStr(j))  ' Persian
            cleanText = Replace(cleanText, ChrW(1632 + j), CStr(j))  ' Arabic-Indic
        Next j
        cleanText = Replace(cleanText, ChrW(1548), "")  ' Arabic comma �
        cleanText = Trim(cleanText)

        ' Detect trailing minus (Persian RTL locale) or leading minus
        Dim isNeg As Boolean: isNeg = False
        If Right(cleanText, 1) = "-" Then
            isNeg = True
            cleanText = Left(cleanText, Len(cleanText) - 1)
        ElseIf Left(cleanText, 1) = "-" Then
            isNeg = True
            cleanText = Mid(cleanText, 2)
        End If

        If IsNumeric(cleanText) And cleanText <> "" Then
            If isNeg Or CDbl(cleanText) < 0 Then
                Me.Listbox_next30days.List(i, 1) = _
                    "*** -" & Application.Text(Abs(CDbl(cleanText)), "#,##0")
            End If
        End If

nextRow:
    Next i

    On Error GoTo 0
End Sub

'----------------------------------------
' CommandButton_Refresh - Refresh all values
'----------------------------------------
Private Sub CommandButton_Refresh_Click()
    Application.ScreenUpdating = False
    
    ' Update month average
    Call UpdateMonthAverage
    
    ' Recalculate cash flow forecast
    Call CalculateCashFlowForecast
    
    ' Save expense settings to sheet "�������"
    Call SaveExpensesToSheet
    
    Call FormatAllExpenseTextboxes
    
    Application.ScreenUpdating = True
    
'    MsgBox "������ ��������� ��.", vbInformation, "���������"
End Sub


'----------------------------------------
' CommandButton4: Select All Years
' Ϙ�� �: ������ ��� �����
'----------------------------------------
Private Sub CommandButton4_Click()
    Dim i As Long
    For i = 0 To ListBox1.ListCount - 1
        ListBox1.Selected(i) = True
    Next i
End Sub

'----------------------------------------
' CommandButton5: Select All Months
' Ϙ�� �: ������ ��� �����
'----------------------------------------
Private Sub CommandButton5_Click()
    Dim i As Long
    For i = 0 To ListBox2.ListCount - 1
        ListBox2.Selected(i) = True
    Next i
End Sub

'----------------------------------------
' CommandButton6: Select All Companies
' Ϙ�� �: ������ ��� �јʝ��
'----------------------------------------
Private Sub CommandButton6_Click()
    Dim i As Long
    For i = 0 To ListBox3.ListCount - 1
        ListBox3.Selected(i) = True
    Next i
End Sub

'----------------------------------------
' Save expense values and due dates to sheet "�������"
'----------------------------------------
Private Sub SaveExpensesToSheet()
    Dim ws As Worksheet
    Dim r As Long
    Dim c As Long
    
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("�������")
    On Error GoTo 0
    
    If ws Is Nothing Then Exit Sub
    
    r = 7          ' row 7
    c = 29         ' column AC = 29
    
    ws.Cells(r, c).value = Me.txtrent1.Text:              r = r + 1
    ws.Cells(r, c).value = Me.txtrent1date.Text:          r = r + 1
    
    ws.Cells(r, c).value = Me.txtrent2.Text:              r = r + 1
    ws.Cells(r, c).value = Me.txtrent2date.Text:          r = r + 1
    
    ws.Cells(r, c).value = Me.txtsalary.Text:             r = r + 1
    ws.Cells(r, c).value = Me.txtsalarydate.Text:         r = r + 1
    
    ws.Cells(r, c).value = Me.txtinsurance.Text:          r = r + 1
    ws.Cells(r, c).value = Me.txtinsurancedate.Text:      r = r + 1
    
    ws.Cells(r, c).value = Me.txtinstallment1.Text:       r = r + 1
    ws.Cells(r, c).value = Me.txtinstallment1date.Text:   r = r + 1
    
    ws.Cells(r, c).value = Me.txtinstallment2.Text:       r = r + 1
    ws.Cells(r, c).value = Me.txtinstallment2date.Text:   r = r + 1
    
    ws.Cells(r, c).value = Me.txtotherexpenses.Text:      r = r + 1
    ws.Cells(r, c).value = Me.txtotherexpensesdate.Text
End Sub


Private Sub LoadExpensesFromSheet()
    Dim ws As Worksheet
    Dim r As Long: r = 7
    Dim c As Long: c = 29
    
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("�������")
    On Error GoTo 0
    If ws Is Nothing Then Exit Sub
    
    Me.txtrent1.Text = ws.Cells(r, c).value:                r = r + 1
    Me.txtrent1date.Text = ws.Cells(r, c).value:        r = r + 1

    Me.txtrent2.Text = ws.Cells(r, c).value:              r = r + 1
    Me.txtrent2date.Text = ws.Cells(r, c).value:          r = r + 1

    Me.txtsalary.Text = ws.Cells(r, c).value:             r = r + 1
    Me.txtsalarydate.Text = ws.Cells(r, c).value:         r = r + 1

    Me.txtinsurance.Text = ws.Cells(r, c).value:          r = r + 1
    Me.txtinsurancedate.Text = ws.Cells(r, c).value:      r = r + 1

    Me.txtinstallment1.Text = ws.Cells(r, c).value:       r = r + 1
    Me.txtinstallment1date.Text = ws.Cells(r, c).value:   r = r + 1

    Me.txtinstallment2.Text = ws.Cells(r, c).value:       r = r + 1
    Me.txtinstallment2date.Text = ws.Cells(r, c).value:   r = r + 1

    Me.txtotherexpenses.Text = ws.Cells(r, c).value:      r = r + 1
    Me.txtotherexpensesdate.Text = ws.Cells(r, c).value
        Call FormatAllExpenseTextboxes
End Sub

Private Function GetDaySalesAmount(persianDate As String, avgSales As Double) As Double
    On Error GoTo ErrorHandler
    
    Dim dayNum As String
    Dim rawOffDays As String
    Dim offDays() As String
    Dim offDayEntry As Variant
    Dim percent As Double
    Dim percentText As String
    
    ' Extract day number from Persian date
    dayNum = CStr(CLng(Split(persianDate, "/")(2)))
    
    ' Get off days list
    rawOffDays = Trim(Me.txtoffdays.value)
    
    ' If no off days specified, return full average
    If rawOffDays = "" Then
        GetDaySalesAmount = avgSales
        Exit Function
    End If
    
    ' Check if current day is an off day
    offDays = Split(rawOffDays, " ")
    For Each offDayEntry In offDays
        If Trim(CStr(offDayEntry)) <> "" Then
            If CStr(CLng(Trim(CStr(offDayEntry)))) = dayNum Then
                ' This is an off day
                If Me.CheckBox1.value Then
                    ' Checkbox is checked - use percentage
                    percentText = Replace(Trim(Me.txtpercent.value), ",", "")
                    percentText = ConvertPersianNumsToEnglishDashboard(percentText)
                    If IsNumeric(percentText) And percentText <> "" Then
                        percent = CDbl(percentText)
                        GetDaySalesAmount = avgSales * percent / 100
                    Else
                        ' Default to 30% if percent is invalid
                        GetDaySalesAmount = avgSales * 0.3
                    End If
                Else
                    ' Checkbox is unchecked - zero sales on off day
                    GetDaySalesAmount = 0
                End If
                Exit Function
            End If
        End If
    Next offDayEntry
    
    ' Not an off day - return full average
    GetDaySalesAmount = avgSales
    Exit Function
    
ErrorHandler:
    ' On any error, return full average as fallback
    GetDaySalesAmount = avgSales
End Function

'----------------------------------------
' txtunclearedcheques Exit - Format and recalculate
'----------------------------------------
Private Sub txtunclearedcheques_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'
'----------------------------------------
' txtsalary Exit - Format and recalculate
'----------------------------------------

Private Sub txtsalary_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtrent1 Exit - Format and recalculate
'----------------------------------------

Private Sub txtrent1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtrent2 Exit - Format and recalculate
'----------------------------------------

Private Sub txtrent2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'----------------------------------------
' txtinsurance Exit - Format and recalculate
'----------------------------------------
Private Sub txtinsurance_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'----------------------------------------
' txtinstallment1 Exit - Format and recalculate
'----------------------------------------
Private Sub txtinstallment1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtinstallment2 Exit - Format and recalculate
'----------------------------------------
Private Sub txtinstallment2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtotherexpenses Exit - Format and recalculate
'----------------------------------------

Private Sub txtotherexpenses_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


Private Sub FormatExpenseTextbox(tb As MSForms.TextBox)

    Dim rawValue As String
    
    rawValue = Trim(tb.value)
    If rawValue = "" Then Exit Sub

    ' Remove formatting
    rawValue = Replace(rawValue, ",", "")
    rawValue = ConvertPersianNumsToEnglishDashboard(rawValue)

    If IsNumeric(rawValue) Then
        tb.value = Format(CDbl(rawValue), "#,##0")
    End If

End Sub

Private Sub FormatAllExpenseTextboxes()

    FormatExpenseTextbox Me.txtrent1
    FormatExpenseTextbox Me.txtrent2
    FormatExpenseTextbox Me.txtsalary
    FormatExpenseTextbox Me.txtinstallment1
    FormatExpenseTextbox Me.txtinstallment2
    FormatExpenseTextbox Me.txtinsurance
    FormatExpenseTextbox Me.txtotherexpenses
    FormatExpenseTextbox Me.txtunclearedcheques

    Call CalculateCashFlowForecast

End Sub
Private Function CleanCompanyName(ByVal companyText As String) As String
      Dim p As Long

      companyText = Trim(companyText)
      p = InStr(1, companyText, "(")

      If p > 0 Then
          companyText = Trim(Left(companyText, p - 1))
      End If

      CleanCompanyName = companyText
  End Function
