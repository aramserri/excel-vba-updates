Attribute VB_Name = "datedecrease"
  Sub ReduceOneInFormula()
      With Sheets("�������").Range("AE1")
          If .HasFormula Then
              .Formula = .Formula & "-1"
          Else
              .value = .value - 1
          End If
      End With
  End Sub
