Attribute VB_Name = "modUpdatePackageV2"
Option Explicit
Private Const UP_MARK As String = "VBA_PACKAGE_2"

Public Function UPText(ByVal codes As String) As String
    Dim item As Variant
    For Each item In Split(codes, ",")
        UPText = UPText & ChrW(CLng(item))
    Next item
End Function

Public Function UPRead(ByVal path As String, Optional ByVal charset As String = "utf-8") As String
    Dim s As Object
    If CreateObject("Scripting.FileSystemObject").GetFile(path).size = 0 Then Exit Function
    Set s = CreateObject("ADODB.Stream")
    s.Type = 2: s.charset = charset: s.Open: s.LoadFromFile path
    UPRead = s.ReadText
    s.Close
End Function

Public Sub UPWrite(ByVal path As String, ByVal text As String, Optional ByVal charset As String = "utf-8")
    Dim s As Object
    Set s = CreateObject("ADODB.Stream")
    s.Type = 2: s.charset = charset: s.Open
    If Len(text) > 0 Then s.WriteText text
    s.SaveToFile path, 2: s.Close
End Sub

Private Function UPQuote(ByVal text As String) As String
    UPQuote = Chr$(34) & text & Chr$(34)
End Function

Public Function UPPSQuote(ByVal text As String) As String
    UPPSQuote = "'" & Replace(text, "'", "''") & "'"
End Function

Public Sub UPPowerShell(ByVal script As String)
    Dim exitCode As Long
    exitCode = CreateObject("WScript.Shell").Run("powershell.exe -NoProfile -NonInteractive -Command " & UPQuote("$ErrorActionPreference='Stop'; " & script), 0, True)
    If exitCode <> 0 Then Err.Raise vbObjectError + 2600, , "Package file operation failed. Exit code: " & exitCode
End Sub

Public Function UPHash(ByVal path As String) As String
    Dim output As String, line As Variant, task As Object, compact As String
    If CreateObject("Scripting.FileSystemObject").GetFile(path).size = 0 Then
        UPHash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        Exit Function
    End If
    Set task = CreateObject("WScript.Shell").Exec("certutil.exe -hashfile " & UPQuote(path) & " SHA256")
    output = task.StdOut.ReadAll
    If task.exitCode <> 0 Then Err.Raise vbObjectError + 2601, , "Cannot hash file: " & path
    For Each line In Split(Replace(output, vbCr, ""), vbLf)
        compact = LCase$(Replace(Trim$(CStr(line)), " ", ""))
        If Len(compact) = 64 And Not compact Like "*[!0-9a-f]*" Then
            UPHash = compact
            Exit Function
        End If
    Next line
    Err.Raise vbObjectError + 2602, , "SHA256 was not returned: " & path
End Function

' Hash a directory in one PowerShell process instead of starting certutil per file.
Private Function UPBatchHashes(ByVal folder As String) As Object
    Dim fso As Object, hashes As Object, outputPath As String, script As String
    Dim line As Variant, fields As Variant, digest As String, errNumber As Long, errText As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set hashes = CreateObject("Scripting.Dictionary"): hashes.CompareMode = vbTextCompare
    outputPath = UPPath(Environ$("TEMP"), fso.GetTempName)
    On Error GoTo Failed
    script = "$sha=[Security.Cryptography.SHA256]::Create(); try { $rows=@(Get-ChildItem -LiteralPath " & UPPSQuote(folder) & _
        " -File | ForEach-Object { $s=[IO.File]::OpenRead($_.FullName); try { $h=([BitConverter]::ToString($sha.ComputeHash($s))).Replace('-','').ToLowerInvariant(); $_.Name + [char]9 + $h } finally { $s.Dispose() } }); " & _
        "[IO.File]::WriteAllLines(" & UPPSQuote(outputPath) & ", [string[]]$rows, (New-Object Text.UTF8Encoding $true)) } finally { $sha.Dispose() }"
    UPPowerShell script
    For Each line In Split(Replace(UPRead(outputPath), vbCr, ""), vbLf)
        If Len(CStr(line)) > 0 Then
            fields = Split(CStr(line), vbTab)
            If UBound(fields) <> 1 Then Err.Raise 5, , "Invalid batch hash result."
            digest = LCase$(CStr(fields(1)))
            If Len(digest) <> 64 Or digest Like "*[!0-9a-f]*" Then Err.Raise 5, , "Invalid batch hash."
            If hashes.exists(CStr(fields(0))) Then Err.Raise 5, , "Duplicate batch hash name."
            hashes.Add CStr(fields(0)), digest
        End If
    Next line
    If fso.FileExists(outputPath) Then fso.DeleteFile outputPath, True
    Set UPBatchHashes = hashes
    Exit Function
Failed:
    errNumber = Err.Number: errText = Err.description
    On Error Resume Next
    If fso.FileExists(outputPath) Then fso.DeleteFile outputPath, True
    On Error GoTo 0
    Err.Raise errNumber, , errText
End Function

Private Function UPBatchHash(ByVal hashes As Object, ByVal leaf As String) As String
    If Not hashes.exists(leaf) Then Err.Raise 5, , "Cannot hash package file: " & leaf
    UPBatchHash = CStr(hashes(leaf))
End Function

Public Function UPNewFolder(ByVal parent As String, ByVal prefix As String) As String
    Dim fso As Object, candidate As String, i As Long
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(parent) Then fso.CreateFolder parent
    For i = 1 To 1000
        candidate = fso.BuildPath(parent, prefix & Format$(Now, "yyyymmdd_hhnnss") & "_" & CStr(i))
        If Not fso.FolderExists(candidate) Then
            fso.CreateFolder candidate
            UPNewFolder = candidate
            Exit Function
        End If
    Next i
    Err.Raise 5, , "Cannot allocate a unique working directory."
End Function

Private Function UPCode(ByVal component As Object) As String
    If component.codeModule.CountOfLines > 0 Then UPCode = component.codeModule.lines(1, component.codeModule.CountOfLines)
End Function

Private Function UPNormalCode(ByVal text As String) As String
    Dim i As Long, ch As String, quoted As Boolean, comment As Boolean, result As String
    text = Trim$(Replace(Replace(text, vbCrLf, vbLf), vbCr, vbLf))
    ' VBA Trim removes spaces, not CR/LF. VBE may append an empty final line.
    Do While Len(text) > 0
        If InStr(1, vbLf & vbTab & " ", Right$(text, 1), vbBinaryCompare) = 0 Then Exit Do
        text = Left$(text, Len(text) - 1)
    Loop
    Do While Len(text) > 0
        If InStr(1, vbLf & vbTab & " ", Left$(text, 1), vbBinaryCompare) = 0 Then Exit Do
        text = Mid$(text, 2)
    Loop
    result = text
    ' VBE recases identifiers across modules. Preserve literal strings/comments exactly.
    For i = 1 To Len(text)
        ch = Mid$(text, i, 1)
        If ch = vbLf Then
            comment = False
        ElseIf Not comment Then
            If ch = Chr$(34) Then quoted = Not quoted
            If ch = Chr$(39) And Not quoted Then comment = True
        End If
        If Not quoted And Not comment Then ch = LCase$(ch)
        Mid$(result, i, 1) = ch
    Next i
    UPNormalCode = result
End Function

Private Sub UPAssertCode(ByVal component As Object, ByVal expected As String)
    Dim actual As String, diagnostic As String
    actual = UPCode(component)
    If UPNormalCode(actual) = UPNormalCode(expected) Then Exit Sub
    diagnostic = UPNewFolder(Environ$("TEMP"), "VBASourceMismatch_")
    UPWrite UPPath(diagnostic, "actual.txt"), actual, "unicode"
    UPWrite UPPath(diagnostic, "expected.txt"), expected, "unicode"
    Err.Raise 5, , "Source verification failed: " & component.name & ". Diagnostic: " & diagnostic
End Sub

Public Function UPComponent(ByVal book As Workbook, ByVal name As String) As Object
    On Error Resume Next
    Set UPComponent = book.VBProject.VBComponents(name)
    On Error GoTo 0
End Function

Private Function UPSafeLeaf(ByVal name As String) As Boolean
    If Len(name) = 0 Or name = "." Or name = ".." Then Exit Function
    UPSafeLeaf = (InStr(name, Chr$(92)) = 0 And InStr(name, "/") = 0 And InStr(name, ":") = 0 And InStr(name, vbTab) = 0)
End Function

Public Function UPPath(ByVal folder As String, ByVal leaf As String) As String
    UPPath = CreateObject("Scripting.FileSystemObject").BuildPath(folder, leaf)
End Function

Public Function UPExport(ByVal book As Workbook, ByVal selected As Object, ByVal destination As String, _
    ByVal fullRepair As Boolean, ByVal cellAddress As String, ByVal cellValue As String, ByVal details As String, Optional ByVal migrations As String = "", Optional ByVal recoverySelection As Object = Nothing) As String
    Dim fso As Object, stage As String, version As String, mode As String, manifest As String
    Dim component As Object, ext As String, file As String, codeFile As String, frx As String
    Dim count As Long, ref As Object, zipPath As String, verifyFolder As String, checked As Object
    Dim expected As Long, selectedName As Variant, includeComponent As Boolean, hashes As Object, hashName As Variant
    Set fso = CreateObject("Scripting.FileSystemObject")
    If book.VBProject.Protection <> 0 Then Err.Raise 5, , "The VBA project is locked."
    If Not fullRepair Then
        For Each selectedName In selected.keys
            If UPComponent(book, CStr(selectedName)) Is Nothing Then Err.Raise 5, , "Selected component no longer exists: " & selectedName
        Next selectedName
        expected = selected.count
    End If
    If Not recoverySelection Is Nothing Then
        If Not fullRepair Then Err.Raise 5, , "Recovery selection requires a recovery export."
        For Each selectedName In recoverySelection.keys
            If UPComponent(book, CStr(selectedName)) Is Nothing Then Err.Raise 5, , "Recovery selection no longer exists: " & selectedName
        Next selectedName
    End If
    If (cellAddress = "") <> (cellValue = "") Then Err.Raise 5, , "Provide both cell address and value, or neither."
    stage = UPNewFolder(Environ$("TEMP"), "VBAExportV2_")
    version = Format$(Now, "yyyymmdd_hhnnss")
    mode = "UPDATE": If fullRepair Then mode = "REPAIR"
    If Not recoverySelection Is Nothing Then mode = "RECOVERY"
    manifest = UP_MARK & vbTab & version & vbTab & mode & vbCrLf
    If mode = "RECOVERY" Then manifest = "VBA_PACKAGE_3" & vbTab & version & vbTab & mode & vbCrLf
    For Each component In book.VBProject.VBComponents
        If mode = "RECOVERY" Then
            If Not recoverySelection.exists(component.name) Then manifest = manifest & "P" & vbTab & component.name & vbTab & component.Type & vbCrLf
        End If
        includeComponent = fullRepair Or selected.exists(component.name)
        If Not recoverySelection Is Nothing Then includeComponent = recoverySelection.exists(component.name)
        If includeComponent Then
            Select Case component.Type
                Case 1: ext = ".bas"
                Case 2, 100: ext = ".cls"
                Case 3: ext = ".frm"
                Case Else: Err.Raise 5, , "Unsupported VBA component type: " & component.name
            End Select
            file = component.name & ext: codeFile = component.name & ".vbacode"
            component.Export UPPath(stage, file)
            UPWrite UPPath(stage, codeFile), UPCode(component), "unicode"
            frx = "-"
            If component.Type = 3 And fso.FileExists(UPPath(stage, component.name & ".frx")) Then frx = component.name & ".frx"
            manifest = manifest & "C" & vbTab & component.name & vbTab & component.Type & vbTab & file & vbTab & "{HASH:" & file & "}" & _
                vbTab & codeFile & vbTab & "{HASH:" & codeFile & "}" & vbTab & frx & vbTab
            If frx = "-" Then manifest = manifest & "-" Else manifest = manifest & "{HASH:" & frx & "}"
            manifest = manifest & vbCrLf
            count = count + 1
        End If
    Next component
    If count = 0 Then Err.Raise 5, , "No components selected."
    If Not fullRepair And count <> expected Then Err.Raise 5, , "Incomplete export; no package published."
    For Each ref In book.VBProject.references
        If ref.IsBroken Then Err.Raise 5, , "Repair the broken source VBA reference before exporting."
        manifest = manifest & "R" & vbTab & ref.GUID & vbTab & ref.Major & vbTab & ref.Minor & vbCrLf
    Next ref
    For Each selectedName In Split(migrations, ",")
        If Trim$(CStr(selectedName)) <> "" Then
            If Trim$(CStr(selectedName)) Like "*[!A-Za-z0-9_.]*" Then Err.Raise 5, , "Invalid migration procedure name."
            manifest = manifest & "M" & vbTab & Trim$(CStr(selectedName)) & vbCrLf
        End If
    Next selectedName
    If cellAddress <> "" Then
        UPWrite UPPath(stage, "cell_update.txt"), cellAddress & vbCrLf & cellValue
        manifest = manifest & "F" & vbTab & "cell_update.txt" & vbTab & "{HASH:cell_update.txt}" & vbCrLf
    End If
    If details <> "" Then
        UPWrite UPPath(stage, "details.txt"), details
        manifest = manifest & "F" & vbTab & "details.txt" & vbTab & "{HASH:details.txt}" & vbCrLf
    End If
    Set hashes = UPBatchHashes(stage)
    For Each hashName In hashes.keys
        manifest = Replace(manifest, "{HASH:" & CStr(hashName) & "}", CStr(hashes(hashName)))
    Next hashName
    If InStr(1, manifest, "{HASH:", vbBinaryCompare) > 0 Then Err.Raise 5, , "A package file could not be hashed."
    UPWrite UPPath(stage, "manifest.tsv"), manifest
    Set checked = UPValidate(stage, fullRepair)
    zipPath = UPPath(destination, version & ".zip")
    If fso.FileExists(zipPath) Or fso.FileExists(UPPath(destination, version & ".txt")) Then Err.Raise 5, , "A package with this timestamp exists. Retry; nothing was overwritten."
    UPPowerShell "Compress-Archive -LiteralPath (Get-ChildItem -LiteralPath " & UPPSQuote(stage) & " -File).FullName -DestinationPath " & UPPSQuote(UPPath(stage, "package.zip"))
    verifyFolder = UPNewFolder(Environ$("TEMP"), "VBAVerifyV2_")
    UPPowerShell "Expand-Archive -LiteralPath " & UPPSQuote(UPPath(stage, "package.zip")) & " -DestinationPath " & UPPSQuote(verifyFolder)
    Set checked = UPValidate(verifyFolder, fullRepair)
    fso.CopyFile UPPath(stage, "package.zip"), zipPath, False
    If details <> "" Then UPWrite UPPath(destination, version & ".txt"), details
    UPExport = version
End Function

Public Function UPValidate(ByVal folder As String, Optional ByVal requireRepair As Boolean = False) As Object
    Dim rows As Variant, fields As Variant, result As Object, components As Object, files As Object, preserved As Object
    Dim references As Collection, migrations As Collection, fso As Object, file As Object, i As Long, name As String, hashes As Object
    Set result = CreateObject("Scripting.Dictionary")
    Set components = CreateObject("Scripting.Dictionary"): components.CompareMode = vbTextCompare
    Set preserved = CreateObject("Scripting.Dictionary"): preserved.CompareMode = vbTextCompare
    Set files = CreateObject("Scripting.Dictionary"): files.CompareMode = vbTextCompare
    Set references = New Collection: Set migrations = New Collection
    Set fso = CreateObject("Scripting.FileSystemObject")
    rows = Split(Replace(UPRead(UPPath(folder, "manifest.tsv")), vbCr, ""), vbLf)
    fields = Split(rows(0), vbTab)
    If UBound(fields) <> 2 Then Err.Raise 5, , "Invalid package header."
    If fields(0) <> UP_MARK And fields(0) <> "VBA_PACKAGE_3" Then Err.Raise 5, , "Unsupported package. Re-export it with the current exporter."
    If Not fields(1) Like "########_######" Then Err.Raise 5, , "Invalid package version."
    If fields(2) <> "UPDATE" And fields(2) <> "REPAIR" And fields(2) <> "RECOVERY" Then Err.Raise 5, , "Invalid package mode."
    If fields(2) = "RECOVERY" And fields(0) <> "VBA_PACKAGE_3" Then Err.Raise 5, , "Selectable recovery requires protocol 3."
    If requireRepair And fields(2) <> "REPAIR" And fields(2) <> "RECOVERY" Then Err.Raise 5, , "Repair requires a recovery package."
    result.Add "Version", fields(1): result.Add "Mode", fields(2)
    Set hashes = UPBatchHashes(folder)
    For i = 1 To UBound(rows)
        If Len(rows(i)) > 0 Then
            fields = Split(rows(i), vbTab)
            Select Case fields(0)
                Case "C"
                    If UBound(fields) <> 8 Then Err.Raise 5, , "Invalid component record."
                    name = fields(1)
                    If Not UPSafeLeaf(name) Or name Like "*[!A-Za-z0-9_]*" Then Err.Raise 5, , "Unsafe component name."
                    If components.exists(name) Or preserved.exists(name) Then Err.Raise 5, , "Duplicate component: " & name
                    If fields(2) <> "1" And fields(2) <> "2" And fields(2) <> "3" And fields(2) <> "100" Then Err.Raise 5, , "Unsupported component type."
                    UPCheckFile folder, CStr(fields(3)), CStr(fields(4)), files, hashes
                    UPCheckFile folder, CStr(fields(5)), CStr(fields(6)), files, hashes
                    If fields(7) <> "-" Then UPCheckFile folder, CStr(fields(7)), CStr(fields(8)), files, hashes
                    If fields(5) <> name & ".vbacode" Then Err.Raise 5, , "Code sidecar name mismatch."
                    Select Case CLng(fields(2))
                        Case 1: If fields(3) <> name & ".bas" Then Err.Raise 5
                        Case 2, 100: If fields(3) <> name & ".cls" Then Err.Raise 5
                        Case 3
                            If fields(3) <> name & ".frm" Then Err.Raise 5
                            If InStr(1, UPRead(UPPath(folder, CStr(fields(3))), "windows-1252"), ".frx", vbTextCompare) > 0 And fields(7) = "-" Then Err.Raise 5, , "Form resource file missing: " & name
                    End Select
                    components.Add name, fields
                Case "P"
                    If result("Mode") <> "RECOVERY" Or UBound(fields) <> 2 Then Err.Raise 5, , "Invalid preserve record."
                    name = fields(1)
                    If Not UPSafeLeaf(name) Or name Like "*[!A-Za-z0-9_]*" Then Err.Raise 5, , "Unsafe preserved component name."
                    If components.exists(name) Or preserved.exists(name) Then Err.Raise 5, , "Duplicate component: " & name
                    If fields(2) <> "1" And fields(2) <> "2" And fields(2) <> "3" And fields(2) <> "100" Then Err.Raise 5, , "Invalid preserved type."
                    preserved.Add name, CLng(fields(2))
                Case "R"
                    If UBound(fields) <> 3 Then Err.Raise 5, , "Invalid reference record."
                    references.Add fields
                Case "M"
                    If UBound(fields) <> 1 Then Err.Raise 5, , "Invalid migration record."
                    If fields(1) = "" Or fields(1) Like "*[!A-Za-z0-9_.]*" Then Err.Raise 5, , "Invalid migration procedure."
                    migrations.Add CStr(fields(1))
                Case "F"
                    If UBound(fields) <> 2 Then Err.Raise 5
                    If fields(1) <> "details.txt" And fields(1) <> "cell_update.txt" Then Err.Raise 5, , "Unsupported package instruction."
                    UPCheckFile folder, CStr(fields(1)), CStr(fields(2)), files, hashes
                Case Else: Err.Raise 5, , "Unknown manifest instruction."
            End Select
        End If
    Next i
    If components.count = 0 Then Err.Raise 5, , "Empty component manifest."
    For Each file In fso.GetFolder(folder).files
        If LCase$(file.name) <> "manifest.tsv" Then
            If Not files.exists(file.name) Then Err.Raise 5, , "Unlisted package file: " & file.name
        End If
    Next file
    If fso.GetFolder(folder).SubFolders.count <> 0 Then Err.Raise 5, , "Nested package folders are not supported."
    result.Add "Components", components: result.Add "References", references: result.Add "Files", files: result.Add "Migrations", migrations
    result.Add "Preserved", preserved
    Set UPValidate = result
End Function

Private Sub UPCheckFile(ByVal folder As String, ByVal leaf As String, ByVal expectedHash As String, ByVal files As Object, ByVal hashes As Object)
    If Not UPSafeLeaf(leaf) Then Err.Raise 5, , "Unsafe package file path."
    If files.exists(leaf) Then Err.Raise 5, , "Duplicate package file."
    If LCase$(expectedHash) <> UPBatchHash(hashes, leaf) Then Err.Raise 5, , "File hash mismatch: " & leaf
    files.Add leaf, expectedHash
End Sub

Public Function UPExpand(ByVal package As String) As String
    Dim fso As Object, folder As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    If fso.FolderExists(package) Then
        UPExpand = fso.GetAbsolutePathName(package)
        Exit Function
    End If
    If LCase$(fso.GetExtensionName(package)) <> "zip" Then Err.Raise 5, , "Select a package ZIP or extracted package folder."
    folder = UPNewFolder(Environ$("TEMP"), "VBAUnpackV2_")
    UPPowerShell "Add-Type -AssemblyName System.IO.Compression.FileSystem; $z=[IO.Compression.ZipFile]::OpenRead(" & UPPSQuote(package) & "); try { foreach($e in $z.Entries) { if($e.FullName -ne $e.Name -or $e.Name -eq '' -or $e.FullName.Contains(':')) { throw 'Unsafe ZIP entry' } }; if($z.Entries.Count -gt 3000) { throw 'Too many entries' } } finally { $z.Dispose() }; Expand-Archive -LiteralPath " & UPPSQuote(package) & " -DestinationPath " & UPPSQuote(folder)
    UPExpand = folder
End Function

Public Sub UPPreflight(ByVal book As Workbook, ByVal package As Object, ByVal fullRepair As Boolean)
    Dim key As Variant, row As Variant, component As Object, ref As Object
    If book.ReadOnly Then Err.Raise 5, , "The workbook is read-only."
    If book.VBProject.Protection <> 0 Then Err.Raise 5, , "The VBA project is locked or inaccessible."
    For Each key In package("Components").keys
        row = package("Components")(key)
        Set component = UPComponent(book, CStr(key))
        If CLng(row(2)) = 100 Then
            If component Is Nothing Then Err.Raise 5, , "Document code name not found in target: " & key
            If component.Type <> 100 Then Err.Raise 5, , "Document type mismatch: " & key
        ElseIf Not component Is Nothing Then
            If component.Type <> CLng(row(2)) Then Err.Raise 5, , "VBA component type mismatch: " & key
        End If
    Next key
    If fullRepair And package("Mode") <> "RECOVERY" Then
        For Each component In book.VBProject.VBComponents
            If component.Type = 100 Then
                If Not package("Components").exists(component.name) Then Err.Raise 5, , "Repair package lacks document code for " & component.name & ". Export a full package matching this workbook's sheet structure."
            End If
        Next component
    End If
    For Each ref In book.VBProject.references
        If ref.IsBroken Then
            If Not fullRepair Then Err.Raise 5, , "Broken target reference. Review installed dependencies before repair."
        End If
    Next ref
End Sub

Public Sub UPApplyToWorkbook(ByVal book As Workbook, ByVal folder As String, ByVal fullRepair As Boolean)
    Dim package As Object, key As Variant, row As Variant, component As Object, i As Long
    Dim body As String, ref As Object, found As Boolean, requested As Variant, code As Object
    Set package = UPValidate(folder, fullRepair)
    UPPreflight book, package, fullRepair
    If fullRepair Then
        For i = book.VBProject.references.count To 1 Step -1
            Set ref = book.VBProject.references(i)
            If ref.IsBroken Then book.VBProject.references.Remove ref
        Next i
    End If
    For Each requested In package("References")
        found = False
        For Each ref In book.VBProject.references
            If StrComp(ref.GUID, requested(1), vbTextCompare) = 0 Then
                If ref.Major < CLng(requested(2)) Then Err.Raise 5, , "Incompatible installed reference: " & ref.name
                found = True
                Exit For
            End If
        Next ref
        If Not found Then book.VBProject.references.AddFromGuid CStr(requested(1)), CLng(requested(2)), CLng(requested(3))
    Next requested
    If fullRepair And package("Mode") <> "RECOVERY" Then
        For i = book.VBProject.VBComponents.count To 1 Step -1
            Set component = book.VBProject.VBComponents(i)
            If component.Type <> 100 Then book.VBProject.VBComponents.Remove component
        Next i
    Else
        For Each key In package("Components").keys
            Set component = UPComponent(book, CStr(key))
            If Not component Is Nothing Then
                If component.Type <> 100 Then book.VBProject.VBComponents.Remove component
            End If
        Next key
    End If
    For Each key In package("Components").keys
        row = package("Components")(key)
        If CLng(row(2)) = 100 Then
            Set component = UPComponent(book, CStr(key))
        Else
            Set component = book.VBProject.VBComponents.Import(UPPath(folder, CStr(row(3))))
            If StrComp(component.name, CStr(key), vbBinaryCompare) <> 0 Or component.Type <> CLng(row(2)) Then Err.Raise 5, , "Import name/type mismatch; working copy rejected: " & key
        End If
        body = UPRead(UPPath(folder, CStr(row(5))), "unicode")
        Set code = component.codeModule
        If code.CountOfLines > 0 Then code.DeleteLines 1, code.CountOfLines
        ' AddFromString can append a stray () to conditional API declarations.
        ' InsertLines restores the Unicode source without that VBE mutation.
        If Len(body) > 0 Then code.InsertLines 1, body
        UPAssertCode component, body
    Next key
    UPVerifyBook book, folder, fullRepair
End Sub

Public Sub UPVerifyBook(ByVal book As Workbook, ByVal folder As String, ByVal fullRepair As Boolean)
    Dim package As Object, key As Variant, row As Variant, component As Object
    Set package = UPValidate(folder, fullRepair)
    For Each key In package("Components").keys
        row = package("Components")(key)
        Set component = UPComponent(book, CStr(key))
        If component Is Nothing Then Err.Raise 5, , "Missing restored component: " & key
        If component.Type <> CLng(row(2)) Then Err.Raise 5, , "Restored type mismatch."
        UPAssertCode component, UPRead(UPPath(folder, CStr(row(5))), "unicode")
    Next key
    If fullRepair And package("Mode") <> "RECOVERY" Then
        If book.VBProject.VBComponents.count <> package("Components").count Then Err.Raise 5, , "Unexpected component remains after full repair."
    End If
End Sub

Public Function UPVersion(ByVal book As Workbook) As String
    On Error Resume Next
    UPVersion = CStr(book.CustomDocumentProperties("VBAUpdateVersion").value)
    On Error GoTo 0
End Function

Public Sub UPSetVersion(ByVal book As Workbook, ByVal version As String)
    Dim prop As Object
    On Error Resume Next
    Set prop = book.CustomDocumentProperties("VBAUpdateVersion")
    On Error GoTo 0
    If prop Is Nothing Then
        book.CustomDocumentProperties.Add "VBAUpdateVersion", False, 4, version
    Else
        prop.value = version
    End If
End Sub




