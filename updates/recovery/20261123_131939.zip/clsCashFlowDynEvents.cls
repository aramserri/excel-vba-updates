VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsCashFlowDynEvents"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

  Public WithEvents Btn As MSForms.CommandButton
Attribute Btn.VB_VarHelpID = -1
  Public WithEvents Txt As MSForms.TextBox
Attribute Txt.VB_VarHelpID = -1
  Public ParentForm As Object

  Private Sub Btn_Click()
      If ParentForm Is Nothing Then Exit Sub
      ParentForm.DynamicButtonClicked Btn.name
  End Sub

  Private Sub Txt_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      If Txt Is Nothing Then Exit Sub
      If ParentForm Is Nothing Then Exit Sub

      Select Case LCase$(CStr(Txt.Tag))
          Case "money"
              If Len(Trim$(Txt.text)) > 0 Then
                  Txt.text = Format(ParentForm.MoneyValue(Txt.text), "#,##0")
              End If

          Case "date"
              Txt.text = ParentForm.NormalizeDateText(Txt.text)

          Case "number"
              If Len(Trim$(Txt.text)) > 0 Then
                  Txt.text = CStr(CLng(val(Txt.text)))
              End If
      End Select
  End Sub
