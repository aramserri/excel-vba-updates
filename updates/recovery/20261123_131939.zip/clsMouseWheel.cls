VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsMouseWheel"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Private WithEvents MyListBox As MSForms.ListBox
Attribute MyListBox.VB_VarHelpID = -1
Private WithEvents MyComboBox As MSForms.ComboBox
Attribute MyComboBox.VB_VarHelpID = -1
Private WithEvents MyFrame As MSForms.Frame
Attribute MyFrame.VB_VarHelpID = -1

' ��� ����� ����� �� ����
Public Sub Attach(ctl As Object)
    If typeName(ctl) = "ListBox" Then
        Set MyListBox = ctl
    ElseIf typeName(ctl) = "ComboBox" Then
        Set MyComboBox = ctl
    ElseIf typeName(ctl) = "Frame" Then
        Set MyFrame = ctl
    End If
End Sub

' ���� ��� �� �� ��� �ј� ���� ��� ���ʝ�ǘ�
Private Sub MyListBox_MouseMove(ByVal Button As Integer, ByVal Shift As Integer, ByVal x As Single, ByVal y As Single)
    modMouseScroll.RegisterControl MyListBox
End Sub

' ���� ��� �� ��� �����ǘ�
Private Sub MyComboBox_MouseMove(ByVal Button As Integer, ByVal Shift As Integer, ByVal x As Single, ByVal y As Single)
    modMouseScroll.RegisterControl MyComboBox
End Sub


Private Sub MyFrame_MouseMove(ByVal Button As Integer, ByVal Shift As Integer, ByVal x As Single, ByVal y As Single)
    modMouseScroll.RegisterControl MyFrame
End Sub

