VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} ComponentExporterForm 
   Caption         =   "EXPORT VBA MODULES AND FORMS"
   ClientHeight    =   12615
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   7170
   OleObjectBlob   =   "ComponentExporterForm.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "ComponentExporterForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
'
' Option Explicit
'
'  ' =============================================================================
'  ' ComponentExporterForm
'  '
'  ' Creates a queue-ready update ZIP:
'  '
'  '   20261005_181500.zip
'  '
'  ' Optional matching details file:
'  '
'  '   20261005_181500.txt
'  '
'  ' The ZIP contains only:
'  ' - .bas
'  ' - .cls
'  ' - .frm
'  ' - .frx
'  ' - cell_update.txt, if provided
'  '
'  ' It does NOT create version.txt.
'  ' After successful ZIP creation, loose exported files are deleted from the
'  ' destination folder so only the final package remains.
'  ' =============================================================================
'
'  Private Const LAST_EXPORT_PATH_NAME As String = "VBA_Export_LastPath"
'  Private Const CONFIG_SHEET_NAME As String = "�������"
'  Private Const SELECTED_COMPONENTS_COL As String = "AH"
'
'  Private Sub UserForm_Initialize()
'      Dim vbComp As Object
'      Dim vbProj As Object
'      Dim itemText As String
'
'      Me.Caption = "Export VBA Components"
'
'      On Error Resume Next
'      Set vbProj = ThisWorkbook.VBProject
'      If Err.Number <> 0 Then
'          MsgBox "Unable to access VBA Project." & vbCrLf & vbCrLf & _
'                 "Please enable 'Trust access to the VBA project object model' in Excel Options > Trust Center > Trust Center Settings > Macro Settings.", vbExclamation
'          Unload Me
'          Exit Sub
'      End If
'      On Error GoTo 0
'
'      lstComponents.Clear
'
'      For Each vbComp In vbProj.VBComponents
'          Select Case vbComp.Type
'              Case 1
'                  itemText = "[Module] " & vbComp.Name
'                  lstComponents.AddItem itemText
'
'              Case 2
'                  itemText = "[Class] " & vbComp.Name
'                  lstComponents.AddItem itemText
'
'              Case 3
'                  itemText = "[Form] " & vbComp.Name
'                  lstComponents.AddItem itemText
'
'              Case 100
'                  If vbComp.Name = "ThisWorkbook" Then
'                      itemText = "[Document] " & vbComp.Name
'                      lstComponents.AddItem itemText
'                  End If
'          End Select
'      Next vbComp
'
'      If lstComponents.ListCount = 0 Then
'          MsgBox "No exportable components found.", vbInformation
'          Unload Me
'          Exit Sub
'      End If
'
'      LoadPreviousSelections
'  End Sub
'
'  Private Sub btnSelectAll_Click()
'      Dim i As Long
'
'      For i = 0 To lstComponents.ListCount - 1
'          lstComponents.Selected(i) = True
'      Next i
'  End Sub
'
'  Private Sub btnDeselectAll_Click()
'      Dim i As Long
'
'      For i = 0 To lstComponents.ListCount - 1
'          lstComponents.Selected(i) = False
'      Next i
'  End Sub
'
'  Private Sub btnCancel_Click()
'      Unload Me
'  End Sub
'
'  Private Sub btnExport_Click()
'      Dim selectedCount As Long
'      Dim i As Long
'      Dim folderPath As String
'      Dim vbProj As Object
'      Dim vbComp As Object
'      Dim componentName As String
'      Dim fileName As String
'      Dim fileExt As String
'      Dim fullPath As String
'      Dim frxPath As String
'      Dim exportCount As Long
'
'      Dim versionText As String
'      Dim zipPath As String
'      Dim detailsPath As String
'      Dim detailsText As String
'
'      Dim fso As Object
'      Dim exportedFiles As Collection
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set exportedFiles = New Collection
'
'      selectedCount = 0
'      For i = 0 To lstComponents.ListCount - 1
'          If lstComponents.Selected(i) Then selectedCount = selectedCount + 1
'      Next i
'
'      If selectedCount = 0 Then
'          MsgBox "Please select at least one component to export.", vbExclamation
'          Exit Sub
'      End If
'
'      SaveSelectedComponents
'
'      folderPath = SelectFolder()
'      If folderPath = "" Then
'          MsgBox "Export cancelled - no folder selected.", vbInformation
'          Exit Sub
'      End If
'
'      versionText = MakeVersionText()
'      zipPath = folderPath & "\" & versionText & ".zip"
'      detailsPath = folderPath & "\" & versionText & ".txt"
'
'      Set vbProj = ThisWorkbook.VBProject
'
'      ' Remove an old package with the same name if it exists.
'      If fso.FileExists(zipPath) Then fso.DeleteFile zipPath, True
'
'      For i = 0 To lstComponents.ListCount - 1
'          If lstComponents.Selected(i) Then
'              componentName = ExtractComponentName(lstComponents.List(i))
'
'              For Each vbComp In vbProj.VBComponents
'                  If vbComp.Name = componentName Then
'                      Select Case vbComp.Type
'                          Case 1
'                              fileExt = ".bas"
'                          Case 2
'                              fileExt = ".cls"
'                          Case 3
'                              fileExt = ".frm"
'                          Case 100
'                              fileExt = ".cls"
'                          Case Else
'                              fileExt = ""
'                      End Select
'
'                      If fileExt <> "" Then
'                          fileName = vbComp.Name & fileExt
'                          fullPath = folderPath & "\" & fileName
'
'                          If fso.FileExists(fullPath) Then fso.DeleteFile fullPath, True
'
'                          If vbComp.Type = 100 Then
'                              If ExportDocumentModule(vbComp, fullPath) Then
'                                  exportCount = exportCount + 1
'                                  exportedFiles.Add fullPath
'                              Else
'                                  MsgBox "Error exporting document module: " & vbComp.Name, vbExclamation
'                              End If
'                          Else
'                              On Error Resume Next
'                              vbComp.Export fullPath
'                              If Err.Number = 0 Then
'                                  exportCount = exportCount + 1
'                                  exportedFiles.Add fullPath
'
'                                  If vbComp.Type = 3 Then
'                                      frxPath = folderPath & "\" & vbComp.Name & ".frx"
'                                      If fso.FileExists(frxPath) Then exportedFiles.Add frxPath
'                                  End If
'                              Else
'                                  MsgBox "Error exporting " & vbComp.Name & ": " & Err.description, vbExclamation
'                              End If
'                              Err.Clear
'                              On Error GoTo 0
'                          End If
'                      End If
'
'                      Exit For
'                  End If
'              Next vbComp
'          End If
'      Next i
'
'      CreateCellUpdateIfNeeded folderPath, exportedFiles
'
'      If exportCount = 0 Then
'          MsgBox "No components were exported. ZIP was not created.", vbExclamation
'          Exit Sub
'      End If
'
'      If Not CreateUpdateZipFromFiles(exportedFiles, zipPath) Then
'          MsgBox "Components were exported, but ZIP package could not be created.", vbExclamation
'          Exit Sub
'      End If
'
'      ' Optional matching update details file. This file is not included inside the ZIP.
'      detailsText = GetOptionalTextBoxText("txtUpdateDetails")
'      If Trim$(detailsText) <> "" Then
'          If Not WriteUtf8TextFile(detailsPath, detailsText) Then
'              MsgBox "ZIP was created, but update details file could not be created:" & vbCrLf & detailsPath, vbExclamation
'          End If
'      End If
'
'      DeleteExportedLooseFiles exportedFiles
'
'      MsgBox "Export package complete!" & vbCrLf & vbCrLf & _
'             "Components exported: " & exportCount & " of " & selectedCount & vbCrLf & _
'             "Version: " & versionText & vbCrLf & _
'             "ZIP: " & zipPath & vbCrLf & vbCrLf & _
'             "Add this line to queue.txt:" & vbCrLf & versionText, _
'             vbInformation
'
'      Unload Me
'  End Sub
'
'  ' =============================================================================
'  ' Saved Selections
'  ' =============================================================================
'
'  Private Sub LoadPreviousSelections()
'      Dim ws As Worksheet
'      Dim lastRow As Long
'      Dim i As Long
'      Dim j As Long
'      Dim savedName As String
'      Dim componentName As String
'      Dim savedComponents As Object
'
'      On Error Resume Next
'      Set ws = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
'      On Error GoTo 0
'
'      If ws Is Nothing Then Exit Sub
'
'      Set savedComponents = CreateObject("Scripting.Dictionary")
'      savedComponents.CompareMode = vbTextCompare
'
'      lastRow = ws.Cells(ws.rows.count, SELECTED_COMPONENTS_COL).End(xlUp).row
'
'      For i = 1 To lastRow
'          savedName = Trim$(CStr(ws.Cells(i, SELECTED_COMPONENTS_COL).value))
'          If savedName <> "" Then savedComponents(savedName) = True
'      Next i
'
'      For j = 0 To lstComponents.ListCount - 1
'          componentName = ExtractComponentName(lstComponents.List(j))
'          If savedComponents.exists(componentName) Then lstComponents.Selected(j) = True
'      Next j
'  End Sub
'
'  Private Sub SaveSelectedComponents()
'      Dim ws As Worksheet
'      Dim i As Long
'      Dim componentName As String
'      Dim writeRow As Long
'      Dim lastRow As Long
'
'      On Error Resume Next
'      Set ws = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
'      On Error GoTo 0
'
'      If ws Is Nothing Then
'          MsgBox "��� '" & CONFIG_SHEET_NAME & "' ���� ���. �����ȝ�� ����� ���.", vbExclamation
'          Exit Sub
'      End If
'
'      lastRow = ws.Cells(ws.rows.count, SELECTED_COMPONENTS_COL).End(xlUp).row
'      If lastRow >= 1 Then
'          ws.Range(ws.Cells(1, SELECTED_COMPONENTS_COL), ws.Cells(lastRow, SELECTED_COMPONENTS_COL)).ClearContents
'      End If
'
'      writeRow = 1
'      For i = 0 To lstComponents.ListCount - 1
'          If lstComponents.Selected(i) Then
'              componentName = ExtractComponentName(lstComponents.List(i))
'              ws.Cells(writeRow, SELECTED_COMPONENTS_COL).value = componentName
'              writeRow = writeRow + 1
'          End If
'      Next i
'  End Sub
'
'  ' =============================================================================
'  ' Export Helpers
'  ' =============================================================================
'
'  Private Function ExtractComponentName(ByVal itemText As String) As String
'      Dim pos As Long
'
'      pos = InStr(itemText, "] ")
'      If pos > 0 Then
'          ExtractComponentName = Mid$(itemText, pos + 2)
'      Else
'          ExtractComponentName = itemText
'      End If
'  End Function
'
'  Private Function SelectFolder() As String
'      Dim folderDialog As FileDialog
'      Dim selectedPath As String
'      Dim lastPath As String
'
'      lastPath = GetLastExportPath()
'
'      Set folderDialog = Application.FileDialog(msoFileDialogFolderPicker)
'
'      With folderDialog
'          .Title = "Select Export Folder"
'          .AllowMultiSelect = False
'
'          If lastPath <> "" Then
'              If Dir(lastPath, vbDirectory) <> "" Then .InitialFileName = lastPath & "\"
'          End If
'
'          If .Show = -1 Then
'              selectedPath = .selectedItems(1)
'              SaveLastExportPath selectedPath
'          Else
'              selectedPath = ""
'          End If
'      End With
'
'      SelectFolder = selectedPath
'  End Function
'
'  Private Function GetLastExportPath() As String
'      On Error Resume Next
'      GetLastExportPath = ThisWorkbook.names(LAST_EXPORT_PATH_NAME).RefersTo
'
'      If Left$(GetLastExportPath, 2) = "=""" Then
'          GetLastExportPath = Mid$(GetLastExportPath, 3, Len(GetLastExportPath) - 3)
'      ElseIf Left$(GetLastExportPath, 1) = "=" Then
'          GetLastExportPath = Mid$(GetLastExportPath, 2)
'      End If
'
'      On Error GoTo 0
'  End Function
'
'  Private Sub SaveLastExportPath(ByVal path As String)
'      On Error Resume Next
'      ThisWorkbook.names(LAST_EXPORT_PATH_NAME).Delete
'      On Error GoTo 0
'
'      ThisWorkbook.names.Add Name:=LAST_EXPORT_PATH_NAME, RefersTo:="=""" & path & """"
'  End Sub
'
'  Private Function ExportDocumentModule(ByVal vbComp As Object, ByVal fullPath As String) As Boolean
'      Dim fso As Object
'      Dim fileStream As Object
'      Dim codeModule As Object
'      Dim totalLines As Long
'      Dim codeText As String
'      Dim header As String
'
'      On Error GoTo Failed
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set codeModule = vbComp.codeModule
'
'      header = "VERSION 1.0 CLASS" & vbCrLf & _
'               "BEGIN" & vbCrLf & _
'               "  MultiUse = -1  'True" & vbCrLf & _
'               "END" & vbCrLf & _
'               "Attribute VB_Name = """ & vbComp.Name & """" & vbCrLf & _
'               "Attribute VB_GlobalNameSpace = False" & vbCrLf & _
'               "Attribute VB_Creatable = False" & vbCrLf & _
'               "Attribute VB_PredeclaredId = True" & vbCrLf & _
'               "Attribute VB_Exposed = True" & vbCrLf
'
'      totalLines = codeModule.CountOfLines
'
'      If totalLines > 0 Then
'          codeText = codeModule.lines(1, totalLines)
'      Else
'          codeText = ""
'      End If
'
'      Set fileStream = fso.CreateTextFile(fullPath, True, False)
'      fileStream.Write header & codeText
'      fileStream.Close
'
'      ExportDocumentModule = True
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If Not fileStream Is Nothing Then fileStream.Close
'      ExportDocumentModule = False
'  End Function
'
'  Private Sub CreateCellUpdateIfNeeded(ByVal folderPath As String, ByRef exportedFiles As Collection)
'      Dim cellAddr As String
'      Dim cellVal As String
'      Dim fso As Object
'      Dim cellFile As Object
'      Dim cellPath As String
'
'      cellAddr = Trim$(txtcell.Text)
'      cellVal = Trim$(txtformula.Text)
'
'      cellVal = Replace(cellVal, vbCrLf, "")
'      cellVal = Replace(cellVal, vbCr, "")
'      cellVal = Replace(cellVal, vbLf, "")
'
'      If cellAddr = "" Or cellVal = "" Then Exit Sub
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      cellPath = folderPath & "\cell_update.txt"
'
'      If fso.FileExists(cellPath) Then fso.DeleteFile cellPath, True
'
'      Set cellFile = fso.CreateTextFile(cellPath, True, False)
'      cellFile.WriteLine cellAddr
'      cellFile.WriteLine cellVal
'      cellFile.Close
'
'      exportedFiles.Add cellPath
'  End Sub
'
'  Private Function MakeVersionText() As String
'      MakeVersionText = Format$(Now, "yyyymmdd_hhnnss")
'  End Function
'
'  ' =============================================================================
'  ' ZIP / Cleanup
'  ' =============================================================================
'
'  Private Function CreateUpdateZipFromFiles(ByVal filesToZip As Collection, ByVal zipPath As String) As Boolean
'      Dim fso As Object
'      Dim wsh As Object
'      Dim stagingFolder As String
'      Dim filePath As Variant
'      Dim fileName As String
'      Dim filesAdded As Long
'      Dim psCommand As String
'      Dim shellCommand As String
'      Dim exitCode As Long
'
'      On Error GoTo Failed
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set wsh = CreateObject("WScript.Shell")
'
'      stagingFolder = Environ$("TEMP") & "\VBAUpdatePackage_" & Format$(Now, "yyyymmdd_hhnnss")
'
'      If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
'      fso.CreateFolder stagingFolder
'
'      For Each filePath In filesToZip
'          If fso.FileExists(CStr(filePath)) Then
'              fileName = fso.GetFileName(CStr(filePath))
'              fso.CopyFile CStr(filePath), stagingFolder & "\" & fileName, True
'              filesAdded = filesAdded + 1
'          End If
'      Next filePath
'
'      If filesAdded = 0 Then GoTo Failed
'
'      If fso.FileExists(zipPath) Then fso.DeleteFile zipPath, True
'
'      psCommand = "$files = Get-ChildItem -LiteralPath " & PowerShellQuote(stagingFolder) & _
'                  " ; if ($files.Count -eq 0) { exit 2 } ; " & _
'                  "Compress-Archive -LiteralPath $files.FullName -DestinationPath " & PowerShellQuote(zipPath) & "-Force"
'
'      shellCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command " & Chr$(34) & psCommand & Chr$(34)
'      exitCode = wsh.Run(shellCommand, 0, True)
'
'      If exitCode <> 0 Then GoTo Failed
'      If Not fso.FileExists(zipPath) Then GoTo Failed
'      If fso.GetFile(zipPath).Size = 0 Then GoTo Failed
'
'      On Error Resume Next
'      If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
'      On Error GoTo 0
'
'      CreateUpdateZipFromFiles = True
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If Not fso Is Nothing Then
'          If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
'      End If
'      CreateUpdateZipFromFiles = False
'  End Function
'
'  Private Sub DeleteExportedLooseFiles(ByVal exportedFiles As Collection)
'      Dim fso As Object
'      Dim filePath As Variant
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'
'      For Each filePath In exportedFiles
'          On Error Resume Next
'          If fso.FileExists(CStr(filePath)) Then fso.DeleteFile CStr(filePath), True
'          On Error GoTo 0
'      Next filePath
'  End Sub
'
'  Private Function PowerShellQuote(ByVal value As String) As String
'      PowerShellQuote = "'" & Replace(value, "'", "''") & "'"
'  End Function
'
'  ' =============================================================================
'  ' Optional Details File
'  ' =============================================================================
'
'  Private Function GetOptionalTextBoxText(ByVal controlName As String) As String
'      Dim ctl As Object
'
'      On Error Resume Next
'      Set ctl = Me.Controls(controlName)
'      If Not ctl Is Nothing Then GetOptionalTextBoxText = CStr(ctl.Text)
'      On Error GoTo 0
'  End Function
'
'  Private Function WriteUtf8TextFile(ByVal filePath As String, ByVal fileText As String) As Boolean
'      Dim stm As Object
'
'      On Error GoTo Failed
'
'      Set stm = CreateObject("ADODB.Stream")
'      stm.Type = 2
'      stm.Charset = "utf-8"
'      stm.Open
'      stm.WriteText fileText
'      stm.SaveToFile filePath, 2
'      stm.Close
'
'      WriteUtf8TextFile = True
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If Not stm Is Nothing Then stm.Close
'      WriteUtf8TextFile = False
'  End Function


 Option Explicit

  ' =============================================================================
  ' ComponentExporterForm
  '
  ' Creates a queue-ready update ZIP:
  '
  '   20261005_181500.zip
  '
  ' Optional matching details file:
  '
  '   20261005_181500.txt
  '
  ' The ZIP contains only:
  ' - .bas
  ' - .cls
  ' - .frm
  ' - .frx
  ' - cell_update.txt, if provided
  '
  ' It does NOT create version.txt.
  ' After successful ZIP creation, loose exported files are deleted from the
  ' destination folder so only the final package remains.
  ' =============================================================================

  Private Const LAST_EXPORT_PATH_NAME As String = "VBA_Export_LastPath"
  Private Const CONFIG_SHEET_NAME As String = "�������"
  Private Const SELECTED_COMPONENTS_COL As String = "AH"
  Private selectedComponents As Object
Private m_RecoveryMode As Boolean
Private m_NormalSelection As Object
Private m_RecoverySelection As Object
  Private currentFilterType As String





   Private Sub UserForm_Initialize()
      Dim vbProj As Object

      Me.Caption = "Export VBA Components"

      On Error Resume Next
      Set vbProj = ThisWorkbook.VBProject
      If Err.Number <> 0 Then
          MsgBox "Unable to access VBA Project." & vbCrLf & vbCrLf & _
                 "Please enable 'Trust access to the VBA project object Model ' in Excel Options > Trust Center > Trust Center Settings > Macro Settings.", vbExclamation
          Unload Me
          Exit Sub
      End If
      On Error GoTo 0

      Set selectedComponents = CreateObject("Scripting.Dictionary")
      selectedComponents.CompareMode = vbTextCompare

      currentFilterType = "All"

      SetupComponentListBox
      LoadSavedSelectionsIntoMemory
      LoadComponentList

      If lstComponents.ListCount = 0 Then
          MsgBox "No exportable components found.", vbInformation
          Unload Me
          Exit Sub
      End If
  End Sub

 Private Sub btnSelectAll_Click()
      Dim i As Long
      Dim componentName As String

      For i = 0 To lstComponents.ListCount - 1
          lstComponents.selected(i) = True
          componentName = GetListComponentName(i)
          selectedComponents(componentName) = True
      Next i
  End Sub

  Private Sub btnDeselectAll_Click()
      Dim i As Long
      Dim componentName As String

      For i = 0 To lstComponents.ListCount - 1
          lstComponents.selected(i) = False
          componentName = GetListComponentName(i)

          If selectedComponents.exists(componentName) Then
  selectedComponents.Remove componentName
  End If
      Next i
  End Sub

  Private Sub btnCancel_Click()
      Unload Me
  End Sub








  ' =============================================================================
  ' Saved Selections
  ' =============================================================================





  ' =============================================================================
  ' Export Helpers
  ' =============================================================================



  Private Function SelectFolder() As String
      Dim folderDialog As FileDialog
      Dim selectedPath As String
      Dim lastPath As String

      lastPath = GetLastExportPath()

      Set folderDialog = Application.FileDialog(msoFileDialogFolderPicker)

      With folderDialog
          .title = "Select Export Folder"
          .AllowMultiSelect = False

          If lastPath <> "" Then
              If Dir(lastPath, vbDirectory) <> "" Then .InitialFileName = lastPath & "\"
          End If

          If .Show = -1 Then
              selectedPath = .selectedItems(1)
              SaveLastExportPath selectedPath
          Else
              selectedPath = ""
          End If
      End With

      SelectFolder = selectedPath
  End Function

  Private Function GetLastExportPath() As String
      On Error Resume Next
      GetLastExportPath = ThisWorkbook.names(LAST_EXPORT_PATH_NAME).RefersTo

      If Left$(GetLastExportPath, 2) = "=""" Then
          GetLastExportPath = Mid$(GetLastExportPath, 3, Len(GetLastExportPath) - 3)
      ElseIf Left$(GetLastExportPath, 1) = "=" Then
          GetLastExportPath = Mid$(GetLastExportPath, 2)
      End If

      On Error GoTo 0
  End Function

  Private Sub SaveLastExportPath(ByVal path As String)
      On Error Resume Next
      ThisWorkbook.names(LAST_EXPORT_PATH_NAME).Delete
      On Error GoTo 0

      ThisWorkbook.names.Add name:=LAST_EXPORT_PATH_NAME, RefersTo:="=""" & path & """"
  End Sub

  Private Function ExportDocumentModule(ByVal vbComp As Object, ByVal fullPath As String) As Boolean
      Dim fso As Object
      Dim fileStream As Object
      Dim codeModule As Object
      Dim totalLines As Long
      Dim codeText As String
      Dim header As String

      On Error GoTo Failed

      Set fso = CreateObject("Scripting.FileSystemObject")
      Set codeModule = vbComp.codeModule

      header = "VERSION 1.0 CLASS" & vbCrLf & _
               "BEGIN" & vbCrLf & _
               "  MultiUse = -1  'True" & vbCrLf & _
               "END" & vbCrLf & _
               "Attribute VB_Name = """ & vbComp.name & """" & vbCrLf & _
               "Attribute VB_GlobalNameSpace = False" & vbCrLf & _
               "Attribute VB_Creatable = False" & vbCrLf & _
               "Attribute VB_PredeclaredId = True" & vbCrLf & _
               "Attribute VB_Exposed = True" & vbCrLf

      totalLines = codeModule.CountOfLines

      If totalLines > 0 Then
          codeText = codeModule.lines(1, totalLines)
      Else
          codeText = ""
      End If

      Set fileStream = fso.CreateTextFile(fullPath, True, False)
      fileStream.Write header & codeText
      fileStream.Close

      ExportDocumentModule = True
      Exit Function

Failed:
      On Error Resume Next
      If Not fileStream Is Nothing Then fileStream.Close
      ExportDocumentModule = False
  End Function

  Private Sub CreateCellUpdateIfNeeded(ByVal folderPath As String, ByRef exportedFiles As Collection)
      Dim cellAddr As String
      Dim cellVal As String
      Dim fso As Object
      Dim cellFile As Object
      Dim cellPath As String

      cellAddr = Trim$(txtcell.text)
      cellVal = Trim$(txtformula.text)

      cellVal = Replace(cellVal, vbCrLf, "")
      cellVal = Replace(cellVal, vbCr, "")
      cellVal = Replace(cellVal, vbLf, "")

      If cellAddr = "" Or cellVal = "" Then Exit Sub

      Set fso = CreateObject("Scripting.FileSystemObject")
      cellPath = folderPath & "\cell_update.txt"

      If fso.FileExists(cellPath) Then fso.DeleteFile cellPath, True

      Set cellFile = fso.CreateTextFile(cellPath, True, False)
      cellFile.WriteLine cellAddr
      cellFile.WriteLine cellVal
      cellFile.Close

      exportedFiles.Add cellPath
  End Sub

  Private Function MakeVersionText() As String
      MakeVersionText = Format$(Now, "yyyymmdd_hhnnss")
  End Function

  ' =============================================================================
  ' ZIP / Cleanup
  ' =============================================================================

  Private Function CreateUpdateZipFromFiles(ByVal filesToZip As Collection, ByVal zipPath As String) As Boolean
      Dim fso As Object
      Dim wsh As Object
      Dim stagingFolder As String
      Dim filePath As Variant
      Dim fileName As String
      Dim filesAdded As Long
      Dim psCommand As String
      Dim shellCommand As String
      Dim exitCode As Long

      On Error GoTo Failed

      Set fso = CreateObject("Scripting.FileSystemObject")
      Set wsh = CreateObject("WScript.Shell")

      stagingFolder = Environ$("TEMP") & "\VBAUpdatePackage_" & Format$(Now, "yyyymmdd_hhnnss")

      If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
      fso.CreateFolder stagingFolder

      For Each filePath In filesToZip
          If fso.FileExists(CStr(filePath)) Then
              fileName = fso.GetFileName(CStr(filePath))
              fso.CopyFile CStr(filePath), stagingFolder & "\" & fileName, True
              filesAdded = filesAdded + 1
          End If
      Next filePath

      If filesAdded = 0 Then GoTo Failed

      If fso.FileExists(zipPath) Then fso.DeleteFile zipPath, True

      psCommand = "$files = Get-ChildItem -LiteralPath " & PowerShellQuote(stagingFolder) & _
                  " ; if ($files.Count -eq 0) { exit 2 } ; " & _
                  "Compress-Archive -LiteralPath $files.FullName -DestinationPath " & PowerShellQuote(zipPath) & "-Force"

      shellCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command " & Chr$(34) & psCommand & Chr$(34)
      exitCode = wsh.Run(shellCommand, 0, True)

      If exitCode <> 0 Then GoTo Failed
      If Not fso.FileExists(zipPath) Then GoTo Failed
      If fso.GetFile(zipPath).size = 0 Then GoTo Failed

      On Error Resume Next
      If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
      On Error GoTo 0

      CreateUpdateZipFromFiles = True
      Exit Function

Failed:
      On Error Resume Next
      If Not fso Is Nothing Then
          If fso.FolderExists(stagingFolder) Then fso.DeleteFolder stagingFolder, True
      End If
      CreateUpdateZipFromFiles = False
  End Function

  Private Sub DeleteExportedLooseFiles(ByVal exportedFiles As Collection)
      Dim fso As Object
      Dim filePath As Variant

      Set fso = CreateObject("Scripting.FileSystemObject")

      For Each filePath In exportedFiles
          On Error Resume Next
          If fso.FileExists(CStr(filePath)) Then fso.DeleteFile CStr(filePath), True
          On Error GoTo 0
      Next filePath
  End Sub

  Private Function PowerShellQuote(ByVal value As String) As String
      PowerShellQuote = "'" & Replace(value, "'", "''") & "'"
  End Function

  ' =============================================================================
  ' Optional Details File
  ' =============================================================================

  Private Function GetOptionalTextBoxText(ByVal controlName As String) As String
      Dim ctl As Object

      On Error Resume Next
      Set ctl = Me.Controls(controlName)
      If Not ctl Is Nothing Then GetOptionalTextBoxText = CStr(ctl.text)
      On Error GoTo 0
  End Function

  Private Function WriteUtf8TextFile(ByVal filePath As String, ByVal fileText As String) As Boolean
      Dim stm As Object

      On Error GoTo Failed

      Set stm = CreateObject("ADODB.Stream")
      stm.Type = 2
      stm.charset = "utf-8"
      stm.Open
      stm.WriteText fileText
      stm.SaveToFile filePath, 2
      stm.Close

      WriteUtf8TextFile = True
      Exit Function

Failed:
      On Error Resume Next
      If Not stm Is Nothing Then stm.Close
      WriteUtf8TextFile = False
  End Function

 Private Sub SetupComponentListBox()
      With lstComponents
          .Clear
          .ColumnCount = 2
          .ColumnWidths = "80 pt;180 pt"
          .MultiSelect = fmMultiSelectMulti
      End With
  End Sub

  Private Sub LoadComponentList()
      Dim vbProj As Object
      Dim searchText As String

      CaptureVisibleSelections

      Set vbProj = ThisWorkbook.VBProject
      searchText = Trim$(txtSearch.text)

      lstComponents.Clear

      AddComponentsByType vbProj, 3, "Form", searchText
      AddComponentsByType vbProj, 1, "Module", searchText
      AddComponentsByType vbProj, 2, "Class", searchText
      AddComponentsByType vbProj, 100, "Document", searchText

      RestoreVisibleSelections
  End Sub

  Private Sub AddComponentsByType(ByVal vbProj As Object, ByVal targetType As Long, ByVal displayType As String, ByVal searchText As String)
      Dim vbComp As Object

      If currentFilterType <> "All" And currentFilterType <> displayType Then Exit Sub

      For Each vbComp In vbProj.VBComponents
          If vbComp.Type = targetType Then
              If True Then
                  If searchText = "" Or InStr(1, vbComp.name, searchText, vbTextCompare) > 0 Then
                      lstComponents.AddItem displayType
                      lstComponents.List(lstComponents.ListCount - 1, 1) = vbComp.name
                  End If
              End If
          End If
      Next vbComp
  End Sub

  Private Function GetListComponentName(ByVal listIndex As Long) As String
      GetListComponentName = CStr(lstComponents.List(listIndex, 1))
  End Function
Private Sub CaptureVisibleSelections()
      Dim i As Long
      Dim componentName As String

      If selectedComponents Is Nothing Then Exit Sub

      For i = 0 To lstComponents.ListCount - 1
          componentName = GetListComponentName(i)

          If lstComponents.selected(i) Then
              selectedComponents(componentName) = True
          Else
              If selectedComponents.exists(componentName) Then
                  selectedComponents.Remove componentName
              End If
          End If
      Next i
  End Sub

  Private Sub RestoreVisibleSelections()
      Dim i As Long
      Dim componentName As String

      If selectedComponents Is Nothing Then Exit Sub

      For i = 0 To lstComponents.ListCount - 1
          componentName = GetListComponentName(i)
          lstComponents.selected(i) = selectedComponents.exists(componentName)
      Next i
  End Sub

  Private Function SelectedComponentCount() As Long
      CaptureVisibleSelections
      SelectedComponentCount = selectedComponents.count
  End Function

  Private Function IsComponentSelected(ByVal componentName As String) As Boolean
      CaptureVisibleSelections
      IsComponentSelected = selectedComponents.exists(componentName)
  End Function
Private Sub txtSearch_Change()
      LoadComponentList
  End Sub

  Private Sub btnShowAll_Click()
      currentFilterType = "All"
      LoadComponentList
  End Sub

  Private Sub btnShowForms_Click()
      currentFilterType = "Form"
      LoadComponentList
  End Sub

  Private Sub btnShowModules_Click()
      currentFilterType = "Module"
      LoadComponentList
  End Sub

  Private Sub btnShowClasses_Click()
      currentFilterType = "Class"
      LoadComponentList
  End Sub

  Private Sub btnShowDocuments_Click()
      currentFilterType = "Document"
      LoadComponentList
  End Sub

Private Function CopyExportVersion(ByVal versionText As String) As Boolean
    Dim clipboard As MSForms.DataObject
    On Error GoTo ClipboardFailed
    Set clipboard = New MSForms.DataObject
    clipboard.SetText versionText
    clipboard.PutInClipboard
    CopyExportVersion = True
    Exit Function
ClipboardFailed:
    CopyExportVersion = False
End Function

Private Sub btnExport_Click()
    ExportPackageV2 m_RecoveryMode
End Sub

Private Sub btnFullRepair_Click()
    If Not m_RecoveryMode Then
        Me.chkRecoveryMode.value = True
        MsgBox "Recovery selection is now active. Select the components to distribute; unselected components will be preserved on recipients. Click Export recovery package when ready.", vbInformation
    Else
        ExportPackageV2 True
    End If
End Sub

Private Sub chkRecoveryMode_Click()
    RF_SwitchSelection CBool(Me.chkRecoveryMode.value)
End Sub

Private Sub RF_SwitchSelection(ByVal recovery As Boolean)
    If selectedComponents Is Nothing Then Exit Sub
    If recovery = m_RecoveryMode Then Exit Sub
    CaptureVisibleSelections
    If recovery Then
        Set m_NormalSelection = selectedComponents
        If m_RecoverySelection Is Nothing Then RF_LoadRecoverySelection
        Set selectedComponents = m_RecoverySelection
        Me.btnFullRepair.Caption = "Export recovery package"
    Else
        RF_SaveRecoverySelection
        Set m_RecoverySelection = selectedComponents
        Set selectedComponents = m_NormalSelection
        Me.btnFullRepair.Caption = "Choose recovery components"
    End If
    m_RecoveryMode = recovery
    Me.lstComponents.Clear
    LoadComponentList
End Sub

Private Sub RF_LoadRecoverySelection()
    Dim excluded As Object, text As String, item As Variant, component As Object, i As Long, count As Long
    Set excluded = CreateObject("Scripting.Dictionary"): excluded.CompareMode = vbTextCompare
    Set m_RecoverySelection = CreateObject("Scripting.Dictionary"): m_RecoverySelection.CompareMode = vbTextCompare
    On Error Resume Next
    count = CLng(ThisWorkbook.CustomDocumentProperties("VBARecoveryExcludeCount").value)
    On Error GoTo 0
    If count < 0 Or count > 1000 Then Err.Raise 5, , "Invalid saved recovery selection."
    For i = 1 To count
        text = CStr(ThisWorkbook.CustomDocumentProperties("VBARecoveryExclude_" & Format$(i, "000")).value)
        For Each item In Split(text, "|")
            If CStr(item) <> "" Then excluded(CStr(item)) = True
        Next item
    Next i
    For Each component In ThisWorkbook.VBProject.VBComponents
        If Not excluded.exists(component.name) Then m_RecoverySelection(component.name) = True
    Next component
End Sub

Private Sub RF_SaveRecoverySelection()
    Dim component As Object, text As String, count As Long, oldCount As Long, i As Long
    On Error Resume Next
    oldCount = CLng(ThisWorkbook.CustomDocumentProperties("VBARecoveryExcludeCount").value)
    On Error GoTo 0
    If oldCount < 0 Or oldCount > 1000 Then Err.Raise 5, , "Invalid saved recovery selection."
    For Each component In ThisWorkbook.VBProject.VBComponents
        If Not selectedComponents.exists(component.name) Then
            If Len(text) + Len(component.name) + 1 > 200 Then
                count = count + 1
                RF_SetProperty "VBARecoveryExclude_" & Format$(count, "000"), text
                text = ""
            End If
            text = text & component.name & "|"
        End If
    Next component
    If Len(text) > 0 Then
        count = count + 1
        RF_SetProperty "VBARecoveryExclude_" & Format$(count, "000"), text
    End If
    For i = count + 1 To oldCount
        ThisWorkbook.CustomDocumentProperties("VBARecoveryExclude_" & Format$(i, "000")).Delete
    Next i
    RF_SetProperty "VBARecoveryExcludeCount", CStr(count)
End Sub

Private Sub RF_SetProperty(ByVal name As String, ByVal value As String)
    On Error Resume Next
    ThisWorkbook.CustomDocumentProperties(name).Delete
    On Error GoTo 0
    ThisWorkbook.CustomDocumentProperties.Add name, False, 4, value
End Sub

Private Function RF_ExclusionSummary(ByVal included As Object) As String
    Dim component As Object, shown As Long, total As Long, text As String
    For Each component In ThisWorkbook.VBProject.VBComponents
        If Not included.exists(component.name) Then
            total = total + 1
            If shown < 10 Then text = text & vbCrLf & component.name: shown = shown + 1
        End If
    Next component
    RF_ExclusionSummary = "Included: " & included.count & vbCrLf & "Excluded/preserved: " & total & text
    If total > shown Then RF_ExclusionSummary = RF_ExclusionSummary & vbCrLf & "... and " & total - shown & " more."
End Function

Private Sub ExportPackageV2(ByVal fullRepair As Boolean)
    Dim selected As Object, key As Variant, destination As String, version As String, notice As String, migrations As Variant
    On Error GoTo Failed
    CaptureVisibleSelections
    Set selected = CreateObject("Scripting.Dictionary"): selected.CompareMode = vbTextCompare
    For Each key In selectedComponents.keys
        If selectedComponents(key) Then selected.Add CStr(key), True
    Next key
    If selected.count = 0 Then
        MsgBox "Select at least one component.", vbExclamation
        Exit Sub
    End If
    If fullRepair Then
        If MsgBox("Export SELECTABLE RECOVERY package?" & vbCrLf & RF_ExclusionSummary(selected) & vbCrLf & vbCrLf & _
            "Excluded code/resources will NOT be distributed or deleted on recipients. Other target components are preserved too." & vbCrLf & _
            "Included code must not require unavailable excluded components. Dependencies are not guaranteed by this export." & vbCrLf & _
            "Included worksheet code names must match the recipient. Continue?", vbYesNo + vbExclamation + vbDefaultButton2) <> vbYes Then Exit Sub
    End If
    destination = SelectFolder()
    If destination = "" Then Exit Sub
    migrations = Application.inputBox("Optional one-time setup procedures, separated by commas. Leave blank for none. Cancel stops export.", "Package setup steps", "", Type:=2)
    If VarType(migrations) = vbBoolean Then Exit Sub
    Me.btnExport.enabled = False: Me.btnFullRepair.enabled = False: Me.chkRecoveryMode.enabled = False
    Application.StatusBar = "Exporting and validating VBA package..."
    If fullRepair Then
        version = UPExport(ThisWorkbook, selected, destination, True, Trim$(txtcell.text), txtformula.text, GetOptionalTextBoxText("txtUpdateDetails"), CStr(migrations), selected)
        RF_SaveRecoverySelection
    Else
        version = UPExport(ThisWorkbook, selected, destination, False, Trim$(txtcell.text), txtformula.text, GetOptionalTextBoxText("txtUpdateDetails"), CStr(migrations))
        SaveSelectedComponents
    End If
    If CopyExportVersion(version) Then notice = "Version copied to clipboard." Else notice = "Copy the version below manually."
    Application.StatusBar = False
    MsgBox "Validated package created." & vbCrLf & notice & vbCrLf & "Version: " & version & vbCrLf & UPPath(destination, version & ".zip") & vbCrLf & _
        IIf(fullRepair, "Publish as a recovery download, NOT in the online update queue.", "Upload the ZIP to updates/packages and add its version to updates/queue-v3.txt."), vbInformation
    Unload Me
    Exit Sub
Failed:
    Application.StatusBar = False
    Me.btnExport.enabled = True: Me.btnFullRepair.enabled = True: Me.chkRecoveryMode.enabled = True
    MsgBox "Export stopped. Do not distribute a partial package." & vbCrLf & Err.description, vbExclamation
End Sub


Private Sub LoadSavedSelectionsIntoMemory()
    Dim ws As Worksheet, lastRow As Long, i As Long, savedName As String
    Dim stored As Object, count As Long, text As String, item As Variant

    ' Normal selections no longer own any worksheet cells.
    On Error Resume Next
    Set stored = ThisWorkbook.CustomDocumentProperties("VBANormalSelectionCount")
    On Error GoTo 0
    If Not stored Is Nothing Then
        count = CLng(stored.value)
        If count < 0 Or count > 1000 Then Err.Raise 5, , "Invalid saved normal selection."
        For i = 1 To count
            text = CStr(ThisWorkbook.CustomDocumentProperties("VBANormalSelection_" & Format$(i, "000")).value)
            For Each item In Split(text, "|")
                If CStr(item) <> "" Then selectedComponents(CStr(item)) = True
            Next item
        Next i
        Exit Sub
    End If

    ' Initial migration only: AH also contains unrelated descriptive text.
    ' Read valid component names without clearing, editing or claiming that range.
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(CONFIG_SHEET_NAME)
    On Error GoTo 0
    If ws Is Nothing Then Exit Sub
    lastRow = ws.Cells(ws.rows.count, SELECTED_COMPONENTS_COL).End(xlUp).row
    For i = 1 To lastRow
        If Not IsError(ws.Cells(i, SELECTED_COMPONENTS_COL).Value2) Then
            savedName = Trim$(CStr(ws.Cells(i, SELECTED_COMPONENTS_COL).Value2))
            If savedName <> "" Then
                If Not UPComponent(ThisWorkbook, savedName) Is Nothing Then selectedComponents(savedName) = True
            End If
        End If
    Next i
    SaveSelectedComponents
End Sub

Private Sub SaveSelectedComponents()
    Dim componentName As Variant, text As String, count As Long, oldCount As Long, i As Long
    CaptureVisibleSelections
    On Error Resume Next
    oldCount = CLng(ThisWorkbook.CustomDocumentProperties("VBANormalSelectionCount").value)
    On Error GoTo 0
    If oldCount < 0 Or oldCount > 1000 Then Err.Raise 5, , "Invalid saved normal selection."
    For Each componentName In selectedComponents.keys
        If selectedComponents(componentName) Then
            If Len(text) + Len(CStr(componentName)) + 1 > 200 Then
                count = count + 1
                RF_SetProperty "VBANormalSelection_" & Format$(count, "000"), text
                text = ""
            End If
            text = text & CStr(componentName) & "|"
        End If
    Next componentName
    If Len(text) > 0 Then
        count = count + 1
        RF_SetProperty "VBANormalSelection_" & Format$(count, "000"), text
    End If
    For i = count + 1 To oldCount
        ThisWorkbook.CustomDocumentProperties("VBANormalSelection_" & Format$(i, "000")).Delete
    Next i
    ' An explicit zero prevents an intentionally empty selection re-importing AH.
    RF_SetProperty "VBANormalSelectionCount", CStr(count)
End Sub



