VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "VBAComponentExporter"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Class Module: VBAComponentExporter
' This should be placed in a Class Module named "VBAComponentExporter"

Private Type ComponentInfo
    name As String
    ComponentType As Long
    typeName As String
End Type

Private components() As ComponentInfo
Private componentCount As Long

Public Sub ShowExportDialog()
    Dim vbComp As Object
    Dim vbProj As Object
    Dim i As Long
    Dim selectedItems As Collection
    Dim folderPath As String
    Dim msg As String
    Dim response As VbMsgBoxResult
    
    ' Get the VBA Project
    On Error Resume Next
    Set vbProj = ThisWorkbook.VBProject
    If Err.Number <> 0 Then
        MsgBox "Unable to access VBA Project. Please enable 'Trust access to the VBA project object model' in Excel Options > Trust Center > Trust Center Settings > Macro Settings.", vbExclamation
        Exit Sub
    End If
    On Error GoTo 0
    
    ' Count and store components
    componentCount = 0
    For Each vbComp In vbProj.VBComponents
        If vbComp.Type = 1 Or vbComp.Type = 2 Or vbComp.Type = 3 Then ' Module, Class, or Form
            componentCount = componentCount + 1
        End If
    Next
    
    If componentCount = 0 Then
        MsgBox "No exportable components found (UserForms, Modules, or Class Modules).", vbInformation
        Exit Sub
    End If
    
    ' Store component information
    ReDim components(1 To componentCount)
    i = 1
    For Each vbComp In vbProj.VBComponents
        Select Case vbComp.Type
            Case 1 ' Standard Module
                components(i).name = vbComp.name
                components(i).ComponentType = vbComp.Type
                components(i).typeName = "Module"
                i = i + 1
            Case 2 ' Class Module
                components(i).name = vbComp.name
                components(i).ComponentType = vbComp.Type
                components(i).typeName = "Class Module"
                i = i + 1
            Case 3 ' UserForm
                components(i).name = vbComp.name
                components(i).ComponentType = vbComp.Type
                components(i).typeName = "UserForm"
                i = i + 1
        End Select
    Next
    
    ' Show selection dialog
    Set selectedItems = ShowSelectionDialog
    
    If selectedItems Is Nothing Or selectedItems.count = 0 Then
        Exit Sub
    End If
    
    ' Get folder path
    folderPath = SelectFolder
    
    If folderPath = "" Then
        MsgBox "Export cancelled - no folder selected.", vbInformation
        Exit Sub
    End If
    
    ' Export selected components
    ExportComponents vbProj, selectedItems, folderPath
    
End Sub

Private Function ShowSelectionDialog() As Collection
    Dim msg As String
    Dim i As Long
    Dim userInput As String
    Dim selections() As String
    Dim selectedIndices As Collection
    Dim j As Long
    Dim idx As Long
    Dim selectAll As Boolean
    
    Set selectedIndices = New Collection
    
    ' Build selection message
    msg = "Select components to export (enter numbers separated by commas, or 'ALL' for all):" & vbCrLf & vbCrLf
    
    For i = 1 To componentCount
        msg = msg & i & ". [" & components(i).typeName & "] " & components(i).name & vbCrLf
    Next
    
    msg = msg & vbCrLf & "Enter your selection (e.g., '1,3,5' or 'ALL'):"
    
    ' Get user input
    userInput = inputBox(msg, "Export VBA Components")
    
    If userInput = "" Then
        Set ShowSelectionDialog = Nothing
        Exit Function
    End If
    
    ' Check for "ALL" selection
    If UCase(Trim(userInput)) = "ALL" Then
        For i = 1 To componentCount
            selectedIndices.Add i
        Next
        Set ShowSelectionDialog = selectedIndices
        Exit Function
    End If
    
    ' Parse comma-separated selections
    selections = Split(userInput, ",")
    
    For i = LBound(selections) To UBound(selections)
        On Error Resume Next
        idx = CLng(Trim(selections(i)))
        If Err.Number = 0 And idx >= 1 And idx <= componentCount Then
            ' Check if not already added
            Dim alreadyAdded As Boolean
            alreadyAdded = False
            For j = 1 To selectedIndices.count
                If selectedIndices(j) = idx Then
                    alreadyAdded = True
                    Exit For
                End If
            Next
            If Not alreadyAdded Then
                selectedIndices.Add idx
            End If
        End If
        On Error GoTo 0
    Next
    
    If selectedIndices.count = 0 Then
        MsgBox "No valid selections made.", vbExclamation
        Set ShowSelectionDialog = Nothing
        Exit Function
    End If
    
    Set ShowSelectionDialog = selectedIndices
End Function

Private Function SelectFolder() As String
    Dim folderDialog As FileDialog
    Dim selectedPath As String
    
    On Error Resume Next
    Set folderDialog = Application.FileDialog(msoFileDialogFolderPicker)
    
    With folderDialog
        .title = "Select Export Folder"
        .AllowMultiSelect = False
        
        If .Show = -1 Then
            selectedPath = .selectedItems(1)
        Else
            selectedPath = ""
        End If
    End With
    
    Set folderDialog = Nothing
    SelectFolder = selectedPath
End Function

Private Sub ExportComponents(vbProj As Object, selectedIndices As Collection, folderPath As String)
    Dim i As Long
    Dim idx As Long
    Dim vbComp As Object
    Dim fileName As String
    Dim fileExt As String
    Dim fullPath As String
    Dim exportCount As Long
    
    exportCount = 0
    
    For i = 1 To selectedIndices.count
        idx = selectedIndices(i)
        
        ' Find the component
        For Each vbComp In vbProj.VBComponents
            If vbComp.name = components(idx).name Then
                ' Determine file extension
                Select Case vbComp.Type
                    Case 1 ' Module
                        fileExt = ".bas"
                    Case 2 ' Class Module
                        fileExt = ".cls"
                    Case 3 ' UserForm
                        fileExt = ".frm"
                End Select
                
                ' Build full path
                fileName = vbComp.name & fileExt
                fullPath = folderPath & "\" & fileName
                
                ' Export the component
                On Error Resume Next
                vbComp.Export fullPath
                If Err.Number = 0 Then
                    exportCount = exportCount + 1
                Else
                    MsgBox "Error exporting " & vbComp.name & ": " & Err.description, vbExclamation
                End If
                On Error GoTo 0
                
                Exit For
            End If
        Next
    Next
    
    MsgBox "Export complete! " & exportCount & " of " & selectedIndices.count & " components exported to:" & vbCrLf & folderPath, vbInformation
End Sub
