Attribute VB_Name = "chequeedit"
Sub ShowfrmChequeEdit()
    frmChequeEdit.Show
End Sub

