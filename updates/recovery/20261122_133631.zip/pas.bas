Attribute VB_Name = "pas"
Sub ShowPasChequeForm()
    pascheque.Show
End Sub

