Attribute VB_Name = "macro_assigner"
Sub AssignMacrosToShapes()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets("�������")  ' your sheet name
    
    ' Assign macros to each shape (button)
    ws.shapes("Rectangle: Rounded Corners 1").OnAction = "ShowVoroodFaktorForm"
    ws.shapes("Rectangle: Rounded Corners 2").OnAction = "ShowCheckForm"
    ws.shapes("Rectangle: Rounded Corners 3").OnAction = "ShowsoorathesabForm"
    ws.shapes("Rectangle: Rounded Corners 4").OnAction = "ShowPasChequeForm"
    ws.shapes("Rectangle: Rounded Corners 5").OnAction = "ShowDailySalesForm"
    ws.shapes("Rectangle: Rounded Corners 6").OnAction = "Showvoroodbimeha"
    ws.shapes("Rectangle: Rounded Corners 7").OnAction = "Showeslahfaktor"
    ws.shapes("Rectangle: Rounded Corners 8").OnAction = "ReplaceMatchingVBAComponents"
    
    MsgBox "All macros have been assigned to shapes!", vbInformation
End Sub
