Attribute VB_Name = "faktor"
'-- Module: modFormsLauncher --

Option Explicit

'-------------------------------------------
' Opens the "voroodFaktor" data-entry form
' Assign this macro to a button on your sheet
'-------------------------------------------
Public Sub ShowVoroodFaktorForm()
    On Error GoTo ErrHandler
    voroodFaktor.Show
    Exit Sub

ErrHandler:
    MsgBox "Could not open voroodFaktor form:" & vbCrLf & Err.description, vbCritical
End Sub

