Attribute VB_Name = "ExportSelectedComponents"
Option Explicit

' Main subroutine to run the export tool
Sub ExportSelectedComponents()
    ComponentExporterForm.Show
End Sub

