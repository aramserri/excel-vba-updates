Attribute VB_Name = "modCompanyHelpers"
'========================================
' SHARED HELPER FUNCTIONS FOR COMPANY/BENEFICIARY
' Add these to a standard module (e.g., modHelpers)
'========================================

'----------------------------------------
' GetCompanyName
' Extracts company name (part before parentheses)
' Example: "�ј� ����� (��� �����)" � "�ј� �����"
' Example: "�ј� �����" � "�ј� �����"
'----------------------------------------
Public Function GetCompanyName(ByVal cellValue As String) As String
    Dim trimmed As String
    Dim parenPos As Long
    
    trimmed = Trim(cellValue)
    
    If Len(trimmed) = 0 Then
        GetCompanyName = ""
        Exit Function
    End If
    
    parenPos = InStr(trimmed, "(")
    
    If parenPos > 0 Then
        GetCompanyName = Trim(Left(trimmed, parenPos - 1))
    Else
        GetCompanyName = trimmed
    End If
End Function

'----------------------------------------
' GetBeneficiaryName
' Extracts beneficiary name (part inside parentheses)
' If no parentheses, returns company name
' Example: "�ј� ����� (��� �����)" � "��� �����"
' Example: "�ј� �����" � "�ј� �����"
'----------------------------------------
Public Function GetBeneficiaryName(ByVal cellValue As String) As String
    Dim trimmed As String
    Dim openParen As Long
    Dim closeParen As Long
    
    trimmed = Trim(cellValue)
    
    If Len(trimmed) = 0 Then
        GetBeneficiaryName = ""
        Exit Function
    End If
    
    openParen = InStr(trimmed, "(")
    closeParen = InStr(trimmed, ")")
    
    If openParen > 0 And closeParen > openParen Then
        GetBeneficiaryName = Trim(Mid(trimmed, openParen + 1, closeParen - openParen - 1))
    Else
        ' No parentheses - beneficiary is same as company
        GetBeneficiaryName = trimmed
    End If
End Function

'----------------------------------------
' HasDifferentBeneficiary
' Returns True if there's a beneficiary in parentheses
' Example: "�ј� ����� (��� �����)" � True
' Example: "�ј� �����" � False
'----------------------------------------
Public Function HasDifferentBeneficiary(ByVal cellValue As String) As Boolean
    HasDifferentBeneficiary = (InStr(cellValue, "(") > 0 And InStr(cellValue, ")") > 0)
End Function
'----------------------------------------
' GetBeneficiaryFromCompany
' Looks up the original cell value from ������� sheet
' and returns the beneficiary name
'----------------------------------------
Public Function GetBeneficiaryFromCompany(ByVal companyName As String) As String
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        GetBeneficiaryFromCompany = companyName
        Exit Function
    End If
    
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If GetCompanyName(cell.value) = companyName Then
            GetBeneficiaryFromCompany = GetBeneficiaryName(cell.value)
            Exit Function
        End If
    Next cell
    
    ' Not found - return company name as fallback
    GetBeneficiaryFromCompany = companyName
End Function
