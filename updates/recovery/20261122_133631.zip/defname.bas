Attribute VB_Name = "defname"
Sub Define_ConfigNamedRanges()
    Dim wb As Workbook
    Set wb = Application.ThisWorkbook
    
    ' --- Define all named ranges ---
    Dim names As Variant
    Dim refs As Variant
    Dim i As Long
    
    names = Array("cfg_DefaultYear", "cfg_DefaultMonth", "cfg_DefaultDay", "cfg_SkipSerial")
    refs = Array("=�������!$AC$1", "=�������!$AC$2", "=�������!$AE$1", "=�������!$K$1")
    
    For i = LBound(names) To UBound(names)
        ' Delete if exists
        On Error Resume Next
        wb.names(names(i)).Delete
        On Error GoTo 0
        
        ' Add the name
        wb.names.Add name:=names(i), RefersTo:=refs(i)
    Next i
    
    ' Confirmation message
    MsgBox "Named ranges created successfully:" & vbCrLf & vbCrLf & _
           "cfg_DefaultYear -> AC1" & vbCrLf & _
           "cfg_DefaultMonth -> AC2" & vbCrLf & _
           "cfg_DefaultDay -> AE1" & vbCrLf & _
           "cfg_SkipSerial -> K1", vbInformation, "����� �����"
End Sub

