VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsRemainingLabelClick"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False

'=====================================================
' Class Module: clsRemainingLabelClick
' Handles click events on Remaining labels for calculator
'=====================================================
Option Explicit

Public WithEvents label As MSForms.label
Attribute label.VB_VarHelpID = -1
Public labelIndex As Long
Public ParentForm As Object

Private Sub Label_Click()
    If Not ParentForm Is Nothing Then
        ParentForm.OnRemainingLabelClick labelIndex
    End If
End Sub
