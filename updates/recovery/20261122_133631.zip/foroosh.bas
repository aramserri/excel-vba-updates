Attribute VB_Name = "foroosh"
Sub ShowDailySalesForm()
    voroodforoosh.Show
End Sub
