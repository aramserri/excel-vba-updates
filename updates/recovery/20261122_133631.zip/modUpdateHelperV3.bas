Attribute VB_Name = "modUpdateHelperV3"
Option Explicit
Private Const HELPER_META_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/tools/helper.tsv"
Private Const HELPER_BASE_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/tools/"
Private Const SIMPLE_HELPER_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/tools/RepairTool.xlsm"

Public Sub UHDownload(ByVal url As String, ByVal path As String)
    Dim request As Object, stream As Object
    If LCase$(Left$(url, 8)) <> "https://" Then Err.Raise 5, , "HTTPS is required."
    Set request = CreateObject("WinHttp.WinHttpRequest.5.1")
    request.SetTimeouts 15000, 15000, 30000, 60000
    request.Open "GET", url, False
    request.setRequestHeader "Cache-Control", "no-cache"
    request.send
    If request.status <> 200 Then Err.Raise 5, , "HTTP " & request.status & ": " & url
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1: stream.Open: stream.Write request.responseBody
    If stream.size = 0 Then Err.Raise 5, , "Empty download."
    stream.SaveToFile path, 2: stream.Close
End Sub

Public Function UHResolve(ByVal online As Boolean) As String
    Dim fso As Object, root As String, stage As String, meta As String, fields As Variant
    Dim version As String, digest As String, folder As String, file As String, bundled As String
    Set fso = CreateObject("Scripting.FileSystemObject")
    root = UPPath(Environ$("LOCALAPPDATA"), "PharmacyVBAUpdaterV3")
    If Not fso.FolderExists(root) Then fso.CreateFolder root
    stage = UPNewFolder(root, "Acquire_")
    bundled = UPPath(UPPath(ThisWorkbook.path, "VBA Update Tools"), "helper.tsv")
    If online Then
        meta = UPPath(stage, "helper.tsv")
        UHDownload HELPER_META_URL, meta
    ElseIf fso.FileExists(bundled) Then
        meta = bundled
    ElseIf fso.FileExists(UPPath(root, "helper-current.tsv")) Then
        meta = UPPath(root, "helper-current.tsv")
    Else
        meta = UPPath(stage, "helper.tsv")
        UHDownload HELPER_META_URL, meta
    End If
    fields = Split(Trim$(Replace(UPRead(meta), vbCr, "")), vbTab)
    If UBound(fields) <> 4 Then Err.Raise 5, , "Invalid helper descriptor."
    If fields(0) <> "VBA_UPDATE_HELPER_1" Or fields(2) <> "3" Or fields(3) <> "RepairTool.xlsm" Then Err.Raise 5, , "Unsupported helper protocol."
    version = CStr(fields(1)): digest = LCase$(CStr(fields(4)))
    If Not version Like "########_######" Then Err.Raise 5, , "Invalid helper version."
    If Len(digest) <> 64 Or digest Like "*[!0-9a-f]*" Then Err.Raise 5, , "Invalid helper digest."
    folder = UPPath(root, version)
    If Not fso.FolderExists(folder) Then fso.CreateFolder folder
    file = UPPath(folder, "RepairTool.xlsm")
    If Not fso.FileExists(file) Then
        If Not online And StrComp(meta, bundled, vbTextCompare) = 0 Then
            fso.CopyFile UPPath(fso.GetParentFolderName(bundled), "RepairTool.xlsm"), UPPath(stage, "RepairTool.xlsm"), False
        Else
            UHDownload HELPER_BASE_URL & version & "/RepairTool.xlsm", UPPath(stage, "RepairTool.xlsm")
        End If
        If UPHash(UPPath(stage, "RepairTool.xlsm")) <> digest Then Err.Raise 5, , "Downloaded helper failed its integrity check. Nothing was executed."
        fso.CopyFile UPPath(stage, "RepairTool.xlsm"), file, False
    End If
    If UPHash(file) <> digest Then Err.Raise 5, , "Cached helper changed. Nothing was executed. Obtain a fresh trusted helper."
    If StrComp(meta, UPPath(root, "helper-current.tsv"), vbTextCompare) <> 0 Then fso.CopyFile meta, UPPath(root, "helper-current.tsv"), True
    UHResolve = file
End Function

Public Function UHResolveSimple() As String
    Dim root As String, stage As String, file As String
    root = UPPath(Environ$("LOCALAPPDATA"), "PharmacyVBAUpdaterV3")
    If Not CreateObject("Scripting.FileSystemObject").FolderExists(root) Then CreateObject("Scripting.FileSystemObject").CreateFolder root
    stage = UPNewFolder(root, "SimpleHelper_")
    file = UPPath(stage, "RepairTool.xlsm")
    UHDownload SIMPLE_HELPER_URL, file
    UHResolveSimple = file
End Function

Public Function UHDownloadLatestRecovery(ByVal destination As String) As String
    Const latestUrl As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/recovery/latest.txt"
    Const recoveryBase As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/recovery/"
    Dim pointer As String, name As String, path As String
    pointer = UPReadToUrl(latestUrl)
    pointer = Replace(pointer, vbCr, "")
    Dim pointerRows As Variant, pointerRow As Variant
    pointerRows = Split(pointer, vbLf)
    pointer = ""
    For Each pointerRow In pointerRows
        If Trim$(CStr(pointerRow)) <> "" Then pointer = Trim$(CStr(pointerRow))
    Next pointerRow
    pointer = Replace(pointer, Chr$(34), "")
    pointer = Replace(pointer, "'", "")
    Do While LCase$(Right$(pointer, 8)) = ".zip.zip"
        pointer = Left$(pointer, Len(pointer) - 4)
    Loop
    If pointer = "" Then Err.Raise 5, , "GitHub recovery pointer is empty."
    name = pointer
    If LCase$(Right$(name, 4)) <> ".zip" Then name = name & ".zip"
    If InStr(name, Chr$(92)) > 0 Or InStr(name, "/") > 0 Or InStr(name, "..") > 0 Then Err.Raise 5, , "Invalid recovery filename."
    path = UPPath(destination, name)
    UHDownload recoveryBase & name, path
    UHDownloadLatestRecovery = path
End Function

Private Function UPReadToUrl(ByVal url As String) As String
    Dim tmp As String
    tmp = UPPath(Environ$("TEMP"), "recovery_pointer_" & Format$(Now, "yyyymmdd_hhnnss") & ".txt")
    UHDownload url, tmp
    UPReadToUrl = UPRead(tmp)
End Function

