Attribute VB_Name = "modTypes"
Option Explicit

'====================================================================
' PUBLIC TYPE DEFINITIONS
' These types are accessible from all modules and forms
'====================================================================

' Type for Bank Cheque Submission
Public Type BankChequeData
    chequeNumber As Long
    companyName As String
    companyNationalID As String
    chequeAmount As String
    chequeDate As String
    Code16Digit As String
    Code_Part1 As String  ' First 4 digits
    Code_Part2 As String  ' Second 4 digits (middle)
    Code_Part3 As String  ' Third 4 digits (middle)
    Code_Part4 As String  ' Last 4 digits
End Type

' Keep your other types in the form as they are form-specific
' ChequeData and CompanyInfo can stay Private in the form
