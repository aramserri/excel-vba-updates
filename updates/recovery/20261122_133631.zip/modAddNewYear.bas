Attribute VB_Name = "modAddNewYear"
'=====================================================
' Module: modAddNewYear (OPTIMIZED VERSION v2)
' Adds a new year's sheets using template copying
'=====================================================
Option Explicit

Sub AddNewYearSheets()
    '-----------------------------------------------
    ' Main procedure to add a new year to the workbook
    '-----------------------------------------------
    Dim wb As Workbook
    Dim wsInfo As Worksheet
    Dim newYear As Long
    Dim numCenters As Long
    Dim userCenters As Long
    Dim chequesPerDay As Long
    Dim factorsPerDay As Long
    Dim directPaysPerDay As Long
    Dim centerNames() As String
    Dim monthNames As Variant
    Dim fixedSummaryStartRow As Long
    Dim i As Long, m As Long
    Dim yearTabColor As Long
    
    Set wb = ThisWorkbook
    
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    
    '-----------------------------------------------
    ' Step 1: Get ������� sheet and read configuration
    '-----------------------------------------------
    On Error Resume Next
    Set wsInfo = wb.Sheets("�������")
    On Error GoTo 0
    
    If wsInfo Is Nothing Then
        MsgBox "���: ��� '�������' ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    On Error Resume Next
    userCenters = wsInfo.Range("cfg_ActualUserCenters").value
    numCenters = wsInfo.Range("cfg_TotalCenters").value
    chequesPerDay = wsInfo.Range("cfg_NumCheques").value
    factorsPerDay = wsInfo.Range("cfg_NumFactors").value
    directPaysPerDay = wsInfo.Range("cfg_NumDirectPays").value
    On Error GoTo 0
    
    If userCenters = 0 Or numCenters = 0 Then
        MsgBox "���: ������� ��ǘ� ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    If chequesPerDay = 0 Then chequesPerDay = 5
    If factorsPerDay = 0 Then factorsPerDay = 5
    If directPaysPerDay = 0 Then directPaysPerDay = 20
    
    ReDim centerNames(1 To numCenters)
    For i = 1 To userCenters
        centerNames(i) = wsInfo.Cells(i + 1, "AA").value
        If centerNames(i) = "" Then centerNames(i) = "�ј� " & i
    Next i
    If numCenters > userCenters Then centerNames(numCenters) = ""
    
    '-----------------------------------------------
    ' Step 2: Ask for new year
    '-----------------------------------------------
    Dim inputYear As Variant
    inputYear = Application.inputBox("��� ���� �� ���� ���� (����� 1404):", "������ ��� ����", Type:=1)
    
    If VarType(inputYear) = vbBoolean And inputYear = False Then
        Exit Sub
    End If
    
    newYear = CLng(inputYear)
    
    If newYear < 1300 Or newYear > 1500 Then
        MsgBox "��� ���� ��� ������� ���.", vbExclamation
        Exit Sub
    End If
    
    Dim testSheet As Worksheet
    On Error Resume Next
    Set testSheet = wb.Sheets(monthNames(0) & " " & newYear)
    On Error GoTo 0
    
    If Not testSheet Is Nothing Then
        MsgBox "��ʝ��� ��� " & newYear & " ����� ���� �����.", vbExclamation, "����"
        Exit Sub
    End If
    
    '-----------------------------------------------
    ' Step 3: Ask for tab color
    '-----------------------------------------------
    yearTabColor = AskForTabColor()
    If yearTabColor = -1 Then Exit Sub ' User cancelled
    
    '-----------------------------------------------
    ' Step 4: Calculate parameters
    '-----------------------------------------------
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    
    Dim maxRowsPerDay As Long, fixedTotalRowsPerDayBlock As Long
    maxRowsPerDay = IIf(userCenters = 1, 2, numCenters)
    fixedTotalRowsPerDayBlock = maxRowsPerDay + 1
    fixedSummaryStartRow = 2 + (31 * fixedTotalRowsPerDayBlock) + 2
    
    ' Get the index of ������� sheet to insert before it
    Dim infoSheetIndex As Long
    infoSheetIndex = wsInfo.index
    
    '-----------------------------------------------
    ' Step 5: Create template sheets (31, 30, 29 days)
    '-----------------------------------------------
    Dim wsTemplate31 As Worksheet
    Dim wsTemplate30 As Worksheet
    Dim wsTemplate29 As Worksheet
    
    Application.StatusBar = "�� ��� ���� ���� 31 ����..."
    Set wsTemplate31 = wb.Sheets.Add(Before:=wb.Sheets(infoSheetIndex))
    wsTemplate31.name = "_Template31_" & newYear
    Call CreateMonthTemplate(wsTemplate31, 31, numCenters, userCenters, centerNames, chequesPerDay, factorsPerDay, directPaysPerDay, fixedSummaryStartRow)
    
    Application.StatusBar = "�� ��� ���� ���� 30 ����..."
    Set wsTemplate30 = wb.Sheets.Add(Before:=wb.Sheets(infoSheetIndex))
    wsTemplate30.name = "_Template30_" & newYear
    Call CreateMonthTemplate(wsTemplate30, 30, numCenters, userCenters, centerNames, chequesPerDay, factorsPerDay, directPaysPerDay, fixedSummaryStartRow)
    
    Application.StatusBar = "�� ��� ���� ���� 29 ����..."
    Set wsTemplate29 = wb.Sheets.Add(Before:=wb.Sheets(infoSheetIndex))
    wsTemplate29.name = "_Template29_" & newYear
    Call CreateMonthTemplate(wsTemplate29, 29, numCenters, userCenters, centerNames, chequesPerDay, factorsPerDay, directPaysPerDay, fixedSummaryStartRow)
    
    '-----------------------------------------------
    ' Step 6: Copy templates to create monthly sheets
    '-----------------------------------------------
    Dim ws As Worksheet
    Dim monthDays As Long
    
    ' Create sheets in FORWARD order (0 to 11) - each inserted before �������
    For m = 0 To 11
        Application.StatusBar = "�� ��� ���� ��� " & monthNames(m) & " " & newYear & "..."
        
        monthDays = GetPersianMonthDays_New(newYear, m + 1)
        
        ' Get fresh index of ������� (it shifts as we add sheets)
        infoSheetIndex = wsInfo.index
        
        Select Case monthDays
            Case 31
                wsTemplate31.Copy Before:=wb.Sheets(infoSheetIndex)
            Case 30
                wsTemplate30.Copy Before:=wb.Sheets(infoSheetIndex)
            Case 29
                wsTemplate29.Copy Before:=wb.Sheets(infoSheetIndex)
        End Select
        
        Set ws = wb.Sheets(infoSheetIndex)
        ws.name = monthNames(m) & " " & newYear
        ws.Range("B1").value = newYear & "/" & Format(m + 1, "00")
        ws.Tab.color = yearTabColor
        Call SetFirstDayOpeningBalance(ws, wb, newYear, m + 1, monthNames, fixedTotalRowsPerDayBlock)

        ' Update summary section formulas for this specific month
        Call UpdateSummaryFormulas(ws, monthDays, numCenters, userCenters, centerNames, chequesPerDay, factorsPerDay, fixedSummaryStartRow, fixedTotalRowsPerDayBlock)
    Next m
    '-----------------------------------------------
    ' Step 7: Delete template sheets
    '-----------------------------------------------
    Application.StatusBar = "�� ��� �ǘ���� ���ȝ��..."
    wsTemplate31.Delete
    wsTemplate30.Delete
    wsTemplate29.Delete
    
    '-----------------------------------------------
    ' Step 8: Create annual performance sheet
    '-----------------------------------------------
    Application.StatusBar = "�� ��� ���� ��� ����� ������..."
    infoSheetIndex = wsInfo.index
    wb.Sheets.Add(Before:=wb.Sheets(infoSheetIndex)).name = "����� ��� " & newYear
    wb.Sheets("����� ��� " & newYear).Tab.color = yearTabColor
    Call FillAnnualPerformanceSheet_New(wb, newYear, numCenters, userCenters, monthNames, fixedSummaryStartRow, centerNames)
    
'-----------------------------------------------
  ' Step 9: Update date columns in �������
  '-----------------------------------------------
  Application.StatusBar = "�� ��� ��������� ������� �����..."
  Call UpdateDateColumns(wsInfo, newYear, chequesPerDay, numCenters, userCenters, monthNames)

  '-----------------------------------------------
  ' Step 9.1: Fill bank clearing formulas in column Y
  '-----------------------------------------------
  Application.StatusBar = "�� ��� ��������� ���� Y..."
  Call FillBankClearingFormulasColumnY_Internal(wb, wsInfo)

  '-----------------------------------------------
  ' Step 9.2: Update daily cheque sum formulas for the new year
  '-----------------------------------------------
  Application.StatusBar = "�� ��� ��������� ����� ��� ��..."
  Call UpdateExistingDailyChequeSumFormulas_Internal(wb, wsInfo, newYear)
  
  '-----------------------------------------------
    ' Step 10: Update cfg_YearList named range
    '-----------------------------------------------
    Call UpdateYearList(wb, wsInfo, newYear)
    '-----------------------------------------------
  ' Step 10.1: Add year to end of column Q in �������
  '-----------------------------------------------
  Call AddYearToColumnQ(wsInfo, newYear)
    '-----------------------------------------------
    ' Step 11: Freeze panes on new sheets (with error handling)
    '-----------------------------------------------
    Application.StatusBar = "�� ��� ����� ����..."
    For m = 0 To 11
        Set ws = wb.Sheets(monthNames(m) & " " & newYear)
        On Error Resume Next
        ws.Activate
        ActiveWindow.FreezePanes = False
        ws.Range("B2").Select
        ActiveWindow.FreezePanes = True
        On Error GoTo 0
    Next m
    
    Application.StatusBar = False
    Application.Calculation = xlCalculationAutomatic
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    
    MsgBox "��ʝ��� ��� " & newYear & " �� ������ ����� ����." & vbCrLf & _
           "- 12 ��� ������" & vbCrLf & _
           "- 1 ��� ����� ������" & vbCrLf & _
           "- ��������� ������� �����", vbInformation, "����� ������"
    
    wb.Sheets(monthNames(0) & " " & newYear).Activate
End Sub

'===============================================================================
' ASK FOR TAB COLOR - Shows color picker dialog
'===============================================================================
Private Function AskForTabColor() As Long
    Dim colorChoice As Variant
    Dim colorOptions As String
    
    colorOptions = "�� �� ��ʝ��� ��� ���� �� ������ ����:" & vbCrLf & vbCrLf & _
                   "1 - ����" & vbCrLf & _
                   "2 - ������" & vbCrLf & _
                   "3 - ���" & vbCrLf & _
                   "4 - ���" & vbCrLf & _
                   "5 - ���" & vbCrLf & _
                   "6 - ����" & vbCrLf & _
                   "7 - �����" & vbCrLf & _
                   "8 - ��������" & vbCrLf & _
                   "9 - �ǘ����" & vbCrLf & _
                   "10 - ������"
    
    colorChoice = Application.inputBox(colorOptions, "������ ��", Default:=5, Type:=1)
    
    If VarType(colorChoice) = vbBoolean And colorChoice = False Then
        AskForTabColor = -1
        Exit Function
    End If
    
    Select Case CLng(colorChoice)
        Case 1: AskForTabColor = RGB(255, 0, 0)       ' Red
        Case 2: AskForTabColor = RGB(255, 165, 0)    ' Orange
        Case 3: AskForTabColor = RGB(255, 255, 0)    ' Yellow
        Case 4: AskForTabColor = RGB(0, 176, 80)     ' Green
        Case 5: AskForTabColor = RGB(0, 112, 192)    ' Blue
        Case 6: AskForTabColor = RGB(112, 48, 160)   ' Purple
        Case 7: AskForTabColor = RGB(255, 102, 153)  ' Pink
        Case 8: AskForTabColor = RGB(0, 176, 240)    ' Turquoise
        Case 9: AskForTabColor = RGB(128, 128, 128)  ' Gray
        Case 10: AskForTabColor = RGB(150, 75, 0)    ' Brown
        Case Else: AskForTabColor = RGB(0, 112, 192) ' Default Blue
    End Select
End Function

'===============================================================================
' CREATE MONTH TEMPLATE - Creates a complete template sheet for given days
'===============================================================================
Private Sub CreateMonthTemplate( _
    ws As Worksheet, _
    monthDays As Long, _
    numCenters As Long, _
    userCenters As Long, _
    centerNames() As String, _
    chequesPerDay As Long, _
    factorsPerDay As Long, _
    directPaysPerDay As Long, _
    fixedSummaryStartRow As Long)
    
    Dim day As Long, i As Long, j As Long
    Dim baseRow As Long
    Dim dayStartRow As Long, dayEndRow As Long
    Dim rowsPerDay As Long
    Dim totalRowsPerDayBlock As Long
    Dim regRowHeight As Double
    Dim upperHalfRows As Long, lowerHalfRows As Long
    Dim upperHalfStartRow As Long, upperHalfEndRow As Long
    Dim lowerHalfStartRow As Long, lowerHalfEndRow As Long
    Dim midRow As Long
    Dim halfCenters As Long
    Dim currentDataCol As Long
    Dim colOffset As Long
    Dim sumFormula As String
    Dim factorSumFormula As String
    Dim directPaySumFormula As String
    Dim separatorColor As Long
    Dim separatorRow As Long
    
    ' Color definitions
    Dim colorOrangeAccent2 As Long
    Dim colorGreenAccent6 As Long
    Dim colorGoldAccent4 As Long
    colorOrangeAccent2 = RGB(252, 228, 214)
    colorGreenAccent6 = RGB(198, 239, 206)
    colorGoldAccent4 = RGB(255, 242, 204)
    
    regRowHeight = 15
    rowsPerDay = IIf(userCenters = 1, 2, numCenters)
    totalRowsPerDayBlock = rowsPerDay + 1
    
    ' Global formatting
    ws.Cells.HorizontalAlignment = xlCenter
    ws.Cells.VerticalAlignment = xlCenter
    
    ' Headers Row 1
    ws.Range("A1").value = "���"
    ws.Range("A1").Font.bold = True
    
    ws.Range("C1").Resize(1, 10).value = _
        Array("���(����)", "����(����)", "������ �� ���(����)", "��� �� ���(����)", "��� ������(����)", _
              "", "", "������ ��� ���(����)", "����� ����� ���(����)", "����" & Chr(10) & "���� ������ (����)")
    ws.Range("C1:L1").Font.bold = True
    ws.Range("L1").WrapText = True
    ws.Range("M1").value = "��� �� ���"
    ws.Range("M1").Font.bold = True
    
    ' Column widths
    ws.Columns("A").ColumnWidth = 6
    ws.Columns("B").ColumnWidth = 25
    ws.Columns("C:G").ColumnWidth = 20
    ws.Columns("H:I").ColumnWidth = 1
    ws.Columns("J:M").ColumnWidth = 20
    ws.Columns("C:G").NumberFormat = "#,##0"
    
    ' Calculate column indices
    Dim firstChequeColIndex As Long
    Dim dailyChequeSumColIndex As Long
    Dim dailyChequeSumColLetter As String
    Dim firstFactorColIndex As Long
    Dim dailyFactorSumColIndex As Long
    Dim dailyFactorSumColLetter As String
    Dim firstDirectPayColIndex As Long
    Dim dailyDirectPaySumColIndex As Long
    Dim dailyDirectPaySumColLetter As String
    
    firstChequeColIndex = 14
    dailyChequeSumColIndex = firstChequeColIndex + (chequesPerDay * 2)
    dailyChequeSumColLetter = Split(ws.Cells(1, dailyChequeSumColIndex).Address(False, False), "1")(0)
    
    firstFactorColIndex = dailyChequeSumColIndex + 1
    dailyFactorSumColIndex = firstFactorColIndex + (factorsPerDay * 2)
    dailyFactorSumColLetter = Split(ws.Cells(1, dailyFactorSumColIndex).Address(False, False), "1")(0)
    
    firstDirectPayColIndex = dailyFactorSumColIndex + 1
    dailyDirectPaySumColIndex = firstDirectPayColIndex + directPaysPerDay
    dailyDirectPaySumColLetter = Split(ws.Cells(1, dailyDirectPaySumColIndex).Address(False, False), "1")(0)
    
    ' Create cheque/factor/direct pay headers
    Dim currentHeaderCol As Long
    currentHeaderCol = 14
    
    For j = 1 To chequesPerDay
        With ws.Cells(1, currentHeaderCol)
            .value = "�ј�" & Chr(10) & "����"
            .WrapText = True: .Font.bold = True
        End With
        ws.Columns(currentHeaderCol).ColumnWidth = 20
        With ws.Cells(1, currentHeaderCol + 1)
            .value = "�����" & Chr(10) & "����� ��"
            .WrapText = True: .Font.bold = True
        End With
        ws.Columns(currentHeaderCol + 1).ColumnWidth = 15
        currentHeaderCol = currentHeaderCol + 2
    Next j
    
    ws.Cells(1, dailyChequeSumColIndex).value = "��� �� ��"
    ws.Cells(1, dailyChequeSumColIndex).Font.bold = True
    ws.Columns(dailyChequeSumColIndex).ColumnWidth = 20
    currentHeaderCol = currentHeaderCol + 1
    
    For j = 1 To factorsPerDay
        With ws.Cells(1, currentHeaderCol)
            .value = "�ј�" & Chr(10) & "����"
            .WrapText = True: .Font.bold = True
        End With
        ws.Columns(currentHeaderCol).ColumnWidth = 20
        With ws.Cells(1, currentHeaderCol + 1)
            .value = "�����" & Chr(10) & "����"
            .WrapText = True: .Font.bold = True
        End With
        ws.Columns(currentHeaderCol + 1).ColumnWidth = 15
        currentHeaderCol = currentHeaderCol + 2
    Next j
    
    ws.Cells(1, dailyFactorSumColIndex).value = "��� �ǘ�����"
    ws.Cells(1, dailyFactorSumColIndex).Font.bold = True
    ws.Columns(dailyFactorSumColIndex).ColumnWidth = 20
    currentHeaderCol = currentHeaderCol + 1
    
    For j = 1 To directPaysPerDay
        With ws.Cells(1, currentHeaderCol)
            .value = "�ј�" & Chr(10) & "����"
            .WrapText = True: .Font.bold = True
        End With
        ws.Columns(currentHeaderCol).ColumnWidth = 20
        currentHeaderCol = currentHeaderCol + 1
    Next j
    
    ws.Cells(1, dailyDirectPaySumColIndex).value = "��� �����ʝ��� ������"
    ws.Cells(1, dailyDirectPaySumColIndex).Font.bold = True
    ws.Columns(dailyDirectPaySumColIndex).ColumnWidth = 20
    
    '-----------------------------------------------
    ' Fill daily structures
    '-----------------------------------------------
    baseRow = 2
    
    For day = 1 To monthDays
        dayStartRow = baseRow
        dayEndRow = baseRow + rowsPerDay - 1
        
        upperHalfRows = rowsPerDay \ 2
        lowerHalfRows = rowsPerDay - upperHalfRows
        
        upperHalfStartRow = dayStartRow
        upperHalfEndRow = dayStartRow + upperHalfRows - 1
        lowerHalfStartRow = dayStartRow + upperHalfRows
        lowerHalfEndRow = dayEndRow
        
        ' Column A - Day number
        With ws.Range("A" & dayStartRow & ":A" & dayEndRow)
            .Merge: .value = day
        End With
        
        ' Column B - Center names
        If userCenters = 1 Then
            With ws.Range("B" & dayStartRow & ":B" & dayEndRow)
                .Merge: .value = centerNames(1)
            End With
        Else
            For i = 1 To numCenters
                ws.Cells(dayStartRow + i - 1, "B").value = centerNames(i)
            Next i
        End If
        
        ' Columns C & D - Cash and Card
        If userCenters = 1 Then
            ws.Range("C" & dayStartRow & ":C" & dayEndRow).Merge
            ws.Range("D" & dayStartRow & ":D" & dayEndRow).Merge
        End If
        ws.Range("C" & dayStartRow & ":D" & dayEndRow).NumberFormat = "#,##0"
        
        ' Column E - Average
        With ws.Range("E" & dayStartRow & ":E" & dayEndRow)
            .Merge: .NumberFormat = "#,##0"
            If day = 1 Then
                .Formula = "=IF(G" & dayStartRow & "=0,"""",F" & dayStartRow & "/" & day & ")"
            Else
                .Formula = "=IF(G" & dayStartRow & "=0, E" & (dayStartRow - totalRowsPerDayBlock) & ", F" & dayStartRow & "/" & day & ")"
            End If
        End With
        
        ' Column F - Sum to day
        With ws.Range("F" & dayStartRow & ":F" & dayEndRow)
            .Merge: .NumberFormat = "#,##0;;;"
            If day = 1 Then
                .Formula = "=G" & dayStartRow
            Else
                .Formula = "=F" & (dayStartRow - totalRowsPerDayBlock) & "+G" & dayStartRow
            End If
        End With
        
        ' Column G - Daily total
        With ws.Range("G" & dayStartRow & ":G" & dayEndRow)
            .Merge
            .Formula = "=SUM(C" & dayStartRow & ":D" & dayEndRow & ")"
            .NumberFormat = "#,##0"
        End With
        
        ' Columns H & I - Spacers
        ws.Range("H" & dayStartRow & ":H" & dayEndRow).Merge
        ws.Range("I" & dayStartRow & ":I" & dayEndRow).Merge
        
        ' Column J - Beginning balance
        With ws.Range("J" & dayStartRow & ":J" & dayEndRow)
            .Merge: .NumberFormat = "#,##0;;;"
            If day = 1 Then
                .value = ""
            Else
                .Formula = "=IF(G" & (dayStartRow - totalRowsPerDayBlock) & "="""","""",K" & (dayStartRow - totalRowsPerDayBlock) & ")"
            End If
        End With
        
        ' Column K - End balance
        midRow = dayStartRow + (rowsPerDay \ 2)
        With ws.Range("K" & dayStartRow & ":K" & dayEndRow)
            .Merge: .NumberFormat = "#,##0;;;"
            .Formula = "=J" & dayStartRow & " + G" & dayStartRow & " + IF(L" & midRow & "="""",0,L" & midRow & ") - (" & dailyChequeSumColLetter & dayStartRow & " + " & dailyDirectPaySumColLetter & dayStartRow & ")"
        End With
        
        ' Column L - Insurance/Deposit
        halfCenters = rowsPerDay \ 2
        With ws.Range("L" & dayStartRow & ":L" & dayStartRow + halfCenters - 1)
            .Merge: .NumberFormat = "@"
        End With
        With ws.Range("L" & dayStartRow + halfCenters & ":L" & dayEndRow)
            .Merge: .NumberFormat = "#,##0"
        End With
        
        ' Cheque structures
        currentDataCol = 14
        
        For j = 1 To chequesPerDay
            With ws.Range(ws.Cells(upperHalfStartRow, currentDataCol), ws.Cells(upperHalfEndRow, currentDataCol))
                .Merge
                .Validation.Delete
                .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=CompanyList"
            End With
            With ws.Range(ws.Cells(lowerHalfStartRow, currentDataCol), ws.Cells(lowerHalfEndRow, currentDataCol))
                .Merge: .NumberFormat = "#,##0"
            End With
            currentDataCol = currentDataCol + 1
            
            With ws.Range(ws.Cells(upperHalfStartRow, currentDataCol), ws.Cells(upperHalfEndRow, currentDataCol))
                .Merge
                .Validation.Delete
                .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=ChequeStatusList"
            End With
            With ws.Range(ws.Cells(lowerHalfStartRow, currentDataCol), ws.Cells(lowerHalfEndRow, currentDataCol))
                .Merge: .NumberFormat = "0"
            End With
            currentDataCol = currentDataCol + 1
        Next j
        
        ' Daily cheque sum
' Daily cheque sum + matching amount from ������� column W by date in column U
  With ws.Range(ws.Cells(dayStartRow, dailyChequeSumColIndex), ws.Cells(dayEndRow, dailyChequeSumColIndex))
      .Merge: .NumberFormat = "#,##0"

      sumFormula = "=SUM("
      For j = 0 To chequesPerDay - 1
          colOffset = 14 + (j * 2)
          sumFormula = sumFormula & ws.Cells(lowerHalfStartRow, colOffset).Address(False, False) & ","
      Next j

      If Len(sumFormula) > 5 Then
          sumFormula = Left(sumFormula, Len(sumFormula) - 1) & ")"
      Else
          sumFormula = "0"
      End If

      sumFormula = sumFormula & _
          "+IFERROR(XLOOKUP($B$1&""/""&TEXT(A" & dayStartRow & ",""00""),'�������'!U:U,'�������'!W:W),0)"

      .Formula = sumFormula
  End With
        
        currentDataCol = currentDataCol + 1
        
        ' Factor structures
        For j = 1 To factorsPerDay
            With ws.Range(ws.Cells(upperHalfStartRow, currentDataCol), ws.Cells(upperHalfEndRow, currentDataCol))
                .Merge
                .Validation.Delete
                .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=CompanyList"
            End With
            With ws.Range(ws.Cells(lowerHalfStartRow, currentDataCol), ws.Cells(lowerHalfEndRow, currentDataCol))
                .Merge: .NumberFormat = "#,##0"
            End With
            currentDataCol = currentDataCol + 1
            
            With ws.Range(ws.Cells(upperHalfStartRow, currentDataCol), ws.Cells(upperHalfEndRow, currentDataCol))
                .Merge
                .Validation.Delete
                .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=FactorStatusList"
            End With
            With ws.Range(ws.Cells(lowerHalfStartRow, currentDataCol), ws.Cells(lowerHalfEndRow, currentDataCol))
                .Merge: .NumberFormat = "0"
            End With
            currentDataCol = currentDataCol + 1
        Next j
        
        ' Daily factor sum
        With ws.Range(ws.Cells(dayStartRow, dailyFactorSumColIndex), ws.Cells(dayEndRow, dailyFactorSumColIndex))
            .Merge: .NumberFormat = "#,##0"
            factorSumFormula = "=SUM("
            For j = 0 To factorsPerDay - 1
                colOffset = firstFactorColIndex + (j * 2)
                factorSumFormula = factorSumFormula & ws.Cells(lowerHalfStartRow, colOffset).Address(False, False) & ","
            Next j
            If Len(factorSumFormula) > 5 Then factorSumFormula = Left(factorSumFormula, Len(factorSumFormula) - 1) & ")"
            .Formula = factorSumFormula
        End With
        
        currentDataCol = currentDataCol + 1
        
        ' Direct pay structures
        For j = 1 To directPaysPerDay
            With ws.Range(ws.Cells(upperHalfStartRow, currentDataCol), ws.Cells(upperHalfEndRow, currentDataCol))
                .Merge
                .Validation.Delete
                .Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=CompanyList"
            End With
            With ws.Range(ws.Cells(lowerHalfStartRow, currentDataCol), ws.Cells(lowerHalfEndRow, currentDataCol))
                .Merge: .NumberFormat = "#,##0"
            End With
            currentDataCol = currentDataCol + 1
        Next j
        
        ' Daily direct pay sum
        With ws.Range(ws.Cells(dayStartRow, dailyDirectPaySumColIndex), ws.Cells(dayEndRow, dailyDirectPaySumColIndex))
            .Merge: .NumberFormat = "#,##0"
            directPaySumFormula = "=SUM("
            For j = 0 To directPaysPerDay - 1
                colOffset = firstDirectPayColIndex + j
                directPaySumFormula = directPaySumFormula & ws.Cells(lowerHalfStartRow, colOffset).Address(False, False) & ","
            Next j
            If Len(directPaySumFormula) > 5 Then directPaySumFormula = Left(directPaySumFormula, Len(directPaySumFormula) - 1) & ")"
            .Formula = directPaySumFormula
        End With
        
        '===========================================
        ' SEPARATOR ROW - Fixed coloring
        '===========================================
        ' Determine which 10-day group this day belongs to
        If day <= 10 Then
            separatorColor = colorOrangeAccent2
        ElseIf day <= 20 Then
            separatorColor = colorGreenAccent6
        Else
            separatorColor = colorGoldAccent4
        End If
        
        separatorRow = dayEndRow + 1
        ws.rows(separatorRow).rowHeight = regRowHeight / 2
        
        ' First: Color entire row gray
        ws.Range(ws.Cells(separatorRow, 1), ws.Cells(separatorRow, dailyDirectPaySumColIndex)).Interior.color = RGB(200, 200, 200)
        
        ' Then: Override Column M with group color
        ws.Cells(separatorRow, 13).Interior.color = separatorColor
        
        ' Then: Override cheque section (column N to cheque sum column) with group color
        ws.Range(ws.Cells(separatorRow, firstChequeColIndex), ws.Cells(separatorRow, dailyChequeSumColIndex)).Interior.color = separatorColor
        
        baseRow = dayEndRow + 2
    Next day
    
    '-----------------------------------------------
    ' Column M - 10-day sums with colors
    '-----------------------------------------------
    Call CreateColumnMSections(ws, monthDays, totalRowsPerDayBlock, dailyChequeSumColIndex, dailyChequeSumColLetter)
    
    '-----------------------------------------------
    ' Apply Conditional Formatting
    '-----------------------------------------------
    Call ApplyConditionalFormatting(ws, fixedSummaryStartRow, dailyChequeSumColIndex, dailyFactorSumColIndex)
End Sub

'===============================================================================
' CREATE COLUMN M SECTIONS - 10-day groupings with colors and new text
'===============================================================================
Private Sub CreateColumnMSections( _
    ws As Worksheet, _
    monthDays As Long, _
    totalRowsPerDayBlock As Long, _
    dailyChequeSumColIndex As Long, _
    dailyChequeSumColLetter As String)
    
    Dim bStart As Long, bEnd As Long
    Dim dayIdx As Long, rowOfSum As Long, sumAddr As String
    
    ' Color definitions (Office Theme Colors - Lighter 60%)
    Dim colorOrangeAccent2 As Long: colorOrangeAccent2 = RGB(252, 228, 214)   ' Orange Accent2 Lighter 60%
    Dim colorGreenAccent6 As Long: colorGreenAccent6 = RGB(198, 239, 206)     ' Green Accent6 Lighter 60%
    Dim colorGoldAccent4 As Long: colorGoldAccent4 = RGB(255, 242, 204)       ' Gold Accent4 Lighter 60%
    
    ' NEW TEXT - Updated as requested
    Const FarsiSumText1 As String = "�� ��� ����� ����"
    Const FarsiSumText2 As String = "�� ��� ����� �������"
    Const FarsiSumText3 As String = "�� ��� ����� ���� � ����"
    Const FarsiCurrency As String = " ����"
    Const FarsiNumberFormat As String = "#,##0"
    
    ' First 10 days (Orange)
    If monthDays >= 1 Then
        bStart = 2
        bEnd = bStart + Application.Min(10, monthDays) * totalRowsPerDayBlock - 2
        
        sumAddr = ""
        For dayIdx = 1 To Application.Min(10, monthDays)
            rowOfSum = 2 + (dayIdx - 1) * totalRowsPerDayBlock
            sumAddr = sumAddr & dailyChequeSumColLetter & rowOfSum & ","
        Next dayIdx
        If Len(sumAddr) > 0 Then sumAddr = Left(sumAddr, Len(sumAddr) - 1)
        
        With ws.Range("M" & bStart & ":M" & bEnd)
            .Merge: .Orientation = xlUpward
            .Interior.color = colorOrangeAccent2
            .Formula = "= """ & FarsiSumText1 & """ & CHAR(10) & TEXT(SUM(" & sumAddr & "),""" & FarsiNumberFormat & """) & """ & FarsiCurrency & """"
        End With
    End If
    
    ' Days 11-20 (Green)
    If monthDays >= 11 Then
        bStart = 2 + 10 * totalRowsPerDayBlock
        bEnd = bStart + Application.Min(10, monthDays - 10) * totalRowsPerDayBlock - 2
        
        sumAddr = ""
        For dayIdx = 11 To Application.Min(20, monthDays)
            rowOfSum = 2 + (dayIdx - 1) * totalRowsPerDayBlock
            sumAddr = sumAddr & dailyChequeSumColLetter & rowOfSum & ","
        Next dayIdx
        If Len(sumAddr) > 0 Then sumAddr = Left(sumAddr, Len(sumAddr) - 1)
        
        With ws.Range("M" & bStart & ":M" & bEnd)
            .Merge: .Orientation = xlUpward
            .Interior.color = colorGreenAccent6
            .Formula = "= """ & FarsiSumText2 & """ & CHAR(10) & TEXT(SUM(" & sumAddr & "),""" & FarsiNumberFormat & """) & """ & FarsiCurrency & """"
        End With
    End If
    
    ' Days 21+ (Gold)
    If monthDays >= 21 Then
        bStart = 2 + 20 * totalRowsPerDayBlock
        bEnd = bStart + (monthDays - 20) * totalRowsPerDayBlock - 2
        
        sumAddr = ""
        For dayIdx = 21 To monthDays
            rowOfSum = 2 + (dayIdx - 1) * totalRowsPerDayBlock
            sumAddr = sumAddr & dailyChequeSumColLetter & rowOfSum & ","
        Next dayIdx
        If Len(sumAddr) > 0 Then sumAddr = Left(sumAddr, Len(sumAddr) - 1)
        
        With ws.Range("M" & bStart & ":M" & bEnd)
            .Merge: .Orientation = xlUpward
            .Interior.color = colorGoldAccent4
            .Formula = "= """ & FarsiSumText3 & """ & CHAR(10) & TEXT(SUM(" & sumAddr & "),""" & FarsiNumberFormat & """) & """ & FarsiCurrency & """"
        End With
    End If
End Sub

'===============================================================================
' APPLY CONDITIONAL FORMATTING
'===============================================================================
Private Sub ApplyConditionalFormatting( _
    ws As Worksheet, _
    fixedSummaryStartRow As Long, _
    dailyChequeSumColIndex As Long, _
    dailyFactorSumColIndex As Long)
    
    Dim lastDataRow As Long
    lastDataRow = fixedSummaryStartRow - 3
    
    Dim dailyChequeSumColLetter As String
    dailyChequeSumColLetter = Split(ws.Cells(1, dailyChequeSumColIndex).Address(False, False), "1")(0)
    
    Dim dailyFactorSumColLetter As String
    dailyFactorSumColLetter = Split(ws.Cells(1, dailyFactorSumColIndex).Address(False, False), "1")(0)
    
    ' 1. Column G - Daily Sales Sum (Low=Red, Mid=Yellow, High=Green)
    With ws.Range("G2:G" & lastDataRow)
        .FormatConditions.Delete
        Dim Cfg As ColorScale
        Set Cfg = .FormatConditions.AddColorScale(3)
        
        With Cfg.ColorScaleCriteria(1)  ' Lowest = Red
            .Type = xlConditionValueLowestValue
            .FormatColor.color = RGB(255, 0, 0)
        End With
        With Cfg.ColorScaleCriteria(2)  ' Midpoint = Yellow
            .Type = xlConditionValuePercentile
            .value = 50
            .FormatColor.color = RGB(255, 255, 0)
        End With
        With Cfg.ColorScaleCriteria(3)  ' Highest = Green
            .Type = xlConditionValueHighestValue
            .FormatColor.color = RGB(0, 176, 80)
        End With
    End With
    
    ' 2. Cheque Sum Column - Reverse (Low=Green, Mid=Yellow, High=Red)
    With ws.Range(dailyChequeSumColLetter & "2:" & dailyChequeSumColLetter & lastDataRow)
        .FormatConditions.Delete
        Dim cfCheque As ColorScale
        Set cfCheque = .FormatConditions.AddColorScale(3)
        
        With cfCheque.ColorScaleCriteria(1)  ' Lowest = Green
            .Type = xlConditionValueLowestValue
            .FormatColor.color = RGB(0, 176, 80)
        End With
        With cfCheque.ColorScaleCriteria(2)  ' Midpoint = Yellow
            .Type = xlConditionValuePercentile
            .value = 50
            .FormatColor.color = RGB(255, 255, 0)
        End With
        With cfCheque.ColorScaleCriteria(3)  ' Highest = Red
            .Type = xlConditionValueHighestValue
            .FormatColor.color = RGB(255, 0, 0)
        End With
    End With
    
    ' 3. Factor Sum Column - Same as Cheque (Low=Green, Mid=Yellow, High=Red)
    With ws.Range(dailyFactorSumColLetter & "2:" & dailyFactorSumColLetter & lastDataRow)
        .FormatConditions.Delete
        Dim cfFactor As ColorScale
        Set cfFactor = .FormatConditions.AddColorScale(3)
        
        With cfFactor.ColorScaleCriteria(1)  ' Lowest = Green
            .Type = xlConditionValueLowestValue
            .FormatColor.color = RGB(0, 176, 80)
        End With
        With cfFactor.ColorScaleCriteria(2)  ' Midpoint = Yellow
            .Type = xlConditionValuePercentile
            .value = 50
            .FormatColor.color = RGB(255, 255, 0)
        End With
        With cfFactor.ColorScaleCriteria(3)  ' Highest = Red
            .Type = xlConditionValueHighestValue
            .FormatColor.color = RGB(255, 0, 0)
        End With
    End With
End Sub
  '===============================================================================
  ' SET FIRST DAY OPENING BALANCE
  ' Column J on the first day equals previous month's last closing balance in column K
  '===============================================================================
  Private Sub SetFirstDayOpeningBalance( _
      ws As Worksheet, _
      wb As Workbook, _
      newYear As Long, _
      monthNumber As Long, _
      monthNames As Variant, _
      totalRowsPerDayBlock As Long)

      Dim prevYear As Long
      Dim prevMonth As Long
      Dim prevMonthDays As Long
      Dim prevSheetName As String
      Dim prevLastDayRow As Long
      Dim wsPrev As Worksheet

      If monthNumber = 1 Then
          prevYear = newYear - 1
          prevMonth = 12
      Else
          prevYear = newYear
          prevMonth = monthNumber - 1
      End If

      prevMonthDays = GetPersianMonthDays_New(prevYear, prevMonth)
      prevLastDayRow = 2 + (prevMonthDays - 1) * totalRowsPerDayBlock
      prevSheetName = monthNames(prevMonth - 1) & " " & prevYear

      On Error Resume Next
      Set wsPrev = wb.Sheets(prevSheetName)
      On Error GoTo 0

      With ws.Range("J2")
          .NumberFormat = "#,##0;;;"

          If wsPrev Is Nothing Then
              .value = ""
          Else
              .Formula = "='" & prevSheetName & "'!K" & prevLastDayRow
          End If
      End With
  End Sub
'===============================================================================
' UPDATE SUMMARY FORMULAS - Updates formulas for specific month
'===============================================================================
Private Sub UpdateSummaryFormulas( _
    ws As Worksheet, _
    monthDays As Long, _
    numCenters As Long, _
    userCenters As Long, _
    centerNames() As String, _
    chequesPerDay As Long, _
    factorsPerDay As Long, _
    fixedSummaryStartRow As Long, _
    totalRowsPerDayBlock As Long)
    
    Dim currentSummaryRow As Long
    Dim i As Long, day As Long
    
    ' Column letter calculations
    Dim firstChequeColIndex As Long: firstChequeColIndex = 14
    Dim dailyChequeSumColIndex As Long: dailyChequeSumColIndex = firstChequeColIndex + (chequesPerDay * 2)
    Dim dailyChequeSumColLetter As String
    dailyChequeSumColLetter = Split(ws.Cells(1, dailyChequeSumColIndex).Address(False, False), "1")(0)
    
    Dim firstFactorColIndex As Long: firstFactorColIndex = dailyChequeSumColIndex + 1
    Dim dailyFactorSumColIndex As Long: dailyFactorSumColIndex = firstFactorColIndex + (factorsPerDay * 2)
    Dim dailyFactorSumColLetter As String
    dailyFactorSumColLetter = Split(ws.Cells(1, dailyFactorSumColIndex).Address(False, False), "1")(0)
    
    currentSummaryRow = fixedSummaryStartRow
    
    ' Monthly cheque sum
    ws.Cells(currentSummaryRow, "B").value = "��� �� ���"
    ws.Cells(currentSummaryRow, "C").Formula = "=SUM(" & dailyChequeSumColLetter & "2:" & dailyChequeSumColLetter & (fixedSummaryStartRow - 3) & ")"
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0"
    currentSummaryRow = currentSummaryRow + 1
    
    ' Monthly factor sum
    ws.Cells(currentSummaryRow, "B").value = "��� �ǘ��� ���"
    ws.Cells(currentSummaryRow, "C").Formula = "=SUM(" & dailyFactorSumColLetter & "2:" & dailyFactorSumColLetter & (fixedSummaryStartRow - 3) & ")"
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0"
    currentSummaryRow = currentSummaryRow + 1
    
    currentSummaryRow = currentSummaryRow + 1
    
    ' Center sales
    For i = 1 To userCenters
        ws.Cells(currentSummaryRow, "B").value = "��� ���� " & centerNames(i)
        
        Dim sumRangeCash As String, sumRangeCard As String
        Dim firstDayRow As Long, centerRowOffset As Long
        centerRowOffset = i - 1
        sumRangeCash = ""
        sumRangeCard = ""
        
        For day = 1 To monthDays
            firstDayRow = 2 + (day - 1) * totalRowsPerDayBlock
            sumRangeCash = sumRangeCash & ws.Cells(firstDayRow + centerRowOffset, "C").Address(False, False) & ","
            sumRangeCard = sumRangeCard & ws.Cells(firstDayRow + centerRowOffset, "D").Address(False, False) & ","
        Next day
        
        Dim combinedSumFormulaPart As String
        If Len(sumRangeCash) > 0 And Len(sumRangeCard) > 0 Then
            combinedSumFormulaPart = Left(sumRangeCash, Len(sumRangeCash) - 1) & "," & Left(sumRangeCard, Len(sumRangeCard) - 1)
            ws.Cells(currentSummaryRow, "C").Formula = "=SUM(" & combinedSumFormulaPart & ")"
        Else
            ws.Cells(currentSummaryRow, "C").value = 0
        End If
        ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0"
        currentSummaryRow = currentSummaryRow + 1
    Next i
    
    ' Insurance total row
    Dim totalInsuranceRow As Long
    totalInsuranceRow = currentSummaryRow
    ws.Cells(totalInsuranceRow, "B").value = "��� ���� ��"
    ws.Cells(totalInsuranceRow, "C").NumberFormat = "#,##0"
    currentSummaryRow = currentSummaryRow + 1
    
    ' Total sales
    Dim totalSalesRow As Long
    totalSalesRow = currentSummaryRow
    ws.Cells(currentSummaryRow, "B").value = "��� ����"
    ws.Cells(currentSummaryRow, "C").Formula = "=SUM(G2:G" & (fixedSummaryStartRow - 3) & ")"
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0"
    currentSummaryRow = currentSummaryRow + 1
    
    ' Total with insurance
    ws.Cells(currentSummaryRow, "B").value = "��� ���� �� �� ���� ��"
    ws.Cells(currentSummaryRow, "C").Formula = "=" & ws.Cells(totalSalesRow, "C").Address(False, False) & " + " & ws.Cells(totalInsuranceRow, "C").Address(False, False)
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0"
    currentSummaryRow = currentSummaryRow + 1
    
    ' Averages
    ws.Cells(currentSummaryRow, "B").value = "����� ����"
    ws.Cells(currentSummaryRow, "C").Formula = "=IFERROR(" & ws.Cells(totalSalesRow, "C").Address(False, False) & " / " & monthDays & ", 0)"
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0.00"
    currentSummaryRow = currentSummaryRow + 1
    
    ws.Cells(currentSummaryRow, "B").value = "����� ���� ��"
    ws.Cells(currentSummaryRow, "C").Formula = "=IFERROR(" & ws.Cells(totalSalesRow + 1, "C").Address(False, False) & " / " & monthDays & ", 0)"
    ws.Cells(currentSummaryRow, "C").NumberFormat = "#,##0.00"
    currentSummaryRow = currentSummaryRow + 1
    
    currentSummaryRow = currentSummaryRow + 2
    
    ' Insurance section header
    With ws.Range(ws.Cells(currentSummaryRow, "B"), ws.Cells(currentSummaryRow, "C"))
        .value = Array("����", "����")
        .Font.bold = True
    End With
    currentSummaryRow = currentSummaryRow + 1
    
    Dim insuranceStartRow As Long
    insuranceStartRow = currentSummaryRow
    
    ws.Cells(currentSummaryRow, "B").value = "���� ����� �������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����� ������� ��� ������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����� ������� ��� ������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "��� ��� �Ԙ": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����� �� �������� ��� ������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����� �� �������� ��� ������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����� �� �������� ��� ������": currentSummaryRow = currentSummaryRow + 1
    ws.Cells(currentSummaryRow, "B").value = "���� ����": currentSummaryRow = currentSummaryRow + 1
    
    If userCenters > 1 Then
        For i = 2 To userCenters
            ws.Cells(currentSummaryRow, "B").value = "���� ����� ���� " & centerNames(i) & " ��� ������": currentSummaryRow = currentSummaryRow + 1
            ws.Cells(currentSummaryRow, "B").value = "���� ����� ���� " & centerNames(i) & " ��� ������": currentSummaryRow = currentSummaryRow + 1
            ws.Cells(currentSummaryRow, "B").value = "���� ����� ���� " & centerNames(i) & " ��� ������": currentSummaryRow = currentSummaryRow + 1
        Next i
    End If
    
    Dim insuranceEndRow As Long
    insuranceEndRow = currentSummaryRow - 1
    
    ws.Range(ws.Cells(insuranceStartRow, "C"), ws.Cells(insuranceEndRow, "C")).NumberFormat = "#,##0"
    ws.Cells(totalInsuranceRow, "C").Formula = "=SUM(C" & insuranceStartRow & ":C" & insuranceEndRow & ")"
End Sub

'===============================================================================
' Helper Functions (PUBLIC for access from other modules)
'===============================================================================

Public Function GetPersianMonthDays_New(pYear As Long, pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        GetPersianMonthDays_New = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        GetPersianMonthDays_New = 30
    ElseIf pMonth = 12 Then
        If ((pYear - 1403) Mod 4 = 0) Then
            GetPersianMonthDays_New = 30
        Else
            GetPersianMonthDays_New = 29
        End If
    Else
        GetPersianMonthDays_New = 0
    End If
End Function

Public Function GregorianToPersian_New(gDate As Date) As String
    Dim days_diff As Long, p_y As Long, p_m As Long, p_d As Long, days_in_p_year As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 21)
    days_diff = gDate - ref_g_date
    p_y = 1403
    
    If days_diff < 0 Then
        Do
            p_y = p_y - 1
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            days_diff = days_diff + days_in_p_year
            If days_diff >= 0 Then Exit Do
        Loop
    Else
        Do
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            If days_diff >= days_in_p_year Then
                days_diff = days_diff - days_in_p_year
                p_y = p_y + 1
            Else
                Exit Do
            End If
        Loop
    End If
    
    p_m = 1
    Do While p_m <= 12
        Dim p_days_in_month As Long
        p_days_in_month = GetPersianMonthDays_New(p_y, p_m)
        If days_diff < p_days_in_month Then Exit Do
        days_diff = days_diff - p_days_in_month
        p_m = p_m + 1
    Loop
    
    p_d = days_diff + 1
    GregorianToPersian_New = p_y & "/" & Format(p_m, "00") & "/" & Format(p_d, "00")
End Function

Public Function PersianToGregorianDate_New(pYear As Long, pMonth As Long, pDay As Long) As Date
    Dim i As Long
    Dim total_days As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 21)
    
    total_days = 0
    For i = 1 To pMonth - 1
        total_days = total_days + GetPersianMonthDays_New(pYear, i)
    Next i
    total_days = total_days + pDay - 1
    
    If pYear > 1403 Then
        For i = 1403 To pYear - 1
            If ((i - 1403) Mod 4 = 0) Then
                total_days = total_days + 366
            Else
                total_days = total_days + 365
            End If
        Next i
    ElseIf pYear < 1403 Then
        For i = pYear To 1402
            If ((i - 1403) Mod 4 = 0) Then
                total_days = total_days - 366
            Else
                total_days = total_days - 365
            End If
        Next i
    End If
    
    PersianToGregorianDate_New = ref_g_date + total_days
End Function

'===============================================================================
  ' UPDATE EXISTING DAILY CHEQUE SUM FORMULAS - Integrated version
  ' Updates only the newly-created year from AddNewYearSheets
  '===============================================================================
  Private Sub UpdateExistingDailyChequeSumFormulas_Internal( _
      wb As Workbook, _
      wsInfo As Worksheet, _
      targetYear As Long)

      Dim ws As Worksheet
      Dim chequesPerDay As Long
      Dim numCenters As Long
      Dim userCenters As Long
      Dim rowsPerDay As Long
      Dim totalRowsPerDayBlock As Long
      Dim firstChequeColIndex As Long
      Dim dailyChequeSumColIndex As Long
      Dim monthDays As Long
      Dim pYear As Long
      Dim pMonth As Long
      Dim dayNum As Long
      Dim dayStartRow As Long
      Dim dayEndRow As Long
      Dim lowerHalfStartRow As Long
      Dim upperHalfRows As Long
      Dim formulaText As String
      Dim j As Long
      Dim colOffset As Long
      Dim infoSheetFormulaName As String

      On Error Resume Next
      chequesPerDay = wsInfo.Range("cfg_NumCheques").value
      numCenters = wsInfo.Range("cfg_TotalCenters").value
      userCenters = wsInfo.Range("cfg_ActualUserCenters").value
      On Error GoTo 0

      If chequesPerDay = 0 Then chequesPerDay = 5
      If numCenters = 0 Or userCenters = 0 Then Exit Sub

      rowsPerDay = IIf(userCenters = 1, 2, numCenters)
      totalRowsPerDayBlock = rowsPerDay + 1

      firstChequeColIndex = 14
      dailyChequeSumColIndex = firstChequeColIndex + (chequesPerDay * 2)

      infoSheetFormulaName = "'" & Replace(wsInfo.name, "'", "''") & "'"

      For Each ws In wb.Worksheets
          If IsMonthlySheet_Internal(ws, pYear, pMonth) Then
              If pYear = targetYear Then
                  monthDays = GetPersianMonthDays_New(pYear, pMonth)

                  For dayNum = 1 To monthDays
                      dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                      dayEndRow = dayStartRow + rowsPerDay - 1

                      upperHalfRows = rowsPerDay \ 2
                      lowerHalfStartRow = dayStartRow + upperHalfRows

                      formulaText = "=SUM("

                      For j = 0 To chequesPerDay - 1
                          colOffset = firstChequeColIndex + (j * 2)
                          formulaText = formulaText & ws.Cells(lowerHalfStartRow, colOffset).Address(False, False) & ","
                      Next j

                      If Right(formulaText, 1) = "," Then
                          formulaText = Left(formulaText, Len(formulaText) - 1) & ")"
                      Else
                          formulaText = "=0"
                      End If

                      formulaText = formulaText & _
                          "+IFERROR(XLOOKUP($B$1&""/""&TEXT(A" & dayStartRow & ",""00"")," & infoSheetFormulaName & "!U:U," & infoSheetFormulaName & "!W:W),0)" & _
                          "-IFERROR(XLOOKUP($B$1&""/""&TEXT(A" & dayStartRow & ",""00"")," & infoSheetFormulaName & "!U:U," & infoSheetFormulaName & "!X:X),0)"

                      With ws.Range(ws.Cells(dayStartRow, dailyChequeSumColIndex), ws.Cells(dayEndRow, dailyChequeSumColIndex))
                          .Formula = formulaText
                          .NumberFormat = "#,##0"
                      End With
                  Next dayNum
              End If
          End If
      Next ws
  End Sub

  Private Function IsMonthlySheet_Internal(ws As Worksheet, ByRef pYear As Long, ByRef pMonth As Long) As Boolean
      Dim dateText As String
      Dim parts() As String

      IsMonthlySheet_Internal = False

      dateText = Trim(CStr(ws.Range("B1").value))
      If InStr(dateText, "/") = 0 Then Exit Function

      parts = Split(dateText, "/")
      If UBound(parts) < 1 Then Exit Function

      If Not IsNumeric(parts(0)) Then Exit Function
      If Not IsNumeric(parts(1)) Then Exit Function

      pYear = CLng(parts(0))
      pMonth = CLng(parts(1))

      If pYear < 1300 Or pYear > 1500 Then Exit Function
      If pMonth < 1 Or pMonth > 12 Then Exit Function

      IsMonthlySheet_Internal = True
  End Function
'-----------------------------------------------
  ' Add new year to the end of column Q in �������
  '-----------------------------------------------
  Private Sub AddYearToColumnQ(wsInfo As Worksheet, newYear As Long)
      Dim lastRow As Long
      Dim firstDataRow As Long
      Dim yearCell As Range
      Dim yearExists As Boolean

      firstDataRow = 1

      lastRow = wsInfo.Cells(wsInfo.rows.count, "Q").End(xlUp).row

      If lastRow < firstDataRow Then
          lastRow = firstDataRow - 1
      End If

      yearExists = False

      If lastRow >= firstDataRow Then
          For Each yearCell In wsInfo.Range("Q" & firstDataRow & ":Q" & lastRow)
              If Trim(CStr(yearCell.value)) = CStr(newYear) Then
                  yearExists = True
                  Exit For
              End If
          Next yearCell
      End If

      If Not yearExists Then
          wsInfo.Cells(lastRow + 1, "Q").value = Format(newYear, "0000")
      End If
  End Sub


  '=====================================================================  ==========
  ' FILL BANK CLEARING FORMULAS COLUMN Y - Integrated version
  ' Fills ������� column Y after date rows are created
  '=====================================================================  ==========
  Private Sub FillBankClearingFormulasColumnY_Internal( _
      wb As Workbook, _
      wsInfo As Worksheet)

      Const INFO_DATE_LIST_COL As String = "U"
      Const INFO_BANK_CLEARING_COL As String = "Y"

      Dim wsMonth As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim persianDate As String
      Dim cleanDate As String
      Dim parts() As String
      Dim ym As String
      Dim dayNum As Long

      Dim numCheques As Long
      Dim firstChequeCol As Long
      Dim lastChequeCol As Long
      Dim totalCenters As Long
      Dim userCenters As Long
      Dim rowsPerDay As Long
      Dim totalRowsPerDayBlock As Long
      Dim lowerHalfStartOffset As Long
      Dim dayStartRow As Long
      Dim amountRow As Long

      Dim c As Long
      Dim formulaText As String
      Dim sheetName As String

      On Error Resume Next
      numCheques = wsInfo.Range("cfg_NumCheques").value
      totalCenters = wsInfo.Range("cfg_TotalCenters").value
      userCenters = wsInfo.Range("cfg_ActualUserCenters").value
      On Error GoTo 0

  If numCheques <= 0 Or totalCenters <= 0 Or userCenters <= 0 Then
      Exit Sub
  End If

      firstChequeCol = 14
      lastChequeCol = firstChequeCol + (numCheques * 2) - 2

      rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
      totalRowsPerDayBlock = rowsPerDay + 1
      lowerHalfStartOffset = rowsPerDay \ 2

      lastRow = wsInfo.Cells(wsInfo.rows.count, INFO_DATE_LIST_COL).End(xlUp).row

      For r = 2 To lastRow
          persianDate = Trim(CStr(wsInfo.Cells(r, INFO_DATE_LIST_COL).value))

          If persianDate <> "" Then
              cleanDate = ConvertPersianNumsToEnglishKeepSlashY_Internal(persianDate)

              If IsValidPersianDateY_Internal(cleanDate) Then
                  parts = Split(cleanDate, "/")

                  ym = CLng(parts(0)) & "/" & Format(CLng(parts(1)), "00")
                  dayNum = CLng(parts(2))

                  Set wsMonth = FindSheetByYM_Internal(wb, ym)

                  If Not wsMonth Is Nothing Then
                      dayStartRow = FindDayRowY_Internal(wsMonth, dayNum, totalRowsPerDayBlock)

                      If dayStartRow > 0 Then
                          amountRow = dayStartRow + lowerHalfStartOffset
                          sheetName = "'" & Replace(wsMonth.name, "'", "''") & "'"

                          formulaText = "=SUM("

                          For c = firstChequeCol To lastChequeCol Step 2
                              formulaText = formulaText & sheetName & "!" & wsMonth.Cells(amountRow, c).Address(False, False) & ","
                          Next c

                          formulaText = Left$(formulaText, Len(formulaText) - 1) & ")"

                          wsInfo.Cells(r, INFO_BANK_CLEARING_COL).Formula = formulaText
                      Else
                          wsInfo.Cells(r, INFO_BANK_CLEARING_COL).value = 0
                      End If
                  Else
                      wsInfo.Cells(r, INFO_BANK_CLEARING_COL).value = 0
                  End If
              Else
                  wsInfo.Cells(r, INFO_BANK_CLEARING_COL).ClearContents
              End If
          Else
              wsInfo.Cells(r, INFO_BANK_CLEARING_COL).ClearContents
          End If

          Set wsMonth = Nothing
      Next r
  End Sub

  Private Function FindSheetByYM_Internal(wb As Workbook, ByVal ym As String) As Worksheet
      Dim ws As Worksheet

      For Each ws In wb.Worksheets
          If Trim(CStr(ws.Range("B1").value)) = ym Then
              Set FindSheetByYM_Internal = ws
              Exit Function
          End If
      Next ws

      Set FindSheetByYM_Internal = Nothing
  End Function

  Private Function FindDayRowY_Internal(ByVal ws As Worksheet, ByVal dayNum As Long, ByVal totalRowsPerDayBlock As Long) As Long
      Dim dayStartRow As Long

      dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

      If ws.Cells(dayStartRow, "A").value = dayNum Then
          FindDayRowY_Internal = dayStartRow
      Else
          FindDayRowY_Internal = 0
      End If
  End Function

  Private Function ConvertPersianNumsToEnglishKeepSlashY_Internal(ByVal s As Variant) As String
      Dim i As Long
      Dim out As String
      Dim ch As String
      Dim code As Long

      If IsNull(s) Or IsEmpty(s) Then
          ConvertPersianNumsToEnglishKeepSlashY_Internal = ""
          Exit Function
      End If

      s = CStr(s)
      out = ""

      For i = 1 To Len(s)
          ch = Mid$(s, i, 1)
          code = AscW(ch)

          Select Case code
              Case 1776 To 1785
                  out = out & CStr(code - 1776)
              Case 1632 To 1641
                  out = out & CStr(code - 1632)
              Case 48 To 57
                  out = out & ch
              Case 47
                  out = out & "/"
              Case 32
                  out = out & " "
              Case Else
                  If ch >= "0" And ch <= "9" Then
                      out = out & ch
                  ElseIf ch = "/" Then
                      out = out & "/"
                  End If
          End Select
      Next i

      ConvertPersianNumsToEnglishKeepSlashY_Internal = Trim(out)
  End Function

  Private Function IsValidPersianDateY_Internal(ByVal dateStr As String) As Boolean
      Dim parts() As String
      Dim y As Long
      Dim m As Long
      Dim d As Long
      Dim maxDay As Long

      On Error GoTo InvalidDate

      dateStr = ConvertPersianNumsToEnglishKeepSlashY_Internal(dateStr)

      If InStr(dateStr, "/") = 0 Then GoTo InvalidDate

      parts = Split(dateStr, "/")
      If UBound(parts) <> 2 Then GoTo InvalidDate

      y = CLng(Trim(parts(0)))
      m = CLng(Trim(parts(1)))
      d = CLng(Trim(parts(2)))

      If y < 1300 Or y > 1500 Then GoTo InvalidDate
      If m < 1 Or m > 12 Then GoTo InvalidDate
      If d < 1 Then GoTo InvalidDate

      maxDay = GetPersianMonthDays_New(y, m)
      If d > maxDay Then GoTo InvalidDate

      IsValidPersianDateY_Internal = True
      Exit Function

InvalidDate:
      IsValidPersianDateY_Internal = False
  End Function

'-----------------------------------------------
' Update date columns T, U, V in ������� sheet
'-----------------------------------------------
Private Sub UpdateDateColumns(wsInfo As Worksheet, newYear As Long, chequesPerDay As Long, numCenters As Long, userCenters As Long, monthNames As Variant)
    Dim lastRow As Long
    Dim rowCounter As Long
    Dim currentGregorianDate As Date
    Dim persianDateString As String
    Dim startGregorianDate As Date
    Dim endGregorianDate As Date
    Dim lastMonthDays As Long
    
    lastRow = wsInfo.Cells(wsInfo.rows.count, "U").End(xlUp).row
    If lastRow < 1 Then lastRow = 0
    
    startGregorianDate = PersianToGregorianDate_New(newYear, 1, 1)
    lastMonthDays = GetPersianMonthDays_New(newYear, 12)
    endGregorianDate = PersianToGregorianDate_New(newYear, 12, lastMonthDays)
    
    rowCounter = lastRow + 1
    
    Dim totalRowsPerDayBlock As Long
    totalRowsPerDayBlock = IIf(userCenters = 1, 2, numCenters) + 1
    
    Dim firstChequeColIndex As Long: firstChequeColIndex = 14
    Dim dailyChequeSumColIndex As Long: dailyChequeSumColIndex = firstChequeColIndex + (chequesPerDay * 2)
    Dim dailyChequeSumColLetter As String
    
    Dim sampleWs As Worksheet
    On Error Resume Next
    Set sampleWs = wsInfo.parent.Sheets(monthNames(0) & " " & newYear)
    On Error GoTo 0
    
    If Not sampleWs Is Nothing Then
        dailyChequeSumColLetter = Split(sampleWs.Cells(1, dailyChequeSumColIndex).Address(False, False), "1")(0)
    Else
        dailyChequeSumColLetter = "AH"
    End If
    
    currentGregorianDate = startGregorianDate
    Do While currentGregorianDate <= endGregorianDate
        persianDateString = GregorianToPersian_New(currentGregorianDate)
        
        wsInfo.Cells(rowCounter, "U").value = persianDateString
        wsInfo.Cells(rowCounter, "T").value = rowCounter
        
        Dim pYear As Long, pMonth As Long, pDay As Long
        Dim partsDate() As String
        
        If InStr(persianDateString, "/") > 0 Then
            partsDate = Split(persianDateString, "/")
            pYear = val(partsDate(0))
            pMonth = val(partsDate(1))
            pDay = val(partsDate(2))
            
            Dim monthlySheetName As String
            monthlySheetName = monthNames(pMonth - 1) & " " & pYear
            
            Dim rowInMonthlySheet As Long
            rowInMonthlySheet = 2 + (pDay - 1) * totalRowsPerDayBlock
            
            wsInfo.Cells(rowCounter, "V").Formula = "=SUM('" & monthlySheetName & "'!" & dailyChequeSumColLetter & rowInMonthlySheet & ")"
        End If
        
        rowCounter = rowCounter + 1
        currentGregorianDate = currentGregorianDate + 1
    Loop
End Sub

'-----------------------------------------------
' Update cfg_YearList named range
'-----------------------------------------------
Private Sub UpdateYearList(wb As Workbook, wsInfo As Worksheet, newYear As Long)
    Dim lastYearRow As Long
    Dim firstYearRow As Long
    Dim yearCell As Range
    Dim yearExists As Boolean
    
    firstYearRow = 31
    lastYearRow = wsInfo.Cells(wsInfo.rows.count, "G").End(xlUp).row
    
    If lastYearRow < firstYearRow Then lastYearRow = firstYearRow - 1
    
    yearExists = False
    For Each yearCell In wsInfo.Range("G" & firstYearRow & ":G" & lastYearRow)
        If yearCell.value = newYear Then
            yearExists = True
            Exit For
        End If
    Next yearCell
    
    If Not yearExists Then
        lastYearRow = lastYearRow + 1
        wsInfo.Cells(lastYearRow, "G").value = newYear
    End If
    
    On Error Resume Next
    wb.names("cfg_YearList").RefersTo = wsInfo.Range("G" & firstYearRow & ":G" & lastYearRow)
    On Error GoTo 0
End Sub

'-----------------------------------------------
' Fill Annual Performance Sheet
'-----------------------------------------------
Private Sub FillAnnualPerformanceSheet_New( _
    wb As Workbook, _
    currentYear As Long, _
    numCenters As Long, _
    userCenters As Long, _
    monthNames As Variant, _
    fixedSummaryStartRow As Long, _
    centerNames() As String)
    
    Dim wsAnnual As Worksheet
    Dim wsMonth As Worksheet
    Dim currentAnnualRow As Long
    Dim m As Long, i As Long
    
    On Error Resume Next
    Set wsAnnual = wb.Sheets("����� ��� " & currentYear)
    On Error GoTo 0
    If wsAnnual Is Nothing Then Exit Sub
    
    wsAnnual.Cells.HorizontalAlignment = xlCenter
    wsAnnual.Cells.VerticalAlignment = xlCenter
    
    wsAnnual.Cells(1, 1).value = "��� �����"
    wsAnnual.Cells(1, 1).Font.bold = True
    
    For m = 0 To 11
        wsAnnual.Cells(1, m + 2).value = monthNames(m)
        wsAnnual.Cells(1, m + 2).Font.bold = True
        wsAnnual.Columns(m + 2).ColumnWidth = 15
    Next m
    
    wsAnnual.Cells(1, 14).value = "��� ���"
    wsAnnual.Cells(1, 14).Font.bold = True
    wsAnnual.Columns(14).ColumnWidth = 20
    
    currentAnnualRow = 2
    Dim monthlySalesRowOffset As Long
    monthlySalesRowOffset = fixedSummaryStartRow + 3
    
    ' Center sales
    For i = 1 To userCenters
        wsAnnual.Cells(currentAnnualRow, 1).value = "��� ���� " & centerNames(i)
        wsAnnual.Cells(currentAnnualRow, 1).Font.bold = True
        
        For m = 0 To 11
            Dim monthlySheetName As String
            monthlySheetName = monthNames(m) & " " & currentYear
            
            On Error Resume Next
            Set wsMonth = wb.Sheets(monthlySheetName)
            On Error GoTo 0
            
            If Not wsMonth Is Nothing Then
                wsAnnual.Cells(currentAnnualRow, m + 2).Formula = "='" & monthlySheetName & "'!C" & (monthlySalesRowOffset + (i - 1))
            Else
                wsAnnual.Cells(currentAnnualRow, m + 2).value = 0
            End If
            wsAnnual.Cells(currentAnnualRow, m + 2).NumberFormat = "#,##0"
            Set wsMonth = Nothing
        Next m
        
        wsAnnual.Cells(currentAnnualRow, 14).Formula = "=SUM(B" & currentAnnualRow & ":M" & currentAnnualRow & ")"
        wsAnnual.Cells(currentAnnualRow, 14).NumberFormat = "#,##0"
        wsAnnual.Cells(currentAnnualRow, 14).Font.bold = True
        currentAnnualRow = currentAnnualRow + 1
    Next i
    
    ' Cheque sum
    Dim monthlyChequeSumRowOffset As Long
    monthlyChequeSumRowOffset = fixedSummaryStartRow
    
    wsAnnual.Cells(currentAnnualRow, 1).value = "��� ��"
    wsAnnual.Cells(currentAnnualRow, 1).Font.bold = True
    For m = 0 To 11
        monthlySheetName = monthNames(m) & " " & currentYear
        On Error Resume Next
        Set wsMonth = wb.Sheets(monthlySheetName)
        On Error GoTo 0
        If Not wsMonth Is Nothing Then
            wsAnnual.Cells(currentAnnualRow, m + 2).Formula = "='" & monthlySheetName & "'!C" & monthlyChequeSumRowOffset
        Else
            wsAnnual.Cells(currentAnnualRow, m + 2).value = 0
        End If
        wsAnnual.Cells(currentAnnualRow, m + 2).NumberFormat = "#,##0"
        Set wsMonth = Nothing
    Next m
    wsAnnual.Cells(currentAnnualRow, 14).Formula = "=SUM(B" & currentAnnualRow & ":M" & currentAnnualRow & ")"
    wsAnnual.Cells(currentAnnualRow, 14).NumberFormat = "#,##0"
    wsAnnual.Cells(currentAnnualRow, 14).Font.bold = True
    currentAnnualRow = currentAnnualRow + 1
    
    ' Factor sum
    Dim monthlyFactorSumRowOffset As Long
    monthlyFactorSumRowOffset = fixedSummaryStartRow + 1
    
    wsAnnual.Cells(currentAnnualRow, 1).value = "��� �ǘ���"
    wsAnnual.Cells(currentAnnualRow, 1).Font.bold = True
    For m = 0 To 11
        monthlySheetName = monthNames(m) & " " & currentYear
        On Error Resume Next
        Set wsMonth = wb.Sheets(monthlySheetName)
        On Error GoTo 0
        If Not wsMonth Is Nothing Then
            wsAnnual.Cells(currentAnnualRow, m + 2).Formula = "='" & monthlySheetName & "'!C" & monthlyFactorSumRowOffset
        Else
            wsAnnual.Cells(currentAnnualRow, m + 2).value = 0
        End If
        wsAnnual.Cells(currentAnnualRow, m + 2).NumberFormat = "#,##0"
        Set wsMonth = Nothing
    Next m
    wsAnnual.Cells(currentAnnualRow, 14).Formula = "=SUM(B" & currentAnnualRow & ":M" & currentAnnualRow & ")"
    wsAnnual.Cells(currentAnnualRow, 14).NumberFormat = "#,##0"
    wsAnnual.Cells(currentAnnualRow, 14).Font.bold = True
    currentAnnualRow = currentAnnualRow + 1
    
    ' Insurance sum
    Dim monthlyInsuranceSumRowOffset As Long
    monthlyInsuranceSumRowOffset = fixedSummaryStartRow + 3 + userCenters
    
    wsAnnual.Cells(currentAnnualRow, 1).value = "��� ���� ��"
    wsAnnual.Cells(currentAnnualRow, 1).Font.bold = True
    For m = 0 To 11
        monthlySheetName = monthNames(m) & " " & currentYear
        On Error Resume Next
        Set wsMonth = wb.Sheets(monthlySheetName)
        On Error GoTo 0
        If Not wsMonth Is Nothing Then
            wsAnnual.Cells(currentAnnualRow, m + 2).Formula = "='" & monthlySheetName & "'!C" & monthlyInsuranceSumRowOffset
        Else
            wsAnnual.Cells(currentAnnualRow, m + 2).value = 0
        End If
        wsAnnual.Cells(currentAnnualRow, m + 2).NumberFormat = "#,##0"
        Set wsMonth = Nothing
    Next m
    wsAnnual.Cells(currentAnnualRow, 14).Formula = "=SUM(B" & currentAnnualRow & ":M" & currentAnnualRow & ")"
    wsAnnual.Cells(currentAnnualRow, 14).NumberFormat = "#,##0"
    wsAnnual.Cells(currentAnnualRow, 14).Font.bold = True
End Sub


