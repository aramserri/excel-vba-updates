Attribute VB_Name = "efaktor"
Sub Showeslahfaktor()
    eslahfaktor.Show
End Sub

