VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsLabelClick"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'=====================================================
' Class Module: clsLabelClick
'=====================================================
Option Explicit

Public WithEvents label As MSForms.label
Attribute label.VB_VarHelpID = -1
Public ParentForm As Object
Public CenterNumber As Long

Private Sub Label_Click()
    If ParentForm Is Nothing Then Exit Sub
    
    Dim labelText As String
    labelText = label.Caption
    
    ' Skip if no valid date
    If labelText = "---" Or labelText = "..." Or Len(labelText) < 3 Then
        Exit Sub
    End If
    
    ' Call the parent form's method to navigate
    Call ParentForm.NavigateToNextDayAfterLabel(CenterNumber)
End Sub
