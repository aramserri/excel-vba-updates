Attribute VB_Name = "unprotect_sheets"
Sub unprotect_all_sheets()
On Error GoTo booboo
unpass = inputBox("Please enter the password:")
For Each Worksheet In ActiveWorkbook.Worksheets
Worksheet.Unprotect Password:=unpass
Next
Exit Sub
booboo: MsgBox "There is s problem - check your password, capslock, etc."
End Sub
