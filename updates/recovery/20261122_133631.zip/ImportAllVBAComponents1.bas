Attribute VB_Name = "ImportAllVBAComponents1"
Sub ImportAllVBAComponents()
    Dim folderPath As String
    Dim fileName As String
    Dim compName As String
    Dim ext As String
    Dim vbComp As VBComponent
    Dim response As VbMsgBoxResult
    
    ' Enable trust access to VBA project object model
    On Error Resume Next
    Application.VBE.MainWindow.Visible = True
    On Error GoTo 0
    
    ' Get folder path from user
    With Application.FileDialog(msoFileDialogFolderPicker)
        .title = "Select Folder Containing VBA Files"
        .AllowMultiSelect = False
        If .Show <> -1 Then Exit Sub
        folderPath = .selectedItems(1)
    End With
    
    If Right(folderPath, 1) <> "\" Then folderPath = folderPath & "\"
    
    ' Confirmation message
    response = MsgBox("This will import all VBA components from the selected folder." & vbCrLf & _
                    "Make sure you trust the source of these files." & vbCrLf & vbCrLf & _
                    "Continue?", vbYesNo + vbExclamation, "Confirm Import")
    
    If response <> vbYes Then Exit Sub
    
    ' Disable break mode and events during import
    Application.EnableEvents = False
    On Error GoTo ErrorHandler
    
    fileName = Dir(folderPath & "*.*")
    
    ' Process all files in the folder
    Do While fileName <> ""
        ext = LCase(Right(fileName, 4))
        compName = Left(fileName, InStrRev(fileName, ".") - 1)
        
        ' Check if file is a VBA component
        If ext = ".bas" Or ext = ".cls" Or ext = ".frm" Then
            ' Delete existing component if it exists
            On Error Resume Next
            Set vbComp = ThisWorkbook.VBProject.VBComponents(compName)
            If Not vbComp Is Nothing Then
                ThisWorkbook.VBProject.VBComponents.Remove vbComp
            End If
            On Error GoTo 0
            
            ' Import the component
            ThisWorkbook.VBProject.VBComponents.Import folderPath & fileName
        End If
        
        fileName = Dir
    Loop
    
    MsgBox "Import completed successfully!", vbInformation, "Success"
    
CleanUp:
    Application.EnableEvents = True
    Exit Sub
    
ErrorHandler:
    MsgBox "Error importing file: " & fileName & vbCrLf & _
           "Error: " & Err.description, vbCritical, "Import Error"
    Resume CleanUp
End Sub


