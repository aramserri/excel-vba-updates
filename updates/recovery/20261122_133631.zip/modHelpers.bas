Attribute VB_Name = "modHelpers"
'========[ Module: modHelpers ]========
Public Function CleanNumber(val As Variant) As Double
    On Error Resume Next
    CleanNumber = CDbl(Replace(val, ",", ""))
    On Error GoTo 0
End Function

