VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "ThisWorkbook"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Private Sub Workbook_WindowResize(ByVal Wn As Window)
    On Error Resume Next
    If ActiveSheet.name = ChrW(1583) & ChrW(1575) & ChrW(1588) & ChrW(1576) & ChrW(1608) & ChrW(1585) & ChrW(1583) Then ReflowDashboardApp
    On Error GoTo 0
End Sub

Private Sub Workbook_SheetActivate(ByVal sh As Object)
    On Error Resume Next
    If sh.name = ChrW(1583) & ChrW(1575) & ChrW(1588) & ChrW(1576) & ChrW(1608) & ChrW(1585) & ChrW(1583) Then ReflowDashboardApp
    On Error GoTo 0
End Sub
  Private Sub Workbook_Open()
      ' Delay startup tasks so Excel can finish opening first.
      ' This helps slower PCs open the workbook more smoothly.
      On Error Resume Next
      Application.OnTime Now + TimeSerial(0, 0, 3), "RunStartupTasks"
      On Error GoTo 0
      Worksheets("�������").Activate
  End Sub
  
