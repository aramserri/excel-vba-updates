Attribute VB_Name = "protect_sheets"
Sub ProtectAll()
     
    Dim wSheet          As Worksheet
    Dim Pwd             As String
     
    Pwd = inputBox("Enter your password to protect all worksheets", "Password Input")
    For Each wSheet In Worksheets
        wSheet.Protect Password:=Pwd
    Next wSheet
     
End Sub
