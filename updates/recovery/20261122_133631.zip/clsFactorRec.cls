VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsFactorRec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

'---- A single unpaid-factor record ----
Public EntryDate As Date
Public amount    As Double
Public Forje     As Long
Public dueDate   As Date
Public sheetName As String
Public rowNum    As Long
Public colNum    As Long

