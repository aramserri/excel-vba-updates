Attribute VB_Name = "ChequeTypes"
Option Explicit

Public Type ChequeData
    amount As String
    chequeDate As String
    serialNumber As String
    SixteenDigitCode As String
End Type

Public Type CompanyInfo
    name As String
    NationalID As String
End Type
