Attribute VB_Name = "cheque"
Sub ShowCheckForm()
    voroodcheque.Show
End Sub

