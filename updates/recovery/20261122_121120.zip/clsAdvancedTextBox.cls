VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsAdvancedTextBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'=====================================================
' Class Module: clsAdvancedTextBox (MERGED - Safe Version)
'=====================================================
Option Explicit

Public WithEvents TBox As MSForms.TextBox
Attribute TBox.VB_VarHelpID = -1
Public ParentForm As Object
Public EnableLiveTotalUpdate As Boolean     ' Flag to control live update
Public TreatSpaceAsPlus As Boolean          ' NEW: Flag to treat space as + (default OFF)
Public EvaluateExpressions As Boolean       ' NEW: Flag to evaluate expressions (default OFF)

Private Sub Class_Initialize()
    EnableLiveTotalUpdate = False   ' Default OFF - won't affect other forms
    TreatSpaceAsPlus = False        ' Default OFF - backward compatible
    EvaluateExpressions = False     ' Default OFF - backward compatible
End Sub

Private Sub TBox_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Call FormatTextBoxImmediate
End Sub

Private Sub TBox_BeforeUpdate(ByVal CANCEL As MSForms.ReturnBoolean)
    Call FormatTextBoxImmediate
End Sub

Private Sub TBox_Change()
    ' Only update total if enabled
    If EnableLiveTotalUpdate Then
        Call UpdateParentTotal
    End If
End Sub

Private Sub TBox_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Or KeyCode = vbKeyTab Then
        Call FormatTextBoxImmediate
    End If
End Sub

Private Sub FormatTextBoxImmediate()
    Dim raw As String, cleaned As String
    Dim hasOperator As Boolean
    Dim result As Double
    
    raw = Trim(TBox.value)
    If raw = "" Then
        If EnableLiveTotalUpdate Then
            Call UpdateParentTotal
        End If
        Exit Sub
    End If
    
    ' Convert Persian numbers
    On Error Resume Next
    If Not ParentForm Is Nothing Then
        cleaned = ParentForm.ConvertPersianNumsToEnglish(raw)
    Else
        cleaned = raw
    End If
    On Error GoTo 0
    
    ' Remove commas
    cleaned = Replace(cleaned, ",", "")
    
    ' Handle space based on setting
    If TreatSpaceAsPlus Then
        ' Normalize multiple spaces to single space
        Do While InStr(cleaned, "  ") > 0
            cleaned = Replace(cleaned, "  ", " ")
        Loop
        cleaned = Trim(cleaned)
        ' Replace space with +
        cleaned = Replace(cleaned, " ", "+")
        
        ' Clean up double operators
        cleaned = Replace(cleaned, "++", "+")
        cleaned = Replace(cleaned, "+-", "-")
        cleaned = Replace(cleaned, "-+", "-")
        cleaned = Replace(cleaned, "*+", "*")
        cleaned = Replace(cleaned, "/+", "/")
        cleaned = Replace(cleaned, "+*", "*")
        cleaned = Replace(cleaned, "+/", "/")
    Else
        ' Original behavior: just remove spaces
        cleaned = Replace(cleaned, " ", "")
    End If
    
    ' Check if expression evaluation is needed
    If EvaluateExpressions Or TreatSpaceAsPlus Then
        ' Check for operators
        hasOperator = (InStr(cleaned, "+") > 0) Or _
                      (InStr(cleaned, "-") > 0 And InStr(cleaned, "-") > 1) Or _
                      (InStr(cleaned, "*") > 0) Or _
                      (InStr(cleaned, "/") > 0)
        
        If hasOperator Then
            On Error Resume Next
            result = CDbl(Application.Evaluate(cleaned))
            If Err.Number = 0 And Not IsError(result) Then
                TBox.value = Format(result, "#,##0")
            End If
            On Error GoTo 0
        ElseIf IsNumeric(cleaned) And cleaned <> "" Then
            TBox.value = Format(CDbl(cleaned), "#,##0")
        End If
    Else
        ' Original behavior: just format as number
        If IsNumeric(cleaned) And cleaned <> "" Then
            TBox.value = Format(CDbl(cleaned), "#,##0")
        End If
    End If
    
    If EnableLiveTotalUpdate Then
        Call UpdateParentTotal
    End If
End Sub

'----------------------------------------
' Try to call parent form's update method
' Supports: UpdateTotalLabel (DailySalesEntry)
'           UpdateSum (sabtBimeha)
'----------------------------------------
Private Sub UpdateParentTotal()
    If ParentForm Is Nothing Then Exit Sub
    
    On Error Resume Next
    
    ' Try UpdateTotalLabel first (for DailySalesEntry and similar forms)
    ParentForm.UpdateTotalLabel
    If Err.Number = 0 Then
        On Error GoTo 0
        Exit Sub
    End If
    Err.Clear
    
    ' Try UpdateSum (for sabtBimeha form)
    ParentForm.UpdateSum
    If Err.Number = 0 Then
        On Error GoTo 0
        Exit Sub
    End If
    Err.Clear
    
    On Error GoTo 0
End Sub

