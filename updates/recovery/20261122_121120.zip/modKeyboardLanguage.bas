Attribute VB_Name = "modKeyboardLanguage"
Option Explicit

' Windows API declarations
#If VBA7 Then
    Private Declare PtrSafe Function ActivateKeyboardLayout Lib "user32" _
        (ByVal hkl As LongPtr, ByVal flags As Long) As LongPtr
    Private Declare PtrSafe Function LoadKeyboardLayout Lib "user32" Alias "LoadKeyboardLayoutA" _
        (ByVal pwszKLID As String, ByVal flags As Long) As LongPtr
    Private Declare PtrSafe Function GetKeyboardLayout Lib "user32" _
        (ByVal idThread As Long) As LongPtr
#Else
    Private Declare Function ActivateKeyboardLayout Lib "user32" _
        (ByVal HKL As Long, ByVal flags As Long) As Long
    Private Declare Function LoadKeyboardLayout Lib "user32" Alias "LoadKeyboardLayoutA" _
        (ByVal pwszKLID As String, ByVal flags As Long) As Long
    Private Declare Function GetKeyboardLayout Lib "user32" _
        (ByVal idThread As Long) As Long
#End If

' Keyboard Layout IDs
Private Const KLF_ACTIVATE As Long = &H1
Private Const LANG_PERSIAN As String = "00000429"   ' Persian (Farsi)
Private Const LANG_ENGLISH As String = "00000409"   ' English (US)
Private Const LANG_ARABIC As String = "00000401"    ' Arabic

'----------------------------------------
' Switch to Persian keyboard
'----------------------------------------
Public Sub SetKeyboardPersian()
    Dim hkl As LongPtr
    hkl = LoadKeyboardLayout(LANG_PERSIAN, KLF_ACTIVATE)
    If hkl <> 0 Then
        ActivateKeyboardLayout hkl, KLF_ACTIVATE
    End If
End Sub

'----------------------------------------
' Switch to English keyboard
'----------------------------------------
Public Sub SetKeyboardEnglish()
    Dim hkl As LongPtr
    hkl = LoadKeyboardLayout(LANG_ENGLISH, KLF_ACTIVATE)
    If hkl <> 0 Then
        ActivateKeyboardLayout hkl, KLF_ACTIVATE
    End If
End Sub

'----------------------------------------
' Switch to Arabic keyboard
'----------------------------------------
Public Sub SetKeyboardArabic()
    Dim hkl As LongPtr
    hkl = LoadKeyboardLayout(LANG_ARABIC, KLF_ACTIVATE)
    If hkl <> 0 Then
        ActivateKeyboardLayout hkl, KLF_ACTIVATE
    End If
End Sub

