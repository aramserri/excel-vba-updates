VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmPaymentHistory 
   Caption         =   "����΍� ������ ��"
   ClientHeight    =   12420
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   18555
   OleObjectBlob   =   "frmPaymentHistory.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmPaymentHistory"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False







'=====================================================
' UserForm: frmPaymentHistory (Search ALL Sheets - IMPROVED)
'=====================================================
Option Explicit

Public targetYear As String
Public targetMonth As String
Public userCenters As Long
Public totalCenters As Long
Public InsuranceTypes As Collection

Private m_Initialized As Boolean

Private WithEvents m_btnClose As MSForms.CommandButton
Attribute m_btnClose.VB_VarHelpID = -1
Private WithEvents m_btnDelete As MSForms.CommandButton
Attribute m_btnDelete.VB_VarHelpID = -1
Private WithEvents m_btnFilter As MSForms.CommandButton
Attribute m_btnFilter.VB_VarHelpID = -1
Private WithEvents m_btnExportPDF As MSForms.CommandButton
Attribute m_btnExportPDF.VB_VarHelpID = -1
Private WithEvents m_btnClearFilter As MSForms.CommandButton
Attribute m_btnClearFilter.VB_VarHelpID = -1
Private WithEvents m_cboFilterInsurance As MSForms.ComboBox
Attribute m_cboFilterInsurance.VB_VarHelpID = -1
Private m_txtFilterAmount As MSForms.TextBox
Private m_txtFilterNote As MSForms.TextBox

' Date filter ComboBoxes - Payment Date
Private WithEvents m_cboPayYearFrom As MSForms.ComboBox
Attribute m_cboPayYearFrom.VB_VarHelpID = -1
Private WithEvents m_cboPayMonthFrom As MSForms.ComboBox
Attribute m_cboPayMonthFrom.VB_VarHelpID = -1
Private WithEvents m_cboPayDayFrom As MSForms.ComboBox
Attribute m_cboPayDayFrom.VB_VarHelpID = -1
Private WithEvents m_cboPayYearTo As MSForms.ComboBox
Attribute m_cboPayYearTo.VB_VarHelpID = -1
Private WithEvents m_cboPayMonthTo As MSForms.ComboBox
Attribute m_cboPayMonthTo.VB_VarHelpID = -1
Private WithEvents m_cboPayDayTo As MSForms.ComboBox
Attribute m_cboPayDayTo.VB_VarHelpID = -1

' Insurance Month filter ComboBoxes
Private WithEvents m_cboInsYearFrom As MSForms.ComboBox
Attribute m_cboInsYearFrom.VB_VarHelpID = -1
Private WithEvents m_cboInsMonthFrom As MSForms.ComboBox
Attribute m_cboInsMonthFrom.VB_VarHelpID = -1
Private WithEvents m_cboInsYearTo As MSForms.ComboBox
Attribute m_cboInsYearTo.VB_VarHelpID = -1
Private WithEvents m_cboInsMonthTo As MSForms.ComboBox
Attribute m_cboInsMonthTo.VB_VarHelpID = -1

Private m_lstPayments As MSForms.ListBox

' Store payment info for deletion
Private Type PaymentInfo
    sheetName As String
    insuranceRow As Long
    paymentCol As Long
End Type

Private m_PaymentList() As PaymentInfo
Private m_PaymentCount As Long



Private Sub UserForm_Initialize()
    Me.Caption = "����΍� ������ ��� ����"
    Me.Width = 950
    Me.Height = 725
    m_Initialized = False
    m_PaymentCount = 0
End Sub

Private Sub UserForm_Activate()
    If m_Initialized Then Exit Sub
    m_Initialized = True
    
    If userCenters = 0 Or totalCenters = 0 Then
        MsgBox "���: ������� ��ǘ� ���� ���� ���.", vbCritical
        Unload Me
        Exit Sub
    End If
    
    Dim topPos As Single: topPos = 10
    Dim lbl As MSForms.label
    Dim formWidth As Single: formWidth = Me.InsideWidth
    Dim i As Long
    Dim currentYear As Long
    
    ' Get current year for ComboBoxes
    On Error Resume Next
    currentYear = val(ThisWorkbook.Sheets("�������").Range("AC1").value)
    On Error GoTo 0
    If currentYear = 0 Then currentYear = 1404
    
    ' ========== Title ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblTitle", True)
    With lbl
        .Caption = "����΍� �� ������ ��� ����"
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 25
        .Font.bold = True
        .Font.size = 14
        .TextAlign = fmTextAlignCenter
    End With
    
    topPos = topPos + 35
    
    ' ========== Filter Section Background ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblFilterBg", True)
    With lbl
        .Caption = ""
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 165
        .BackColor = RGB(240, 240, 240)
        .BorderStyle = fmBorderStyleSingle
    End With
    
    ' ========== Row 1: Insurance Type Filter ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblFilterTitle", True)
    With lbl
        .Caption = "����� ��� ����:"
        .Top = topPos + 8
        .Left = formWidth - 100
        .Width = 85
        .Font.bold = True
        .BackStyle = fmBackStyleTransparent
        .TextAlign = fmTextAlignCenter
    End With
    
    Set m_cboFilterInsurance = Me.Controls.Add("Forms.ComboBox.1", "cboFilterInsurance", True)
    With m_cboFilterInsurance
        .Top = topPos + 5
        .Left = formWidth - 280
        .Width = 170
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboFilterInsurance.AddItem "���"
    m_cboFilterInsurance.AddItem "���� ����� �������"
    m_cboFilterInsurance.AddItem "��� ��� �Ԙ"
    m_cboFilterInsurance.AddItem "���� ����"
    m_cboFilterInsurance.AddItem "���� �����"
    m_cboFilterInsurance.listIndex = 0
    
    ' ========== Row 2: Insurance Month Filter (��� ����) ==========
    topPos = topPos + 35
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsMonth", True)
    With lbl
        .Caption = "��� ����:"
        .Top = topPos + 8
        .Left = formWidth - 100
        .Width = 85
        .Font.bold = True
        .BackStyle = fmBackStyleTransparent
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsFrom", True)
    With lbl
        .Caption = "��"
        .Top = topPos + 8
        .Left = formWidth - 130
        .Width = 20
        .BackStyle = fmBackStyleTransparent
    End With
    
    ' Insurance Year From
    Set m_cboInsYearFrom = Me.Controls.Add("Forms.ComboBox.1", "cboInsYearFrom", True)
    With m_cboInsYearFrom
        .Top = topPos + 5
        .Left = formWidth - 200
        .Width = 60
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboInsYearFrom.AddItem ""
    For i = currentYear - 5 To currentYear + 1
        m_cboInsYearFrom.AddItem CStr(i)
    Next i
    m_cboInsYearFrom.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsSlash1", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 210: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Insurance Month From
    Set m_cboInsMonthFrom = Me.Controls.Add("Forms.ComboBox.1", "cboInsMonthFrom", True)
    With m_cboInsMonthFrom
        .Top = topPos + 5
        .Left = formWidth - 260
        .Width = 45
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboInsMonthFrom.AddItem ""
    For i = 1 To 12
        m_cboInsMonthFrom.AddItem Format(i, "00")
    Next i
    m_cboInsMonthFrom.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsTo", True)
    With lbl
        .Caption = "��"
        .Top = topPos + 8
        .Left = formWidth - 290
        .Width = 20
        .BackStyle = fmBackStyleTransparent
    End With
    
    ' Insurance Year To
    Set m_cboInsYearTo = Me.Controls.Add("Forms.ComboBox.1", "cboInsYearTo", True)
    With m_cboInsYearTo
        .Top = topPos + 5
        .Left = formWidth - 360
        .Width = 60
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboInsYearTo.AddItem ""
    For i = currentYear - 5 To currentYear + 1
        m_cboInsYearTo.AddItem CStr(i)
    Next i
    m_cboInsYearTo.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsSlash2", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 370: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Insurance Month To
    Set m_cboInsMonthTo = Me.Controls.Add("Forms.ComboBox.1", "cboInsMonthTo", True)
    With m_cboInsMonthTo
        .Top = topPos + 5
        .Left = formWidth - 420
        .Width = 45
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboInsMonthTo.AddItem ""
    For i = 1 To 12
        m_cboInsMonthTo.AddItem Format(i, "00")
    Next i
    m_cboInsMonthTo.listIndex = 0
    
    ' ========== Row 3: Payment Date Filter (����� ������) ==========
    topPos = topPos + 35
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPayDate", True)
    With lbl
        .Caption = "����� ������:"
        .Top = topPos + 8
        .Left = formWidth - 100
        .Width = 85
        .Font.bold = True
        .BackStyle = fmBackStyleTransparent
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPayFrom", True)
    With lbl
        .Caption = "��"
        .Top = topPos + 8
        .Left = formWidth - 130
        .Width = 20
        .BackStyle = fmBackStyleTransparent
    End With
    
    ' Payment Day From
    Set m_cboPayDayFrom = Me.Controls.Add("Forms.ComboBox.1", "cboPayDayFrom", True)
    With m_cboPayDayFrom
        .Top = topPos + 5
        .Left = formWidth - 175
        .Width = 40
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayDayFrom.AddItem ""
    For i = 1 To 31
        m_cboPayDayFrom.AddItem Format(i, "00")
    Next i
    m_cboPayDayFrom.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPaySlash1", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 185: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Payment Month From
    Set m_cboPayMonthFrom = Me.Controls.Add("Forms.ComboBox.1", "cboPayMonthFrom", True)
    With m_cboPayMonthFrom
        .Top = topPos + 5
        .Left = formWidth - 230
        .Width = 40
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayMonthFrom.AddItem ""
    For i = 1 To 12
        m_cboPayMonthFrom.AddItem Format(i, "00")
    Next i
    m_cboPayMonthFrom.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPaySlash2", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 240: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Payment Year From
    Set m_cboPayYearFrom = Me.Controls.Add("Forms.ComboBox.1", "cboPayYearFrom", True)
    With m_cboPayYearFrom
        .Top = topPos + 5
        .Left = formWidth - 300
        .Width = 55
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayYearFrom.AddItem ""
    For i = currentYear - 5 To currentYear + 1
        m_cboPayYearFrom.AddItem CStr(i)
    Next i
    m_cboPayYearFrom.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPayTo", True)
    With lbl
        .Caption = "��"
        .Top = topPos + 8
        .Left = formWidth - 330
        .Width = 20
        .BackStyle = fmBackStyleTransparent
    End With
    
    ' Payment Day To
    Set m_cboPayDayTo = Me.Controls.Add("Forms.ComboBox.1", "cboPayDayTo", True)
    With m_cboPayDayTo
        .Top = topPos + 5
        .Left = formWidth - 375
        .Width = 40
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayDayTo.AddItem ""
    For i = 1 To 31
        m_cboPayDayTo.AddItem Format(i, "00")
    Next i
    m_cboPayDayTo.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPaySlash3", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 385: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Payment Month To
    Set m_cboPayMonthTo = Me.Controls.Add("Forms.ComboBox.1", "cboPayMonthTo", True)
    With m_cboPayMonthTo
        .Top = topPos + 5
        .Left = formWidth - 430
        .Width = 40
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayMonthTo.AddItem ""
    For i = 1 To 12
        m_cboPayMonthTo.AddItem Format(i, "00")
    Next i
    m_cboPayMonthTo.listIndex = 0
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPaySlash4", True)
    With lbl: .Caption = "/": .Top = topPos + 8: .Left = formWidth - 440: .Width = 10: .BackStyle = fmBackStyleTransparent: End With
    
    ' Payment Year To
    Set m_cboPayYearTo = Me.Controls.Add("Forms.ComboBox.1", "cboPayYearTo", True)
    With m_cboPayYearTo
        .Top = topPos + 5
        .Left = formWidth - 500
        .Width = 55
        .Style = fmStyleDropDownList
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    m_cboPayYearTo.AddItem ""
    For i = currentYear - 5 To currentYear + 1
        m_cboPayYearTo.AddItem CStr(i)
    Next i
    m_cboPayYearTo.listIndex = 0
    
    ' ========== Row 4: Amount and note filters ==========
    topPos = topPos + 35
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblAmountFilter", True)
    With lbl
        .Caption = UiText("1605,1576,1604,1594,32,1662,1585,1583,1575,1582,1578")
        .Top = topPos + 8
        .Left = formWidth - 100
        .Width = 85
        .Font.bold = True
        .BackStyle = fmBackStyleTransparent
        .TextAlign = fmTextAlignCenter
    End With
    Set m_txtFilterAmount = Me.Controls.Add("Forms.TextBox.1", "txtFilterAmount", True)
    With m_txtFilterAmount
        .Top = topPos + 5
        .Left = formWidth - 250
        .Width = 140
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblNoteFilter", True)
    With lbl
        .Caption = UiText("1580,1587,1578,1580,1608,32,1583,1585,32,1578,1608,1590,1740,1581,1575,1578")
        .Top = topPos + 8
        .Left = formWidth - 365
        .Width = 105
        .Font.bold = True
        .BackStyle = fmBackStyleTransparent
        .TextAlign = fmTextAlignCenter
    End With
    Set m_txtFilterNote = Me.Controls.Add("Forms.TextBox.1", "txtFilterNote", True)
    With m_txtFilterNote
        .Top = topPos + 5
        .Left = formWidth - 610
        .Width = 235
        .Font.name = "Tahoma"
        .Font.size = 9
        .TextAlign = fmTextAlignCenter
    End With
    
    ' ========== Row 5: Filter Buttons ==========
    topPos = topPos + 35
    
    Set m_btnFilter = Me.Controls.Add("Forms.CommandButton.1", "btnFilter", True)
    With m_btnFilter
        .Caption = "����� �����"
        .Top = topPos
        .Left = formWidth - 130
        .Width = 100
        .Height = 24
    End With
    
    Set m_btnClearFilter = Me.Controls.Add("Forms.CommandButton.1", "btnClearFilter", True)
    With m_btnClearFilter
        .Caption = "�ǘ ���� �����"
        .Top = topPos
        .Left = formWidth - 250
        .Width = 110
        .Height = 24
    End With
    
    topPos = topPos + 40
    
    ' ========== ListBox ==========
    Set m_lstPayments = Me.Controls.Add("Forms.ListBox.1", "lstPayments", True)
    With m_lstPayments
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 320
        .ColumnCount = 7
        .ColumnWidths = "40;90;260;110;110;1;240"
        .Font.size = 10
        .TextAlign = fmTextAlignCenter
    End With
    
    topPos = topPos + 330
    
    ' ========== Total Label ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblTotal", True)
    With lbl
        .Caption = "��� ������ ��: 0 ����"
        .Top = topPos
        .Left = formWidth - 500
        .Width = 490
        .Height = 30
        .Font.bold = True
        .Font.size = 14
        .TextAlign = fmTextAlignCenter
        .ForeColor = RGB(0, 100, 0)
    End With
    
    topPos = topPos + 40
    
    ' ========== Buttons ==========
Set m_btnDelete = Me.Controls.Add("Forms.CommandButton.1", "btnDelete", True)
    With m_btnDelete
        .Caption = "��� ������ ���"
        .Top = topPos
        .Left = formWidth - 150
        .Width = 130
        .Height = 32
        .BackColor = RGB(255, 200, 200)
    End With
    
    Set m_btnClose = Me.Controls.Add("Forms.CommandButton.1", "btnClose", True)
    With m_btnClose
        .Caption = "����"
        .Top = topPos
        .Left = formWidth - 290
        .Width = 130
        .Height = 32
    End With
    
    Set m_btnExportPDF = Me.Controls.Add("Forms.CommandButton.1", "btnExport", True)
    With m_btnExportPDF
        .Caption = "����� PDF"
        .Top = topPos
        .Left = formWidth - 430
        .Width = 130
        .Height = 32
        .BackColor = RGB(200, 230, 255)
    End With
    
    Call HistoryUI_ApplyLayout
    Call LoadPayments
End Sub

'=========================================
' LOAD PAYMENTS FROM ALL SHEETS
'=========================================
Private Sub LoadPayments()
    Dim ws As Worksheet
    Dim insuranceStartRow As Long
    Dim insuranceCount As Long
    Dim i As Long, col As Long
    Dim total As Double
    Dim cellValue As Variant
    Dim commentText As String
    Dim paymentDate As String
    Dim paymentDesc As String
    Dim InsuranceName As String
    Dim filterInsurance As String
    Dim filterPayDateFrom As String
    Dim filterPayDateTo As String
    Dim filterInsMonthFrom As String
    Dim filterInsMonthTo As String
    Dim insuranceGroup As String
    Dim sheetDate As String
    Dim rowNum As Long
    Dim paymentRowValues As Variant
    Dim fundRows() As Long
    Dim fundNames() As String
    Dim fundGroups() As String
    Dim filterAmount As Double
    Dim hasAmountFilter As Boolean
    Dim filterNoteText As String
    Dim previousScreenUpdating As Boolean
    On Error GoTo LoadPaymentsError
    previousScreenUpdating = Application.ScreenUpdating
    Application.ScreenUpdating = False
    m_lstPayments.Visible = False
    m_lstPayments.Clear
    m_PaymentCount = 0
    ReDim m_PaymentList(1 To 1000)
    
    ' Header
    m_lstPayments.AddItem
    m_lstPayments.List(0, 0) = "����"
    m_lstPayments.List(0, 1) = "��� ����"
    m_lstPayments.List(0, 2) = "��� ����"
    m_lstPayments.List(0, 3) = "����"
    m_lstPayments.List(0, 4) = "����� ������"
    m_lstPayments.List(0, 5) = ""
    m_lstPayments.List(0, 6) = "�������"
    
    ' Get filter values
    filterInsurance = ""
    filterPayDateFrom = ""
    filterPayDateTo = ""
    filterInsMonthFrom = ""
    filterInsMonthTo = ""
    hasAmountFilter = False
    filterNoteText = ""
    
    On Error Resume Next
    
    ' Insurance type filter
    If m_cboFilterInsurance.listIndex > 0 Then
        filterInsurance = m_cboFilterInsurance.value
    End If
    
    ' Payment date filter
    filterPayDateFrom = BuildDateString(m_cboPayYearFrom.value, m_cboPayMonthFrom.value, m_cboPayDayFrom.value)
    filterPayDateTo = BuildDateString(m_cboPayYearTo.value, m_cboPayMonthTo.value, m_cboPayDayTo.value)
    
    ' Insurance month filter
    filterInsMonthFrom = BuildMonthString(m_cboInsYearFrom.value, m_cboInsMonthFrom.value)
    filterInsMonthTo = BuildMonthString(m_cboInsYearTo.value, m_cboInsMonthTo.value)
    filterNoteText = NormalizeSearchText(m_txtFilterNote.value)
    If Trim(m_txtFilterAmount.value) <> "" Then
        If Not TryParseAmount(m_txtFilterAmount.value, filterAmount) Then
            MsgBox UiText("1605,1576,1604,1594,32,1662,1585,1583,1575,1582,1578") & " " & UiText("1605,1593,1576,1585,32,1606,1740,1587,1578,46"), vbExclamation
            Exit Sub
        End If
        hasAmountFilter = True
    End If
    
    On Error GoTo 0
    
    insuranceCount = GetInsuranceCount()
    ReDim fundRows(1 To insuranceCount)
    ReDim fundNames(1 To insuranceCount)
    ReDim fundGroups(1 To insuranceCount)
    For i = 1 To insuranceCount
        fundRows(i) = InsuranceFundRow(i, userCenters, totalCenters)
        fundNames(i) = GetInsuranceName(i)
        fundGroups(i) = GetInsuranceGroup(fundNames(i))
    Next i
    total = 0
    rowNum = 0
    
    ' Loop through ALL worksheets
    For Each ws In ThisWorkbook.Worksheets
        On Error Resume Next
        sheetDate = Trim(CStr(ws.Range("B1").value))
        On Error GoTo 0
        
        If IsValidMonthlySheet(sheetDate) Then
            ' Apply insurance month filter
            If filterInsMonthFrom <> "" Then
                If CompareMonths(sheetDate, filterInsMonthFrom) < 0 Then
                    GoTo NextSheet
                End If
            End If
            If filterInsMonthTo <> "" Then
                If CompareMonths(sheetDate, filterInsMonthTo) > 0 Then
                    GoTo NextSheet
                End If
            End If
            
            insuranceStartRow = GetInsuranceStartRow()
            For i = 1 To insuranceCount
                Dim insuranceRow As Long
                insuranceRow = fundRows(i)
                InsuranceName = fundNames(i)
                insuranceGroup = fundGroups(i)
                
                ' Apply insurance filter
                If filterInsurance <> "" Then
                    If filterInsurance <> insuranceGroup Then
                        GoTo NextInsurance
                    End If
                End If
                
                paymentRowValues = ws.Range(ws.Cells(insuranceRow, 4), ws.Cells(insuranceRow, 6)).Value2
                For col = 4 To 6
                    cellValue = paymentRowValues(1, col - 3)
                    If IsEmpty(cellValue) Then Exit For
                    If VarType(cellValue) = vbString Then
                        If Trim$(CStr(cellValue)) = "" Then Exit For
                    End If
                    If Not IsNumeric(cellValue) Then Exit For
                    If CDbl(cellValue) <= 0 Then Exit For
                    
If IsNumeric(cellValue) Then
    paymentDate = ""
    paymentDesc = ""

    On Error Resume Next

    If Not ws.Cells(insuranceRow, col).comment Is Nothing Then
        commentText = ws.Cells(insuranceRow, col).comment.text

        If InStr(commentText, vbLf) > 0 Then
            paymentDate = Left(commentText, InStr(commentText, vbLf) - 1)
            paymentDesc = Mid(commentText, InStr(commentText, vbLf) + 1)
        Else
            paymentDate = commentText
        End If
    End If

    On Error GoTo LoadPaymentsError

    ' Continue with amount, note, and date filters here


                        
                        ' Apply amount and note filters
                        If hasAmountFilter Then
                            If Abs(CDbl(cellValue) - filterAmount) > 0.5 Then GoTo NextPayment
                        End If
                        If filterNoteText <> "" Then
                            If InStr(1, NormalizeSearchText(paymentDesc), filterNoteText, vbTextCompare) = 0 Then GoTo NextPayment
                        End If
                        
                        ' Apply payment date filter
                        If filterPayDateFrom <> "" Then
                            If ComparePersianDates(paymentDate, filterPayDateFrom) < 0 Then
                                GoTo NextPayment
                            End If
                        End If
                        If filterPayDateTo <> "" Then
                            If ComparePersianDates(paymentDate, filterPayDateTo) > 0 Then
                                GoTo NextPayment
                            End If
                        End If
                        
                        rowNum = rowNum + 1
                        
                        m_PaymentCount = m_PaymentCount + 1
                        If m_PaymentCount > UBound(m_PaymentList) Then
                            ReDim Preserve m_PaymentList(1 To m_PaymentCount + 100)
                        End If
                        m_PaymentList(m_PaymentCount).sheetName = ws.name
                        m_PaymentList(m_PaymentCount).insuranceRow = insuranceRow
                        m_PaymentList(m_PaymentCount).paymentCol = col
                        
                        m_lstPayments.AddItem
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 0) = CStr(rowNum)
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 1) = sheetDate
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 2) = InsuranceName
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 3) = Format(CDbl(cellValue), "#,##0")
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 4) = paymentDate
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 5) = CStr(m_PaymentCount)
                        m_lstPayments.List(m_lstPayments.ListCount - 1, 6) = paymentDesc
                        
                        total = total + CDbl(cellValue)
                    End If
NextPayment:
                Next col
NextInsurance:
            Next i
        End If
NextSheet:
    Next ws
    
Me.Controls("lblTotal").Caption = "��� ������ ��: " & Format(total, "#,##0") & " ���� (" & rowNum & " ����)"

LoadPaymentsExit:
    On Error Resume Next
    Call HistoryUI_FitList
    m_lstPayments.Visible = True
    Application.ScreenUpdating = previousScreenUpdating
    On Error GoTo 0
    Exit Sub

LoadPaymentsError:
    MsgBox "History load error: " & Err.description, vbExclamation
    Resume LoadPaymentsExit
End Sub
'=========================================
' BUILD DATE STRING FROM COMBOBOXES
'=========================================
Private Function TryParseAmount(ByVal inputText As String, ByRef amount As Double) As Boolean
    Dim cleaned As String
    
    cleaned = ConvertPersianNumsToEnglish(inputText)
    cleaned = Replace(cleaned, ",", "")
    cleaned = Replace(cleaned, ChrW(1644), "")
    cleaned = Replace(cleaned, " ", "")
    If IsNumeric(cleaned) Then
        amount = CDbl(cleaned)
        TryParseAmount = True
    End If
End Function

Private Function NormalizeSearchText(ByVal inputText As String) As String
    Dim cleaned As String
    
    cleaned = LCase$(ConvertPersianNumsToEnglish(Trim$(inputText)))
    cleaned = Replace(cleaned, ChrW(1610), ChrW(1740))
    cleaned = Replace(cleaned, ChrW(1603), ChrW(1705))
    NormalizeSearchText = cleaned
End Function

Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    Dim i As Long
    
    result = inputText
    For i = 1776 To 1785
        result = Replace(result, ChrW(i), CStr(i - 1776))
    Next i
    For i = 1632 To 1641
        result = Replace(result, ChrW(i), CStr(i - 1632))
    Next i
    ConvertPersianNumsToEnglish = result
End Function

Private Function UiText(ByVal codePoints As String) As String
    Dim tokens() As String
    Dim token As Variant
    
    tokens = Split(codePoints, ",")
    For Each token In tokens
        UiText = UiText & ChrW(CLng(token))
    Next token
End Function
Private Function BuildDateString(yr As String, mo As String, dy As String) As String
    If Trim(yr) = "" And Trim(mo) = "" And Trim(dy) = "" Then
        BuildDateString = ""
    Else
        ' Build partial date for comparison
        If Trim(yr) = "" Then yr = "1300"
        If Trim(mo) = "" Then mo = "01"
        If Trim(dy) = "" Then dy = "01"
        BuildDateString = yr & "/" & mo & "/" & dy
    End If
End Function

'=========================================
' BUILD MONTH STRING FROM COMBOBOXES
'=========================================
Private Function BuildMonthString(yr As String, mo As String) As String
    If Trim(yr) = "" And Trim(mo) = "" Then
        BuildMonthString = ""
    Else
        If Trim(yr) = "" Then yr = "1300"
        If Trim(mo) = "" Then mo = "01"
        BuildMonthString = yr & "/" & mo
    End If
End Function

'=========================================
' COMPARE MONTHS (YYYY/MM format)
'=========================================
Private Function CompareMonths(month1 As String, month2 As String) As Long
    Dim m1 As Long, m2 As Long
    
    m1 = MonthToNumeric(month1)
    m2 = MonthToNumeric(month2)
    
    If m1 < m2 Then
        CompareMonths = -1
    ElseIf m1 > m2 Then
        CompareMonths = 1
    Else
        CompareMonths = 0
    End If
End Function

Private Function MonthToNumeric(monthStr As String) As Long
    Dim parts() As String
    
    MonthToNumeric = 0
    
    On Error Resume Next
    If InStr(monthStr, "/") > 0 Then
        parts = Split(monthStr, "/")
        If UBound(parts) >= 1 Then
            MonthToNumeric = val(parts(0)) * 100 + val(parts(1))
        End If
    End If
    On Error GoTo 0
End Function

'=========================================
' CHECK IF SHEET IS A VALID MONTHLY SHEET
'=========================================
Private Function IsValidMonthlySheet(sheetDate As String) As Boolean
    Dim parts() As String
    
    IsValidMonthlySheet = False
    
    If sheetDate = "" Then Exit Function
    If InStr(sheetDate, "/") = 0 Then Exit Function
    
    parts = Split(sheetDate, "/")
    If UBound(parts) < 1 Then Exit Function
    
    If val(parts(0)) < 1300 Or val(parts(0)) > 1500 Then Exit Function
    If val(parts(1)) < 1 Or val(parts(1)) > 12 Then Exit Function
    
    IsValidMonthlySheet = True
End Function

'=========================================
' GET INSURANCE GROUP FOR FILTERING
'=========================================
Private Function GetInsuranceGroup(InsuranceName As String) As String
    If InStr(InsuranceName, "����� �������") > 0 Then
        GetInsuranceGroup = "���� ����� �������"
    ElseIf InStr(InsuranceName, "��� �Ԙ") > 0 Then
        GetInsuranceGroup = "��� ��� �Ԙ"
    ElseIf InStr(InsuranceName, "����") > 0 Then
        GetInsuranceGroup = "���� ����"
    Else
        GetInsuranceGroup = "���� �����"
    End If
End Function

'=========================================
' COMPARE PERSIAN DATES
'=========================================
Private Function ComparePersianDates(date1 As String, date2 As String) As Long
    Dim d1 As Long, d2 As Long
    
    d1 = DateToNumeric(date1)
    d2 = DateToNumeric(date2)
    
    If d1 < d2 Then
        ComparePersianDates = -1
    ElseIf d1 > d2 Then
        ComparePersianDates = 1
    Else
        ComparePersianDates = 0
    End If
End Function

Private Function DateToNumeric(dateStr As String) As Long
    Dim parts() As String
    
    DateToNumeric = 0
    
    On Error Resume Next
    If InStr(dateStr, "/") > 0 Then
        parts = Split(dateStr, "/")
        If UBound(parts) >= 2 Then
            DateToNumeric = val(parts(0)) * 10000 + val(parts(1)) * 100 + val(parts(2))
        End If
    End If
    On Error GoTo 0
End Function

'=========================================
' FILTER BUTTONS
'=========================================
Private Sub m_btnFilter_Click()
    Call LoadPayments
End Sub

Private Sub m_btnClearFilter_Click()
    m_cboFilterInsurance.listIndex = 0
    
    ' Clear payment date filters
    m_cboPayYearFrom.listIndex = 0
    m_cboPayMonthFrom.listIndex = 0
    m_cboPayDayFrom.listIndex = 0
    m_cboPayYearTo.listIndex = 0
    m_cboPayMonthTo.listIndex = 0
    m_cboPayDayTo.listIndex = 0
    
    ' Clear insurance month filters
    m_cboInsYearFrom.listIndex = 0
    m_cboInsMonthFrom.listIndex = 0
    m_cboInsYearTo.listIndex = 0
    m_cboInsMonthTo.listIndex = 0
    m_txtFilterAmount.value = ""
    m_txtFilterNote.value = ""
    
    Call LoadPayments
End Sub

'=========================================
' DELETE BUTTON
'=========================================
Private Sub m_btnDelete_Click()
    If m_lstPayments.listIndex < 1 Then
        MsgBox "����� � ���� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    Dim paymentIndex As Long
    paymentIndex = val(m_lstPayments.List(m_lstPayments.listIndex, 5))
    
    If paymentIndex < 1 Or paymentIndex > m_PaymentCount Then
        MsgBox "��� �� ������� ������.", vbCritical
        Exit Sub
    End If
    
    Dim paymentAmount As String
    paymentAmount = m_lstPayments.List(m_lstPayments.listIndex, 3)
    
    Dim sheetMonth As String
    sheetMonth = m_lstPayments.List(m_lstPayments.listIndex, 1)
    
    If MsgBox("��� �� ��� ��� ������ ������� ����Ͽ" & vbCrLf & _
              "��� ����: " & sheetMonth & vbCrLf & _
              "����: " & paymentAmount & " ����", _
              vbYesNo + vbQuestion, "����� ���") = vbNo Then
        Exit Sub
    End If
    
    Dim ws As Worksheet
    Dim insuranceRow As Long
    Dim paymentCol As Long
    Dim col As Long
    
    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(m_PaymentList(paymentIndex).sheetName)
    On Error GoTo 0
    
    If ws Is Nothing Then
        MsgBox "��� ���� ���.", vbCritical
        Exit Sub
    End If
    
    insuranceRow = m_PaymentList(paymentIndex).insuranceRow
    paymentCol = m_PaymentList(paymentIndex).paymentCol
    
    On Error Resume Next
    ws.Cells(insuranceRow, paymentCol).ClearComments
    ws.Cells(insuranceRow, paymentCol).ClearContents
    On Error GoTo 0
    
    ' Shift remaining payments left
    For col = paymentCol To 49
        If IsEmpty(ws.Cells(insuranceRow, col + 1).value) Then
            Exit For
        End If
        
        ws.Cells(insuranceRow, col).value = ws.Cells(insuranceRow, col + 1).value
        
        On Error Resume Next
        ws.Cells(insuranceRow, col).ClearComments
        If Not ws.Cells(insuranceRow, col + 1).comment Is Nothing Then
            ws.Cells(insuranceRow, col).AddComment ws.Cells(insuranceRow, col + 1).comment.text
            ws.Cells(insuranceRow, col).comment.Visible = False
        End If
        ws.Cells(insuranceRow, col + 1).ClearComments
        ws.Cells(insuranceRow, col + 1).ClearContents
        On Error GoTo 0
    Next col
    
    MsgBox "������ ��� ��.", vbInformation
    Call LoadPayments
End Sub

'=========================================
' CLOSE BUTTON
'=========================================
Private Sub m_btnClose_Click()
    Unload Me
End Sub

'=========================================
' HELPER FUNCTIONS
'=========================================
Private Function GetInsuranceStartRow() As Long
    Dim totalRowsPerDayBlock As Long
    Dim fixedSummaryStartRow As Long
    
    totalRowsPerDayBlock = IIf(userCenters = 1, 2, totalCenters) + 1
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    
    GetInsuranceStartRow = fixedSummaryStartRow + 10 + userCenters + 1
End Function
Private Function GetInsuranceCount() As Long
    GetInsuranceCount = ConfiguredInsuranceFundCount(userCenters, totalCenters)
End Function
Private Function GetInsuranceName(index As Long) As String
    GetInsuranceName = ConfiguredInsuranceFundName(index, userCenters, totalCenters)
End Function
'=========================================
' EXPORT BUTTON
'=========================================
Private Sub m_btnExportpdf_Click()
    If m_lstPayments.ListCount <= 1 Then
        MsgBox "������ ���� ����� ���� �����.", vbExclamation, "���"
        Exit Sub
    End If
    
    Call ExportToPDF
End Sub

'=========================================
' EXPORT TO PDF
'=========================================
Private Sub ExportToPDF()
    On Error GoTo ErrorHandler
    
    Application.StatusBar = "�� ��� ����� ���� PDF..."
    DoEvents
    
    Dim wsTemp As Worksheet
    Dim desktopPath As String
    Dim fileName As String
    Dim i As Long, j As Long
    Dim lastRow As Long
    Dim lastCol As Long
    Dim totalAmount As Double
    
    ' Get desktop path
    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")
    
    ' Create filename with timestamp
    fileName = desktopPath & "\PaymentHistory_" & Format(Now, "yyyymmdd_hhmmss") & ".pdf"
    
    ' Create temporary worksheet
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    Set wsTemp = ThisWorkbook.Worksheets.Add
    wsTemp.name = "TempExport_" & Format(Now, "hhmmss")
    
    ' Set RTL direction for the sheet
    wsTemp.DisplayRightToLeft = True
    
    ' ========== Title ==========
    wsTemp.Cells(1, 1).value = "����� �����ʝ��� ����"
    wsTemp.Cells(1, 1).Font.bold = True
    wsTemp.Cells(1, 1).Font.size = 16
    wsTemp.Range("A1:F1").Merge
    wsTemp.Range("A1:F1").HorizontalAlignment = xlCenter
    
    ' ========== Date ==========
    wsTemp.Cells(2, 1).value = "����� �����: " & GetCurrentPersianDate()
    wsTemp.Cells(2, 1).Font.size = 10
    wsTemp.Range("A2:F2").Merge
    wsTemp.Range("A2:F2").HorizontalAlignment = xlCenter
    
    ' ========== Filter Info ==========
    Dim filterInfo As String
    filterInfo = GetFilterInfo()
    If filterInfo <> "" Then
        wsTemp.Cells(3, 1).value = "�����: " & filterInfo
        wsTemp.Cells(3, 1).Font.size = 9
        wsTemp.Cells(3, 1).Font.Italic = True
        wsTemp.Range("A3:F3").Merge
        wsTemp.Range("A3:F3").HorizontalAlignment = xlCenter
    End If
    
    ' ========== Headers (Row 5) ==========
    wsTemp.Cells(5, 1).value = "����"
    wsTemp.Cells(5, 2).value = "��� ����"
    wsTemp.Cells(5, 3).value = "��� ����"
    wsTemp.Cells(5, 4).value = "���� (����)"
    wsTemp.Cells(5, 5).value = "����� ������"
    wsTemp.Cells(5, 6).value = "�������"
    
    ' Format headers
    With wsTemp.Range("A5:F5")
        .Font.bold = True
        .Font.size = 11
        .Interior.color = RGB(70, 130, 180)
        .Font.color = RGB(255, 255, 255)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .rowHeight = 25
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    
    ' ========== Data ==========
    totalAmount = 0
    lastRow = 5
    
    For i = 1 To m_lstPayments.ListCount - 1  ' Skip header row
        lastRow = lastRow + 1
        
        wsTemp.Cells(lastRow, 1).value = m_lstPayments.List(i, 0)  ' Row number
        wsTemp.Cells(lastRow, 2).value = m_lstPayments.List(i, 1)  ' Insurance month
        wsTemp.Cells(lastRow, 3).value = m_lstPayments.List(i, 2)  ' Insurance name
        wsTemp.Cells(lastRow, 4).value = m_lstPayments.List(i, 3)  ' Amount
        wsTemp.Cells(lastRow, 5).value = m_lstPayments.List(i, 4)  ' Payment date
        wsTemp.Cells(lastRow, 6).value = m_lstPayments.List(i, 6)  ' Description
        
        ' Add to total
        On Error Resume Next
        totalAmount = totalAmount + CDbl(Replace(m_lstPayments.List(i, 3), ",", ""))
        On Error GoTo ErrorHandler
        
        ' Alternate row colors
        If i Mod 2 = 0 Then
            wsTemp.Range("A" & lastRow & ":F" & lastRow).Interior.color = RGB(240, 248, 255)
        Else
            wsTemp.Range("A" & lastRow & ":F" & lastRow).Interior.color = RGB(255, 255, 255)
        End If
    Next i
    
    ' Format data rows
    With wsTemp.Range("A6:F" & lastRow)
        .Font.size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .rowHeight = 20
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With
    
    ' Left-align description column
    wsTemp.Range("F6:F" & lastRow).HorizontalAlignment = xlRight
    
    ' ========== Total Row ==========
    lastRow = lastRow + 1
    wsTemp.Cells(lastRow, 1).value = "��� ��:"
    wsTemp.Range("A" & lastRow & ":C" & lastRow).Merge
    wsTemp.Cells(lastRow, 4).value = Format(totalAmount, "#,##0")
    wsTemp.Cells(lastRow, 5).value = m_lstPayments.ListCount - 1 & " ����"
    
    With wsTemp.Range("A" & lastRow & ":F" & lastRow)
        .Font.bold = True
        .Font.size = 12
        .Interior.color = RGB(144, 238, 144)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .rowHeight = 28
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    
    ' ========== Column Widths ==========
    wsTemp.Columns("A").ColumnWidth = 8
    wsTemp.Columns("B").ColumnWidth = 12
    wsTemp.Columns("C").ColumnWidth = 35
    wsTemp.Columns("D").ColumnWidth = 15
    wsTemp.Columns("E").ColumnWidth = 14
    wsTemp.Columns("F").ColumnWidth = 30
    
    ' ========== Page Setup ==========
    With wsTemp.PageSetup
        .Orientation = xlLandscape
        .PaperSize = xlPaperA4
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftMargin = Application.InchesToPoints(0.4)
        .RightMargin = Application.InchesToPoints(0.4)
        .TopMargin = Application.InchesToPoints(0.5)
        .BottomMargin = Application.InchesToPoints(0.5)
        .HeaderMargin = Application.InchesToPoints(0.2)
        .FooterMargin = Application.InchesToPoints(0.2)
        .CenterHorizontally = True
        .PrintArea = "A1:F" & lastRow
        
        ' Footer with page number
        .CenterFooter = "���� &P �� &N"
    End With
    
    ' ========== Export to PDF ==========
    Application.StatusBar = "�� ��� ����� ���� PDF..."
    DoEvents
    
    wsTemp.ExportAsFixedFormat _
        Type:=xlTypePDF, _
        fileName:=fileName, _
        Quality:=xlQualityStandard, _
        IncludeDocProperties:=True, _
        IgnorePrintAreas:=False, _
        OpenAfterPublish:=True
    
    ' ========== Cleanup ==========
    Application.DisplayAlerts = False
    wsTemp.Delete
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    Application.StatusBar = False
    
    MsgBox "���� PDF �� ������ ����� ��:" & vbCrLf & vbCrLf & fileName, vbInformation, "����� PDF"
    
    Exit Sub
    
ErrorHandler:
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.StatusBar = False
    
    ' Try to delete temp sheet if it exists
    On Error Resume Next
    If Not wsTemp Is Nothing Then
        wsTemp.Delete
    End If
    On Error GoTo 0
    
    MsgBox "��� �� ����� ���� PDF:" & vbCrLf & Err.description, vbCritical, "���"
End Sub

'=========================================
' GET CURRENT PERSIAN DATE
'=========================================
Private Function GetCurrentPersianDate() As String
    Dim yr As String, mo As String, dy As String
    
    On Error Resume Next
    yr = CStr(ThisWorkbook.Sheets("�������").Range("AC1").value)
    mo = Format(ThisWorkbook.Sheets("�������").Range("AC2").value, "00")
    dy = Format(ThisWorkbook.Sheets("�������").Range("AE1").value, "00")
    On Error GoTo 0
    
    If yr = "" Or mo = "" Or dy = "" Then
        GetCurrentPersianDate = Format(Now, "yyyy/mm/dd")
    Else
        GetCurrentPersianDate = yr & "/" & mo & "/" & dy
    End If
End Function

'=========================================
' GET FILTER INFO FOR REPORT
'=========================================
Private Function GetFilterInfo() As String
    Dim parts() As String
    Dim filterText As String
    
    filterText = ""
    
    On Error Resume Next
    
    ' Insurance type filter
    If m_cboFilterInsurance.listIndex > 0 Then
        filterText = "��� ����: " & m_cboFilterInsurance.value
    End If
    
    ' Insurance month filter
    If m_cboInsYearFrom.value <> "" Or m_cboInsMonthFrom.value <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & "��� ���� ��: " & m_cboInsYearFrom.value & "/" & m_cboInsMonthFrom.value
    End If
    If m_cboInsYearTo.value <> "" Or m_cboInsMonthTo.value <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & "��� ���� ��: " & m_cboInsYearTo.value & "/" & m_cboInsMonthTo.value
    End If
    
    ' Payment date filter
    If m_cboPayYearFrom.value <> "" Or m_cboPayMonthFrom.value <> "" Or m_cboPayDayFrom.value <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & "����� ������ ��: " & m_cboPayYearFrom.value & "/" & m_cboPayMonthFrom.value & "/" & m_cboPayDayFrom.value
    End If
    If m_cboPayYearTo.value <> "" Or m_cboPayMonthTo.value <> "" Or m_cboPayDayTo.value <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & "����� ������ ��: " & m_cboPayYearTo.value & "/" & m_cboPayMonthTo.value & "/" & m_cboPayDayTo.value
    End If
    
    If Trim(m_txtFilterAmount.value) <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & UiText("1605,1576,1604,1594,32,1662,1585,1583,1575,1582,1578") & ": " & m_txtFilterAmount.value
    End If
    If Trim(m_txtFilterNote.value) <> "" Then
        If filterText <> "" Then filterText = filterText & " | "
        filterText = filterText & UiText("1580,1587,1578,1580,1608,32,1583,1585,32,1578,1608,1590,1740,1581,1575,1578") & ": " & m_txtFilterNote.value
    End If
    
    On Error GoTo 0
    
    GetFilterInfo = filterText
End Function







' Appearance-only helpers for payment history.
Private Sub HistoryUI_ApplyLayout()
    Dim historyC As Object, historyNavy As Long, historyInk As Long, historyMuted As Long, historyTeal As Long
    Dim historyBottomY As Single, historyMaxH As Single
    historyNavy = RGB(24, 43, 67): historyInk = RGB(40, 55, 73)
    historyMuted = RGB(98, 115, 134): historyTeal = RGB(0, 123, 117)
    Me.Width = 940: Me.Height = 650
    Me.BackColor = RGB(241, 245, 249)
    historyBottomY = Me.InsideHeight - 50
    For Each historyC In Me.Controls
        historyC.Font.name = "Tahoma": historyC.Font.size = 10
        historyC.ForeColor = historyInk
        If TypeOf historyC Is MSForms.label Then
            historyC.BackStyle = fmBackStyleTransparent
            historyC.TextAlign = fmTextAlignRight
        Else
            historyC.BackColor = vbWhite
            If TypeOf historyC Is MSForms.CommandButton Then
                historyC.Font.bold = True
            Else
                historyC.SpecialEffect = fmSpecialEffectFlat
                historyC.BorderStyle = fmBorderStyleSingle
                historyC.BorderColor = RGB(211, 221, 232)
            End If
        End If
    Next historyC
    HistoryUI_Label "uiHistoryHeader", "", 0, 0, 940, 64, historyNavy
    With Me.Controls("lblTitle")
        .Font.size = 18: .Font.bold = True: .ForeColor = vbWhite
    End With
    HistoryUI_Place Me.Controls("lblTitle"), 200, 15, 702, 32
    Me.Controls("lblFilterBg").Visible = False
    HistoryUI_Label "uiHistoryFilters", "", 18, 80, 900, 190, vbWhite
    HistoryUI_Place Me.Controls("lblFilterTitle"), 812, 94, 90, 20
    HistoryUI_Place m_cboFilterInsurance, 510, 91, 292, 28
    HistoryUI_Place Me.Controls("lblAmountFilter"), 392, 94, 105, 20
    HistoryUI_Place m_txtFilterAmount, 210, 91, 170, 28
    HistoryUI_Place Me.Controls("lblInsMonth"), 797, 136, 105, 22
    HistoryUI_Place Me.Controls("lblInsFrom"), 765, 138, 26, 20
    HistoryUI_Place m_cboInsYearFrom, 680, 133, 76, 27
    HistoryUI_Place m_cboInsMonthFrom, 615, 133, 55, 27
    HistoryUI_Place Me.Controls("lblInsTo"), 575, 138, 28, 20
    HistoryUI_Place m_cboInsYearTo, 490, 133, 76, 27
    HistoryUI_Place m_cboInsMonthTo, 425, 133, 55, 27
    HistoryUI_Place Me.Controls("lblPayDate"), 797, 177, 105, 22
    HistoryUI_Place Me.Controls("lblPayFrom"), 765, 179, 26, 20
    HistoryUI_Place m_cboPayYearFrom, 680, 174, 76, 27
    HistoryUI_Place m_cboPayMonthFrom, 615, 174, 55, 27
    HistoryUI_Place m_cboPayDayFrom, 550, 174, 55, 27
    HistoryUI_Place Me.Controls("lblPayTo"), 510, 179, 28, 20
    HistoryUI_Place m_cboPayYearTo, 425, 174, 76, 27
    HistoryUI_Place m_cboPayMonthTo, 360, 174, 55, 27
    HistoryUI_Place m_cboPayDayTo, 295, 174, 55, 27
    For Each historyC In Me.Controls
        If historyC.name Like "lblInsSlash*" Or historyC.name Like "lblPaySlash*" Then historyC.Visible = False
    Next historyC
    HistoryUI_Place Me.Controls("lblNoteFilter"), 780, 224, 122, 22
    HistoryUI_Place m_txtFilterNote, 425, 218, 345, 30
    HistoryUI_Place m_btnFilter, 32, 218, 170, 32
    m_btnFilter.BackColor = historyTeal: m_btnFilter.ForeColor = vbWhite
    HistoryUI_Place m_btnClearFilter, 214, 218, 170, 32
    HistoryUI_Label "uiHistoryResults", "", 18, 284, 900, historyBottomY - 298, vbWhite
    With m_lstPayments
        .IntegralHeight = False: .Font.size = 10
        .ColumnWidths = "35;68;210;115;100;0;325"
    End With
    With Me.Controls("lblTotal")
        .Font.size = 12: .Font.bold = True: .ForeColor = historyTeal
    End With
    HistoryUI_Place Me.Controls("lblTotal"), 32, historyBottomY - 55, 872, 29
    HistoryUI_Place m_btnClose, 32, historyBottomY, 140, 36
    HistoryUI_Place m_btnDelete, 184, historyBottomY, 180, 36
    m_btnDelete.BackColor = RGB(255, 235, 235)
    m_btnDelete.ForeColor = RGB(166, 40, 40)
    HistoryUI_Place m_btnExportPDF, 724, historyBottomY, 194, 36
    m_btnExportPDF.BackColor = historyNavy: m_btnExportPDF.ForeColor = vbWhite
    ' Assign final list bounds after all font/column changes.
    HistoryUI_Place m_lstPayments, 32, 298, 872, historyBottomY - 366
    m_lstPayments.ZOrder 0
    Call HistoryUI_FitScreen
    Call HistoryUI_FitList
End Sub

Private Sub HistoryUI_FitScreen()
    Dim historyScreenControl As Object
    Dim historyOldInsideH As Single, historyOldInsideW As Single
    Dim historyScaleY As Single, historyScaleX As Single
    Dim historyScreenH As Single, historyScreenW As Single
    historyOldInsideH = Me.InsideHeight: historyOldInsideW = Me.InsideWidth
    historyScreenH = Application.UsableHeight - 12
    historyScreenW = Application.UsableWidth - 12
    If historyScreenH >= 400 And historyScreenH < Me.Height Then Me.Height = historyScreenH
    If historyScreenW >= 600 And historyScreenW < Me.Width Then Me.Width = historyScreenW
    historyScaleY = Me.InsideHeight / historyOldInsideH
    historyScaleX = Me.InsideWidth / historyOldInsideW
    For Each historyScreenControl In Me.Controls
        With historyScreenControl
            .Left = .Left * historyScaleX
            .Top = .Top * historyScaleY
            .Width = .Width * historyScaleX
            .Height = .Height * historyScaleY
        End With
    Next historyScreenControl
    Me.StartUpPosition = 1
End Sub

Private Sub HistoryUI_FitList()
    Dim historyListW As Single
    Dim historyListH As Single
    Dim historyColumnScale As Double
    Dim historyBaseWidths As Variant
    Dim historyWidths As String
    Dim historyColumnWidth As Long
    Dim historyIndex As Long

    If m_lstPayments Is Nothing Then Exit Sub

    historyListW = Me.Controls("uiHistoryResults").Width - 20

    historyListH = Me.Controls("lblTotal").Top _
                 - (Me.Controls("uiHistoryResults").Top + 10) _
                 - 10

    If historyListW <= 20 Or historyListH <= 0 Then Exit Sub

    ' Reserve space for the vertical scrollbar.
    historyColumnScale = (historyListW - 20) / 853#

    historyBaseWidths = Array(35, 68, 210, 115, 100, 0, 325)

    ' Use integer widths, avoiding regional decimal separators.
    For historyIndex = 0 To 6
        historyColumnWidth = CLng( _
            historyBaseWidths(historyIndex) * historyColumnScale)

        If historyIndex > 0 Then
            historyWidths = historyWidths & ";"
        End If

        historyWidths = historyWidths _
                      & Trim$(Str$(historyColumnWidth))
    Next historyIndex

    With m_lstPayments
        .IntegralHeight = False
        .ColumnCount = 7
        .ColumnWidths = historyWidths

        ' Apply final bounds after column formatting.
        .Left = Me.Controls("uiHistoryResults").Left + 10
        .Top = Me.Controls("uiHistoryResults").Top + 10
        .Width = historyListW
        .Height = historyListH
        .ZOrder 0
    End With
End Sub


Private Sub HistoryUI_Place(ByVal historyTarget As Object, ByVal historyX As Single, ByVal historyY As Single, ByVal historyW As Single, ByVal historyH As Single)
    With historyTarget
        .Left = historyX: .Top = historyY: .Width = historyW: .Height = historyH
    End With
End Sub

Private Sub HistoryUI_Label(ByVal historyControlName As String, ByVal historyCaptionText As String, ByVal historyX As Single, ByVal historyY As Single, ByVal historyW As Single, ByVal historyH As Single, ByVal historyFill As Long)
    Dim historyNewLabel As MSForms.label
    Set historyNewLabel = Me.Controls.Add("Forms.Label.1", historyControlName, True)
    With historyNewLabel
        .Caption = historyCaptionText: .BackStyle = fmBackStyleOpaque: .BackColor = historyFill
        .Left = historyX: .Top = historyY: .Width = historyW: .Height = historyH
        .ZOrder 1
    End With
End Sub

Private Function HistoryUI_Text(ByVal historyCodes As String) As String
    Dim historyCode As Variant
    For Each historyCode In Split(historyCodes, ",")
        HistoryUI_Text = HistoryUI_Text & ChrW$(CLng(historyCode))
    Next historyCode
End Function

