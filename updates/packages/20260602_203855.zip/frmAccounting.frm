VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmAccounting 
   Caption         =   "��������"
   ClientHeight    =   10626
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   16142
   OleObjectBlob   =   "frmAccounting.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmAccounting"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 Option Explicit

  '=========================================================
  ' frmAccounting
  ' Accounting module for Persian/Jalali Excel workbook
  '
  ' Requires:
  ' - Sheet "�������"
  ' - Optional existing monthly sheets identified by B1 = yyyy/mm
  ' - modKeyboardLanguage with SetKeyboardEnglish
  ' - frmChoicePicker with 3-option support
  '=========================================================

  Private Const SH_ACCOUNTING As String = "��������"
  Private Const SH_INFO As String = "�������"

  ' �������� sheet layout
  Private Const COL_EXPENSE As String = "D"        ' D:D expense definitions
  Private Const COL_FIXED_FIRST As String = "F"   ' F:M fixed expenses
  Private Const COL_IRR_FIRST As String = "O"     ' O:R irregular expenses
  Private Const COL_TRANSFER_FIRST As String = "T" ' T:W transfers

  Private mInsuranceCache As Object
  Private mInsuranceCacheReady As Boolean





  '=========================================================
  ' FORM INIT / PAGE EVENTS
  '=========================================================
Private MouseWheelHandlers As Collection

Private Sub UserForm_Initialize()
    

      EnsureAccountingSheet
      SetupListBoxes

      mpAccounting.value = 5

      LoadInitialSettings
      LoadExpenses
      LoadFixedExpenses
      LoadIrregularExpenses
      LoadTransfers
      InitTransferPage
      InitCalculationDefaults
      
    Set MouseWheelHandlers = New Collection
    
    AttachMouseWheelToControls Me
      
  End Sub

  Private Sub InitCalculationDefaults()
      Dim wsAcc As Worksheet
      Dim wsInfo As Worksheet
      Dim startDate As String
      Dim currentDate As String

      Set wsAcc = EnsureAccountingSheet()
      Set wsInfo = ThisWorkbook.Worksheets(SH_INFO)

      startDate = NormalizePersianDate(wsAcc.Range("B1").value)

      currentDate = Format(CLng(wsInfo.Range("AC1").value), "0000") & "/" & _
                    Format(CLng(wsInfo.Range("AC2").value), "00") & "/" & _
                    Format(CLng(wsInfo.Range("AE1").value), "00")

      currentDate = NormalizePersianDate(currentDate)

      If currentDate = vbNullString Then
          MsgBox "����� ���� �� �������!AC1, AC2, AE1 ����� ����.", vbExclamation
          Exit Sub
      End If

      txtCurrentDate.value = currentDate
      txtListboxEndDate.value = currentDate

      If startDate <> vbNullString Then
          txtListboxStartDate.value = startDate
      Else
          txtListboxStartDate.value = currentDate
      End If
  End Sub
  Private Sub mpAccounting_Change()
      LoadExpenses

      If mpAccounting.value = 2 Then
          LoadFixedExpenses
      ElseIf mpAccounting.value = 3 Then
          LoadIrregularExpenses
          ElseIf mpAccounting.value = 4 Then
  If NormalizePersianDate(txtToDate.value) = vbNullString Then
  txtToDate.value = GetConfiguredCurrentDate()
  End If
      End If
  End Sub

  Private Sub cmdGoToPage2_Click()
      If Not SaveInitialSettings Then Exit Sub
      LoadExpenses
      mpAccounting.value = 1
  End Sub

  Private Sub cmdGoToPage3_Click()
      LoadExpenses
      LoadFixedExpenses
      mpAccounting.value = 2
  End Sub

  Private Sub cmdGoToPage4_Click()
      LoadExpenses
      LoadIrregularExpenses
      mpAccounting.value = 3
  End Sub


        Private Sub cmdGoToPage5_Click()
      InitTransferPage
      LoadTransfers
      
'      If NormalizePersianDate(txtFromDate.value) = vbNullString Then
'  txtFromDate.value = GetConfiguredCurrentDate()
'  End If
  If NormalizePersianDate(txtToDate.value) = vbNullString Then
  txtToDate.value = GetConfiguredCurrentDate()
  End If
      mpAccounting.value = 4
  End Sub
      


  '=========================================================
  ' KEYBOARD / FORMAT EVENTS
  '=========================================================

  Private Sub txtStartDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtInitialBank_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtInitialCash_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtTransferDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtTransferAmount_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtCurrentDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtListboxStartDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtListboxEndDate_Enter(): SetKeyboardEnglish: End Sub
 Private Sub txtFromDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtToDate_Enter(): SetKeyboardEnglish: End Sub

  Private Sub txtFromDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtFromDate.value = NormalizePersianDate(txtFromDate.value)
  End Sub

  Private Sub txtToDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtToDate.value = NormalizePersianDate(txtToDate.value)
  End Sub
  Private Sub txtInitialBank_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtInitialBank.value = FormatAmountText(txtInitialBank.value)
  End Sub

  Private Sub txtInitialCash_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtInitialCash.value = FormatAmountText(txtInitialCash.value)
  End Sub

  Private Sub txtTransferAmount_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtTransferAmount.value = FormatAmountText(txtTransferAmount.value)
  End Sub

  Private Sub txtStartDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtStartDate.value = NormalizePersianDate(txtStartDate.value)
  End Sub

  Private Sub txtTransferDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtTransferDate.value = NormalizePersianDate(txtTransferDate.value)
  End Sub

  Private Sub txtCurrentDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtCurrentDate.value = NormalizePersianDate(txtCurrentDate.value)
  End Sub

  Private Sub txtListboxStartDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtListboxStartDate.value = NormalizePersianDate(txtListboxStartDate.value)
  End Sub

  Private Sub txtListboxEndDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtListboxEndDate.value = NormalizePersianDate(txtListboxEndDate.value)
  End Sub

  '=========================================================
  ' INITIAL SETTINGS PAGE
  '=========================================================

  Private Function SaveInitialSettings() As Boolean
      Dim ws As Worksheet
      Dim startDate As String

      Set ws = EnsureAccountingSheet()
      startDate = NormalizePersianDate(txtStartDate.value)

      If startDate = vbNullString Then
          MsgBox "����� ���� ����� ����.", vbExclamation
          Exit Function
      End If

      ws.Range("A1").value = "StartDate"
      ws.Range("B1").value = startDate
      ws.Range("A2").value = "InitialBank"
      ws.Range("B2").value = ParseAmount(txtInitialBank.value)
      ws.Range("A3").value = "InitialCash"
      ws.Range("B3").value = ParseAmount(txtInitialCash.value)

      txtStartDate.value = startDate
      txtInitialBank.value = FormatAmountText(ws.Range("B2").value)
      txtInitialCash.value = FormatAmountText(ws.Range("B3").value)

      SaveInitialSettings = True
  End Function

  Private Sub LoadInitialSettings()
      Dim ws As Worksheet
      Set ws = EnsureAccountingSheet()

      txtStartDate.value = ws.Range("B1").value
      If Len(ws.Range("B2").value) > 0 Then txtInitialBank.value = Format(ws.Range("B2").value, "#,##0")
      If Len(ws.Range("B3").value) > 0 Then txtInitialCash.value = Format(ws.Range("B3").value, "#,##0")
  End Sub

  '=========================================================
  ' PAGE 2: EXPENSE DEFINITIONS
  '=========================================================

  Private Sub cmdExpenseAdd_Click()
      Dim ws As Worksheet
      Dim expenseName As String

      Set ws = EnsureAccountingSheet()
      expenseName = AskTextFa("��� ����� �� ���� ����:", "����� �����")
      If expenseName = vbNullString Then Exit Sub

      If ExpenseExists(expenseName) Then
          MsgBox "��� ����� ����� ��� ��� ���.", vbExclamation
          Exit Sub
      End If

      ws.Cells(NextEmptyRow(ws, "D"), "D").value = expenseName
      LoadExpenses
  End Sub

  Private Sub cmdExpenseEdit_Click()
      Dim oldName As String, newName As String
      Dim rowNum As Long

      If lstExpenses.listIndex < 0 Then
          MsgBox "����� � ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      oldName = CStr(lstExpenses.List(lstExpenses.listIndex, 0))

      If ExpenseIsUsed(oldName) Then
          MsgBox "��� ����� ������� ��� � ���� ������ ����.", vbExclamation
          Exit Sub
      End If

      newName = AskTextFa("��� ���� �����:", "������ �����", oldName)
      If newName = vbNullString Or newName = oldName Then Exit Sub

      If ExpenseExists(newName) Then
          MsgBox "��� ��� ����� ���� ����.", vbExclamation
          Exit Sub
      End If

      rowNum = FindExpenseRow(oldName)
      If rowNum > 0 Then
          EnsureAccountingSheet().Cells(rowNum, "D").value = newName
      End If

      LoadExpenses
  End Sub

  Private Sub cmdExpenseDelete_Click()
      Dim expenseName As String
      Dim rowNum As Long

      If lstExpenses.listIndex < 0 Then
          MsgBox "����� � ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      expenseName = CStr(lstExpenses.List(lstExpenses.listIndex, 0))

      If ExpenseIsUsed(expenseName) Then
          MsgBox "��� ����� ������� ��� � ���� ��� ����.", vbExclamation
          Exit Sub
      End If

      If MsgBox("��� ��� ��Ͽ", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

      rowNum = FindExpenseRow(expenseName)
If rowNum > 0 Then
      EnsureAccountingSheet().Range("D" & rowNum).ClearContents
  End If

      LoadExpenses
  End Sub

  Private Sub LoadExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim expenseName As String

      Set ws = EnsureAccountingSheet()

      lstExpenses.Clear
      lstExpensePick1.Clear
      lstExpensePick2.Clear

      lastRow = ws.Cells(ws.rows.Count, "D").End(xlUp).Row

      For r = 2 To lastRow
          expenseName = Trim(CStr(ws.Cells(r, "D").value))
          If expenseName <> vbNullString Then
              lstExpenses.AddItem expenseName
              lstExpensePick1.AddItem expenseName
              lstExpensePick2.AddItem expenseName
          End If
      Next r
  End Sub

  '=========================================================
  ' PAGE 3: FIXED EXPENSES
  '=========================================================

  Private Sub cmdFixedAdd_Click()
      Dim expenseName As String

      If lstExpensePick1.listIndex < 0 Then
          MsgBox "����� � ��� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      expenseName = CStr(lstExpensePick1.List(lstExpensePick1.listIndex, 0))
      SaveFixedExpense 0, expenseName
  End Sub

  Private Sub cmdFixedEdit_Click()
      If lstFixedExpenses.listIndex < 0 Then
          MsgBox "����� � ���� ����� ���� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      SaveFixedExpense CLng(lstFixedExpenses.List(lstFixedExpenses.listIndex, 0)), _
                       CStr(lstFixedExpenses.List(lstFixedExpenses.listIndex, 1))
  End Sub

  Private Sub cmdFixedDelete_Click()
      Dim rowNum As Long

      If lstFixedExpenses.listIndex < 0 Then
          MsgBox "����� � ���� ����� ���� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      If MsgBox("��� ��� ��Ͽ", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

      rowNum = FixedDataRowByNo(CLng(lstFixedExpenses.List(lstFixedExpenses.listIndex, 0)))
 If rowNum > 0 Then
      EnsureAccountingSheet().Range("F" & rowNum & ":M" & rowNum).ClearContents
      RenumberTable "F"
  End If
  LoadFixedExpenses
  End Sub

  Private Sub SaveFixedExpense(ByVal fixedNo As Long, ByVal expenseName As String)
      Dim ws As Worksheet
      Dim rowNum As Long
      Dim amount As Double
      Dim startDate As String, endDate As String
      Dim frequency As String, source As String
      Dim frequencyCountText As String
      Dim frequencyCount As Long

      Set ws = EnsureAccountingSheet()

      If fixedNo > 0 And FixedExpenseHasStarted(fixedNo) Then
          rowNum = FixedDataRowByNo(fixedNo)
          endDate = NormalizePersianDate(AskTextEn("��� ����� ����� ����  ������ ���:", "������ ����� ����", ws.Cells(rowNum, "L").value))

          If endDate = vbNullString Then
              MsgBox "����� ����� ����� ����.", vbExclamation
              Exit Sub
          End If

          ws.Cells(rowNum, "L").value = endDate
          LoadFixedExpenses
          Exit Sub
      End If

      amount = AskAmount("����� ����", "���� �����:")
      If amount <= 0 Then Exit Sub

      startDate = NormalizePersianDate(AskTextEn("����� ���� ��ѐ����:", "����� ����"))
      If startDate = vbNullString Then
          MsgBox "����� ���� ����� ����.", vbExclamation
          Exit Sub
      End If

      frequency = PickChoice3("����� �����", "����� �� ������ ����:", "������", "������", "������")
      If frequency = vbNullString Then Exit Sub

      frequencyCountText = AskTextEn("���� ��� ���� ʘ��� ��Ͽ ���� ����  �� ���� ����.", "����� ����", "")
      If frequencyCountText = vbNullString Then
          frequencyCount = 0
          endDate = vbNullString
      Else
          frequencyCount = CLng(val(ToEnglishDigits(frequencyCountText)))
          If frequencyCount <= 0 Then frequencyCount = 0
          endDate = CalculateFixedEndDate(startDate, frequency, frequencyCount)
      End If

      source = PickChoice2("���� ������", "���� ����� �� ������ ����:", "���", "���")
      If source = vbNullString Then Exit Sub

      If fixedNo = 0 Then
          rowNum = NextEmptyRow(ws, "F")
          ws.Cells(rowNum, "F").value = NextTableNo(ws, "F")
      Else
          rowNum = FixedDataRowByNo(fixedNo)
          If rowNum = 0 Then Exit Sub
      End If

      ws.Cells(rowNum, "G").value = expenseName
      ws.Cells(rowNum, "H").value = amount
      ws.Cells(rowNum, "I").value = startDate
      ws.Cells(rowNum, "J").value = frequency
      ws.Cells(rowNum, "K").value = frequencyCount
      ws.Cells(rowNum, "L").value = endDate
      ws.Cells(rowNum, "M").value = source

      LoadFixedExpenses
  End Sub

  Private Sub LoadFixedExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long

      Set ws = EnsureAccountingSheet()
      lstFixedExpenses.Clear

      lastRow = ws.Cells(ws.rows.Count, "F").End(xlUp).Row

      For r = 2 To lastRow
          If Len(ws.Cells(r, "F").value) > 0 Then
              lstFixedExpenses.AddItem ws.Cells(r, "F").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 1) = ws.Cells(r, "G").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 2) = Format(ws.Cells(r, "H").value, "#,##0")
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 3) = ws.Cells(r, "I").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 4) = ws.Cells(r, "J").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 5) = ws.Cells(r, "K").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 6) = ws.Cells(r, "L").value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 7) = ws.Cells(r, "M").value
          End If
      Next r
  End Sub

  '=========================================================
  ' PAGE 4: IRREGULAR EXPENSES
  '=========================================================

  Private Sub cmdIrregularAdd_Click()
      If lstExpensePick2.listIndex < 0 Then
          MsgBox "����� � ��� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      SaveIrregularExpense 0, CStr(lstExpensePick2.List(lstExpensePick2.listIndex, 0))
  End Sub

  Private Sub cmdIrregularEdit_Click()
      If lstIrregularExpenses.listIndex < 0 Then
          MsgBox "����� � ���� ����� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      SaveIrregularExpense CLng(lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 0)), _
                           CStr(lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 1))
  End Sub

  Private Sub cmdIrregularDelete_Click()
      Dim rowNum As Long

      If lstIrregularExpenses.listIndex < 0 Then
          MsgBox "����� � ���� ����� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      If MsgBox("��� ��� ��Ͽ", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

      rowNum = IrregularDataRowByNo(CLng(lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 0)))
If rowNum > 0 Then
      EnsureAccountingSheet().Range("O" & rowNum & ":S" & rowNum).ClearContents
      RenumberTable "O"
  End If
  LoadIrregularExpenses
  End Sub

 Private Sub SaveIrregularExpense(ByVal irregularNo As Long, ByVal expenseName As String)
      Dim ws As Worksheet
      Dim rowNum As Long
      Dim amount As Double
      Dim expenseDate As String
      Dim source As String

      Set ws = EnsureAccountingSheet()

      If irregularNo > 0 And IrregularExpenseIsUsed(irregularNo) Then
          MsgBox "��� ����� ������� ��� � ���� ������ ����. ���� ����ѡ  � ����� ���� ��� ����.", vbExclamation
          Exit Sub
      End If

      amount = AskAmount("����� �����", "���� �����:")
      If amount <= 0 Then Exit Sub

expenseDate = NormalizePersianDate(AskTextEn("����� �����:", "����� ����� ", GetConfiguredCurrentDate()))
If expenseDate = vbNullString Then
          MsgBox "����� ����� ����.", vbExclamation
          Exit Sub
      End If

      source = PickChoice2("���� ������", "���� ����� �� ������ ����:", "���", "���")
      If source = vbNullString Then Exit Sub

      If irregularNo = 0 Then
          rowNum = NextEmptyRow(ws, "O")
          ws.Cells(rowNum, "O").value = NextTableNo(ws, "O")
      Else
          rowNum = IrregularDataRowByNo(irregularNo)
          If rowNum = 0 Then Exit Sub
      End If

      ws.Cells(rowNum, "P").value = expenseName
      ws.Cells(rowNum, "Q").value = amount
      ws.Cells(rowNum, "R").value = expenseDate
      ws.Cells(rowNum, "S").value = source

      LoadIrregularExpenses
  End Sub
Private Sub LoadIrregularExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim newRow As Long

      Set ws = EnsureAccountingSheet()

      With lstIrregularExpenses
          .RowSource = vbNullString
          .Clear
          .ColumnCount = 5
          .ColumnWidths = "70 pt;120 pt;90 pt;80 pt;100 pt"
      End With

      lastRow = ws.Cells(ws.rows.Count, "O").End(xlUp).Row

      For r = 2 To lastRow
          If Len(ws.Cells(r, "O").value) > 0 Then
              lstIrregularExpenses.AddItem ws.Cells(r, "O").value
              newRow = lstIrregularExpenses.ListCount - 1

              lstIrregularExpenses.List(newRow, 1) = ws.Cells(r, "P").value
              lstIrregularExpenses.List(newRow, 2) = Format(ToNumber(ws.Cells(r, "Q").value), "#,##0")
              lstIrregularExpenses.List(newRow, 3) = ws.Cells(r, "R").value
              lstIrregularExpenses.List(newRow, 4) = ws.Cells(r, "S").value
          End If
      Next r
  End Sub

  '=========================================================
  ' PAGE 5: TRANSFERS
  '=========================================================

  Private Sub InitTransferPage()
      cboTransferType.Clear
      cboTransferType.AddItem "�����"
      cboTransferType.AddItem "������"
  End Sub

  Private Sub cmdTransferSubmit_Click()
      Dim ws As Worksheet
      Dim rowNum As Long
      Dim transferType As String
      Dim transferDate As String
      Dim amount As Double

      Set ws = EnsureAccountingSheet()

      If cboTransferType.listIndex < 0 Then
          MsgBox "��� ������ �� ������ ����.", vbExclamation
          Exit Sub
      End If

      transferType = CStr(cboTransferType.value)
      transferDate = NormalizePersianDate(txtTransferDate.value)
      amount = ParseAmount(txtTransferAmount.value)

      If transferDate = vbNullString Then
          MsgBox "����� ����� ����.", vbExclamation
          Exit Sub
      End If

      If amount <= 0 Then
          MsgBox "���� ����� ����.", vbExclamation
          Exit Sub
      End If

      rowNum = NextEmptyRow(ws, "T")
      ws.Cells(rowNum, "T").value = NextTableNo(ws, "T")
      ws.Cells(rowNum, "U").value = transferType
      ws.Cells(rowNum, "V").value = transferDate
      ws.Cells(rowNum, "W").value = amount

      txtTransferDate.value = vbNullString
      txtTransferAmount.value = vbNullString
      cboTransferType.listIndex = -1

      LoadTransfers
      MsgBox "��� ��.", vbInformation
  End Sub
Private Sub cmdCal_Click()
      Dim fromDate As String
      Dim toDate As String
      Dim cashTotal As Double
      Dim cardTotal As Double

      fromDate = NormalizePersianDate(txtFromDate.value)
      toDate = NormalizePersianDate(txtToDate.value)

      If fromDate = vbNullString Or toDate = vbNullString Then
          MsgBox "���� ����� ����� ����.", vbExclamation
          Exit Sub
      End If

      If ComparePersianDates(toDate, fromDate) < 0 Then
          MsgBox "����� ����� �������� ��� �� ����� ���� ����.", vbExclamation
          Exit Sub
      End If

      SumSalesOnly fromDate, toDate, cashTotal, cardTotal

      txtSumOfCash.value = Format(cashTotal, "#,##0")
      txtSumOfCard.value = Format(cardTotal, "#,##0")
  End Sub
Private Sub LoadTransfers()
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long

      Set ws = EnsureAccountingSheet()
      lstTransfers.Clear

      lastRow = ws.Cells(ws.rows.Count, "T").End(xlUp).Row

      For r = 2 To lastRow
          If Len(ws.Cells(r, "T").value) > 0 Then
              lstTransfers.AddItem ws.Cells(r, "T").value
              lstTransfers.List(lstTransfers.ListCount - 1, 1) = ws.Cells(r, "U").value
              lstTransfers.List(lstTransfers.ListCount - 1, 2) = ws.Cells(r, "V").value
              lstTransfers.List(lstTransfers.ListCount - 1, 3) = Format(ToNumber(ws.Cells(r, "W").value), "#,##0")
          End If
      Next r
  End Sub

  '=========================================================
  ' PAGE 6: CALCULATION
  '=========================================================

  Private Sub cmdCalculateNow_Click()
  ResetInsuranceCache
      Dim ws As Worksheet
      Dim startDate As String, endDate As String
      Dim cashBalance As Double, bankBalance As Double

      Set ws = EnsureAccountingSheet()

      startDate = NormalizePersianDate(ws.Range("B1").value)
      endDate = NormalizePersianDate(txtCurrentDate.value)

      If startDate = vbNullString Or endDate = vbNullString Then
          MsgBox "����� ���� �� ����� ����� ����.", vbExclamation
          Exit Sub
      End If

      cashBalance = CDbl(val(ws.Range("B3").value))
      bankBalance = CDbl(val(ws.Range("B2").value))

      CalculateBalances startDate, endDate, cashBalance, bankBalance

      txtCurrentCash.value = Format(cashBalance, "#,##0")
      txtCurrentBank.value = Format(bankBalance, "#,##0")
      txtGrandTotal.value = Format(cashBalance + bankBalance, "#,##0")
  End Sub

  Private Sub cmdDetails_Click()
ResetInsuranceCache
Dim startDate As String, endDate As String

      startDate = NormalizePersianDate(txtListboxStartDate.value)
      endDate = NormalizePersianDate(txtListboxEndDate.value)

      If startDate = vbNullString Or endDate = vbNullString Then
          MsgBox "���� ����� ����� ����.", vbExclamation
          Exit Sub
      End If

      PopulateCalculationList startDate, endDate
  End Sub

  Private Sub cmdDownload_Click()
      ExportCalculationList
  End Sub

  Private Sub CalculateBalances(ByVal startDate As String, ByVal endDate As String, _
                                ByRef cashBalance As Double, ByRef bankBalance As Double)

      Dim currentDate As String
      Dim dayData As Variant

      currentDate = startDate

      Do While ComparePersianDates(currentDate, endDate) <= 0
          dayData = GetDailyAccountingData(currentDate)


                      
 cashBalance = cashBalance _
              + CDbl(dayData(0)) _
              + CDbl(dayData(9)) _
              - CDbl(dayData(8)) _
              - CDbl(dayData(10)) _
              - CDbl(dayData(11))

  bankBalance = bankBalance _
              + CDbl(dayData(1)) _
              - CDbl(dayData(2)) _
              - CDbl(dayData(3)) _
              - CDbl(dayData(6)) _
              - CDbl(dayData(12)) _
              + CDbl(dayData(4)) _
              + CDbl(dayData(8)) _
              - CDbl(dayData(9))

          currentDate = AddPersianDays(currentDate, 1)
      Loop
  End Sub

 Private Sub PopulateCalculationList(ByVal startDate As String, ByVal endDate As String)
      Dim ws As Worksheet
      Dim currentDate As String
      Dim calcStartDate As String
      Dim cashBalance As Double, bankBalance As Double
      Dim startCash As Double, startBank As Double
      Dim finalCash As Double, finalBank As Double
      Dim dayData As Variant
      Dim rowCount As Long, rowIndex As Long
      Dim outputTopLeft As Range
      Dim outputData() As Variant
      Dim outputRange As Range

      Set ws = EnsureAccountingSheet()

      calcStartDate = NormalizePersianDate(ws.Range("B1").value)

      If calcStartDate = vbNullString Then
          MsgBox "����� ����� ���� ������ �� �� ���� ������� ����� ��� ����.", vbExclamation
          Exit Sub
      End If

      If ComparePersianDates(endDate, startDate) < 0 Then
          MsgBox "����� ����� �������� ��� �� ����� ���� ����.", vbExclamation
          Exit Sub
      End If

      cashBalance = CDbl(val(ws.Range("B3").value))
      bankBalance = CDbl(val(ws.Range("B2").value))

      currentDate = calcStartDate

      Do While ComparePersianDates(currentDate, AddPersianDays(startDate, -1)) <= 0
          dayData = GetDailyAccountingData(currentDate)

 cashBalance = cashBalance _
              + CDbl(dayData(0)) _
              + CDbl(dayData(9)) _
              - CDbl(dayData(8)) _
              - CDbl(dayData(10)) _
              - CDbl(dayData(11))

  bankBalance = bankBalance _
              + CDbl(dayData(1)) _
              - CDbl(dayData(2)) _
              - CDbl(dayData(3)) _
              - CDbl(dayData(6)) _
              - CDbl(dayData(12)) _
              + CDbl(dayData(4)) _
              + CDbl(dayData(8)) _
              - CDbl(dayData(9))


          currentDate = AddPersianDays(currentDate, 1)
      Loop

      rowCount = PersianDateToSerial(endDate) - PersianDateToSerial(startDate) + 1
      If rowCount <= 0 Then Exit Sub

  ReDim outputData(1 To rowCount, 1 To 15)
      currentDate = startDate
      rowIndex = 1

      Do While ComparePersianDates(currentDate, endDate) <= 0
          dayData = GetDailyAccountingData(currentDate)

          startCash = cashBalance
          startBank = bankBalance

           finalCash = startCash _
            + CDbl(dayData(0)) _
            + CDbl(dayData(9)) _
            - CDbl(dayData(8)) _
            - CDbl(dayData(10)) _
            - CDbl(dayData(11))
            
          finalBank = startBank _
            + CDbl(dayData(1)) _
            - CDbl(dayData(2)) _
            - CDbl(dayData(3)) _
            - CDbl(dayData(6)) _
            - CDbl(dayData(12)) _
            + CDbl(dayData(4)) _
            + CDbl(dayData(8)) _
            - CDbl(dayData(9))
            
                    outputData(rowIndex, 1) = currentDate
                    outputData(rowIndex, 2) = startCash
                    outputData(rowIndex, 3) = startBank
                    outputData(rowIndex, 4) = dayData(0)
                    outputData(rowIndex, 5) = dayData(1)
                    outputData(rowIndex, 6) = dayData(2)
                    outputData(rowIndex, 7) = dayData(3)
                    outputData(rowIndex, 8) = dayData(5)
                    outputData(rowIndex, 9) = dayData(7)
                    outputData(rowIndex, 10) = dayData(4)
                    outputData(rowIndex, 11) = dayData(8)
                    outputData(rowIndex, 12) = dayData(9)
                    outputData(rowIndex, 13) = finalCash
                    outputData(rowIndex, 14) = finalBank
                    outputData(rowIndex, 15) = finalCash + finalBank

          cashBalance = finalCash
          bankBalance = finalBank

          rowIndex = rowIndex + 1
          currentDate = AddPersianDays(currentDate, 1)
      Loop

      lstCalculate.RowSource = vbNullString

      Set outputTopLeft = ws.Range("Z1")
  ws.Range("Z:AN").ClearContents
  
ws.Range("Z1:AN1").value = Array( _
      "�����", _
      "��� ��� ���", _
      "��� ��� ���", _
      "���� ���", _
      "���� ����", _
      "��� ��", _
      "������ ������", _
      "����� ����", _
      "����� �����", _
      "������ ����", _
      "����� �� ���", _
      "������ �� ���", _
      "��� ����� ���", _
      "��� ����� ���", _
      "��� �� ����� ���")

Set outputRange = ws.Range("Z2").Resize(rowCount, 15)
  outputRange.value = outputData
  outputRange.NumberFormat = "#,##0"
  ws.Range("Z2:Z" & rowCount + 1).NumberFormat = "@"
  ws.Columns("Z:AN").AutoFit

lstCalculate.ColumnCount = 15
  lstCalculate.ColumnHeads = True
  lstCalculate.RowSource = "'" & ws.Name & "'!" & outputRange.Address
  End Sub
   ' 0 cash sale
  ' 1 card sale
  ' 2 cheque sum
  ' 3 direct pay sum
  ' 4 insurance received to bank
  ' 5 fixed total display
  ' 6 fixed bank deduction
  ' 7 irregular total display
  ' 8 deposit cash to bank
  ' 9 withdraw bank to cash
  ' 10 fixed cash deduction
  ' 11 irregular cash deduction
  ' 12 irregular bank deduction
  Private Function GetDailyAccountingData(ByVal pDate As String) As Variant
      Dim result(0 To 12) As Double
      Dim Y As Long, m As Long, d As Long

      SplitPersianDate pDate, Y, m, d

      ReadMonthlyDailyValues Y, m, d, result
      AddFixedExpensesForDate pDate, result
      AddIrregularExpensesForDate pDate, result
      AddTransfersForDate pDate, result

      GetDailyAccountingData = result
  End Function

  Private Sub ReadMonthlyDailyValues(ByVal pYear As Long, ByVal pMonth As Long, ByVal pDay As Long, ByRef result() As Double)
      Dim ws As Worksheet
      Dim rowsPerDay As Long, blockRows As Long, lowerOffset As Long
      Dim chequeSumCol As Long, factorSumCol As Long, directPaySumCol As Long
      Dim dayStartRow As Long, r As Long
      Dim yearMonth As String
      Dim clearingAmount As Double

      yearMonth = CStr(pYear) & "/" & Format(pMonth, "00")
      Set ws = FindMonthSheet(yearMonth)

      If ws Is Nothing Then Exit Sub

      GetLayout rowsPerDay, blockRows, lowerOffset, chequeSumCol, factorSumCol, directPaySumCol
      dayStartRow = 2 + (pDay - 1) * blockRows

      If CLng(val(ws.Cells(dayStartRow, "A").value)) <> pDay Then Exit Sub

      For r = dayStartRow To dayStartRow + rowsPerDay - 1
          result(0) = result(0) + ToNumber(ws.Cells(r, "C").value)
          result(1) = result(1) + ToNumber(ws.Cells(r, "D").value)
      Next r

      ' Prefer real bank-clearing amount from �������!Y. If missing, fallback to monthly cheque sum.
      clearingAmount = GetBankClearingAmount(CStr(pYear) & "/" & Format(pMonth, "00") & "/" & Format(pDay, "00"))
      If clearingAmount > 0 Then
          result(2) = clearingAmount
      Else
          result(2) = ToNumber(ws.Cells(dayStartRow, chequeSumCol).MergeArea.Cells(1, 1).value)
      End If

  result(3) = GetDirectPayTotalFromSlots(ws, dayStartRow, lowerOffset)
      ' Workbook structure says column L lower half is insurance/deposit amount.
result(4) = GetInsurancePaymentsReceivedOnDate(CStr(pYear) & "/" & Format(pMonth, "00") & "/" & Format(pDay, "00"))
End Sub

  Private Sub AddFixedExpensesForDate(ByVal pDate As String, ByRef result() As Double)
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim amount As Double, source As String

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, "F").End(xlUp).Row

      For r = 2 To lastRow
          If Len(ws.Cells(r, "F").value) > 0 Then
              If FixedExpenseOccursOnDate(pDate, ws.Cells(r, "I").value, ws.Cells(r, "L").value, _
                                          ws.Cells(r, "J").value, CLng(val(ws.Cells(r, "K").value))) Then

                  amount = ToNumber(ws.Cells(r, "H").value)
                  source = CStr(ws.Cells(r, "M").value)

                  result(5) = result(5) + amount

                  If source = "���" Then
                      result(10) = result(10) + amount
                  Else
                      result(6) = result(6) + amount
                  End If
              End If
          End If
      Next r
  End Sub

  Private Sub AddIrregularExpensesForDate(ByVal pDate As String, ByRef result() As Double)
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim amount As Double, source As String

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, "O").End(xlUp).Row

      For r = 2 To lastRow
          If NormalizePersianDate(ws.Cells(r, "R").value) = pDate Then
              amount = ToNumber(ws.Cells(r, "Q").value)
              source = CStr(ws.Cells(r, "S").value)

              result(7) = result(7) + amount

              If source = "���" Then
                  result(11) = result(11) + amount
              Else
                  result(12) = result(12) + amount
              End If
          End If
      Next r
  End Sub

  Private Sub AddTransfersForDate(ByVal pDate As String, ByRef result() As Double)
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim amount As Double
      Dim transferType As String

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, "T").End(xlUp).Row

      For r = 2 To lastRow
          If NormalizePersianDate(ws.Cells(r, "V").value) = pDate Then
              transferType = CStr(ws.Cells(r, "U").value)
              amount = ToNumber(ws.Cells(r, "W").value)

              If transferType = "�����" Then
                  result(8) = result(8) + amount
              ElseIf transferType = "������" Then
                  result(9) = result(9) + amount
              End If
          End If
      Next r
  End Sub

  '=========================================================
  ' EXPORT
  '=========================================================

   Private Sub ExportCalculationList()
      Dim wb As Workbook
      Dim ws As Worksheet
      Dim r As Long, c As Long
      Dim exportType As String
      Dim filePath As String
      Dim cellValue As Variant

      If lstCalculate.ListCount = 0 Then
          MsgBox "����� ������ �� ������ ����.", vbExclamation
          Exit Sub
      End If

      exportType = PickChoice2("�����", "��� ����� �� ������ ����:", "Excel", "PDF")
      If exportType = vbNullString Then Exit Sub

      Set wb = Workbooks.Add
      Set ws = wb.Worksheets(1)
      ws.Name = "Accounting"

      ws.Range("A1:O1").value = Array( _
          "�����", _
          "��� ��� ���", _
          "��� ��� ���", _
          "���� ���", _
          "���� ����", _
          "��� ��", _
          "������ ������", _
          "����� ����", _
          "����� �����", _
          "������ ����", _
          "����� �� ���", _
          "������ �� ���", _
          "��� ����� ���", _
          "��� ����� ���", _
          "��� �� ����� ���")

      For r = 0 To lstCalculate.ListCount - 1
          For c = 0 To 14
              cellValue = lstCalculate.List(r, c)

              If c = 0 Then
                  ws.Cells(r + 2, c + 1).value = CStr(cellValue)
              Else
                  ws.Cells(r + 2, c + 1).value = ToNumber(cellValue)
              End If
          Next c
      Next r

      ws.Range("A:A").NumberFormat = "@"
      ws.Range("B:O").NumberFormat = "#,##0"
      ws.rows(1).Font.Bold = True
      ws.Columns("A:O").AutoFit
      ws.DisplayRightToLeft = True

      filePath = Environ$("USERPROFILE") & "\Desktop\Accounting_" & Format(Now, "yyyymmdd_hhnnss")

      If exportType = "PDF" Then
          ws.ExportAsFixedFormat xlTypePDF, filePath & ".pdf"
          wb.Close SaveChanges:=False
          MsgBox "PDF ����� ��.", vbInformation
      Else
          wb.SaveAs filePath & ".xlsx", xlOpenXMLWorkbook
          wb.Close SaveChanges:=False
          MsgBox "���� Excel ����� ��.", vbInformation
      End If
  End Sub

  '=========================================================
  ' SHEET / LISTBOX SETUP
  '=========================================================

  Private Function EnsureAccountingSheet() As Worksheet
      On Error Resume Next
      Set EnsureAccountingSheet = ThisWorkbook.Worksheets(SH_ACCOUNTING)
      On Error GoTo 0

      If EnsureAccountingSheet Is Nothing Then
          Set EnsureAccountingSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
          EnsureAccountingSheet.Name = SH_ACCOUNTING
          SetupAccountingHeaders EnsureAccountingSheet
      ElseIf EnsureAccountingSheet.Range("D1").value = vbNullString Then
          SetupAccountingHeaders EnsureAccountingSheet
      End If
  End Function

  Private Sub SetupAccountingHeaders(ByVal ws As Worksheet)
      ws.Range("A1").value = "StartDate"
      ws.Range("A2").value = "InitialBank"
      ws.Range("A3").value = "InitialCash"

      ws.Range("D1").value = "ExpenseName"

      ws.Range("F1:M1").value = Array("No", "ExpenseName", "Amount", "StartDate", "Frequency", "FrequencyCount", "EndDate", "Source")
      ws.Range("O1:S1").value = Array("No", "ExpenseName", "Amount", "Date", "Source")
      ws.Range("T1:W1").value = Array("No", "Type", "Date", "Amount")

      ws.Columns("A:W").AutoFit
  End Sub

Private Sub SetupListBoxes()
      lstExpenses.ColumnCount = 1

      lstExpensePick1.ColumnCount = 1
      lstExpensePick2.ColumnCount = 1

      lstFixedExpenses.ColumnCount = 8
      lstFixedExpenses.ColumnWidths = "40 pt;100 pt;90 pt;80 pt;70 pt;70 pt;80 pt;60 pt"

  With lstIrregularExpenses
      .ColumnCount = 5
      .ColumnWidths = "70 pt;120 pt;90 pt;80 pt;100 pt"
  End With

      With lstCalculate
          .ColumnCount = 15
          .ColumnHeads = True
          .ColumnWidths = "80 pt;85 pt;85 pt;80 pt;80 pt;80 pt;90 pt;90 pt;90 pt;100 pt;90 pt;90 pt;90 pt;90 pt;95 pt"
          .RowSource = vbNullString
      End With
       With lstTransfers
      .ColumnCount = 4
      .ColumnWidths = "40 pt;80 pt;90 pt;100 pt"
  End With
      
  End Sub

  '=========================================================
  ' ACCOUNTING LOOKUPS
  '=========================================================

  Private Function FindMonthSheet(ByVal yearMonth As String) As Worksheet
      Dim ws As Worksheet

      For Each ws In ThisWorkbook.Worksheets
          If CStr(ws.Range("B1").value) = yearMonth Then
              Set FindMonthSheet = ws
              Exit Function
          End If
      Next ws
  End Function

  Private Sub GetLayout(ByRef rowsPerDay As Long, ByRef blockRows As Long, ByRef lowerOffset As Long, _
                        ByRef dailyChequeSumCol As Long, ByRef dailyFactorSumCol As Long, ByRef dailyDirectPaySumCol As Long)

      Dim totalCenters As Long, actualCenters As Long
      Dim numCheques As Long, numFactors As Long, numDirectPays As Long
      Dim firstFactorCol As Long, lastFactorCol As Long, firstDirectPayCol As Long

      totalCenters = CLng(Range("cfg_TotalCenters").value)
      actualCenters = CLng(Range("cfg_ActualUserCenters").value)
      numCheques = CLng(Range("cfg_NumCheques").value)
      numFactors = CLng(Range("cfg_NumFactors").value)
      numDirectPays = CLng(Range("cfg_NumDirectPays").value)

      If actualCenters = 1 Then
          rowsPerDay = 2
      Else
          rowsPerDay = totalCenters
      End If

      blockRows = rowsPerDay + 1
      lowerOffset = rowsPerDay \ 2

      dailyChequeSumCol = 14 + (numCheques * 2)

      firstFactorCol = 14 + (numCheques * 2) + 1
      lastFactorCol = firstFactorCol + (numFactors * 2) - 2
      dailyFactorSumCol = firstFactorCol + (numFactors * 2)

      firstDirectPayCol = lastFactorCol + 3
      dailyDirectPaySumCol = firstDirectPayCol + numDirectPays
  End Sub

  Private Function GetBankClearingAmount(ByVal pDate As String) As Double
      Dim ws As Worksheet
      Dim foundCell As Range

      Set ws = ThisWorkbook.Worksheets(SH_INFO)

      Set foundCell = ws.Columns("U").Find(What:=pDate, LookAt:=xlWhole, LookIn:=xlValues)
      If Not foundCell Is Nothing Then
          GetBankClearingAmount = ToNumber(ws.Cells(foundCell.Row, "Y").value)
      End If
  End Function

  '=========================================================
  ' EXPENSE HELPERS
  '=========================================================

  Private Function ExpenseExists(ByVal expenseName As String) As Boolean
      ExpenseExists = (FindExpenseRow(expenseName) > 0)
  End Function

  Private Function FindExpenseRow(ByVal expenseName As String) As Long
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, "D").End(xlUp).Row

      For r = 2 To lastRow
          If Trim(CStr(ws.Cells(r, "D").value)) = expenseName Then
              FindExpenseRow = r
              Exit Function
          End If
      Next r
  End Function

  Private Function ExpenseIsUsed(ByVal expenseName As String) As Boolean
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long

      Set ws = EnsureAccountingSheet()

      lastRow = ws.Cells(ws.rows.Count, "G").End(xlUp).Row
      For r = 2 To lastRow
          If CStr(ws.Cells(r, "G").value) = expenseName Then
              ExpenseIsUsed = True
              Exit Function
          End If
      Next r

      lastRow = ws.Cells(ws.rows.Count, "P").End(xlUp).Row
      For r = 2 To lastRow
          If CStr(ws.Cells(r, "P").value) = expenseName Then
              ExpenseIsUsed = True
              Exit Function
          End If
      Next r
  End Function

  Private Function FixedDataRowByNo(ByVal fixedNo As Long) As Long
      FixedDataRowByNo = DataRowByNo("F", fixedNo)
  End Function

  Private Function IrregularDataRowByNo(ByVal irregularNo As Long) As Long
      IrregularDataRowByNo = DataRowByNo("O", irregularNo)
  End Function

  Private Function DataRowByNo(ByVal noColumn As String, ByVal itemNo As Long) As Long
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, noColumn).End(xlUp).Row

      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, noColumn).value)) = itemNo Then
              DataRowByNo = r
              Exit Function
          End If
      Next r
  End Function

  Private Function FixedExpenseOccursOnDate(ByVal pDate As String, ByVal startDate As String, ByVal endDate As String, _
                                            ByVal frequency As String, ByVal frequencyCount As Long) As Boolean

      Dim y1 As Long, m1 As Long, d1 As Long
      Dim y2 As Long, m2 As Long, d2 As Long
      Dim diffMonths As Long
      Dim diffYears As Long

      startDate = NormalizePersianDate(startDate)
      endDate = NormalizePersianDate(endDate)

      If startDate = vbNullString Then Exit Function
      If ComparePersianDates(pDate, startDate) < 0 Then Exit Function
      If endDate <> vbNullString And ComparePersianDates(pDate, endDate) > 0 Then Exit Function

      If frequency = "������" Then
          FixedExpenseOccursOnDate = True

      ElseIf frequency = "������" Then
          SplitPersianDate startDate, y1, m1, d1
          SplitPersianDate pDate, y2, m2, d2

          diffMonths = ((y2 - y1) * 12) + (m2 - m1)
          FixedExpenseOccursOnDate = (diffMonths >= 0 And d1 = d2)

      ElseIf frequency = "������" Then
          SplitPersianDate startDate, y1, m1, d1
          SplitPersianDate pDate, y2, m2, d2

          diffYears = y2 - y1
          FixedExpenseOccursOnDate = (diffYears >= 0 And m1 = m2 And d1 = d2)
      End If
  End Function

  '=========================================================
  ' DATE / NUMBER HELPERS
  '=========================================================

  Private Function NormalizePersianDate(ByVal value As String) As String
      Dim s As String
      Dim Y As Long, m As Long, d As Long

      s = Trim(ToEnglishDigits(CStr(value)))
      s = Replace(s, "-", "/")
      s = Replace(s, ".", "/")
      s = Replace(s, " ", "")

      If Len(s) = 8 And InStr(s, "/") = 0 Then
          s = Left$(s, 4) & "/" & Mid$(s, 5, 2) & "/" & Right$(s, 2)
      End If

      If Not s Like "####/##/##" Then Exit Function

      SplitPersianDate s, Y, m, d

      If m < 1 Or m > 12 Then Exit Function
      If d < 1 Or d > PersianMonthDays(Y, m) Then Exit Function

      NormalizePersianDate = Format(Y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
  End Function

  Private Sub SplitPersianDate(ByVal pDate As String, ByRef Y As Long, ByRef m As Long, ByRef d As Long)
      pDate = NormalizeDateShapeOnly(pDate)

      Y = CLng(Left$(pDate, 4))
      m = CLng(Mid$(pDate, 6, 2))
      d = CLng(Right$(pDate, 2))
  End Sub

  Private Function NormalizeDateShapeOnly(ByVal value As String) As String
      Dim s As String
      s = Trim(ToEnglishDigits(CStr(value)))
      s = Replace(s, "-", "/")
      s = Replace(s, ".", "/")
      s = Replace(s, " ", "")

      If Len(s) = 8 And InStr(s, "/") = 0 Then
          s = Left$(s, 4) & "/" & Mid$(s, 5, 2) & "/" & Right$(s, 2)
      End If

      NormalizeDateShapeOnly = s
  End Function

  Private Function PersianMonthDays(ByVal pYear As Long, ByVal pMonth As Long) As Long
      If pMonth <= 6 Then
          PersianMonthDays = 31
      ElseIf pMonth <= 11 Then
          PersianMonthDays = 30
      Else
          If IsPersianLeapYear(pYear) Then PersianMonthDays = 30 Else PersianMonthDays = 29
      End If
  End Function

  Private Function IsPersianLeapYear(ByVal pYear As Long) As Boolean
      ' Simplified rule, matching common workbook-style approximation.
      IsPersianLeapYear = ((pYear Mod 4) = 3)
  End Function

  Private Function PersianDateToSerial(ByVal pDate As String) As Long
      Dim Y As Long, m As Long, d As Long
      Dim yy As Long, mm As Long

      SplitPersianDate pDate, Y, m, d

      For yy = 1 To Y - 1
          PersianDateToSerial = PersianDateToSerial + 365
          If IsPersianLeapYear(yy) Then PersianDateToSerial = PersianDateToSerial + 1
      Next yy

      For mm = 1 To m - 1
          PersianDateToSerial = PersianDateToSerial + PersianMonthDays(Y, mm)
      Next mm

      PersianDateToSerial = PersianDateToSerial + d
  End Function

  Private Function ComparePersianDates(ByVal date1 As String, ByVal date2 As String) As Long
      Dim s1 As Long, s2 As Long

      s1 = PersianDateToSerial(NormalizePersianDate(date1))
      s2 = PersianDateToSerial(NormalizePersianDate(date2))

      If s1 < s2 Then
          ComparePersianDates = -1
      ElseIf s1 > s2 Then
          ComparePersianDates = 1
      Else
          ComparePersianDates = 0
      End If
  End Function

  Private Function AddPersianDays(ByVal pDate As String, ByVal daysToAdd As Long) As String
      Dim Y As Long, m As Long, d As Long
      Dim i As Long

      SplitPersianDate NormalizePersianDate(pDate), Y, m, d

      If daysToAdd >= 0 Then
          For i = 1 To daysToAdd
              d = d + 1
              If d > PersianMonthDays(Y, m) Then
                  d = 1
                  m = m + 1
                  If m > 12 Then
                      m = 1
                      Y = Y + 1
                  End If
              End If
          Next i
      Else
          For i = 1 To Abs(daysToAdd)
              d = d - 1
              If d < 1 Then
                  m = m - 1
                  If m < 1 Then
                      m = 12
                      Y = Y - 1
                  End If
                  d = PersianMonthDays(Y, m)
              End If
          Next i
      End If

      AddPersianDays = Format(Y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
  End Function

Private Function ToEnglishDigits(ByVal text As String) As String
      Dim i As Long

      For i = 0 To 9
          text = Replace(text, ChrW(&H6F0 + i), CStr(i)) ' Persian  digits
          text = Replace(text, ChrW(&H660 + i), CStr(i)) ' Arabic digits
      Next i

      ToEnglishDigits = text
  End Function

  Private Function ParseAmount(ByVal value As String) As Double
      Dim s As String

      s = ToEnglishDigits(CStr(value))
      s = Replace(s, ",", "")
      s = Replace(s, "�", "")
      s = Replace(s, " ", "+")

      If Trim(s) = vbNullString Then s = "0"

      On Error GoTo SafeExit
      ParseAmount = CDbl(Application.Evaluate(s))
      Exit Function

SafeExit:
      ParseAmount = 0
  End Function

  Private Function FormatAmountText(ByVal value As String) As String
      FormatAmountText = Format(ParseAmount(value), "#,##0")
  End Function

  Private Function ToNumber(ByVal value As Variant) As Double
      If IsError(value) Or IsEmpty(value) Or Trim(CStr(value)) = vbNullString Then
          ToNumber = 0
      Else
          ToNumber = CDbl(val(Replace(ToEnglishDigits(CStr(value)), ",", "")))
      End If
  End Function

  '=========================================================
  ' GENERAL TABLE HELPERS
  '=========================================================

  Private Function NextEmptyRow(ByVal ws As Worksheet, ByVal colLetter As String) As Long
      NextEmptyRow = ws.Cells(ws.rows.Count, colLetter).End(xlUp).Row + 1
      If NextEmptyRow < 2 Then NextEmptyRow = 2
  End Function

  Private Function NextTableNo(ByVal ws As Worksheet, ByVal noColumn As String) As Long
      Dim lastRow As Long

      lastRow = ws.Cells(ws.rows.Count, noColumn).End(xlUp).Row

      If lastRow < 2 Or Len(ws.Cells(2, noColumn).value) = 0 Then
          NextTableNo = 1
      Else
          NextTableNo = CLng(Application.WorksheetFunction.Max(ws.Range(noColumn & "2:" & noColumn & lastRow))) + 1
      End If
  End Function

Private Sub RenumberTable(ByVal noColumn As String)
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long, n As Long

      Set ws = EnsureAccountingSheet()
      lastRow = ws.Cells(ws.rows.Count, noColumn).End(xlUp).Row
      n = 1

      For r = 2 To lastRow
          If Application.WorksheetFunction.CountA(ws.Range(noColumn & r).Resize(1, GetTableColumnCount(noColumn))) > 0 Then
              ws.Cells(r, noColumn).value = n
              n = n + 1
          End If
      Next r
  End Sub
  Private Function GetTableColumnCount(ByVal noColumn As String) As Long
      Select Case noColumn
          Case "F": GetTableColumnCount = 8   ' F:M
          Case "O": GetTableColumnCount = 5   ' O:S
          Case "T": GetTableColumnCount = 4   ' T:W
          Case Else: GetTableColumnCount = 1
      End Select
  End Function
  Private Function PickChoice2(ByVal title As String, ByVal prompt As String, ByVal option1 As String, ByVal option2 As String) As String
      frmChoicePicker.Setup title, prompt, option1, option2
      frmChoicePicker.Show vbModal
      PickChoice2 = frmChoicePicker.SelectedValue
      Unload frmChoicePicker
  End Function

  Private Function PickChoice3(ByVal title As String, ByVal prompt As String, ByVal option1 As String, ByVal option2 As String, ByVal option3 As String) As String
      frmChoicePicker.Setup title, prompt, option1, option2, option3
      frmChoicePicker.Show vbModal
      PickChoice3 = frmChoicePicker.SelectedValue
      Unload frmChoicePicker
  End Function
 Private Function AskAmount(ByVal title As String, ByVal prompt As String, Optional ByVal defaultAmount As Double = 0) As Double
      frmAmountInput.Setup title, prompt, defaultAmount
      frmAmountInput.Show vbModal

      If frmAmountInput.Cancelled Then
          AskAmount = -1
      Else
          AskAmount = frmAmountInput.AmountValue
      End If

      Unload frmAmountInput
  End Function

  Private Function AskTextFa(ByVal prompt As String, ByVal title As String, Optional ByVal defaultValue As String = "") As String
      SetKeyboardPersian
      AskTextFa = Trim(InputBox(prompt, title, defaultValue))
  End Function

  Private Function AskTextEn(ByVal prompt As String, ByVal title As String, Optional ByVal defaultValue As String = "") As String
      SetKeyboardEnglish
      AskTextEn = Trim(InputBox(prompt, title, defaultValue))
  End Function
 Private Function FixedExpenseHasStarted(ByVal fixedNo As Long) As Boolean
      Dim rowNum As Long
      Dim startDate As String
      Dim currentDate As String

      rowNum = FixedDataRowByNo(fixedNo)
      If rowNum = 0 Then Exit Function

      startDate = NormalizePersianDate(EnsureAccountingSheet().Cells(rowNum, "I").value)
      currentDate = GetConfiguredCurrentDate()

      If startDate <> vbNullString And currentDate <> vbNullString Then
          FixedExpenseHasStarted = (ComparePersianDates(currentDate, startDate) >= 0)
      End If
  End Function

  Private Function GetConfiguredCurrentDate() As String
      Dim wsInfo As Worksheet

      Set wsInfo = ThisWorkbook.Worksheets(SH_INFO)

      GetConfiguredCurrentDate = NormalizePersianDate( _
          Format(CLng(wsInfo.Range("AC1").value), "0000") & "/" & _
          Format(CLng(wsInfo.Range("AC2").value), "00") & "/" & _
          Format(CLng(wsInfo.Range("AE1").value), "00"))
  End Function

  Private Function CalculateFixedEndDate(ByVal startDate As String, ByVal frequency As String, ByVal frequencyCount As Long) As String
      If frequencyCount <= 0 Then
          CalculateFixedEndDate = vbNullString
      ElseIf frequency = "������" Then
          CalculateFixedEndDate = AddPersianDays(startDate, frequencyCount - 1)
      ElseIf frequency = "������" Then
          CalculateFixedEndDate = AddPersianMonths(startDate, frequencyCount - 1)
      ElseIf frequency = "������" Then
          CalculateFixedEndDate = AddPersianYears(startDate, frequencyCount - 1)
      End If
  End Function

Private Function AddPersianMonths(ByVal pDate As String, ByVal monthsToAdd As Long) As String
      Dim Y As Long, m As Long, d As Long
      Dim totalMonths As Long

      SplitPersianDate NormalizePersianDate(pDate), Y, m, d

      totalMonths = (Y * 12 + (m - 1)) + monthsToAdd
      Y = totalMonths \ 12
      m = (totalMonths Mod 12) + 1

      If d > PersianMonthDays(Y, m) Then d = PersianMonthDays(Y, m)

      AddPersianMonths = Format(Y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
  End Function

  Private Function AddPersianYears(ByVal pDate As String, ByVal yearsToAdd As Long) As String
      Dim Y As Long, m As Long, d As Long

      SplitPersianDate NormalizePersianDate(pDate), Y, m, d

      Y = Y + yearsToAdd

      If d > PersianMonthDays(Y, m) Then d = PersianMonthDays(Y, m)

      AddPersianYears = Format(Y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
  End Function
Private Function IrregularExpenseIsUsed(ByVal irregularNo As Long) As Boolean
      Dim rowNum As Long
      Dim expenseDate As String
      Dim currentDate As String

      rowNum = IrregularDataRowByNo(irregularNo)
      If rowNum = 0 Then Exit Function

      expenseDate = NormalizePersianDate(EnsureAccountingSheet().Cells(rowNum, "R").value)
      currentDate = GetConfiguredCurrentDate()

      If expenseDate <> vbNullString And currentDate <> vbNullString Then
          IrregularExpenseIsUsed = (ComparePersianDates(currentDate, expenseDate) >= 0)
      End If
  End Function
Private Function GetDirectPayTotalFromSlots(ByVal ws As Worksheet, ByVal dayStartRow As Long, ByVal lowerOffset As Long) As Double
      Dim rowsPerDay As Long, blockRows As Long, dummyOffset As Long
      Dim chequeSumCol As Long, factorSumCol As Long, directPaySumCol As Long
      Dim numCheques As Long, numFactors As Long, numDirectPays As Long
      Dim firstFactorCol As Long, lastFactorCol As Long
      Dim firstDirectPayCol As Long, lastDirectPayCol As Long
      Dim c As Long

      GetLayout rowsPerDay, blockRows, dummyOffset, chequeSumCol, factorSumCol, directPaySumCol

      numCheques = CLng(Range("cfg_NumCheques").value)
      numFactors = CLng(Range("cfg_NumFactors").value)
      numDirectPays = CLng(Range("cfg_NumDirectPays").value)

      firstFactorCol = 14 + (numCheques * 2) + 1
      lastFactorCol = firstFactorCol + (numFactors * 2) - 2
      firstDirectPayCol = lastFactorCol + 3
      lastDirectPayCol = firstDirectPayCol + numDirectPays - 1

      For c = firstDirectPayCol To lastDirectPayCol
          GetDirectPayTotalFromSlots = GetDirectPayTotalFromSlots + ToNumber(ws.Cells(dayStartRow + lowerOffset, c).value)
      Next c
  End Function
Private Function GetInsurancePaymentsReceivedOnDate(ByVal targetDate As String) As Double
      targetDate = NormalizePersianDate(targetDate)
      If targetDate = vbNullString Then Exit Function

      If Not mInsuranceCacheReady Then BuildInsurancePaymentCache

      If mInsuranceCache.exists(targetDate) Then
          GetInsurancePaymentsReceivedOnDate = CDbl(mInsuranceCache(targetDate))
      End If
  End Function



  Private Sub BuildInsurancePaymentCache()
      Dim ws As Worksheet
      Dim actualCenters As Long, totalCenters As Long
      Dim rowsPerDay As Long, blockRows As Long
      Dim fixedSummaryStartRow As Long, insuranceStartRow As Long
      Dim insuranceCount As Long
      Dim r As Long, c As Long
      Dim amount As Double
      Dim paymentDate As String

      Set mInsuranceCache = CreateObject("Scripting.Dictionary")

      actualCenters = CLng(Range("cfg_ActualUserCenters").value)
      totalCenters = CLng(Range("cfg_TotalCenters").value)

      If actualCenters = 1 Then
          rowsPerDay = 2
      Else
          rowsPerDay = totalCenters
      End If

      blockRows = rowsPerDay + 1
      fixedSummaryStartRow = 2 + (31 * blockRows) + 2
      insuranceStartRow = fixedSummaryStartRow + 10 + actualCenters + 1
      insuranceCount = 8 + ((actualCenters - 1) * 3)

      For Each ws In ThisWorkbook.Worksheets
          If IsMonthlyDataSheet(ws) Then
              For r = insuranceStartRow To insuranceStartRow + insuranceCount - 1
                  For c = 4 To 50
                      amount = ToNumber(ws.Cells(r, c).value)

                      If amount <> 0 Then
                          paymentDate = ExtractPersianDateFromComment(ws.Cells(r, c))

                          If paymentDate <> vbNullString Then
                              If mInsuranceCache.exists(paymentDate) Then
                                  mInsuranceCache(paymentDate) = CDbl(mInsuranceCache(paymentDate)) + amount
                              Else
                                  mInsuranceCache.Add paymentDate, amount
                              End If
                          End If
                      End If
                  Next c
              Next r
          End If
      Next ws

      mInsuranceCacheReady = True
  End Sub

Private Function ExtractPersianDateFromComment(ByVal targetCell As Range) As String
      ExtractPersianDateFromComment = ExtractPersianDateFromText(GetCellCommentText(targetCell))
  End Function

  Private Function IsMonthlyDataSheet(ByVal ws As Worksheet) As Boolean
      Dim b1Text As String

      If ws Is Nothing Then Exit Function
      If ws.Name = SH_INFO Then Exit Function
      If ws.Name = "�������" Or ws.Name = "�������" Then Exit Function
      If ws.Name = "�" Or ws.Name = "�" Then Exit Function
      If InStr(1, ws.Name, "�����", vbTextCompare) > 0 Then Exit Function
      If InStr(1, ws.Name, "������", vbTextCompare) > 0 Then Exit Function

      b1Text = NormalizePersianYearMonth(ws.Cells(1, 2).text)
      IsMonthlyDataSheet = (b1Text <> vbNullString)
  End Function
  Private Function NormalizePersianYearMonth(ByVal value As String) As String
      Dim s As String
      Dim Y As Long, m As Long

      s = Trim$(ToEnglishDigits(CStr(value)))
      s = Replace(s, ".", "/")
      s = Replace(s, "-", "/")
      s = Replace(s, " ", "")

      If Not s Like "####/##" Then Exit Function

      Y = CLng(Left$(s, 4))
      m = CLng(Right$(s, 2))

      If Y < 1300 Or Y > 1500 Then Exit Function
      If m < 1 Or m > 12 Then Exit Function

      NormalizePersianYearMonth = Format$(Y, "0000") & "/" & Format$(m, "00")
  End Function
Private Function GetCellCommentText(ByVal targetCell As Range) As String
      On Error Resume Next

      If Not targetCell.Comment Is Nothing Then
          GetCellCommentText = targetCell.Comment.text
          Exit Function
      End If

      GetCellCommentText = CallByName(CallByName(targetCell, "CommentThreaded", VbGet), "Text", VbGet)

      On Error GoTo 0
  End Function
 Private Function ExtractPersianDateFromText(ByVal commentText As String) As String
      Dim digitsOnly As String
      Dim i As Long
      Dim ch As String
      Dim rawDate As String

      commentText = ToEnglishDigits(commentText)

      For i = 1 To Len(commentText)
          ch = Mid$(commentText, i, 1)
          If ch >= "0" And ch <= "9" Then
              digitsOnly = digitsOnly & ch
          End If
      Next i

      If Len(digitsOnly) < 8 Then Exit Function

      rawDate = Left$(digitsOnly, 4) & "/" & Mid$(digitsOnly, 5, 2) & "/" & Mid$(digitsOnly, 7, 2)
      ExtractPersianDateFromText = NormalizePersianDate(rawDate)
  End Function
 Private Sub cmdTransEdit_Click()
      Dim ws As Worksheet
      Dim transNo As Long
      Dim rowNum As Long
      Dim transferType As String
      Dim transferDate As String
      Dim amount As Double

      If lstTransfers.listIndex < 0 Then
          MsgBox "����� � ��ǘ�� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      Set ws = EnsureAccountingSheet()
      transNo = CLng(lstTransfers.List(lstTransfers.listIndex, 0))
      rowNum = TransferDataRowByNo(transNo)

      If rowNum = 0 Then
          MsgBox "���� ��ǘ�� ���� ���.", vbExclamation
          Exit Sub
      End If

transferType = PickChoice2("��� ��ǘ��", "��� ��ǘ�� �� ������ ����:", "�����", "������")
  If transferType = vbNullString Then Exit Sub

      transferDate = NormalizePersianDate(AskTextEn("����� ��ǘ��:", "������ ��ǘ��", ws.Cells(rowNum, "V").value))
      If transferDate = vbNullString Then
          MsgBox "����� ����� ����.", vbExclamation
          Exit Sub
      End If

      amount = AskAmount("������ ��ǘ��", "���� ��ǘ��:", ToNumber(ws.Cells(rowNum, "W").value))
      If amount <= 0 Then Exit Sub

      ws.Cells(rowNum, "U").value = transferType
      ws.Cells(rowNum, "V").value = transferDate
      ws.Cells(rowNum, "W").value = amount

      LoadTransfers
  End Sub

  Private Sub cmdTransDelete_Click()
      Dim rowNum As Long
      Dim transNo As Long

      If lstTransfers.listIndex < 0 Then
          MsgBox "����� � ��ǘ�� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      If MsgBox("��� ��� ��ǘ�� ��� ��Ͽ", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

      transNo = CLng(lstTransfers.List(lstTransfers.listIndex, 0))
      rowNum = TransferDataRowByNo(transNo)

If rowNum > 0 Then
      EnsureAccountingSheet().Range("T" & rowNum & ":W" & rowNum).ClearContents
      RenumberTable "T"
  End If
  LoadTransfers
  End Sub
  Private Function TransferDataRowByNo(ByVal transNo As Long) As Long
      TransferDataRowByNo = DataRowByNo("T", transNo)
  End Function
Private Sub SumSalesOnly(ByVal fromDate As String, ByVal toDate As String, _
                           ByRef cashTotal As Double, ByRef cardTotal As Double)

      Dim currentDate As String
      Dim Y As Long, m As Long, d As Long

      currentDate = fromDate

      Do While ComparePersianDates(currentDate, toDate) <= 0
          SplitPersianDate currentDate, Y, m, d
          AddSalesForDate Y, m, d, cashTotal, cardTotal
          currentDate = AddPersianDays(currentDate, 1)
      Loop
  End Sub

  Private Sub AddSalesForDate(ByVal pYear As Long, ByVal pMonth As Long, ByVal pDay As Long, _
                              ByRef cashTotal As Double, ByRef cardTotal As Double)

      Dim ws As Worksheet
      Dim rowsPerDay As Long, blockRows As Long, lowerOffset As Long
      Dim chequeSumCol As Long, factorSumCol As Long, directPaySumCol As Long
      Dim dayStartRow As Long, r As Long
      Dim yearMonth As String

      yearMonth = CStr(pYear) & "/" & Format(pMonth, "00")
      Set ws = FindMonthSheet(yearMonth)

      If ws Is Nothing Then Exit Sub

      GetLayout rowsPerDay, blockRows, lowerOffset, chequeSumCol, factorSumCol, directPaySumCol
      dayStartRow = 2 + (pDay - 1) * blockRows

      If CLng(val(ws.Cells(dayStartRow, "A").value)) <> pDay Then Exit Sub

      For r = dayStartRow To dayStartRow + rowsPerDay - 1
          cashTotal = cashTotal + ToNumber(ws.Cells(r, "C").value)
          cardTotal = cardTotal + ToNumber(ws.Cells(r, "D").value)
      Next r
  End Sub
  Private Sub ResetInsuranceCache()
      Set mInsuranceCache = Nothing
      mInsuranceCacheReady = False
  End Sub
Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)

    modMouseScroll.StopHook

End Sub

' ��� ������ ���� ���� ���� �������� ���� MultiPage � Frame
Private Sub AttachMouseWheelToControls(ByVal parentObj As Object)
    Dim ctl As Control
    Dim pg As Page
    Dim mw As clsMouseWheel

    On Error Resume Next

    For Each ctl In parentObj.Controls
        
        ' ����� ���� ����� ���ʝ�ǘ� ��� �� �����ǘ�
        If typeName(ctl) = "ListBox" Or typeName(ctl) = "ComboBox" Then
            Set mw = New clsMouseWheel
            mw.Attach ctl
            MouseWheelHandlers.Add mw
        End If
        
        ' ������ ������ �� ���� ���� ���� �� ����� ���
        If typeName(ctl) = "Frame" Then
            AttachMouseWheelToControls ctl
        ElseIf typeName(ctl) = "MultiPage" Then
            For Each pg In ctl.Pages
                AttachMouseWheelToControls pg
            Next pg
        End If
        
    Next ctl

    On Error GoTo 0
End Sub
