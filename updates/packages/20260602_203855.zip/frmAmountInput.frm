VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmAmountInput 
   Caption         =   "UserForm1"
   ClientHeight    =   2863
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   4298
   OleObjectBlob   =   "frmAmountInput.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmAmountInput"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

  Public AmountValue As Double
  Public Cancelled As Boolean

  Public Sub Setup(ByVal formTitle As String, ByVal promptText As String, Optional ByVal defaultAmount As Double = 0)
      Me.Caption = formTitle
      lblTitle.Caption = promptText
      Cancelled = True
      AmountValue = 0

      If defaultAmount > 0 Then
          txtAmount.value = Format(defaultAmount, "#,##0")
      Else
          txtAmount.value = vbNullString
      End If
  End Sub

  Private Sub UserForm_Activate()
      SetKeyboardEnglish
      txtAmount.SetFocus
  End Sub

  Private Sub txtAmount_Enter()
      SetKeyboardEnglish
  End Sub

  Private Sub txtAmount_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      If Trim(txtAmount.value) <> vbNullString Then
          txtAmount.value = Format(ParseAmountLocal(txtAmount.value), "#,##0")
      End If
  End Sub

  Private Sub cmdOK_Click()
      AmountValue = ParseAmountLocal(txtAmount.value)

      If AmountValue <= 0 Then
          MsgBox "���� ����� ����.", vbExclamation
          txtAmount.SetFocus
          Exit Sub
      End If

      Cancelled = False
      Me.Hide
  End Sub

  Private Sub cmdCancel_Click()
      Cancelled = True
      Me.Hide
  End Sub

  Private Function ParseAmountLocal(ByVal value As String) As Double
      Dim s As String

      s = ToEnglishDigitsLocal(CStr(value))
      s = Replace(s, ",", "")
      s = Replace(s, "�", "")
      s = Replace(s, " ", "+")

      If Trim(s) = vbNullString Then s = "0"

      On Error GoTo SafeExit
      ParseAmountLocal = CDbl(Application.Evaluate(s))
      Exit Function

SafeExit:
      ParseAmountLocal = 0
  End Function

  Private Function ToEnglishDigitsLocal(ByVal text As String) As String
      Dim fa, ar, en
      Dim i As Long

      fa = Array("�", "�", "�", "�", "�", "�", "�", "�", "�", "�")
      ar = Array("�", "�", "�", "�", "�", "�", "�", "�", "�", "�")
      en = Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9")

      For i = 0 To 9
          text = Replace(text, fa(i), en(i))
          text = Replace(text, ar(i), en(i))
      Next i

      ToEnglishDigitsLocal = text
  End Function
