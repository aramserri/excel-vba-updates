Attribute VB_Name = "modAccounting"
Sub ShowfrmAccounting()
    frmAccounting.Show
End Sub


