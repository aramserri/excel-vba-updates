VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmChoicePicker 
   Caption         =   "UserForm1"
   ClientHeight    =   2863
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   4298
   OleObjectBlob   =   "frmChoicePicker.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmChoicePicker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
  Option Explicit

  '=========================================================
  ' frmChoicePicker
  '
  ' Required controls:
  ' - lblTitle
  ' - cmdOption1
  ' - cmdOption2
  ' - cmdOption3
  ' - cmdCancel
  '=========================================================

  Public SelectedValue As String

  Public Sub Setup(ByVal formTitle As String, _
                   ByVal promptText As String, _
                   ByVal option1Caption As String, _
                   ByVal option2Caption As String, _
                   Optional ByVal option3Caption As String = vbNullString)

      Me.Caption = formTitle
      lblTitle.Caption = promptText

      cmdOption1.Caption = option1Caption
      cmdOption2.Caption = option2Caption

      If option3Caption = vbNullString Then
          cmdOption3.Visible = False
      Else
          cmdOption3.Visible = True
          cmdOption3.Caption = option3Caption
      End If

      cmdCancel.Caption = "������"
      SelectedValue = vbNullString
  End Sub

  Private Sub cmdOption1_Click()
      SelectedValue = cmdOption1.Caption
      Me.Hide
  End Sub

  Private Sub cmdOption2_Click()
      SelectedValue = cmdOption2.Caption
      Me.Hide
  End Sub

  Private Sub cmdOption3_Click()
      SelectedValue = cmdOption3.Caption
      Me.Hide
  End Sub

  Private Sub cmdCancel_Click()
      SelectedValue = vbNullString
      Me.Hide
  End Sub

  Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
      SelectedValue = vbNullString
  End Sub
