VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} voroodforoosh 
   Caption         =   "��� ����"
   ClientHeight    =   6475
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   7581
   OleObjectBlob   =   "voroodforoosh.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "voroodforoosh"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False









'=====================================================
' UserForm: DailySalesEntry (WITH MONTHLY SUMMARY)
'=====================================================
Option Explicit

'====================================================================================================
'                                    MODULE-LEVEL VARIABLES
'====================================================================================================
Private m_UserCenters As Long
Private m_TotalCenters As Long
Private m_CenterNames As Object
Private m_ActiveCenters As Object
Private m_ActiveCenterCount As Long
'--- Collections to hold dynamic controls ---
Private m_CashTextBoxes As Collection
Private m_CardTextBoxes As Collection
'--- Statistics Labels Collections ---
Private m_MonthlySumLabels As Collection  ' NEW: Monthly sum per center
Private m_MonthHighLabels As Collection     ' Highest day in month per center
Private m_MonthLowLabels As Collection      ' Lowest day in month per center
Private m_MonthAvgLabels As Collection      ' Average of month per center
Private m_YearHighLabels As Collection      ' Highest day in year per center
Private m_YearLowLabels As Collection       ' Lowest day in year per center
Private m_LastEntryLabels As Collection
Private m_YearTotalLabels As Collection
'--- Overall Min/Max Day Labels ---
Private m_lblMonthBestDay As MSForms.Label
Private m_lblMonthWorstDay As MSForms.Label
Private m_lblYearBestDay As MSForms.Label
Private m_lblYearWorstDay As MSForms.Label
Private m_lblYearGrandTotal As MSForms.Label
'--- Keep event handler objects alive ---
Private m_TextBoxEvents As Collection
Private m_LabelClickEvents As Collection
'--- Control references for easy access ---
Private WithEvents m_btnDayPicker As MSForms.CommandButton
Attribute m_btnDayPicker.VB_VarHelpID = -1
Private WithEvents m_btnSubmit As MSForms.CommandButton
Attribute m_btnSubmit.VB_VarHelpID = -1
Private m_lblDay As MSForms.Label
Private m_lblTotalSales As MSForms.Label
'--- NEW: Monthly summary labels ---
Private m_lblMonthlyTotalCenters As MSForms.Label
Private m_lblMonthlyBimeha As MSForms.Label
Private m_lblMonthlyGrandTotal As MSForms.Label
Private WithEvents m_cboYear As MSForms.ComboBox
Attribute m_cboYear.VB_VarHelpID = -1
Private WithEvents m_cboMonth As MSForms.ComboBox
Attribute m_cboMonth.VB_VarHelpID = -1
Private m_lblMonthlyTotalCentersAvg As MSForms.Label

'====================================================================================================
'                                    FORM INITIALIZATION
'====================================================================================================

Private Sub UserForm_Initialize()
    Dim i As Long

    '--- Read Configuration First ---
    If Not ReadConfiguration() Then
        MsgBox "���: ������� ���� ���� ���. ��� �������� ��ѐ��� ���.", vbCritical, "���� �������"
        Unload Me
        Exit Sub
    End If

    '--- Set Form Properties ---
    With Me
        .Caption = "��� ���� ������"
        .Width = 920  ' Wider to fit all statistics
        .Font.Name = "Tahoma"
        .Font.Size = 12
    End With

    '--- Create Collections ---
    Set m_CashTextBoxes = New Collection
    Set m_CardTextBoxes = New Collection
    Set m_LastEntryLabels = New Collection
    Set m_MonthlySumLabels = New Collection
    Set m_MonthHighLabels = New Collection
    Set m_MonthLowLabels = New Collection
    Set m_MonthAvgLabels = New Collection
    Set m_YearHighLabels = New Collection
    Set m_YearLowLabels = New Collection
    Set m_TextBoxEvents = New Collection
    Set m_LabelClickEvents = New Collection
    Set m_YearTotalLabels = New Collection

    '--- Create Static Controls (Year/Month/Day Selection) ---'--- Create Static Controls (Year/Month/Day Selection) ---
    Dim lbl As MSForms.Label
    Dim topPosition As Single
    topPosition = 10

    ' Day label FIRST (on the right)
    Set m_lblDay = Me.Controls.Add("Forms.Label.1", "lblDay", True)
    With m_lblDay
        .Caption = ""
        .Top = topPosition + 4
        .Left = 520
        .Width = 40
        .Font.Bold = True
        .Font.Size = 14
        .TextAlign = fmTextAlignCenter
    End With

    ' Day Picker Button
    Set m_btnDayPicker = Me.Controls.Add("Forms.CommandButton.1", "btnDayPicker", True)
    With m_btnDayPicker: .Caption = "������ ���": .Top = topPosition: .Left = 420: .Width = 70: .TabIndex = 2: .TabStop = True: End With

    ' Month Label
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonth", True)
    With lbl: .Caption = "���:": .Top = topPosition + 4: .Left = 320: .Width = 30: End With

    ' Month ComboBox
    Set m_cboMonth = Me.Controls.Add("Forms.ComboBox.1", "cboMonth", True)
    With m_cboMonth: .Top = topPosition: .Left = 220: .Width = 45: .TabIndex = 1: .TabStop = True: End With

    ' Year Label
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYear", True)
    With lbl: .Caption = "���:": .Top = topPosition + 4: .Left = 120: .Width = 35: End With

    ' Year ComboBox
    Set m_cboYear = Me.Controls.Add("Forms.ComboBox.1", "cboYear", True)
    With m_cboYear: .Top = topPosition: .Left = 20: .Width = 60: .TabIndex = 0: .TabStop = True: End With

    '--- Populate ComboBoxes ---
    On Error Resume Next
    m_cboYear.RowSource = "cfg_YearList"
    m_cboYear.value = CStr(ThisWorkbook.Sheets("�������").Range("cfg_DefaultYear").value)
    If m_cboYear.value = "" And m_cboYear.ListCount > 0 Then
        m_cboYear.ListIndex = m_cboYear.ListCount - 1
    End If
    On Error GoTo 0

    m_cboMonth.Clear
    For i = 1 To 12: m_cboMonth.AddItem CStr(i): Next i

    Dim defaultMonth As Variant
    On Error Resume Next
    defaultMonth = ThisWorkbook.Sheets("�������").Range("AC2").value
    On Error GoTo 0

    If IsNumeric(defaultMonth) And CLng(defaultMonth) >= 1 And CLng(defaultMonth) <= 12 Then
        m_cboMonth.value = CStr(CLng(defaultMonth))
    Else
        m_cboMonth.ListIndex = 0
    End If

    '--- Dynamically Create Data Entry Headers and Controls ---
    topPosition = topPosition + 40

    ' Headers Row 1 - Statistics
    Dim headerLeft As Single
    headerLeft = 5

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderYearLow", True)
    With lbl: .Caption = "������ ���": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: .ForeColor = RGB(100, 100, 100): End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderYearHigh", True)
    With lbl: .Caption = "������� ���": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: .ForeColor = RGB(100, 100, 100): End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderMonthAvg", True)
    With lbl: .Caption = "������ ���": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: .ForeColor = RGB(100, 100, 100): End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderMonthLow", True)
    With lbl: .Caption = "������ ���": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: .ForeColor = RGB(100, 100, 100): End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderMonthHigh", True)
    With lbl: .Caption = "������� ���": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: .ForeColor = RGB(100, 100, 100): End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderMonthlySum", True)
    With lbl: .Caption = "��� ���": .Top = topPosition: .Left = headerLeft: .Width = 70: .TextAlign = fmTextAlignCenter: .Font.Size = 8: End With
    headerLeft = headerLeft + 73

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderLastEntry", True)
    With lbl: .Caption = "����� ����": .Top = topPosition: .Left = headerLeft: .Width = 55: .TextAlign = fmTextAlignCenter: .Font.Size = 8: End With
    headerLeft = headerLeft + 58

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderCard", True)
    With lbl: .Caption = "���� (����)": .Top = topPosition: .Left = headerLeft: .Width = 100: .TextAlign = fmTextAlignCenter: End With
    headerLeft = headerLeft + 103

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderCash", True)
    With lbl: .Caption = "��� (����)": .Top = topPosition: .Left = headerLeft: .Width = 100: .TextAlign = fmTextAlignCenter: End With
    headerLeft = headerLeft + 103

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHeaderCenter", True)
    With lbl: .Caption = "�ј�": .Top = topPosition: .Left = headerLeft: .Width = 130: .TextAlign = fmTextAlignCenter: End With

    topPosition = topPosition + 22

    ' Data entry controls per center
    Dim tabIdx As Long
    tabIdx = 4

    For i = 1 To m_ActiveCenterCount
        headerLeft = 5

        ' Year Low Label
        Dim lblYearLow As MSForms.Label
        Set lblYearLow = Me.Controls.Add("Forms.Label.1", "lblYearLow" & i, True)
        With lblYearLow
            .Caption = "-"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(255, 230, 230)  ' Light red
            .Font.Size = 8
        End With
        m_YearLowLabels.Add lblYearLow, "Center" & i
        headerLeft = headerLeft + 58

        ' Year High Label
        Dim lblYearHigh As MSForms.Label
        Set lblYearHigh = Me.Controls.Add("Forms.Label.1", "lblYearHigh" & i, True)
        With lblYearHigh
            .Caption = "-"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(230, 255, 230)  ' Light green
            .Font.Size = 8
        End With
        m_YearHighLabels.Add lblYearHigh, "Center" & i
        headerLeft = headerLeft + 58

        ' Month Average Label
        Dim lblMonthAvg As MSForms.Label
        Set lblMonthAvg = Me.Controls.Add("Forms.Label.1", "lblMonthAvg" & i, True)
        With lblMonthAvg
            .Caption = "0"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(240, 240, 255)  ' Light purple
            .Font.Size = 8
        End With
        m_MonthAvgLabels.Add lblMonthAvg, "Center" & i
        headerLeft = headerLeft + 58

        ' Month Low Label
        Dim lblMonthLow As MSForms.Label
        Set lblMonthLow = Me.Controls.Add("Forms.Label.1", "lblMonthLow" & i, True)
        With lblMonthLow
            .Caption = "-"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(255, 245, 230)  ' Light orange
            .Font.Size = 8
        End With
        m_MonthLowLabels.Add lblMonthLow, "Center" & i
        headerLeft = headerLeft + 58

        ' Month High Label
        Dim lblMonthHigh As MSForms.Label
        Set lblMonthHigh = Me.Controls.Add("Forms.Label.1", "lblMonthHigh" & i, True)
        With lblMonthHigh
            .Caption = "-"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(230, 255, 245)  ' Light cyan
            .Font.Size = 8
        End With
        m_MonthHighLabels.Add lblMonthHigh, "Center" & i
        headerLeft = headerLeft + 58

        ' Monthly Sum Label
        Dim lblMonthlySum As MSForms.Label
        Set lblMonthlySum = Me.Controls.Add("Forms.Label.1", "lblMonthlySum" & i, True)
        With lblMonthlySum
            .Caption = "0"
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 70
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(230, 240, 255)
            .Font.Size = 9
        End With
        m_MonthlySumLabels.Add lblMonthlySum, "Center" & i
        headerLeft = headerLeft + 73

        ' Last Entry Date Label (Clickable)
        Dim lblLastEntry As MSForms.Label
        Set lblLastEntry = Me.Controls.Add("Forms.Label.1", "lblLastEntry" & i, True)
        With lblLastEntry
            .Caption = "..."
            .Top = topPosition + 2
            .Left = headerLeft
            .Width = 55
            .Height = 18
            .TextAlign = fmTextAlignCenter
            .BorderStyle = fmBorderStyleSingle
            .BackColor = RGB(255, 255, 230)
            .Font.Size = 9
        End With
        m_LastEntryLabels.Add lblLastEntry, "Center" & i
        Call HookupLabelClickEvent(lblLastEntry, i)
        headerLeft = headerLeft + 58

        ' Card TextBox
        Dim txtCard As MSForms.TextBox
        Set txtCard = Me.Controls.Add("Forms.TextBox.1", "txtCard" & i, True)
        With txtCard: .Top = topPosition: .Left = headerLeft: .Width = 100: .Height = 20: .TextAlign = fmTextAlignCenter: .TabStop = True: .TabIndex = tabIdx: End With
        m_CardTextBoxes.Add txtCard, "Center" & i
        Call HookupTextBoxEvents(txtCard)
        headerLeft = headerLeft + 103

        ' Cash TextBox
        Dim txtCash As MSForms.TextBox
        Set txtCash = Me.Controls.Add("Forms.TextBox.1", "txtCash" & i, True)
        With txtCash: .Top = topPosition: .Left = headerLeft: .Width = 100: .Height = 20: .TextAlign = fmTextAlignCenter: .TabStop = True: .TabIndex = tabIdx: End With
        m_CashTextBoxes.Add txtCash, "Center" & i
        Call HookupTextBoxEvents(txtCash)
        tabIdx = tabIdx + 1
        headerLeft = headerLeft + 103

        txtCard.TabIndex = tabIdx
        tabIdx = tabIdx + 1

        ' Center Name Label
        Set lbl = Me.Controls.Add("Forms.Label.1", "lblCenter" & i, True)
 With lbl: .Caption = m_CenterNames(ActualCenterIndex(i)): .Top = topPosition + 2: .Left = headerLeft: .Width = 130:  .TextAlign = fmTextAlignRight: End With
        topPosition = topPosition + 26
    Next i

    '--- Daily Total Sales Row ---
    topPosition = topPosition + 8
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblTotalCaption", True)
    With lbl: .Caption = "��� ���� ���:": .Top = topPosition + 4: .Left = 670: .Width = 130: .TextAlign = fmTextAlignRight: End With

    Set m_lblTotalSales = Me.Controls.Add("Forms.Label.1", "lblTotalSales", True)
    With m_lblTotalSales: .Caption = "0": .Top = topPosition + 4: .Left = 565: .Width = 100: .Font.Bold = True: .BorderStyle = fmBorderStyleSingle: .TextAlign = fmTextAlignRight: End With
    topPosition = topPosition + 30

    '--- Submit Button ---
    Set m_btnSubmit = Me.Controls.Add("Forms.CommandButton.1", "btnSubmit", True)
    With m_btnSubmit: .Caption = "��� ������": .Top = topPosition: .Left = 400: .Width = 120: .Height = 28: .TabIndex = tabIdx: .TabStop = True: End With
    topPosition = topPosition + 40

   '--- Monthly Summary Section ---
    '--- Bottom Summary Section (Side by Side) ---
    topPosition = topPosition + 12

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSeparator", True)
    With lbl
        .Caption = "���������������������������������������������������������������������������������������������������������������������������"
        .Top = topPosition
        .Left = 10
        .Width = 590
        .TextAlign = fmTextAlignCenter
        .ForeColor = RGB(180, 180, 180)
    End With
    topPosition = topPosition + 18

    ' ============ LEFT SIDE: ����� ��� ============
    Dim leftColStart As Single
    leftColStart = 500

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSummaryTitle", True)
    With lbl
        .Caption = "����� ���"
        .Top = topPosition
        .Left = leftColStart + 60
        .Width = 100
        .TextAlign = fmTextAlignCenter
        .Font.Bold = True
        .ForeColor = RGB(80, 80, 80)
    End With

    ' ============ RIGHT SIDE: ���� ����� ============
    Dim rightColStart As Single
    rightColStart = 110

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblStatsTitle", True)
    With lbl
        .Caption = "���� �����"
        .Top = topPosition
        .Left = rightColStart + 80
        .Width = 100
        .TextAlign = fmTextAlignCenter
        .Font.Bold = True
        .ForeColor = RGB(80, 80, 80)
    End With

    topPosition = topPosition + 22

    ' --- LEFT COLUMN: Monthly Summary ---
    ' Row 1: ��� ���� ��ǘ�
    Set m_lblMonthlyTotalCenters = Me.Controls.Add("Forms.Label.1", "lblMonthlyTotalCenters", True)
    With m_lblMonthlyTotalCenters
        .Caption = "0"
        .Top = topPosition
        .Left = leftColStart
        .Width = 120
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(220, 255, 220)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthlyTotalCentersCaption", True)
    With lbl
        .Caption = "��� ���� ��ǘ�"
        .Top = topPosition + 2
        .Left = leftColStart + 125
        .Width = 100
        .TextAlign = fmTextAlignLeft
    End With

    ' --- RIGHT COLUMN: Day Statistics ---
    ' Row 1: ������� ���� ���
    Set m_lblMonthBestDay = Me.Controls.Add("Forms.Label.1", "lblMonthBestDay", True)
    With m_lblMonthBestDay
        .Caption = "-"
        .Top = topPosition
        .Left = rightColStart
        .Width = 140
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(200, 255, 200)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthBestDayCaption", True)
    With lbl
        .Caption = "������� ���� ���"
        .Top = topPosition + 2
        .Left = rightColStart + 145
        .Width = 110
        .TextAlign = fmTextAlignLeft
    End With

    topPosition = topPosition + 24

' Row 2 LEFT: ������ ���� ��ǘ�
      Set m_lblMonthlyTotalCentersAvg = Me.Controls.Add("Forms.Label.1", "lblMonthlyTotalCentersAvg", True)
      With m_lblMonthlyTotalCentersAvg
          .Caption = "0"
          .Top = topPosition
          .Left = leftColStart
          .Width = 120
          .Height = 20
          .Font.Bold = True
          .BorderStyle = fmBorderStyleSingle
          .TextAlign = fmTextAlignCenter
          .BackColor = RGB(230, 245, 255)
      End With

      Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthlyTotalCentersAvgCaption", True)
      With lbl
          .Caption = "������ ��ǘ�"
          .Top = topPosition + 2
          .Left = leftColStart + 125
          .Width = 100
          .TextAlign = fmTextAlignLeft
      End With
      
       ' Row 2 RIGHT: ������ ���� ���
    Set m_lblMonthWorstDay = Me.Controls.Add("Forms.Label.1", "lblMonthWorstDay", True)
    With m_lblMonthWorstDay
        .Caption = "-"
        .Top = topPosition
        .Left = rightColStart
        .Width = 140
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(255, 220, 220)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthWorstDayCaption", True)
    With lbl
        .Caption = "������ ���� ���"
        .Top = topPosition + 2
        .Left = rightColStart + 145
        .Width = 110
        .TextAlign = fmTextAlignLeft
    End With

      topPosition = topPosition + 24

    ' Row 3 LEFT: ��� ������
    Set m_lblMonthlyBimeha = Me.Controls.Add("Forms.Label.1", "lblMonthlyBimeha", True)
    With m_lblMonthlyBimeha
        .Caption = "0"
        .Top = topPosition
        .Left = leftColStart
        .Width = 120
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(255, 255, 200)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthlyBimehaCaption", True)
    With lbl
        .Caption = "��� ������"
        .Top = topPosition + 2
        .Left = leftColStart + 125
        .Width = 100
        .TextAlign = fmTextAlignLeft
    End With
 ' Row 3 RIGHT: ������� ���� ���
    Set m_lblYearBestDay = Me.Controls.Add("Forms.Label.1", "lblYearBestDay", True)
    With m_lblYearBestDay
        .Caption = "-"
        .Top = topPosition
        .Left = rightColStart
        .Width = 140
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(180, 255, 180)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearBestDayCaption", True)
    With lbl
        .Caption = "������� ���� ���"
        .Top = topPosition + 2
        .Left = rightColStart + 145
        .Width = 110
        .TextAlign = fmTextAlignLeft
    End With
'    ' Row 2 RIGHT: ������ ���� ���
'    Set m_lblMonthWorstDay = Me.Controls.Add("Forms.Label.1", "lblMonthWorstDay", True)
'    With m_lblMonthWorstDay
'        .Caption = "-"
'        .Top = topPosition
'        .Left = rightColStart
'        .Width = 140
'        .Height = 20
'        .Font.Bold = True
'        .BorderStyle = fmBorderStyleSingle
'        .TextAlign = fmTextAlignCenter
'        .BackColor = RGB(255, 220, 220)
'    End With
'
'    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthWorstDayCaption", True)
'    With lbl
'        .Caption = "������ ���� ���"
'        .Top = topPosition + 2
'        .Left = rightColStart + 145
'        .Width = 110
'        .TextAlign = fmTextAlignLeft
'    End With

    topPosition = topPosition + 24

    ' Row 3 LEFT: ��� �� ���
    Set m_lblMonthlyGrandTotal = Me.Controls.Add("Forms.Label.1", "lblMonthlyGrandTotal", True)
    With m_lblMonthlyGrandTotal
        .Caption = "0"
        .Top = topPosition
        .Left = leftColStart
        .Width = 120
        .Height = 20
        .Font.Bold = True
        .Font.Size = 10
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(200, 220, 255)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonthlyGrandTotalCaption", True)
    With lbl
        .Caption = "��� �� ���"
        .Top = topPosition + 2
        .Left = leftColStart + 125
        .Width = 100
        .TextAlign = fmTextAlignLeft
        .Font.Bold = True
    End With
        ' Row 4 RIGHT ONLY: ������ ���� ���
    Set m_lblYearWorstDay = Me.Controls.Add("Forms.Label.1", "lblYearWorstDay", True)
    With m_lblYearWorstDay
        .Caption = "-"
        .Top = topPosition
        .Left = rightColStart
        .Width = 140
        .Height = 20
        .Font.Bold = True
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(255, 200, 200)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearWorstDayCaption", True)
    With lbl
        .Caption = "������ ���� ���"
        .Top = topPosition + 2
        .Left = rightColStart + 145
        .Width = 110
        .TextAlign = fmTextAlignLeft
    End With

'    ' Row 3 RIGHT: ������� ���� ���
'    Set m_lblYearBestDay = Me.Controls.Add("Forms.Label.1", "lblYearBestDay", True)
'    With m_lblYearBestDay
'        .Caption = "-"
'        .Top = topPosition
'        .Left = rightColStart
'        .Width = 140
'        .Height = 20
'        .Font.Bold = True
'        .BorderStyle = fmBorderStyleSingle
'        .TextAlign = fmTextAlignCenter
'        .BackColor = RGB(180, 255, 180)
'    End With
'
'    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearBestDayCaption", True)
'    With lbl
'        .Caption = "������� ���� ���"
'        .Top = topPosition + 2
'        .Left = rightColStart + 145
'        .Width = 110
'        .TextAlign = fmTextAlignLeft
'    End With

    topPosition = topPosition + 24

'    ' Row 4 RIGHT ONLY: ������ ���� ���
'    Set m_lblYearWorstDay = Me.Controls.Add("Forms.Label.1", "lblYearWorstDay", True)
'    With m_lblYearWorstDay
'        .Caption = "-"
'        .Top = topPosition
'        .Left = rightColStart
'        .Width = 140
'        .Height = 20
'        .Font.Bold = True
'        .BorderStyle = fmBorderStyleSingle
'        .TextAlign = fmTextAlignCenter
'        .BackColor = RGB(255, 200, 200)
'    End With
'
'    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearWorstDayCaption", True)
'    With lbl
'        .Caption = "������ ���� ���"
'        .Top = topPosition + 2
'        .Left = rightColStart + 145
'        .Width = 110
'        .TextAlign = fmTextAlignLeft
'    End With

    topPosition = topPosition + 28

    '--- Yearly Totals Section ---
    topPosition = topPosition + 12

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearTotalTitle", True)
    With lbl
        .Caption = "��� �� ��� �� ���� �ј�"
        .Top = topPosition
        .Left = 10
        .Width = 880
        .TextAlign = fmTextAlignCenter
        .Font.Bold = True
        .ForeColor = RGB(60, 60, 160)
    End With
    topPosition = topPosition + 22

    ' One label per center
    Dim yearColLeft As Single
    yearColLeft = 10
    Dim lblYearCenter As MSForms.Label

    For i = 1 To m_ActiveCenterCount
        Set lblYearCenter = Me.Controls.Add("Forms.Label.1", "lblYearTotal" & i, True)
        With lblYearCenter
            .Caption = "0"
            .Top = topPosition
            .Left = yearColLeft
            .Width = 120
            .Height = 22
            .Font.Bold = True
            .Font.Size = 9
            .BorderStyle = fmBorderStyleSingle
            .TextAlign = fmTextAlignCenter
            .BackColor = RGB(230, 240, 255)
        End With
        m_YearTotalLabels.Add lblYearCenter, "Center" & i

        Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearTotalCaption" & i, True)
        With lbl
            .Caption = m_CenterNames(ActualCenterIndex(i))

            .Top = topPosition + 3
            .Left = yearColLeft + 124
            .Width = 80
            .TextAlign = fmTextAlignLeft
            .Font.Size = 9
        End With

        yearColLeft = yearColLeft + 215
        If yearColLeft > 700 Then
            yearColLeft = 10
            topPosition = topPosition + 26
        End If
    Next i

    topPosition = topPosition + 30

    ' Grand total of all centers for the year
    Set m_lblYearGrandTotal = Me.Controls.Add("Forms.Label.1", "lblYearGrandTotal", True)
    With m_lblYearGrandTotal
        .Caption = "0"
        .Top = topPosition
        .Left = 10
        .Width = 180
        .Height = 26
        .Font.Bold = True
        .Font.Size = 12
        .BorderStyle = fmBorderStyleSingle
        .TextAlign = fmTextAlignCenter
        .BackColor = RGB(200, 215, 255)
    End With

    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYearGrandTotalCaption", True)
    With lbl
        .Caption = "��� �� ���"
        .Top = topPosition + 4
        .Left = 195
        .Width = 100
        .TextAlign = fmTextAlignLeft
        .Font.Bold = True
    End With

    topPosition = topPosition + 34
'--- Finalize Form Size ---
    Dim requiredHeight As Single
    requiredHeight = topPosition + 20

    Me.ScrollBars = fmScrollBarsNone  ' Remove scrollbar if not needed

    If requiredHeight > 500 Then
        Me.Height = 500
        Me.ScrollBars = fmScrollBarsVertical
        Me.ScrollHeight = requiredHeight
    Else
        Me.Height = requiredHeight
    End If

    ' Load yesterday's date and data
    Call LoadYesterdayDate

    ' Update all statistics
    Call UpdateLastEntryLabels
    Call UpdateMonthlySummary
    Call UpdateMonthlyStatistics
    Call UpdateYearlyStatistics
    Call UpdateOverallDayStatistics
    Call UpdateYearlyTotals
    Call FocusFirstEmptyCenter

End Sub

Private Sub UserForm_Activate()
    SetKeyboardEnglish
End Sub

'====================================================================================================
'                                    MONTHLY SUMMARY FUNCTIONS
'====================================================================================================


'----------------------------------------
' Update all monthly summary labels
'----------------------------------------
Private Sub UpdateMonthlySummary()
    Dim ws As Worksheet
    Dim ym As String
    Dim i As Long
  Dim centerSum As Double
  Dim totalCentersSum As Double
  Dim bimehaSum As Double
  Dim daysWithCentersData As Long
  Dim avgCentersSum As Double

    On Error Resume Next

    If m_cboYear.value = "" Or m_cboMonth.value = "" Then Exit Sub
    If m_MonthlySumLabels Is Nothing Then Exit Sub

    ym = m_cboYear.value & "/" & Format(CInt(m_cboMonth.value), "00")
    Set ws = FindSheet(ym)

  If ws Is Nothing Then
      For i = 1 To m_ActiveCenterCount
          m_MonthlySumLabels(i).Caption = "0"
      Next i

      m_lblMonthlyTotalCenters.Caption = "0"
      m_lblMonthlyTotalCentersAvg.Caption = "0"
      m_lblMonthlyBimeha.Caption = "0"
      m_lblMonthlyGrandTotal.Caption = "0"
      Exit Sub
  End If

    Application.StatusBar = "�� ��� ������ ����� ���..."

    ' Calculate row structure
    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    totalCentersSum = 0
     daysWithCentersData = CountMonthlyDaysWithCentersData(ws, totalRowsPerDayBlock)

    ' Calculate sum for each center (access by index, not key)
    For i = 1 To m_ActiveCenterCount
centerSum = CalculateMonthlySumForCenter(ws, ActualCenterIndex(i), totalRowsPerDayBlock)
        ' Make sure centerSum is valid
        If IsError(centerSum) Or IsEmpty(centerSum) Then
            centerSum = 0
        End If

        m_MonthlySumLabels(i).Caption = Format(centerSum, "#,##0")
        totalCentersSum = totalCentersSum + centerSum
    Next i

    ' Calculate bimeha sum
    bimehaSum = CalculateMonthlyBimehaSum(ws, totalRowsPerDayBlock)
    If IsError(bimehaSum) Or IsEmpty(bimehaSum) Then
        bimehaSum = 0
    End If
    
If daysWithCentersData > 0 Then
      avgCentersSum = totalCentersSum / daysWithCentersData
  Else
      avgCentersSum = 0
  End If
  
    ' Update summary labels
    m_lblMonthlyTotalCenters.Caption = Format(totalCentersSum, "#,##0")
    m_lblMonthlyTotalCentersAvg.Caption = Format(avgCentersSum, "#,##0")
    m_lblMonthlyBimeha.Caption = Format(bimehaSum, "#,##0")
    m_lblMonthlyGrandTotal.Caption = Format(totalCentersSum + bimehaSum, "#,##0")

    Application.StatusBar = False
    On Error GoTo 0
End Sub

'----------------------------------------
' Calculate monthly sum for a specific center
'----------------------------------------
Private Function CalculateMonthlySumForCenter(ws As Worksheet, centerNum As Long, totalRowsPerDayBlock As Long) As Double
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim centerRow As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim total As Double

    total = 0

    For dayNum = 1 To 31
        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

        ' Check if day exists
        If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
            If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                ' Calculate center row
                If m_UserCenters = 1 Then
                    centerRow = dayStartRow
                Else
                    centerRow = dayStartRow + (centerNum - 1)
                End If

                ' Add Cash (Column C)
                cashValue = ws.Cells(centerRow, "C").value
                If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then
                    total = total + CDbl(cashValue)
                End If

                ' Add Card (Column D)
                cardValue = ws.Cells(centerRow, "D").value
                If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then
                    total = total + CDbl(cardValue)
                End If
            End If
        End If
    Next dayNum

    CalculateMonthlySumForCenter = total
End Function

'----------------------------------------
' Calculate monthly bimeha sum
'----------------------------------------
Private Function CalculateMonthlyBimehaSum(ws As Worksheet, totalRowsPerDayBlock As Long) As Double
    Dim fixedSummaryStartRow As Long
    Dim insuranceStartRow As Long
    Dim total As Double
    Dim rowNum As Long
    Dim cellValue As Variant
    Dim insuranceCount As Long

    ' Calculate insurance start row (same logic as sabtBimeha form)
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    insuranceStartRow = fixedSummaryStartRow + 10 + m_UserCenters + 1

    ' Count insurance types (8 base + 3 per additional center)
    insuranceCount = 8
    If m_UserCenters > 1 Then
        insuranceCount = insuranceCount + (m_UserCenters - 1) * 3
    End If

    total = 0

    ' Sum all insurance values in Column C
    For rowNum = insuranceStartRow To insuranceStartRow + insuranceCount - 1
        cellValue = ws.Cells(rowNum, "C").value
        If IsNumeric(cellValue) And Not IsEmpty(cellValue) Then
            total = total + CDbl(cellValue)
        End If
    Next rowNum

    CalculateMonthlyBimehaSum = total
End Function

'====================================================================================================
'                                    LAST ENTRY DATE FUNCTIONS
'====================================================================================================

Private Sub UpdateLastEntryLabels()
    Dim i As Long
    Dim lastDate As String
    Dim rowsPerDayBlock As Long
    Dim totalRowsPerDayBlock As Long

    If m_LastEntryLabels Is Nothing Then Exit Sub

    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    Application.StatusBar = "�� ��� ��������� ����� ����Ν��..."

    For i = 1 To m_ActiveCenterCount
lastDate = FindLastEntryDateForCenter(ActualCenterIndex(i), totalRowsPerDayBlock)
        If lastDate <> "" And lastDate <> "---" Then
            Dim parts() As String
            parts = Split(lastDate, "/")
            If UBound(parts) = 2 Then
                m_LastEntryLabels("Center" & i).Caption = parts(1) & "/" & parts(2)
                Call ColorCodeLastEntryLabel(m_LastEntryLabels("Center" & i), lastDate)
            Else
                m_LastEntryLabels("Center" & i).Caption = "---"
                m_LastEntryLabels("Center" & i).BackColor = RGB(255, 200, 200)
            End If
        Else
            m_LastEntryLabels("Center" & i).Caption = "---"
            m_LastEntryLabels("Center" & i).BackColor = RGB(255, 200, 200)
        End If
    Next i

    Application.StatusBar = False
End Sub

Private Function FindLastEntryDateForCenter(centerNum As Long, totalRowsPerDayBlock As Long) As String
    Dim ws As Worksheet
    Dim configSheet As Worksheet
    Dim currentYear As Long
    Dim currentMonth As Long
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim centerRow As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim ym As String
    Dim searchYear As Long
    Dim searchMonth As Long
    Dim m As Long

    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    currentYear = configSheet.Range("AC1").value
    currentMonth = configSheet.Range("AC2").value
    On Error GoTo 0

    If currentYear = 0 Or currentYear < 1300 Then currentYear = 1403
    If currentMonth = 0 Or currentMonth < 1 Or currentMonth > 12 Then currentMonth = 1

    For m = 0 To 11
        searchMonth = currentMonth - m
        searchYear = currentYear

        Do While searchMonth < 1
            searchMonth = searchMonth + 12
            searchYear = searchYear - 1
        Loop

        ym = CStr(searchYear) & "/" & Format(searchMonth, "00")

        Set ws = Nothing
        Set ws = FindSheet(ym)

        If Not ws Is Nothing Then
            For dayNum = 31 To 1 Step -1
                dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

                If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
                    If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                        If m_UserCenters = 1 Then
                            centerRow = dayStartRow
                        Else
                            centerRow = dayStartRow + (centerNum - 1)
                        End If

                        cashValue = ws.Cells(centerRow, "C").value
                        cardValue = ws.Cells(centerRow, "D").value

                        If HasActualNumericData(cashValue) Or HasActualNumericData(cardValue) Then
                            FindLastEntryDateForCenter = searchYear & "/" & Format(searchMonth, "00") & "/" & Format(dayNum, "00")
                            Exit Function
                        End If
                    End If
                End If
            Next dayNum
        End If
    Next m

    FindLastEntryDateForCenter = ""
End Function

Private Function HasActualNumericData(cellValue As Variant) As Boolean
    Dim strValue As String

    If IsEmpty(cellValue) Or IsNull(cellValue) Then
        HasActualNumericData = False
        Exit Function
    End If

    strValue = Trim(CStr(cellValue))

    If Len(strValue) = 0 Then
        HasActualNumericData = False
        Exit Function
    End If

    strValue = Replace(strValue, " ", "")
    strValue = Replace(strValue, Chr(160), "")
    If Len(strValue) = 0 Then
        HasActualNumericData = False
        Exit Function
    End If

    If IsNumeric(cellValue) Then
        If CDbl(cellValue) > 0 Then
            HasActualNumericData = True
        Else
            HasActualNumericData = False
        End If
    Else
        HasActualNumericData = False
    End If
End Function

Private Sub ColorCodeLastEntryLabel(lbl As MSForms.Label, lastDateStr As String)
    Dim configSheet As Worksheet
    Dim currentYear As Long
    Dim currentMonth As Long
    Dim currentDay As Long
    Dim lastYear As Long
    Dim lastMonth As Long
    Dim lastDay As Long
    Dim daysDiff As Long
    Dim parts() As String

    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    currentYear = configSheet.Range("AC1").value
    currentMonth = configSheet.Range("AC2").value
    currentDay = configSheet.Range("AE1").value
    On Error GoTo 0

    If currentDay = 0 Then currentDay = day(Date) - 20
    If currentDay < 1 Then currentDay = 1

    parts = Split(lastDateStr, "/")
    If UBound(parts) <> 2 Then
        lbl.BackColor = RGB(255, 200, 200)
        Exit Sub
    End If

    lastYear = CLng(parts(0))
    lastMonth = CLng(parts(1))
    lastDay = CLng(parts(2))

    daysDiff = (currentYear - lastYear) * 365 + (currentMonth - lastMonth) * 30 + (currentDay - lastDay)

    Select Case daysDiff
        Case Is <= 1
            lbl.BackColor = RGB(200, 255, 200)
        Case 2 To 3
            lbl.BackColor = RGB(255, 255, 200)
        Case 4 To 7
            lbl.BackColor = RGB(255, 220, 180)
        Case Else
            lbl.BackColor = RGB(255, 200, 200)
    End Select
End Sub

'====================================================================================================
'                                    EVENT HANDLERS
'====================================================================================================

Private Sub HookupTextBoxEvents(ByVal txtBox As MSForms.TextBox)
    Dim TBoxEvent As clsAdvancedTextBox
    Set TBoxEvent = New clsAdvancedTextBox
    Set TBoxEvent.ParentForm = Me
    Set TBoxEvent.TBox = txtBox
    TBoxEvent.EnableLiveTotalUpdate = True
    TBoxEvent.TreatSpaceAsPlus = True       ' NEW: Enable space as plus
    TBoxEvent.EvaluateExpressions = True    ' NEW: Enable expression evaluation
    m_TextBoxEvents.Add TBoxEvent
End Sub

Private Sub m_btnDayPicker_Click()
    On Error GoTo ErrDay

    If m_cboYear.value = "" Or m_cboMonth.value = "" Then
        MsgBox "����� ��� � ��� �� ������ ����.", vbExclamation, "����� ����"
        Exit Sub
    End If

    With frmDayPicker
        .currentYear = CLng(m_cboYear.value)
        .currentMonth = CInt(m_cboMonth.value)
        .selectedDay = ""
        .Show

        If Len(.selectedDay) > 0 Then
            m_lblDay.Caption = .selectedDay
            Call ClearDataTextBoxes
            Call LoadDataForDay
        End If
    End With

    Exit Sub
ErrDay:
    MsgBox "��� �� ������ ���: " & Err.description, vbCritical
End Sub

Private Sub m_btnSubmit_Click()
    Dim ws As Worksheet
    Dim ym As String, dayLabel As String
    Dim dayNum As Long, blockStartRow As Long
    Dim i As Long

    If m_cboYear.value = "" Or m_cboMonth.value = "" Or m_lblDay.Caption = "" Then
        MsgBox "����� ��� ��� � ��� �� ������ ����.", vbExclamation
        Exit Sub
    End If

    ym = m_cboYear.value & "/" & Format(CInt(m_cboMonth.value), "00")
    dayLabel = m_lblDay.Caption
    dayNum = val(dayLabel)

    If dayNum < 1 Or dayNum > 31 Then
        MsgBox "��� �������: " & dayLabel, vbExclamation
        Exit Sub
    End If

    Set ws = FindSheet(ym)
    If ws Is Nothing Then
        MsgBox "���� �� ����� B1 ����� " & ym & " ���� ���.", vbExclamation
        Exit Sub
    End If

    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1
    blockStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

    ForceFormatAll

    Dim needsOverwriteConfirm As Boolean
    needsOverwriteConfirm = False
 For i = 1 To m_ActiveCenterCount
      Dim actualCenter As Long
      actualCenter = ActualCenterIndex(i)
      If Trim(m_CashTextBoxes("Center" & i).value) <> "" And Trim(CStr(ws.Cells(blockStartRow + (actualCenter - 1), "C").value)) <> "" Then
            needsOverwriteConfirm = True
            Exit For
        End If
        If Trim(m_CardTextBoxes("Center" & i).value) <> "" And Trim(CStr(ws.Cells(blockStartRow + (actualCenter - 1), "D").value)) <> "" Then
            needsOverwriteConfirm = True
            Exit For
        End If
    Next i

    If needsOverwriteConfirm Then
        If MsgBox("���� �� ������ ����� ������� �����. ��� �������� ����� ���� � ������� ���� �� ������ ���Ͽ", vbYesNo + vbQuestion, "����� �������") = vbNo Then
            Exit Sub
        End If
    End If

For i = 1 To m_ActiveCenterCount
      actualCenter = ActualCenterIndex(i)
      Dim cashValue As String, cardValue As String
        cashValue = Trim(m_CashTextBoxes("Center" & i).value)
        cardValue = Trim(m_CardTextBoxes("Center" & i).value)

        If cashValue <> "" Then
            ws.Cells(blockStartRow + (actualCenter - 1), "C").value = EvaluateExpression(cashValue)
        Else
            ws.Cells(blockStartRow + (actualCenter - 1), "C").ClearContents
        End If

        If cardValue <> "" Then
      ws.Cells(blockStartRow + (actualCenter - 1), "D").value = EvaluateExpression(cardValue)
  Else
      ws.Cells(blockStartRow + (actualCenter - 1), "D").ClearContents
  End If
    Next i

    MsgBox "������ �� ������ ��� ��.", vbInformation

    ' Update all labels after saving
    Call UpdateLastEntryLabels
    Call UpdateMonthlySummary
    Call UpdateMonthlyStatistics
    Call UpdateYearlyStatistics
    Call IncrementDay
    Call UpdateOverallDayStatistics
    Call UpdateYearlyTotals
    Call FocusFirstEmptyCenter

End Sub

Private Sub m_cboYear_Change()
    Call ClearDataTextBoxes
    Call UpdateMonthlySummary
    Call UpdateMonthlyStatistics
    Call UpdateYearlyStatistics
    Call UpdateYearlyTotals
    Call UpdateOverallDayStatistics
End Sub



'====================================================================================================
'                                    HELPER FUNCTIONS
'====================================================================================================

Private Sub ClearDataTextBoxes()
    Dim ctrl As MSForms.TextBox
    On Error Resume Next
    For Each ctrl In m_CashTextBoxes
        ctrl.value = ""
    Next ctrl
    For Each ctrl In m_CardTextBoxes
        ctrl.value = ""
    Next ctrl
    Call UpdateTotalLabel
    On Error GoTo 0
End Sub
  Private Function ActualCenterIndex(ByVal visibleCenterIndex As Long) As Long
      ActualCenterIndex = CLng(m_ActiveCenters(visibleCenterIndex))
  End Function
 Private Function ReadConfiguration() As Boolean
      Dim wsInfo As Worksheet, i As Long
      Dim activeMark As String

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets("�������")
      If wsInfo Is Nothing Then GoTo ConfigFail

      m_UserCenters = wsInfo.Range("cfg_ActualUserCenters").value
      m_TotalCenters = wsInfo.Range("cfg_TotalCenters").value

      Set m_CenterNames = CreateObject("Scripting.Dictionary")
      Set m_ActiveCenters = CreateObject("Scripting.Dictionary")
      m_ActiveCenterCount = 0

      For i = 1 To m_UserCenters
          m_CenterNames.Add i, wsInfo.Cells(i + 1, "AA").value

          activeMark = Trim(CStr(wsInfo.Cells(i + 1, "Z").value))
          If activeMark = "*" Then
              m_ActiveCenterCount = m_ActiveCenterCount + 1
              m_ActiveCenters.Add m_ActiveCenterCount, i
          End If
      Next i

      If Err.Number <> 0 Or m_UserCenters = 0 Or m_TotalCenters = 0 Or m_ActiveCenterCount = 0 Then
ConfigFail:
          ReadConfiguration = False
      Else
          ReadConfiguration = True
      End If

      On Error GoTo 0
  End Function

Private Sub IncrementDay()
    Dim currentYear As Long
    Dim currentMonth As Long
    Dim currentDay As Long
    Dim daysInMonth As Long

    If m_cboYear.value = "" Or m_cboMonth.value = "" Or m_lblDay.Caption = "" Then Exit Sub

    currentYear = CLng(m_cboYear.value)
    currentMonth = CLng(m_cboMonth.value)
    currentDay = CLng(m_lblDay.Caption)

    daysInMonth = GetPersianMonthDays(currentYear, currentMonth)

    currentDay = currentDay + 1

    If currentDay > daysInMonth Then
        currentDay = 1
        currentMonth = currentMonth + 1

        If currentMonth > 12 Then
            currentMonth = 1
            currentYear = currentYear + 1
        End If

        m_cboYear.value = CStr(currentYear)
        m_cboMonth.value = CStr(currentMonth)
    End If

    m_lblDay.Caption = CStr(currentDay)

    Call ClearDataTextBoxes
    Call LoadDataForDay
End Sub

Private Function EvaluateExpression(expr As String) As Double
    Dim cleanExpr As String

    If Trim(expr) = "" Then
        EvaluateExpression = 0
        Exit Function
    End If

    cleanExpr = expr

    ' Convert Persian numbers to English
    cleanExpr = ConvertPersianNumsToEnglish(cleanExpr)

    ' Remove commas
    cleanExpr = Replace(cleanExpr, ",", "")

    ' IMPORTANT: Replace spaces with + (treat space as plus)
    ' First, normalize multiple spaces to single space
    Do While InStr(cleanExpr, "  ") > 0
        cleanExpr = Replace(cleanExpr, "  ", " ")
    Loop

    ' Trim leading/trailing spaces
    cleanExpr = Trim(cleanExpr)

    ' Replace space with + (for addition shortcut)
    cleanExpr = Replace(cleanExpr, " ", "+")

    ' Handle double operators that might result from space replacement
    cleanExpr = Replace(cleanExpr, "++", "+")
    cleanExpr = Replace(cleanExpr, "+-", "-")
    cleanExpr = Replace(cleanExpr, "-+", "-")
    cleanExpr = Replace(cleanExpr, "*+", "*")
    cleanExpr = Replace(cleanExpr, "/+", "/")
    cleanExpr = Replace(cleanExpr, "+*", "*")
    cleanExpr = Replace(cleanExpr, "+/", "/")

    On Error GoTo Fail
    EvaluateExpression = CDbl(Application.Evaluate(cleanExpr))
    Exit Function

Fail:
    EvaluateExpression = 0
End Function

Private Function FindSheet(ym As String) As Worksheet
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set FindSheet = sht
            Exit Function
        End If
    Next sht
End Function

Private Sub LoadDataForDay()
    Dim ws As Worksheet
    Dim ym As String, dayLabel As String
    Dim dayNum As Long, blockStartRow As Long
    Dim i As Long

    If m_cboYear.value = "" Or m_cboMonth.value = "" Or m_lblDay.Caption = "" Then Exit Sub

    ym = m_cboYear.value & "/" & Format(CInt(m_cboMonth.value), "00")
    dayLabel = m_lblDay.Caption
    dayNum = val(dayLabel)

    Set ws = FindSheet(ym)
    If ws Is Nothing Then
        ' No sheet found - focus on first Cash
        Call FocusFirstEmptyCenter
        Exit Sub
    End If

    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1
    blockStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

    ' Load data for each center
For i = 1 To m_ActiveCenterCount
      Dim actualCenter As Long
      actualCenter = ActualCenterIndex(i)

      With ws.Cells(blockStartRow + (actualCenter - 1), "C")
      If IsNumeric(.value) And .value <> 0 Then
                m_CashTextBoxes("Center" & i).value = .value
            Else
                m_CashTextBoxes("Center" & i).value = ""
            End If
        End With
       With ws.Cells(blockStartRow + (actualCenter - 1), "D")
            If IsNumeric(.value) And .value <> 0 Then
                m_CardTextBoxes("Center" & i).value = .value
            Else
                m_CardTextBoxes("Center" & i).value = ""
            End If
        End With
    Next i

    Call ForceFormatAll
    Call UpdateTotalLabel

    ' Focus on first empty center (or first center if all have data)
    Call FocusFirstEmptyCenter
End Sub
Public Sub UpdateTotalLabel()
    On Error Resume Next
    Dim total As Double
    Dim ctrl As MSForms.TextBox
    total = 0

    For Each ctrl In m_CashTextBoxes
        total = total + EvaluateExpression(ctrl.value)
    Next ctrl

    For Each ctrl In m_CardTextBoxes
        total = total + EvaluateExpression(ctrl.value)
    Next ctrl

    m_lblTotalSales.Caption = Format(total, "#,##0")
    On Error GoTo 0
End Sub

Public Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    Dim i As Long
    result = inputText
    For i = 1776 To 1785: result = Replace(result, ChrW(i), CStr(i - 1776)): Next i
    For i = 1632 To 1641: result = Replace(result, ChrW(i), CStr(i - 1632)): Next i
    For i = 65296 To 65305: result = Replace(result, ChrW(i), CStr(i - 65296)): Next i
    ConvertPersianNumsToEnglish = result
End Function

Public Sub ForceFormatAll()
    Dim k As Long
    Dim raw As String, conv As String
    If m_CardTextBoxes Is Nothing Then Exit Sub
    If m_CashTextBoxes Is Nothing Then Exit Sub

    For k = 1 To m_CardTextBoxes.count
        raw = Trim(m_CardTextBoxes(k).value)
        If raw <> "" Then
            raw = Replace(raw, ",", ""): raw = Replace(raw, " ", "")
            conv = ConvertPersianNumsToEnglish(raw)
            If IsNumeric(conv) Then m_CardTextBoxes(k).value = Format(CDbl(conv), "#,##0")
        End If
    Next k

    For k = 1 To m_CashTextBoxes.count
        raw = Trim(m_CashTextBoxes(k).value)
        If raw <> "" Then
            raw = Replace(raw, ",", ""): raw = Replace(raw, " ", "")
            conv = ConvertPersianNumsToEnglish(raw)
            If IsNumeric(conv) Then m_CashTextBoxes(k).value = Format(CDbl(conv), "#,##0")
        End If
    Next k

    DoEvents
    Me.Repaint
End Sub
  Private Function CountMonthlyDaysWithCentersData(ws As Worksheet, totalRowsPerDayBlock As Long) As Long
      Dim dayNum As Long
      Dim dayStartRow As Long
      Dim centerRow As Long
      Dim i As Long
      Dim actualCenter As Long
      Dim dayTotal As Double
      Dim cashValue As Variant
      Dim cardValue As Variant

      CountMonthlyDaysWithCentersData = 0

      For dayNum = 1 To 31
          dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

          If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
              If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                  dayTotal = 0

                  For i = 1 To m_ActiveCenterCount
                      actualCenter = ActualCenterIndex(i)
                      centerRow = IIf(m_UserCenters = 1, dayStartRow, dayStartRow + (actualCenter - 1))

                      cashValue = ws.Cells(centerRow, "C").value
                      cardValue = ws.Cells(centerRow, "D").value

                      If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then dayTotal = dayTotal + CDbl(cashValue)
                      If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then dayTotal = dayTotal + CDbl(cardValue)
                  Next i

                  If dayTotal > 0 Then CountMonthlyDaysWithCentersData = CountMonthlyDaysWithCentersData + 1
              End If
          End If
      Next dayNum
  End Function

Private Function GregorianToPersian(gDate As Date) As String
    Dim days_diff As Long, p_y As Long, p_m As Long, p_d As Long, days_in_p_year As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 20)
    days_diff = gDate - ref_g_date
    p_y = 1403

    If days_diff < 0 Then
        Do
            p_y = p_y - 1
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            days_diff = days_diff + days_in_p_year
            If days_diff >= 0 Then Exit Do
        Loop
    Else
        Do
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            If days_diff >= days_in_p_year Then
                days_diff = days_diff - days_in_p_year
                p_y = p_y + 1
            Else
                Exit Do
            End If
        Loop
    End If

    p_m = 1
    Do While p_m <= 12
        Dim p_days_in_month As Long
        If p_m >= 1 And p_m <= 6 Then
            p_days_in_month = 31
        ElseIf p_m >= 7 And p_m <= 11 Then
            p_days_in_month = 30
        Else
            p_days_in_month = IIf(((p_y - 1403) Mod 4 = 0), 30, 29)
        End If

        If days_diff < p_days_in_month Then Exit Do
        days_diff = days_diff - p_days_in_month
        p_m = p_m + 1
    Loop

    p_d = days_diff + 1
    GregorianToPersian = p_y & "/" & Format(p_m, "00") & "/" & Format(p_d, "00")
End Function

Private Function GetPersianMonthDays(pYear As Long, pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        GetPersianMonthDays = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        GetPersianMonthDays = 30
    ElseIf pMonth = 12 Then
        GetPersianMonthDays = IIf(((pYear - 1403) Mod 4 = 0), 30, 29)
    Else
        GetPersianMonthDays = 0
    End If
End Function

Private Sub LoadYesterdayDate()
    Dim todayPersian As String
    Dim parts() As String

    todayPersian = GregorianToPersian(Date - 1)
    parts = Split(todayPersian, "/")

    If UBound(parts) = 2 Then
        m_cboYear.value = parts(0)
        m_cboMonth.value = CStr(CLng(parts(1)))
        m_lblDay.Caption = CStr(CLng(parts(2)))
        Call LoadDataForDay
    End If
End Sub

'----------------------------------------
' Hook up click event for last entry label
'----------------------------------------
Private Sub HookupLabelClickEvent(ByVal lbl As MSForms.Label, ByVal centerNum As Long)
    Dim lblEvent As clsLabelClick
    Set lblEvent = New clsLabelClick
    Set lblEvent.Label = lbl
    Set lblEvent.ParentForm = Me
    lblEvent.CenterNumber = centerNum

    If m_LabelClickEvents Is Nothing Then
        Set m_LabelClickEvents = New Collection
    End If
    m_LabelClickEvents.Add lblEvent
End Sub

'----------------------------------------
' Navigate to the day after the last entry date for a center
'----------------------------------------
Public Sub NavigateToNextDayAfterLabel(centerNum As Long)
    Dim lastDateStr As String
    Dim parts() As String
    Dim lastYear As Long, lastMonth As Long, lastDay As Long
    Dim nextYear As Long, NextMonth As Long, NextDay As Long
    Dim daysInMonth As Long
    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long

    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    ' Get the full last entry date for this center
 lastDateStr = FindLastEntryDateForCenter(ActualCenterIndex(centerNum), totalRowsPerDayBlock)
    If lastDateStr = "" Or lastDateStr = "---" Then
        MsgBox "����� ����� ���� ���� ��� �ј� ���� ���.", vbExclamation
        Exit Sub
    End If

    ' Parse the date
    parts = Split(lastDateStr, "/")
    If UBound(parts) <> 2 Then Exit Sub

    lastYear = CLng(parts(0))
    lastMonth = CLng(parts(1))
    lastDay = CLng(parts(2))

    ' Calculate next day
    nextYear = lastYear
    NextMonth = lastMonth
    NextDay = lastDay + 1

    daysInMonth = GetPersianMonthDays(lastYear, lastMonth)

    If NextDay > daysInMonth Then
        NextDay = 1
        NextMonth = NextMonth + 1

        If NextMonth > 12 Then
            NextMonth = 1
            nextYear = nextYear + 1
        End If
    End If

    ' Update form controls
    m_cboYear.value = CStr(nextYear)
    m_cboMonth.value = CStr(NextMonth)
    m_lblDay.Caption = CStr(NextDay)

    ' Clear and load data for the new day
    Call ClearDataTextBoxes
    Call LoadDataForDay
    Call UpdateMonthlySummary

' Set focus to first empty center's Cash textbox
    Call FocusFirstEmptyCenter
End Sub

'====================================================================================================
'                                    MONTHLY STATISTICS FUNCTIONS
'====================================================================================================

'----------------------------------------
' Update monthly statistics (high, low, avg) for all centers
'----------------------------------------
Private Sub UpdateMonthlyStatistics()
    Dim ws As Worksheet
    Dim ym As String
    Dim i As Long
    Dim highDay As Long, highAmount As Double
    Dim lowDay As Long, lowAmount As Double
    Dim avgAmount As Double
    Dim daysWithData As Long


    On Error Resume Next

    If m_cboYear.value = "" Or m_cboMonth.value = "" Then Exit Sub
    If m_MonthHighLabels Is Nothing Then Exit Sub

    ym = m_cboYear.value & "/" & Format(CInt(m_cboMonth.value), "00")
    Set ws = FindSheet(ym)

    If ws Is Nothing Then
        ' Clear all labels if no sheet found
        For i = 1 To m_ActiveCenterCount
            m_MonthHighLabels(i).Caption = "-"
            m_MonthLowLabels(i).Caption = "-"
            m_MonthAvgLabels(i).Caption = "0"
            m_lblMonthlyTotalCentersAvg.Caption = "0"
        Next i
        Exit Sub
    End If

    ' Calculate row structure
    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    ' Calculate statistics for each center
    For i = 1 To m_ActiveCenterCount
       Call CalculateMonthlyStatsForCenter(ws, ActualCenterIndex(i), totalRowsPerDayBlock, _
                                       highDay, highAmount, _
                                       lowDay, lowAmount, _
                                       avgAmount, daysWithData)

        ' Update labels
        If highDay > 0 Then
            m_MonthHighLabels(i).Caption = highDay & ": " & FormatCompact(highAmount)
            m_MonthHighLabels(i).ControlTipText = "��� " & highDay & " - " & Format(highAmount, "#,##0")
        Else
            m_MonthHighLabels(i).Caption = "-"
            m_MonthHighLabels(i).ControlTipText = ""
        End If

        If lowDay > 0 Then
            m_MonthLowLabels(i).Caption = lowDay & ": " & FormatCompact(lowAmount)
            m_MonthLowLabels(i).ControlTipText = "��� " & lowDay & " - " & Format(lowAmount, "#,##0")
        Else
            m_MonthLowLabels(i).Caption = "-"
            m_MonthLowLabels(i).ControlTipText = ""
        End If

        If daysWithData > 0 Then
            m_MonthAvgLabels(i).Caption = FormatCompact(avgAmount)
            m_MonthAvgLabels(i).ControlTipText = "������: " & Format(avgAmount, "#,##0") & " (" & daysWithData & " ���)"
        Else
            m_MonthAvgLabels(i).Caption = "0"
            m_MonthAvgLabels(i).ControlTipText = ""
        End If
    Next i

    On Error GoTo 0
End Sub

'----------------------------------------
' Calculate monthly statistics for a specific center
'----------------------------------------
Private Sub CalculateMonthlyStatsForCenter(ws As Worksheet, centerNum As Long, totalRowsPerDayBlock As Long, _
                                            ByRef highDay As Long, ByRef highAmount As Double, _
                                            ByRef lowDay As Long, ByRef lowAmount As Double, _
                                            ByRef avgAmount As Double, ByRef daysWithData As Long)
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim centerRow As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim dayTotal As Double
    Dim totalSum As Double

    highDay = 0
    highAmount = 0
    lowDay = 0
    lowAmount = 999999999999#  ' Very large number
    avgAmount = 0
    daysWithData = 0
    totalSum = 0

    For dayNum = 1 To 31
        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

        ' Check if day exists
        If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
            If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                ' Calculate center row
                If m_UserCenters = 1 Then
                    centerRow = dayStartRow
                Else
                    centerRow = dayStartRow + (centerNum - 1)
                End If

                dayTotal = 0

                ' Add Cash (Column C)
                cashValue = ws.Cells(centerRow, "C").value
                If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then
                    dayTotal = dayTotal + CDbl(cashValue)
                End If

                ' Add Card (Column D)
                cardValue = ws.Cells(centerRow, "D").value
                If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then
                    dayTotal = dayTotal + CDbl(cardValue)
                End If

                ' Only count days with actual data
                If dayTotal > 0 Then
                    daysWithData = daysWithData + 1
                    totalSum = totalSum + dayTotal

                    ' Check for high
                    If dayTotal > highAmount Then
                        highAmount = dayTotal
                        highDay = dayNum
                    End If

                    ' Check for low
                    If dayTotal < lowAmount Then
                        lowAmount = dayTotal
                        lowDay = dayNum
                    End If
                End If
            End If
        End If
    Next dayNum

    ' Calculate average
    If daysWithData > 0 Then
        avgAmount = totalSum / daysWithData
    Else
        lowAmount = 0
        lowDay = 0
    End If
End Sub

'====================================================================================================
'                                    YEARLY STATISTICS FUNCTIONS
'====================================================================================================

'----------------------------------------
' Update yearly statistics (high, low) for all centers
'----------------------------------------
Private Sub UpdateYearlyStatistics()
    Dim i As Long
    Dim highMonth As Long, highDay As Long, highAmount As Double
    Dim lowMonth As Long, lowDay As Long, lowAmount As Double
    Dim selectedYear As Long

    On Error Resume Next

    If m_cboYear.value = "" Then Exit Sub
    If m_YearHighLabels Is Nothing Then Exit Sub

    selectedYear = CLng(m_cboYear.value)

    ' Calculate row structure
    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    Application.StatusBar = "�� ��� ������ ���� ������..."

    ' Calculate statistics for each center
    For i = 1 To m_ActiveCenterCount
        Call CalculateYearlyStatsForCenter(selectedYear, ActualCenterIndex(i), totalRowsPerDayBlock, _
                                      highMonth, highDay, highAmount, _
                                      lowMonth, lowDay, lowAmount)

        ' Update labels
        If highMonth > 0 Then
            m_YearHighLabels(i).Caption = highMonth & "/" & highDay & ": " & FormatCompact(highAmount)
            m_YearHighLabels(i).ControlTipText = "��� " & highMonth & " ��� " & highDay & " - " & Format(highAmount, "#,##0")
        Else
            m_YearHighLabels(i).Caption = "-"
            m_YearHighLabels(i).ControlTipText = ""
        End If

        If lowMonth > 0 Then
            m_YearLowLabels(i).Caption = lowMonth & "/" & lowDay & ": " & FormatCompact(lowAmount)
            m_YearLowLabels(i).ControlTipText = "��� " & lowMonth & " ��� " & lowDay & " - " & Format(lowAmount, "#,##0")
        Else
            m_YearLowLabels(i).Caption = "-"
            m_YearLowLabels(i).ControlTipText = ""
        End If
    Next i

    Application.StatusBar = False
    On Error GoTo 0
End Sub

'----------------------------------------
' Calculate yearly statistics for a specific center
'----------------------------------------
Private Sub CalculateYearlyStatsForCenter(selectedYear As Long, centerNum As Long, totalRowsPerDayBlock As Long, _
                                           ByRef highMonth As Long, ByRef highDay As Long, ByRef highAmount As Double, _
                                           ByRef lowMonth As Long, ByRef lowDay As Long, ByRef lowAmount As Double)
    Dim ws As Worksheet
    Dim monthNum As Long
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim centerRow As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim dayTotal As Double
    Dim ym As String

    highMonth = 0
    highDay = 0
    highAmount = 0
    lowMonth = 0
    lowDay = 0
    lowAmount = 999999999999#  ' Very large number

    Dim foundAnyData As Boolean
    foundAnyData = False

    ' Loop through all months
    For monthNum = 1 To 12
        ym = selectedYear & "/" & Format(monthNum, "00")
        Set ws = FindSheet(ym)

        If Not ws Is Nothing Then
            ' Loop through all days
            For dayNum = 1 To 31
                dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

                ' Check if day exists
                If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
                    If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                        ' Calculate center row
                        If m_UserCenters = 1 Then
                            centerRow = dayStartRow
                        Else
                            centerRow = dayStartRow + (centerNum - 1)
                        End If

                        dayTotal = 0

                        ' Add Cash (Column C)
                        cashValue = ws.Cells(centerRow, "C").value
                        If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then
                            dayTotal = dayTotal + CDbl(cashValue)
                        End If

                        ' Add Card (Column D)
                        cardValue = ws.Cells(centerRow, "D").value
                        If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then
                            dayTotal = dayTotal + CDbl(cardValue)
                        End If

                        ' Only count days with actual data
                        If dayTotal > 0 Then
                            foundAnyData = True

                            ' Check for high
                            If dayTotal > highAmount Then
                                highAmount = dayTotal
                                highMonth = monthNum
                                highDay = dayNum
                            End If

                            ' Check for low
                            If dayTotal < lowAmount Then
                                lowAmount = dayTotal
                                lowMonth = monthNum
                                lowDay = dayNum
                            End If
                        End If
                    End If
                End If
            Next dayNum
        End If
    Next monthNum

    ' Reset low if no data found
    If Not foundAnyData Then
        lowAmount = 0
        lowMonth = 0
        lowDay = 0
    End If
End Sub

'----------------------------------------
' Format number in compact form (e.g., 1.5M, 500K)
'----------------------------------------
Private Function FormatCompact(amount As Double) As String
    If amount >= 1000000000 Then
        FormatCompact = Format(amount / 1000000000, "0.0") & "B"
    ElseIf amount >= 1000000 Then
        FormatCompact = Format(amount / 1000000, "0.0") & "M"
    ElseIf amount >= 1000 Then
        FormatCompact = Format(amount / 1000, "0") & "K"
    Else
        FormatCompact = Format(amount, "#,##0")
    End If
End Function


'====================================================================================================
'                                    OVERALL MIN/MAX DAY STATISTICS
'====================================================================================================


'----------------------------------------
' Update overall min/max day statistics for month and year
'----------------------------------------
Private Sub UpdateOverallDayStatistics()
    Dim ws As Worksheet
    Dim ym As String
    Dim selectedYear As Long
    Dim bestDay As Long, bestAmount As Double
    Dim worstDay As Long, worstAmount As Double
    Dim bestMonth As Long, bestMonthDay As Long, bestYearAmount As Double
    Dim worstMonth As Long, worstMonthDay As Long, worstYearAmount As Double

    On Error Resume Next

    If m_cboYear.value = "" Then Exit Sub

    selectedYear = CLng(m_cboYear.value)

    ' Calculate row structure
    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    '--- MONTH Statistics ---
    If m_cboMonth.value <> "" Then
        ym = m_cboYear.value & "/" & Format(CInt(m_cboMonth.value), "00")
        Set ws = FindSheet(ym)

        If ws Is Nothing Then
            m_lblMonthBestDay.Caption = "-"
            m_lblMonthBestDay.ControlTipText = ""
            m_lblMonthWorstDay.Caption = "-"
            m_lblMonthWorstDay.ControlTipText = ""
        Else
            Call FindMonthBestWorstDays(ws, totalRowsPerDayBlock, bestDay, bestAmount, worstDay, worstAmount)

            If bestDay > 0 Then
                m_lblMonthBestDay.Caption = Format(bestAmount, "#,##0") & " : " & bestDay
                m_lblMonthBestDay.ControlTipText = "��� " & bestDay & " �� ����� ���� " & Format(bestAmount, "#,##0") & " ����"
            Else
                m_lblMonthBestDay.Caption = "-"
                m_lblMonthBestDay.ControlTipText = ""
            End If

            If worstDay > 0 Then
                m_lblMonthWorstDay.Caption = Format(worstAmount, "#,##0") & " : " & worstDay
                m_lblMonthWorstDay.ControlTipText = "��� " & worstDay & " �� ����� ���� " & Format(worstAmount, "#,##0") & " ����"
            Else
                m_lblMonthWorstDay.Caption = "-"
                m_lblMonthWorstDay.ControlTipText = ""
            End If
        End If
    End If

    '--- YEAR Statistics ---
    Application.StatusBar = "�� ��� ������ ���� ������..."

    Call FindYearBestWorstDays(selectedYear, totalRowsPerDayBlock, _
                                bestMonth, bestMonthDay, bestYearAmount, _
                                worstMonth, worstMonthDay, worstYearAmount)

    If bestMonth > 0 Then
        m_lblYearBestDay.Caption = Format(bestYearAmount, "#,##0") & " : " & bestMonth & "/" & bestMonthDay
        m_lblYearBestDay.ControlTipText = "��� " & bestMonth & " ��� " & bestMonthDay & " �� ����� ���� " & Format(bestYearAmount, "#,##0") & " ����"
    Else
        m_lblYearBestDay.Caption = "-"
        m_lblYearBestDay.ControlTipText = ""
    End If

    If worstMonth > 0 Then
        m_lblYearWorstDay.Caption = Format(worstYearAmount, "#,##0") & " : " & worstMonth & "/" & worstMonthDay
        m_lblYearWorstDay.ControlTipText = "��� " & worstMonth & " ��� " & worstMonthDay & " �� ����� ���� " & Format(worstYearAmount, "#,##0") & " ����"
    Else
        m_lblYearWorstDay.Caption = "-"
        m_lblYearWorstDay.ControlTipText = ""
    End If

    Application.StatusBar = False
    On Error GoTo 0
End Sub
'----------------------------------------
' Find best and worst days in a month (total of all centers)
'----------------------------------------
Private Sub FindMonthBestWorstDays(ws As Worksheet, totalRowsPerDayBlock As Long, _
                                    ByRef bestDay As Long, ByRef bestAmount As Double, _
                                    ByRef worstDay As Long, ByRef worstAmount As Double)
    Dim dayNum As Long
    Dim dayTotal As Double
    Dim foundAnyData As Boolean

    bestDay = 0
    bestAmount = 0
    worstDay = 0
    worstAmount = 999999999999#
    foundAnyData = False

    For dayNum = 1 To 31
        dayTotal = GetDayTotalAllCenters(ws, dayNum, totalRowsPerDayBlock)

        If dayTotal > 0 Then
            foundAnyData = True

            ' Check for best (maximum)
            If dayTotal > bestAmount Then
                bestAmount = dayTotal
                bestDay = dayNum
            End If

            ' Check for worst (minimum)
            If dayTotal < worstAmount Then
                worstAmount = dayTotal
                worstDay = dayNum
            End If
        End If
    Next dayNum

    ' Reset worst if no data found
    If Not foundAnyData Then
        worstAmount = 0
        worstDay = 0
    End If
End Sub

'----------------------------------------
' Find best and worst days in a year (total of all centers)
'----------------------------------------
Private Sub FindYearBestWorstDays(selectedYear As Long, totalRowsPerDayBlock As Long, _
                                   ByRef bestMonth As Long, ByRef bestDay As Long, ByRef bestAmount As Double, _
                                   ByRef worstMonth As Long, ByRef worstDay As Long, ByRef worstAmount As Double)
    Dim ws As Worksheet
    Dim monthNum As Long
    Dim dayNum As Long
    Dim dayTotal As Double
    Dim ym As String
    Dim foundAnyData As Boolean

    bestMonth = 0
    bestDay = 0
    bestAmount = 0
    worstMonth = 0
    worstDay = 0
    worstAmount = 999999999999#
    foundAnyData = False

    ' Loop through all months
    For monthNum = 1 To 12
        ym = selectedYear & "/" & Format(monthNum, "00")
        Set ws = FindSheet(ym)

        If Not ws Is Nothing Then
            ' Loop through all days
            For dayNum = 1 To 31
                dayTotal = GetDayTotalAllCenters(ws, dayNum, totalRowsPerDayBlock)

                If dayTotal > 0 Then
                    foundAnyData = True

                    ' Check for best (maximum)
                    If dayTotal > bestAmount Then
                        bestAmount = dayTotal
                        bestMonth = monthNum
                        bestDay = dayNum
                    End If

                    ' Check for worst (minimum)
                    If dayTotal < worstAmount Then
                        worstAmount = dayTotal
                        worstMonth = monthNum
                        worstDay = dayNum
                    End If
                End If
            Next dayNum
        End If
    Next monthNum

    ' Reset worst if no data found
    If Not foundAnyData Then
        worstAmount = 0
        worstMonth = 0
        worstDay = 0
    End If
End Sub

'----------------------------------------
' Get total sales of ALL centers for a specific day
'----------------------------------------
Private Function GetDayTotalAllCenters(ws As Worksheet, dayNum As Long, totalRowsPerDayBlock As Long) As Double
    Dim dayStartRow As Long
    Dim centerRow As Long
    Dim centerNum As Long
    Dim cashValue As Variant
    Dim cardValue As Variant
    Dim total As Double

    total = 0
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

    ' Check if day exists
    On Error Resume Next
    If Not IsNumeric(ws.Cells(dayStartRow, "A").value) Then
        GetDayTotalAllCenters = 0
        Exit Function
    End If

    If CLng(ws.Cells(dayStartRow, "A").value) <> dayNum Then
        GetDayTotalAllCenters = 0
        Exit Function
    End If
    On Error GoTo 0

    ' Sum all centers
      For centerNum = 1 To m_ActiveCenterCount
      Dim actualCenter As Long
      actualCenter = ActualCenterIndex(centerNum)

      If m_UserCenters = 1 Then
          centerRow = dayStartRow
      Else
          centerRow = dayStartRow + (actualCenter - 1)
      End If

      cashValue = ws.Cells(centerRow, "C").value
      If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then
          total = total + CDbl(cashValue)
      End If

      cardValue = ws.Cells(centerRow, "D").value
      If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then
          total = total + CDbl(cardValue)
      End If
  Next centerNum

    GetDayTotalAllCenters = total
End Function

'----------------------------------------
' Find the first center with no data and set focus to its Cash textbox
' Returns True if an empty center was found and focused
'----------------------------------------
Private Function FocusFirstEmptyCenter() As Boolean
    Dim i As Long

    On Error Resume Next

    FocusFirstEmptyCenter = False

    If m_CashTextBoxes Is Nothing Or m_CardTextBoxes Is Nothing Then Exit Function

    ' Loop through all centers to find the first one with no data
    For i = 1 To m_ActiveCenterCount
        Dim cashVal As String
        Dim cardVal As String

        cashVal = Trim(m_CashTextBoxes("Center" & i).value)
        cardVal = Trim(m_CardTextBoxes("Center" & i).value)

        ' If both Cash and Card are empty, this center needs data
        If cashVal = "" And cardVal = "" Then
            m_CashTextBoxes("Center" & i).SetFocus
            FocusFirstEmptyCenter = True
            Exit Function
        End If
    Next i

    ' If all centers have data, focus on the first Cash textbox anyway
    m_CashTextBoxes("Center1").SetFocus
    FocusFirstEmptyCenter = True

    On Error GoTo 0
End Function
Private Sub UpdateYearlyTotals()
    Dim ws As Worksheet
    Dim i As Long, monthNum As Long, dayNum As Long
    Dim dayStartRow As Long, centerRow As Long
    Dim cashValue As Variant, cardValue As Variant
    Dim centerSum As Double, grandTotal As Double
    Dim selectedYear As Long
    Dim ym As String

    On Error Resume Next
    If m_cboYear.value = "" Then Exit Sub
    If m_YearTotalLabels Is Nothing Then Exit Sub

    selectedYear = CLng(m_cboYear.value)
    grandTotal = 0

    Dim rowsPerDayBlock As Long, totalRowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    totalRowsPerDayBlock = rowsPerDayBlock + 1

    For i = 1 To m_ActiveCenterCount
        centerSum = 0

        For monthNum = 1 To 12
            ym = selectedYear & "/" & Format(monthNum, "00")
            Set ws = FindSheet(ym)
            If Not ws Is Nothing Then
                For dayNum = 1 To 31
                    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                    If IsNumeric(ws.Cells(dayStartRow, "A").value) Then
                        If CLng(ws.Cells(dayStartRow, "A").value) = dayNum Then
                            centerRow = IIf(m_UserCenters = 1, dayStartRow, dayStartRow + (ActualCenterIndex(i) - 1))
                            cashValue = ws.Cells(centerRow, "C").value
                            cardValue = ws.Cells(centerRow, "D").value
                            If IsNumeric(cashValue) And Not IsEmpty(cashValue) Then centerSum = centerSum + CDbl(cashValue)
                            If IsNumeric(cardValue) And Not IsEmpty(cardValue) Then centerSum = centerSum + CDbl(cardValue)
                        End If
                    End If
                Next dayNum
            End If
        Next monthNum

        m_YearTotalLabels("Center" & i).Caption = Format(centerSum, "#,##0")
        grandTotal = grandTotal + centerSum
    Next i

    m_lblYearGrandTotal.Caption = Format(grandTotal, "#,##0")
    On Error GoTo 0
End Sub

Private Sub m_cboMonth_Change()
    Call ClearDataTextBoxes
    Call UpdateMonthlySummary
    Call UpdateMonthlyStatistics
    Call UpdateYearlyStatistics
    Call UpdateYearlyTotals
    Call UpdateOverallDayStatistics
End Sub


