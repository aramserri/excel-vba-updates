VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmChequeEdit 
   Caption         =   "����� ��"
   ClientHeight    =   11116
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   12194
   OleObjectBlob   =   "frmChequeEdit.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmChequeEdit"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False



'=====================================================
' UserForm: frmChequeManagement
' ��� ������ �� - ���� ����
'=====================================================
Option Explicit

'====================================================================================================
'                                    CONSTANTS & TYPES
'                                    ���ʝ�� � �����
'====================================================================================================
Private Const CONFIG_SHEET_NAME As String = "�������"

' Type for bank submission - ��� ���� ���� ��� ���
Private Type BankChequeData
    chequeNumber As Long
    companyName As String
    companyNationalID As String
    chequeAmount As String
    chequeDate As String
    Code16Digit As String
    Code_Part1 As String
    Code_Part2 As String
    Code_Part3 As String
    Code_Part4 As String
End Type

'====================================================================================================
'                                    CONFIGURATION HELPER
'                                    ����� ��� �������
'====================================================================================================

'----------------------------------------------------------------------------------
' Read configuration value from named range
' ������ ����� ������� �� ������ ��㝐���� ���
'----------------------------------------------------------------------------------
Private Function ReadConfigValue(configName As String) As Long
    On Error Resume Next
    Dim val As Variant
    val = ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range(configName).value
    If IsNumeric(val) Then
        ReadConfigValue = CLng(val)
    Else
        ReadConfigValue = 0
    End If
    On Error GoTo 0
End Function


Private Sub ComboBox1_Enter()
SetKeyboardPersian
End Sub

Private Sub CommandButton8_Click()

    '--- Abort early if nothing to sort ---
    If ListBox1.ListCount < 2 Then
        MsgBox "����� ���ݝ�� ���� ���ȝ���� ���� ����.", vbInformation, "���ȝ����"
        Exit Sub
    End If

    '--- Column index constants (0-based) ---
    Const COL_DATE      As Integer = 0
    Const COL_AMOUNT    As Integer = 1
    Const COL_NATID     As Integer = 2
    Const COL_COMPANY   As Integer = 3
    Const COL_STATUS    As Integer = 4
    Const COL_SERIAL    As Integer = 5
    Const TOTAL_COLS    As Integer = 6

    Const SORT_KEY_LEN  As Integer = 10  ' only first 10 digits used for sorting

    '--------------------------------------------------------------------------
    ' STEP 1 � Copy all rows from ListBox1 into a 2-D array for easy sorting
    '--------------------------------------------------------------------------
    Dim rowCount As Long
    rowCount = ListBox1.ListCount

    Dim rows()     As String
    Dim sortKeys() As String
    ReDim rows(0 To rowCount - 1, 0 To TOTAL_COLS - 1)
    ReDim sortKeys(0 To rowCount - 1)

    Dim i As Long, j As Integer

    For i = 0 To rowCount - 1
        For j = 0 To TOTAL_COLS - 1
            rows(i, j) = ListBox1.List(i, j)
        Next j

        ' Serial is always 12 digits � take only the first 10 for sorting
        Dim rawSerial As String
        rawSerial = ConvertPersianNumsToEnglish(Trim(rows(i, COL_SERIAL)))
        rawSerial = KeepDigitsOnly(rawSerial)
        sortKeys(i) = Left(rawSerial, SORT_KEY_LEN)

    Next i

    '--------------------------------------------------------------------------
    ' STEP 2 � Insertion sort on sortKeys (ascending)
    '--------------------------------------------------------------------------
    Dim k        As Long
    Dim keyTemp  As String
    Dim rowTemp() As String
    ReDim rowTemp(0 To TOTAL_COLS - 1)

    For i = 1 To rowCount - 1

        keyTemp = sortKeys(i)
        For j = 0 To TOTAL_COLS - 1
            rowTemp(j) = rows(i, j)
        Next j

        k = i - 1

        Do While k >= 0
            If sortKeys(k) > keyTemp Then
                sortKeys(k + 1) = sortKeys(k)
                For j = 0 To TOTAL_COLS - 1
                    rows(k + 1, j) = rows(k, j)
                Next j
                k = k - 1
            Else
                Exit Do
            End If
        Loop

        sortKeys(k + 1) = keyTemp
        For j = 0 To TOTAL_COLS - 1
            rows(k + 1, j) = rowTemp(j)
        Next j

    Next i

    '--------------------------------------------------------------------------
    ' STEP 3 � Rebuild ListBox1 from the sorted array
    '--------------------------------------------------------------------------
    ListBox1.Clear

    For i = 0 To rowCount - 1
        ListBox1.AddItem rows(i, COL_DATE)
        For j = 1 To TOTAL_COLS - 1
            ListBox1.List(ListBox1.ListCount - 1, j) = rows(i, j)
        Next j
    Next i

    '--------------------------------------------------------------------------
    ' STEP 4 � Count cleared vs not-cleared cheques and update labels
    '--------------------------------------------------------------------------
    Dim countCleared    As Long
    Dim countNotCleared As Long
    countCleared = 0
    countNotCleared = 0

    For i = 0 To rowCount - 1
        If Trim(rows(i, COL_STATUS)) = "��� ���" Then
            countCleared = countCleared + 1
        ElseIf Trim(rows(i, COL_STATUS)) = "��� ����" Then
            countNotCleared = countNotCleared + 1
        End If
    Next i

    ' Update the labels
    Label77.Caption = " ��� ��� " & countCleared      ' cleared cheques
    Label78.Caption = " ��� ���� " & countNotCleared   ' not cleared cheques

    MsgBox "���ȝ���� �� ���� ����� (�� ��� ���) ����� ��." & vbCrLf & _
           rowCount & " ���� ���� ����.", vbInformation, "���ȝ����"

End Sub

'==========================================================================
' Helper: strips every character that is not an ASCII digit (0-9)
' Call AFTER ConvertPersianNumsToEnglish so all digits are already ASCII.
'==========================================================================
Private Function KeepDigitsOnly(ByVal s As String) As String
    Dim result As String
    result = ""
    Dim idx As Integer
    For idx = 1 To Len(s)
        If Mid(s, idx, 1) >= "0" And Mid(s, idx, 1) <= "9" Then
            result = result & Mid(s, idx, 1)
        End If
    Next idx
    KeepDigitsOnly = result
End Function






Private Sub TextBox4_Enter()
SetKeyboardEnglish
End Sub

Private Sub TextBox5_Enter()
SetKeyboardEnglish
End Sub

'====================================================================================================
'                                    FORM INITIALIZATION
'                                    �������� ����� ���
'====================================================================================================

Private Sub UserForm_Initialize()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim i As Long, j As Long
    Dim tempVal As String
    Dim foundSeparator As Boolean
    
    Dim companyArr() As String
    Dim otherArr() As String
    Dim companyCount As Long
    Dim otherCount As Long
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        MsgBox "���: ��� ������� ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    ComboBox1.Clear
    
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
    If lastRow < 2 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    '--- First pass: count items ---
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
            Else
                otherCount = otherCount + 1
            End If
        End If
    Next cell
    
    If companyCount > 0 Then ReDim companyArr(1 To companyCount)
    If otherCount > 0 Then ReDim otherArr(1 To otherCount)
    
    '--- Second pass: fill arrays ---
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
                companyArr(companyCount) = GetCompanyName(cell.value)
            Else
                otherCount = otherCount + 1
                otherArr(otherCount) = GetCompanyName(cell.value)
            End If
        End If
    Next cell
    
    '--- Sort company array (Bubble Sort) ---
    If companyCount > 1 Then
        For i = 1 To companyCount - 1
            For j = i + 1 To companyCount
                If StrComp(companyArr(i), companyArr(j), vbTextCompare) > 0 Then
                    tempVal = companyArr(i)
                    companyArr(i) = companyArr(j)
                    companyArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    '--- Sort other array ---
    If otherCount > 1 Then
        For i = 1 To otherCount - 1
            For j = i + 1 To otherCount
                If StrComp(otherArr(i), otherArr(j), vbTextCompare) > 0 Then
                    tempVal = otherArr(i)
                    otherArr(i) = otherArr(j)
                    otherArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    '--- Add companies to ComboBox ---
    For i = 1 To companyCount
        ComboBox1.AddItem companyArr(i)
    Next i
    
    '--- Add separator and others ---
    If otherCount > 0 Then
        ComboBox1.AddItem "-------------"
        For i = 1 To otherCount
            ComboBox1.AddItem otherArr(i)
        Next i
    End If
    
    '--- Initialize ListBox ---
    ' Columns: Date | Amount | National ID | Company | Status | Serial
    ListBox1.ColumnCount = 6
    ListBox1.ColumnWidths = "70;85;85;100;60;90"
    ListBox1.MultiSelect = fmMultiSelectMulti

    '--- Initialize TextBoxes ---
    TextBox1.value = ""  ' Target date for move
    TextBox2.value = ""  ' Amount for edit
    TextBox3.value = ""  ' Serial for edit
    TextBox4.value = ""  ' Search date - NO PREFILL
    
    '--- Initialize CheckBoxes ---
    CheckBox1.value = False
    CheckBox2.value = False
End Sub

'================================================================
' ���� ���� ��� ��� ����� �흘�� �� ��� �� pascheque
' �� ������� �� ��� �������� �������� ��� �� ��
'================================================================
Private Sub UserForm_Activate()
    
    ' ����� ���� ��� ������� ������� �� pascheque ���� ����
    If ChequeEdit_SearchMode <> "" Then
        
        Select Case UCase(ChequeEdit_SearchMode)
        
            Case "DATE"
                ' ����� �� ���� ����� ����
                If ChequeEdit_SearchDate <> "" Then
                    TextBox4.Text = ChequeEdit_SearchDate
                    ' �������� ������ ������ �����
                    CommandButton6_Click
                End If
                
            Case "COMPANY"
                ' ����� �� ���� ��� �ј�
                If ChequeEdit_SearchCompany <> "" Then
                    ' ������ �ј� �� ComboBox1
                    Dim i As Long
                    For i = 0 To ComboBox1.ListCount - 1
                        If Trim(ComboBox1.List(i)) = _
                           Trim(ChequeEdit_SearchCompany) Then
                            ComboBox1.ListIndex = i
                            Exit For
                        End If
                    Next i
                    ' �������� ������ �ј�
                    CommandButton1_Click
                End If
                
        End Select
        
        ' �ǘ ���� �������� ������� ��� �� �������
        ChequeEdit_SearchCompany = ""
        ChequeEdit_SearchDate = ""
        ChequeEdit_SearchMode = ""
        
    End If
    
End Sub


'====================================================================================================
'                                    COMBOBOX EVENTS
'====================================================================================================

Private Sub ComboBox1_Change()
    ' Prevent selecting separator - ������ �� ������ ��ǘ����
    If Me.ComboBox1.value = "-------------" Then
        Me.ComboBox1.value = ""
        Me.ComboBox1.DropDown
        Exit Sub
    End If
    Call CommandButton1_Click
End Sub

'====================================================================================================
'                                    SEARCH FUNCTIONS
'                                    ����� �����
'====================================================================================================

'-------------------------------
' CommandButton1: Search by Company
' Ϙ�� ����� �� ���� �ј�
'-------------------------------
Private Sub CommandButton1_Click()
    Dim ws As Worksheet, c As Long
    Dim company As String, chequeDate As String
    Dim amount As Variant, serial As Variant, status As String
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim results As Collection: Set results = New Collection

    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")

    If numCheques = 0 Or totalCenters = 0 Or startYear = 0 Then
        MsgBox "���: ������ ������� ������ ���.", vbCritical, "���� �������"
        Exit Sub
    End If

    '--- Calculate column and row offsets ---
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ListBox1.Clear
    Me.Label76.Caption = ""
    
    company = Trim(ComboBox1.value)
    
    If company = "" Then
        MsgBox "����� �ј� �� ������ ����.", vbExclamation, "������ �ј�"
        Exit Sub
    End If

    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    '--- Loop through all sheets ---
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name <> CONFIG_SHEET_NAME And ws.Name <> "�������" And ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0

            If yearNum >= startYear And yearNum <= endYear Then
                Dim dayStartRow As Long
                For dayNum = 1 To 31
                    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                    If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For

                    For c = firstChequeCol To lastChequeCol Step 2
                        If Trim(ws.Cells(dayStartRow, c).value) = company Then
                            amount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
                            serial = ws.Cells(dayStartRow + lowerHalfStartOffset, c + 1).value
                            status = Trim(ws.Cells(dayStartRow, c + 1).value)
                            chequeDate = FormatJalaliDate(yearNum, monthNum, dayNum)
                            results.Add Array(chequeDate, amount, serial, status, ws.Name, dayStartRow, c)
                        End If
                    Next c
                Next dayNum
            End If
        End If
    Next ws

    '--- Populate ListBox (newest first) ---
    Dim i As Long
    Dim companyNationalID As String
    companyNationalID = ConvertPersianNumsToEnglish(GetNationalID(company))
    
    For i = results.count To 1 Step -1
        With ListBox1
            .AddItem results(i)(0)                                              ' Column 0: Date
            .List(.ListCount - 1, 1) = Format(results(i)(1), "#,##0")           ' Column 1: Amount
            .List(.ListCount - 1, 2) = companyNationalID                        ' Column 2: National ID
            .List(.ListCount - 1, 3) = company                                  ' Column 3: Company (same company for all)
            .List(.ListCount - 1, 4) = IIf(results(i)(3) = "", "��� ����", "��� ���")  ' Column 4: Status
            .List(.ListCount - 1, 5) = ConvertPersianNumsToEnglish(CStr(results(i)(2)))  ' Column 5: Serial
        End With
    Next i
    Me.Label76.Caption = "����� " & ListBox1.ListCount & " �� ���� ��"
    ' No message after search - ���� ���� ��� �� �����
End Sub

'-------------------------------
' CommandButton6: Search by DATE (range-aware)
'-------------------------------
Private Sub CommandButton6_Click()
    Dim ws As Worksheet, c As Long
    Dim company As String, chequeDate As String
    Dim amount As Variant, serial As Variant, status As String
    Dim searchYear As Long, searchMonth As Long, searchDay As Long
    Dim results As Collection: Set results = New Collection
    Dim parts() As String
    Dim companyNationalID As String
    Dim searchMode As Integer ' 1=year only, 2=year+month, 3=full date

    If Trim(TextBox4.value) = "" Then
        MsgBox "����� ����� ����� �� ���� ����." & vbCrLf & "����: 1404 �� 1404/10 �� 1404/10/15", vbExclamation, "����� ����"
        TextBox4.SetFocus
        Exit Sub
    End If

    Dim searchDateStr As String
    searchDateStr = ConvertPersianNumsToEnglish(Trim(TextBox4.value))
    parts = Split(searchDateStr, "/")

    Select Case UBound(parts)
        Case 0: searchMode = 1 ' year only
        Case 1: searchMode = 2 ' year/month
        Case 2: searchMode = 3 ' year/month/day
        Case Else
            MsgBox "���� ����� ������� ���.", vbExclamation: Exit Sub
    End Select

    On Error Resume Next
    searchYear = CLng(parts(0))
    If searchMode >= 2 Then searchMonth = CLng(parts(1))
    If searchMode = 3 Then searchDay = CLng(parts(2))
    On Error GoTo 0

    If searchYear < 1300 Or searchYear > 1500 Then
        MsgBox "��� ���� ��� ������� ���.", vbExclamation: Exit Sub
    End If
    If searchMode >= 2 And (searchMonth < 1 Or searchMonth > 12) Then
        MsgBox "��� ���� ��� ������� ���.", vbExclamation: Exit Sub
    End If
    If searchMode = 3 And (searchDay < 1 Or searchDay > 31) Then
        MsgBox "��� ���� ��� ������� ���.", vbExclamation: Exit Sub
    End If

    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    If numCheques = 0 Or totalCenters = 0 Then
        MsgBox "���: ������ ������� ������ ���.", vbCritical: Exit Sub
    End If

    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ListBox1.Clear

    '--- Determine which months to scan ---
    Dim startMonth As Long, endMonth As Long
    If searchMode = 1 Then
        startMonth = 1: endMonth = 12
    Else
        startMonth = searchMonth: endMonth = searchMonth
    End If

    Dim m As Long
    For m = startMonth To endMonth
        Dim targetDateString As String
        targetDateString = searchYear & "/" & Format(m, "00")

        Set ws = Nothing
        Dim wsTemp As Worksheet
        For Each wsTemp In ThisWorkbook.Worksheets
            If CStr(wsTemp.Range("B1").value) = targetDateString Then
                Set ws = wsTemp
                Exit For
            End If
        Next wsTemp

        If ws Is Nothing Then GoTo NextMonth

        '--- Determine which days to scan ---
        Dim startDay As Long, endDay As Long
        If searchMode = 3 Then
            startDay = searchDay: endDay = searchDay
        Else
            startDay = 1: endDay = 31
        End If

        Dim d As Long
        For d = startDay To endDay
            Dim dayStartRow As Long
            dayStartRow = 2 + (d - 1) * totalRowsPerDayBlock

            ' Skip if day doesn't exist in sheet
            If IsEmpty(ws.Cells(dayStartRow, "A").value) Then GoTo NextDay

            For c = firstChequeCol To lastChequeCol Step 2
                company = Trim(ws.Cells(dayStartRow, c).value)
                If company <> "" Then
                    amount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
                    serial = ws.Cells(dayStartRow + lowerHalfStartOffset, c + 1).value
                    status = Trim(ws.Cells(dayStartRow, c + 1).value)
                    chequeDate = FormatJalaliDate(searchYear, m, d)
                    results.Add Array(chequeDate, amount, serial, status, company, ws.Name, dayStartRow, c)
                End If
            Next c
NextDay:
        Next d
NextMonth:
    Next m

    If results.count = 0 Then
        MsgBox "�� ��� ���� ��� ���� ���� ���.", vbInformation
        Exit Sub
    End If

    Dim i As Long
    For i = 1 To results.count
        companyNationalID = ConvertPersianNumsToEnglish(GetNationalID(CStr(results(i)(4))))
        With ListBox1
            .AddItem results(i)(0)
            .List(.ListCount - 1, 1) = Format(results(i)(1), "#,##0")
            .List(.ListCount - 1, 2) = companyNationalID
            .List(.ListCount - 1, 3) = results(i)(4)
            .List(.ListCount - 1, 4) = IIf(results(i)(3) = "", "��� ����", "��� ���")
            .List(.ListCount - 1, 5) = ConvertPersianNumsToEnglish(CStr(results(i)(2)))
        End With
    Next i
End Sub

'====================================================================================================
'                                    HELPER FUNCTIONS
'                                    ����� ���
'====================================================================================================

'----------------------------------------
' Get National ID for a company
' ������ ����� ��� �ј�
'----------------------------------------
Private Function GetNationalID(companyName As String) As String
    Dim wsInfo As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    
    On Error Resume Next
    Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
    On Error GoTo 0
    
    If wsInfo Is Nothing Then
        GetNationalID = ""
        Exit Function
    End If
    
    lastRow = wsInfo.Cells(wsInfo.rows.count, "A").End(xlUp).row
    
    For Each cell In wsInfo.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If GetCompanyName(cell.value) = companyName Then
                ' Convert to English numbers
                GetNationalID = ConvertPersianNumsToEnglish(CStr(cell.Offset(0, 1).value))
                Exit Function
            End If
        End If
    Next cell
    
    GetNationalID = ""
End Function

'----------------------------------------
' Format Jalali date
' ���� ����� ����
'----------------------------------------
Private Function FormatJalaliDate(y, m, d) As String
    FormatJalaliDate = Format(y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
End Function

'----------------------------------------
' Find sheet by year/month
' ���� ���� ��� �� ���� ���/���
'----------------------------------------
Private Function FindSheet(ym As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.Range("B1").value = ym Then
            Set FindSheet = ws
            Exit Function
        End If
    Next ws
    Set FindSheet = Nothing
End Function

'----------------------------------------
' Evaluate mathematical expression
' ������ ����� �����
'----------------------------------------
Private Function EvaluateExpression(expr As String) As Double
    On Error Resume Next
    EvaluateExpression = Evaluate(Replace(expr, ",", ""))
    If Err.Number <> 0 Then EvaluateExpression = 0
    On Error GoTo 0
End Function

'----------------------------------------
' Normalize number (remove formatting)
' ��������� ���
'----------------------------------------
Private Function NormalizeNumber(v As Variant) As String
    Dim s As String
    s = Trim(CStr(v))
    If s = "" Then
        NormalizeNumber = ""
        Exit Function
    End If
    s = Replace(s, ",", "")
    s = Replace(s, " ", "")
    s = ConvertPersianNumsToEnglish(s)
    NormalizeNumber = s
End Function

'----------------------------------------
' Convert Persian/Arabic numbers to English
' ����� ����� �����/���� �� ������
'----------------------------------------
Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    Dim i As Long
    result = inputText
    
    ' Persian digits (�-�)
    For i = 1776 To 1785
        result = Replace(result, ChrW(i), CStr(i - 1776))
    Next i
    
    ' Arabic-Indic digits (�-�)
    For i = 1632 To 1641
        result = Replace(result, ChrW(i), CStr(i - 1632))
    Next i
    
    ' Full-width digits
    For i = 65296 To 65305
        result = Replace(result, ChrW(i), CStr(i - 65296))
    Next i
    
    ConvertPersianNumsToEnglish = result
End Function

'----------------------------------------
' Clean amount text (remove all non-numeric)
' �ǘ����� ��� ����
'----------------------------------------
Private Function CleanAmountText(amountText As String) As String
    Dim result As String
    Dim j As Integer
    Dim charCode As Integer
    
    result = ConvertPersianNumsToEnglish(amountText)
    result = Replace(result, ",", "")
    result = Replace(result, ChrW(1644), "")   ' Persian comma
    result = Replace(result, ChrW(1548), "")   ' Arabic comma
    result = Replace(result, " ", "")
    result = Replace(result, ".", "")
    
    Dim cleanResult As String
    cleanResult = ""
    For j = 1 To Len(result)
        charCode = Asc(Mid(result, j, 1))
        If charCode >= 48 And charCode <= 57 Then
            cleanResult = cleanResult & Mid(result, j, 1)
        End If
    Next j
    
    CleanAmountText = cleanResult
End Function











'====================================================================================================
  '                           MERGED CHEQUE HELPERS - ChequeEdit
  '====================================================================================================

  Private Function FindConfigDateRow_CE(ByVal persianDate As String) As Long
      Dim wsInfo As Worksheet
      Dim matchRow As Variant

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      On Error GoTo 0

      If wsInfo Is Nothing Then Exit Function

      matchRow = Application.Match(persianDate, wsInfo.Columns("U"), 0)

      If Not IsError(matchRow) Then
          FindConfigDateRow_CE = CLng(matchRow)
      Else
          FindConfigDateRow_CE = 0
      End If
  End Function

  Private Sub AddToInfoColumn_CE(ByVal persianDate As String, ByVal colLetter As String, ByVal amount As Double)
      Dim wsInfo As Worksheet
      Dim rowNum As Long
      Dim currentVal As Double

      If amount <= 0 Then Exit Sub

      rowNum = FindConfigDateRow_CE(persianDate)
      If rowNum = 0 Then Exit Sub

      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)

      currentVal = 0
      If Not IsError(wsInfo.Cells(rowNum, colLetter).value) Then
          If IsNumeric(wsInfo.Cells(rowNum, colLetter).value) Then
              currentVal = CDbl(wsInfo.Cells(rowNum, colLetter).value)
          End If
      End If

      wsInfo.Cells(rowNum, colLetter).value = currentVal + amount
  End Sub

  Private Sub SubtractFromInfoColumn_CE(ByVal persianDate As String, ByVal colLetter As String, ByVal amount As Double)
      Dim wsInfo As Worksheet
      Dim rowNum As Long
      Dim currentVal As Double

      If amount <= 0 Then Exit Sub

      rowNum = FindConfigDateRow_CE(persianDate)
      If rowNum = 0 Then Exit Sub

      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)

      currentVal = 0
      If Not IsError(wsInfo.Cells(rowNum, colLetter).value) Then
          If IsNumeric(wsInfo.Cells(rowNum, colLetter).value) Then
              currentVal = CDbl(wsInfo.Cells(rowNum, colLetter).value)
          End If
      End If

      wsInfo.Cells(rowNum, colLetter).value = Application.Max(currentVal - amount, 0)
  End Sub

  Private Function IsLogActive_CE(ByVal v As Variant) As Boolean
      Dim s As String

      If VarType(v) = vbBoolean Then
          IsLogActive_CE = CBool(v)
          Exit Function
      End If

      s = UCase$(Trim(CStr(v)))
      IsLogActive_CE = (s = "TRUE" Or s = "1" Or s = "YES" Or s = "����")
  End Function

  Private Function FindActiveMergeIDForCheque_CE(ByVal chequeDate As String, ByVal chequeAmount As Double, ByVal serialNumber As String, ByVal companyName As String) As String
      Dim wsLog As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim logDate As String
      Dim logAmount As Double
      Dim logSerial As String
      Dim logCompany As String

      On Error Resume Next
      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      On Error GoTo 0

      If wsLog Is Nothing Then Exit Function

      lastRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).row
      If lastRow < 2 Then Exit Function

      serialNumber = NormalizeNumber(serialNumber)
      companyName = Trim(companyName)

      For r = 2 To lastRow
          If IsLogActive_CE(wsLog.Cells(r, "BF").value) Then
              logDate = Trim(CStr(wsLog.Cells(r, "BB").value))

              If IsNumeric(wsLog.Cells(r, "BC").value) Then
                  logAmount = CDbl(wsLog.Cells(r, "BC").value)
              Else
                  logAmount = 0
              End If

              logSerial = NormalizeNumber(wsLog.Cells(r, "BI").value)
              logCompany = Trim(CStr(wsLog.Cells(r, "BH").value))

              If logDate = chequeDate _
                 And Abs(logAmount - chequeAmount) < 0.01 _
                 And logSerial = serialNumber _
                 And logCompany = companyName Then

                  FindActiveMergeIDForCheque_CE = Trim(CStr(wsLog.Cells(r, "BA").value))
                  Exit Function
              End If
          End If
      Next r
  End Function

  Private Sub DeactivateMergeLog_CE(ByVal mergeID As String)
      Dim wsLog As Worksheet
      Dim lastRow As Long
      Dim r As Long

      If Trim(mergeID) = "" Then Exit Sub

      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      lastRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).row

      For r = 2 To lastRow
          If Trim(CStr(wsLog.Cells(r, "BA").value)) = mergeID _
             And IsLogActive_CE(wsLog.Cells(r, "BF").value) Then
              wsLog.Cells(r, "BF").value = False
          End If
      Next r
  End Sub

  Private Sub RemoveMergedChequeAccounting_CE(ByVal mergeID As String)
      Dim wsLog As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim chequeDate As String
      Dim chequeAmount As Double
      Dim reserveDate As String
      Dim reserveAmount As Double
      Dim xAdjusted As Boolean

      If Trim(mergeID) = "" Then Exit Sub

      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      lastRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).row

      For r = 2 To lastRow
          If Trim(CStr(wsLog.Cells(r, "BA").value)) = mergeID _
             And IsLogActive_CE(wsLog.Cells(r, "BF").value) Then

              chequeDate = Trim(CStr(wsLog.Cells(r, "BB").value))

              If IsNumeric(wsLog.Cells(r, "BC").value) Then
                  chequeAmount = CDbl(wsLog.Cells(r, "BC").value)
              Else
                  chequeAmount = 0
              End If

              reserveDate = Trim(CStr(wsLog.Cells(r, "BD").value))

              If IsNumeric(wsLog.Cells(r, "BE").value) Then
                  reserveAmount = CDbl(wsLog.Cells(r, "BE").value)
              Else
                  reserveAmount = 0
              End If

              ' X is stored once per merged cheque, but log has multiple  W rows.
              If Not xAdjusted Then
                  Call SubtractFromInfoColumn_CE(chequeDate, "X", chequeAmount)
                  xAdjusted = True
              End If

              Call SubtractFromInfoColumn_CE(reserveDate, "W", reserveAmount)
          End If
      Next r

      Call DeactivateMergeLog_CE(mergeID)
  End Sub

  Private Sub MoveMergedChequeAccounting_CE(ByVal mergeID As String, ByVal oldChequeDate As String, ByVal newChequeDate As String, ByVal chequeAmount As Double)
      Dim wsLog As Worksheet
      Dim lastRow As Long
      Dim r As Long

      If Trim(mergeID) = "" Then Exit Sub
      If oldChequeDate = newChequeDate Then Exit Sub

      ' Move X from old cheque date to new cheque date.
      Call SubtractFromInfoColumn_CE(oldChequeDate, "X", chequeAmount)
      Call AddToInfoColumn_CE(newChequeDate, "X", chequeAmount)

      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      lastRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).row

      For r = 2 To lastRow
          If Trim(CStr(wsLog.Cells(r, "BA").value)) = mergeID _
             And IsLogActive_CE(wsLog.Cells(r, "BF").value) Then
              wsLog.Cells(r, "BB").value = newChequeDate
          End If
      Next r
  End Sub

  Private Sub UpdateMergedChequeSerial_CE(ByVal mergeID As String, ByVal newSerial As String)
      Dim wsLog As Worksheet
      Dim lastRow As Long
      Dim r As Long

      If Trim(mergeID) = "" Then Exit Sub

      Set wsLog = ThisWorkbook.Sheets("����� �ǐ")
      lastRow = wsLog.Cells(wsLog.rows.count, "BA").End(xlUp).row

      For r = 2 To lastRow
          If Trim(CStr(wsLog.Cells(r, "BA").value)) = mergeID _
             And IsLogActive_CE(wsLog.Cells(r, "BF").value) Then
              wsLog.Cells(r, "BI").value = newSerial
          End If
      Next r
  End Sub










'====================================================================================================
'                                    EDIT / DELETE / MOVE FUNCTIONS
'                                    ����� ������ / ��� / ������
'====================================================================================================

'-------------------------------
' CommandButton2: Edit selected cheque
' ������ �� ������ ���
'-------------------------------
Private Sub CommandButton2_Click()
    Dim idx As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim rawDate As String
    Dim foundCol As Boolean

    If Me.ListBox1.ListIndex = -1 Then
        MsgBox "�� ��� ������ ���� ���.", vbExclamation, "���"
        Exit Sub
    End If
    
    idx = Me.ListBox1.ListIndex
    
    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    rawDate = Trim(CStr(Me.ListBox1.List(idx, 0)))
    If InStr(rawDate, "/") = 0 Then Exit Sub
    parts = Split(rawDate, "/")
    If UBound(parts) <> 2 Then Exit Sub

    Dim y As String, m As String, d As String
    y = parts(0): m = parts(1): d = parts(2)
    Set ws = FindSheet(y & "/" & Format(CInt(m), "00"))
    If ws Is Nothing Then Exit Sub

    r = 2 + (val(d) - 1) * totalRowsPerDayBlock
    foundCol = False

    Dim selectedAmount As Double, selectedSerial As String
    selectedAmount = CDbl(Replace(ListBox1.List(idx, 1), ",", ""))
    selectedSerial = NormalizeNumber(ListBox1.List(idx, 5))
      Dim selectedCompany As String
  Dim mergeID As String
selectedCompany = Trim(CStr(ListBox1.List(idx, 3)))

  mergeID = FindActiveMergeIDForCheque_CE(rawDate, selectedAmount, selectedSerial, selectedCompany)

  If mergeID <> "" And Trim(TextBox2.value) <> "" Then
      MsgBox "��� ��� �� �������� ���. ����� ���� �� �� ��� ��� ��������." & vbCrLf & _
             "���� ����� ���ۡ �� �� ��� ���� � ������ �� ��� �������� ���� ����.", vbExclamation, "�� ��������"
      Exit Sub
  End If
    ' Find the matching cheque
    For c = firstChequeCol To lastChequeCol Step 2
        If CDbl(ws.Cells(r + lowerHalfStartOffset, c).value) = selectedAmount Then
            Dim cellSerial As String
            cellSerial = NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value)
            If cellSerial = selectedSerial Then
                foundCol = True
                Exit For
            End If
        End If
    Next c

    If Not foundCol Then
        MsgBox "�� ������ ���� ������ ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    '--- Apply edits ---
    If TextBox2.value <> "" Then
        On Error Resume Next
        ws.Cells(r + lowerHalfStartOffset, c).value = EvaluateExpression(TextBox2.value)
        If Err.Number <> 0 Then
            MsgBox "����� ���� ���� ��� ���� ������ ����.", vbExclamation, "���"
            On Error GoTo 0
            Exit Sub
        End If
        On Error GoTo 0
    End If

   If TextBox3.value <> "" Then
      Dim newSerial As String
      newSerial = NormalizeNumber(TextBox3.value)

      ws.Cells(r + lowerHalfStartOffset, c + 1).value = CDbl(newSerial)

      If mergeID <> "" Then
          Call UpdateMergedChequeSerial_CE(mergeID, newSerial)
      End If
  End If

    MsgBox "�� �� ������ ������ ��.", vbInformation, "����"
    
    ' Refresh list
    If ComboBox1.value <> "" Then
        Call CommandButton1_Click
    End If
    
    TextBox1.value = ""
    TextBox2.value = ""
    TextBox3.value = ""
    Me.Label76.Caption = "����� " & ListBox1.ListCount & " �� ���� ��"
End Sub

'-------------------------------
' CommandButton3: Update cleared status
' ��������� ����� ��� ���
'-------------------------------
Private Sub CommandButton3_Click()
    Dim i As Long, selectedCount As Long, updatedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim statusVal As String
    Dim dateStr As String
    Dim listAmount As Double, listSerial As String
    
    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    '--- Count selected items ---
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i

    If selectedCount = 0 Then
        MsgBox "�� ��� ������ ����.", vbExclamation, "���"
        Exit Sub
    End If

    '--- Validate checkbox selection ---
    If (CheckBox1.value And CheckBox2.value) Or (Not CheckBox1.value And Not CheckBox2.value) Then
        MsgBox "����� ��� �� �� �������� '��� ���' �� '��� ����' �� ������ ����.", vbExclamation, "���"
        Exit Sub
    End If

    If CheckBox1.value Then
        statusVal = ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("C1").value
    Else
        statusVal = ""
    End If

    updatedCount = 0
    
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            dateStr = Trim(Me.ListBox1.List(i, 0))
            If InStr(dateStr, "/") > 0 Then
                parts = Split(dateStr, "/")
                If UBound(parts) = 2 Then
                    Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
                    If Not ws Is Nothing Then
                        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
                        listAmount = CDbl(Replace(ListBox1.List(i, 1), ",", ""))
                        listSerial = NormalizeNumber(ListBox1.List(i, 5))

                        For c = firstChequeCol To lastChequeCol Step 2
                            If CDbl(ws.Cells(r + lowerHalfStartOffset, c).value) = listAmount Then
                                If NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value) = listSerial Then
                                    ws.Cells(r, c + 1).value = statusVal
                                    updatedCount = updatedCount + 1
                                    Exit For
                                End If
                            End If
                        Next c
                    End If
                End If
            End If
        End If
    Next i

    MsgBox "����� " & updatedCount & " �� ��������� ��.", vbInformation, "����"
    
    ' Refresh list
    If ComboBox1.value <> "" Then
        Call CommandButton1_Click
    ElseIf TextBox4.value <> "" Then
        Call CommandButton6_Click
    End If
End Sub

'-------------------------------
' CommandButton4: Delete selected cheques
' ��� ������ ������ ���
'-------------------------------
Private Sub CommandButton4_Click()
    Dim i As Long, deletedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim dateStr As String
    Dim listAmount As Double, listSerial As String
    Dim found As Boolean

    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    '--- Count selected items ---
    Dim selectedCount As Long
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i
    
    If selectedCount = 0 Then
        MsgBox "�� ��� ������ ����.", vbExclamation, "���"
        Exit Sub
    End If
'--- Safety check: do not allow deleting multiple merged cheques at  once ---
  Dim selectedMergedCount As Long
  Dim checkDateStr As String
  Dim checkAmount As Double
  Dim checkSerial As String
  Dim checkCompany As String
  Dim checkMergeID As String

  selectedMergedCount = 0

  For i = 0 To Me.ListBox1.ListCount - 1
      If Me.ListBox1.Selected(i) Then
          checkDateStr = Trim(CStr(Me.ListBox1.List(i, 0)))
          checkAmount = CDbl(Replace(Me.ListBox1.List(i, 1), ",", ""))
          checkSerial = NormalizeNumber(Me.ListBox1.List(i, 5))
          checkCompany = Trim(CStr(Me.ListBox1.List(i, 3)))

          checkMergeID = FindActiveMergeIDForCheque_CE(checkDateStr, checkAmount, checkSerial, checkCompany)

          If checkMergeID <> "" Then
              selectedMergedCount = selectedMergedCount + 1
          End If
      End If
  Next i

  If selectedMergedCount > 1 Then
      MsgBox "��� ������ ��� �� � �� �������� ���� ����." & vbCrLf & _
             "����� ������ �������� �� ���� ��� ����.", _
             vbExclamation, "��� �� ��������"
      Exit Sub
  End If
    '--- Confirm deletion ---
    If MsgBox("��� ���� �� ��� " & selectedCount & " �� �����ȝ��� ����Ͽ" & vbCrLf & "��� ������ ���� ��Ґ�� ����.", _
              vbYesNo + vbExclamation, "����� ���") = vbNo Then Exit Sub

    deletedCount = 0
    
    For i = 0 To Me.ListBox1.ListCount - 1
        If Not Me.ListBox1.Selected(i) Then GoTo NextIterDel

        dateStr = Trim(Me.ListBox1.List(i, 0))
        If InStr(dateStr, "/") = 0 Then GoTo NextIterDel
        parts = Split(dateStr, "/")
        If UBound(parts) <> 2 Then GoTo NextIterDel

        Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
        If ws Is Nothing Then GoTo NextIterDel

        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
        listAmount = CDbl(Replace(ListBox1.List(i, 1), ",", ""))
        listSerial = NormalizeNumber(ListBox1.List(i, 5))

        found = False
        For c = firstChequeCol To lastChequeCol Step 2
            If CDbl(ws.Cells(r + lowerHalfStartOffset, c).value) = listAmount Then
               If NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value) = listSerial Then
      Dim deleteCompany As String
      Dim deleteMergeID As String

      deleteCompany = Trim(CStr(Me.ListBox1.List(i, 3)))

      deleteMergeID = FindActiveMergeIDForCheque_CE(dateStr, listAmount, listSerial, deleteCompany)

      If deleteMergeID <> "" Then
          Call RemoveMergedChequeAccounting_CE(deleteMergeID)
      End If

      ws.Cells(r, c).MergeArea.ClearContents
      ws.Cells(r, c + 1).MergeArea.ClearContents
      ws.Cells(r + lowerHalfStartOffset, c).MergeArea.ClearContents
      ws.Cells(r + lowerHalfStartOffset, c + 1).MergeArea.ClearContents

      deletedCount = deletedCount + 1
      found = True
      Exit For
  End If
            End If
        Next c

NextIterDel:
    Next i

    MsgBox deletedCount & " �� ��� ��.", vbInformation, "����� ���"

    ' Refresh list
    If ComboBox1.value <> "" Then
        Call CommandButton1_Click
    ElseIf TextBox4.value <> "" Then
        Call CommandButton6_Click
    End If
End Sub


'-------------------------------
' CommandButton5: Move cheque to new date
' ������ �� �� ����� ����
'-------------------------------
Private Sub CommandButton5_Click()
    Dim i As Long, movedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long, destR As Long
    Dim dateStr As String
    Dim listAmount As Double, listSerial As String
    Dim found As Boolean
    Dim destY As Long, destM As Long, destD As Long
    Dim destSheet As Worksheet
    Dim availableCol As Long
    Dim compValue As String

    '--- Read configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    '--- Validate target date ---
    If Trim(TextBox1.value) = "" Then
        MsgBox "����� ����� ���� �� ���� ����." & vbCrLf & "����: yyyy/mm/dd", vbExclamation, "����� ����"
        Exit Sub
    End If

    Dim t As String: t = ConvertPersianNumsToEnglish(Trim(TextBox1.value))
    If InStr(t, "/") = 0 Then
        MsgBox "���� ����� ������� ���.", vbExclamation, "���"
        Exit Sub
    End If
    parts = Split(t, "/")
    If UBound(parts) <> 2 Then
        MsgBox "���� ����� ������� ���.", vbExclamation, "���"
        Exit Sub
    End If
    
    On Error Resume Next
    destY = CLng(parts(0)): destM = CLng(parts(1)): destD = CLng(parts(2))
    On Error GoTo 0
    
    If destY < 1000 Or destM < 1 Or destM > 12 Or destD < 1 Or destD > 31 Then
        MsgBox "����� ���� ������� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Set destSheet = FindSheet(destY & "/" & Format(destM, "00"))
    If destSheet Is Nothing Then
        MsgBox "���� �� ����� " & destY & "/" & Format(destM, "00") & " ���� ���.", vbCritical, "��� ���� ���"
        Exit Sub
    End If

    '--- Count selected items ---
    Dim selectedCount As Long
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i
    
    If selectedCount = 0 Then
        MsgBox "�� ��� ������ ����.", vbExclamation, "���"
        Exit Sub
    End If

    movedCount = 0
    
    For i = 0 To Me.ListBox1.ListCount - 1
        If Not Me.ListBox1.Selected(i) Then GoTo NextIterMove

        dateStr = Trim(Me.ListBox1.List(i, 0))
        If InStr(dateStr, "/") = 0 Then GoTo NextIterMove
        parts = Split(dateStr, "/")
        If UBound(parts) <> 2 Then GoTo NextIterMove

        Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
        If ws Is Nothing Then GoTo NextIterMove

        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
        listAmount = CDbl(Replace(ListBox1.List(i, 1), ",", ""))
        listSerial = NormalizeNumber(ListBox1.List(i, 5))
 Dim moveCompany As String
  Dim moveMergeID As String
  Dim oldChequeDate As String
  Dim newChequeDate As String

  moveCompany = Trim(CStr(Me.ListBox1.List(i, 3)))
  oldChequeDate = dateStr
  newChequeDate = destY & "/" & Format(destM, "00") & "/" & Format(destD, "00")

  moveMergeID = FindActiveMergeIDForCheque_CE(oldChequeDate, listAmount, listSerial, moveCompany)
        '--- Find source cheque ---
        found = False
        For c = firstChequeCol To lastChequeCol Step 2
            If CDbl(ws.Cells(r + lowerHalfStartOffset, c).value) = listAmount Then
                If NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value) = listSerial Then
                    found = True
                    Exit For
                End If
            End If
        Next c

        If Not found Then GoTo NextIterMove

        '--- Find available spot in destination ---
        destR = 2 + (destD - 1) * totalRowsPerDayBlock
        availableCol = 0
        
        Dim checkCol As Long
        For checkCol = firstChequeCol To lastChequeCol Step 2
            If Len(Trim(destSheet.Cells(destR, checkCol).value)) = 0 Then
                availableCol = checkCol
                Exit For
            End If
        Next checkCol
        
        If availableCol = 0 Then
            MsgBox "��� ��� ���� ������� ���� �� �� ������." & vbCrLf & _
                   "��: " & listSerial & " - ����: " & Format(listAmount, "#,##0"), _
                   vbExclamation, "����� ʘ���"
            GoTo NextIterMove
        End If

        '--- Store company name from source ---
        compValue = ws.Cells(r, c).value

        '--- Copy data to available destination spot ---
        destSheet.Cells(destR, availableCol).value = compValue
        destSheet.Cells(destR, availableCol + 1).value = ws.Cells(r, c + 1).value
        destSheet.Cells(destR + lowerHalfStartOffset, availableCol).value = ws.Cells(r + lowerHalfStartOffset, c).value
        destSheet.Cells(destR + lowerHalfStartOffset, availableCol + 1).value = ws.Cells(r + lowerHalfStartOffset, c + 1).value

        '--- Clear source ---
        ws.Cells(r, c).MergeArea.ClearContents
        ws.Cells(r, c + 1).MergeArea.ClearContents
        ws.Cells(r + lowerHalfStartOffset, c).MergeArea.ClearContents
        ws.Cells(r + lowerHalfStartOffset, c + 1).MergeArea.ClearContents

        If moveMergeID <> "" Then
      Call MoveMergedChequeAccounting_CE(moveMergeID, oldChequeDate, newChequeDate, listAmount)
  End If

  movedCount = movedCount + 1

NextIterMove:
    Next i

    MsgBox movedCount & " �� ����� ��.", vbInformation, "����� ������"

    ' Refresh list
    If ComboBox1.value <> "" Then
        Call CommandButton1_Click
    End If
End Sub


'====================================================================================================
'                                    BANK SUBMISSION
'                                    ��� ���
'====================================================================================================

'-------------------------------
' SubmitButton: Submit to bank
' Ϙ�� ��� ���
'-------------------------------
Private Sub SubmitButton_Click()
    On Error GoTo ErrorHandler
    
    '--- Validate company selection ---
    If Me.ComboBox1.value = "" Then
        MsgBox "����� �ј� �� ������ ����.", vbExclamation, "������ �ј�"
        Exit Sub
    End If
    
    If Me.ListBox1.ListCount = 0 Then
        MsgBox "�� ��� �� ���� ���� �����.", vbExclamation, "���� ����"
        Exit Sub
    End If
    
    '--- Count selected items ---
    Dim selectedCount As Long
    Dim i As Long
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            selectedCount = selectedCount + 1
        End If
    Next i
    
    If selectedCount = 0 Then
        MsgBox "����� ����� � �� �� �� ���� ������ ����.", vbExclamation, "������ ��"
        Exit Sub
    End If
    
    '--- Get company info ---
    Dim companyName As String
    Dim BeneficiaryName As String
    Dim companyNationalID As String

    companyName = Me.ComboBox1.value
    BeneficiaryName = GetBeneficiaryFromCompany(companyName)
    companyNationalID = ConvertPersianNumsToEnglish(GetNationalID(companyName))
    
    If companyNationalID = "" Then
        MsgBox "����� ��� �ј� ���� ���.", vbCritical, "���"
        Exit Sub
    End If
    
    '--- Build cheques array ---
    Dim cheques() As BankChequeData
    ReDim cheques(1 To selectedCount)
    
    Dim chequeIndex As Long
    chequeIndex = 1
    
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            cheques(chequeIndex).chequeNumber = chequeIndex
            cheques(chequeIndex).companyName = BeneficiaryName
            cheques(chequeIndex).companyNationalID = companyNationalID
            cheques(chequeIndex).chequeAmount = CleanAmountText(Me.ListBox1.List(i, 1))
            cheques(chequeIndex).chequeDate = Me.ListBox1.List(i, 0)
            chequeIndex = chequeIndex + 1
        End If
    Next i
    
    '--- Get cheque codes from user ---
    Dim Middle8Digits As String
    Dim Last4Digits As String

    On Error Resume Next
    Middle8Digits = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value)
    Last4Digits = Trim(ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value)
    On Error GoTo ErrorHandler
    
    For i = 1 To selectedCount
        With frmChequeCodeInput
            If i = 1 Then
                .Initialize Middle8Digits, Last4Digits, True
                .Label1.Caption = "�� ��� (" & i & " �� " & selectedCount & ")" & vbCrLf & _
                                  "����: " & Format(CDbl(cheques(i).chequeAmount), "#,##0") & vbCrLf & _
                                  "�����: " & cheques(i).chequeDate & vbCrLf & vbCrLf & _
                                  "����� �� 16 ���� ���� �� ���� ����:"
                .Show
                
                If .WasCancelled Then
                    MsgBox "������ ��� ��.", vbInformation, "���"
                    Exit Sub
                End If
                
                Middle8Digits = .Middle8Digits
                Last4Digits = .Last4Digits
                
                On Error Resume Next
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value = Middle8Digits
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value = Last4Digits
                On Error GoTo ErrorHandler
                
            Else
                .Initialize Middle8Digits, Last4Digits, False
                .Label1.Caption = "�� " & i & " �� " & selectedCount & vbCrLf & _
                                  "����: " & Format(CDbl(cheques(i).chequeAmount), "#,##0") & vbCrLf & _
                                  "�����: " & cheques(i).chequeDate & vbCrLf & vbCrLf & _
                                  "��� 4 ��� ��� �� ���� ����:"
                .Show
                
                If .WasCancelled Then
                    Dim userChoice As VbMsgBoxResult
                    userChoice = MsgBox("��� �������� ��� �� �� �� ���� � �� �� ���� ����Ͽ" & vbCrLf & vbCrLf & _
                                       "��� = �� ��� � ����� ����" & vbCrLf & _
                                       "��� = ������ ���� ��� ���", _
                                       vbYesNo + vbQuestion, "�����")
                    If userChoice = vbNo Then
                        MsgBox "������ ��� ��.", vbInformation, "���"
                        Exit Sub
                    Else
                        GoTo NextChequeSubmit
                    End If
                End If
                
                Middle8Digits = .Middle8Digits
                Last4Digits = .Last4Digits
                
                On Error Resume Next
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AE3").value = Middle8Digits
                ThisWorkbook.Sheets(CONFIG_SHEET_NAME).Range("AF3").value = Last4Digits
                On Error GoTo ErrorHandler
            End If
            
            cheques(i).Code16Digit = .FullCode
            cheques(i).Code_Part1 = .First4Digits
            cheques(i).Code_Part2 = Left(.Middle8Digits, 4)
            cheques(i).Code_Part3 = Right(.Middle8Digits, 4)
            cheques(i).Code_Part4 = .Last4Digits
        End With
        
NextChequeSubmit:
    Next i
    
    '--- Export to CSV ---
    Call ExportChequesForBankSubmission(cheques)
    
    '--- Show success count ---
    Dim successCount As Long
    For i = 1 To selectedCount
        If cheques(i).Code16Digit <> "" Then
            successCount = successCount + 1
        End If
    Next i
    
    MsgBox "������� " & successCount & " �� ��ڝ���� � ����� ��.", vbInformation, "����"
    
    Exit Sub
    
ErrorHandler:
    MsgBox "���: " & Err.description, vbCritical, "���"
End Sub

'-------------------------------
' Export cheques to CSV file
' ����� ����� �� ���� CSV
'-------------------------------
Private Sub ExportChequesForBankSubmission(cheques() As BankChequeData)
    On Error GoTo ErrorHandler
    
    Dim desktopPath As String
    desktopPath = CreateObject("WScript.Shell").SpecialFolders("Desktop")
    
    Dim timestamp As String
    timestamp = Format(Now, "yyyymmdd_hhmmss")
    
    Dim fileName As String
    fileName = desktopPath & "\BankCheques_" & timestamp & ".csv"
    
    '--- Create UTF-8 CSV file ---
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    
    stream.Type = 2  ' Text
    stream.Charset = "UTF-8"
    stream.Open
    
    ' Write header
    stream.WriteText "Cheque_Number,Company_Name,Company_National_ID,Amount,Date,Code_16Digit,Code_Part1,Code_Part2,Code_Part3,Code_Part4" & vbCrLf
    
    ' Write data
    Dim i As Long
    For i = LBound(cheques) To UBound(cheques)
        If cheques(i).Code16Digit <> "" Then
            Dim csvLine As String
            csvLine = cheques(i).chequeNumber & "," & _
                     Chr(34) & cheques(i).companyName & Chr(34) & "," & _
                     cheques(i).companyNationalID & "," & _
                     cheques(i).chequeAmount & "," & _
                     Chr(34) & cheques(i).chequeDate & Chr(34) & "," & _
                     cheques(i).Code16Digit & "," & _
                     cheques(i).Code_Part1 & "," & _
                     cheques(i).Code_Part2 & "," & _
                     cheques(i).Code_Part3 & "," & _
                     cheques(i).Code_Part4
            
            stream.WriteText csvLine & vbCrLf
        End If
    Next i
    
    ' Save file
    stream.SaveToFile fileName, 2  ' 2 = overwrite
    stream.Close
    Set stream = Nothing
    
    MsgBox "���� ����� ��:" & vbCrLf & fileName, vbInformation, "����� ����"
    
    Exit Sub
    
ErrorHandler:
    MsgBox "��� �� ����� ����: " & Err.description, vbCritical, "���"
    If Not stream Is Nothing Then
        stream.Close
        Set stream = Nothing
    End If
End Sub

'====================================================================================================
'                                    TEXTBOX EVENTS
'                                    ��������� ʘ�ʝ�ǘ�
'====================================================================================================

'--- TextBox1: Target date for move ---
Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim txt As String, digits As String
    txt = Trim(TextBox1.value)
    If txt = "" Then Exit Sub
    txt = ConvertPersianNumsToEnglish(txt)
    Dim i As Long
    digits = ""
    For i = 1 To Len(txt)
        If Mid$(txt, i, 1) >= "0" And Mid$(txt, i, 1) <= "9" Then digits = digits & Mid$(txt, i, 1)
    Next i
    If Len(digits) = 8 Then
        TextBox1.value = Left(digits, 4) & "/" & Mid(digits, 5, 2) & "/" & Right(digits, 2)
    End If
End Sub

'--- TextBox2: Amount for edit ---
Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim raw As String, cleaned As String
    raw = Trim(TextBox2.value)
    If raw = "" Then Exit Sub
    cleaned = ConvertPersianNumsToEnglish(Replace(raw, ",", ""))
    cleaned = Replace(cleaned, " ", "")
    If IsNumeric(cleaned) Then
        On Error Resume Next
        TextBox2.value = Format(CDbl(cleaned), "#,##0")
        On Error GoTo 0
    End If
End Sub

'--- TextBox4: Search date ---
Private Sub TextBox4_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim txt As String, digits As String
    txt = Trim(TextBox4.value)
    If txt = "" Then Exit Sub
    txt = ConvertPersianNumsToEnglish(txt)
    Dim i As Long
    digits = ""
    For i = 1 To Len(txt)
        If Mid$(txt, i, 1) >= "0" And Mid$(txt, i, 1) <= "9" Then digits = digits & Mid$(txt, i, 1)
    Next i
    If Len(digits) = 8 Then
        TextBox4.value = Left(digits, 4) & "/" & Mid(digits, 5, 2) & "/" & Right(digits, 2)
    End If
End Sub

'--- TextBox4: Enter key to search ---
Private Sub TextBox4_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = 13 Then
        Call CommandButton6_Click
        KeyCode = 0
    End If
End Sub


'-------------------------------
' TextBox5: Enter key triggers search
'-------------------------------
Private Sub TextBox5_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = 13 Then
        Call CommandButton7_Click
        KeyCode = 0
    End If
End Sub

'-------------------------------
' TextBox5: Normalize serial on exit
'-------------------------------
Private Sub TextBox5_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim txt As String
    txt = Trim(TextBox5.value)
    If txt = "" Then Exit Sub
    ' Convert Persian/Arabic digits to ASCII and strip spaces
    TextBox5.value = Trim(ConvertPersianNumsToEnglish(txt))
End Sub


'-------------------------------
' CommandButton7: Search by Serial Number
' ����� �� ���� ����� ����� ��
'-------------------------------
Private Sub CommandButton7_Click()
    Dim ws          As Worksheet
    Dim c           As Long
    Dim company     As String
    Dim chequeDate  As String
    Dim amount      As Variant
    Dim serial      As Variant
    Dim status      As String
    Dim yearNum     As Long, monthNum As Long, dayNum As Long
    Dim results     As Collection: Set results = New Collection

    '--- Validate input ---
    Me.Label76.Caption = ""     ' reset before each search
    Dim searchSerial As String
    searchSerial = Trim(ConvertPersianNumsToEnglish(Trim(TextBox5.value)))

    If searchSerial = "" Then
        MsgBox "����� ����� ����� �� ���� ����.", vbExclamation, "����� ����"
        TextBox5.SetFocus
        Exit Sub
    End If

    '--- Read configuration ---
    Dim numCheques   As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters  As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear    As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount    As Long: yearCount = ReadConfigValue("cfg_YearCount")

    If numCheques = 0 Or totalCenters = 0 Or startYear = 0 Then
        MsgBox "���: ������ ������� ������ ���.", vbCritical, "���� �������"
        Exit Sub
    End If

    '--- Column / row offsets ---
    Dim firstChequeCol     As Long: firstChequeCol = 14
    Dim lastChequeCol      As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay         As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlk As Long: totalRowsPerDayBlk = rowsPerDay + 1
    Dim lowerOffset        As Long: lowerOffset = rowsPerDay \ 2

    ListBox1.Clear

    Dim endYear As Long: endYear = startYear + yearCount - 1

    '--- Scan every data sheet ---
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name <> CONFIG_SHEET_NAME And ws.Name <> "�������" And _
           ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then

            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0

            If yearNum >= startYear And yearNum <= endYear Then
                Dim dayStartRow As Long
                For dayNum = 1 To 31
                    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlk
                    If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For

                    For c = firstChequeCol To lastChequeCol Step 2
                        ' Compare serial (normalize both sides)
                        Dim cellSerial As String
                        cellSerial = NormalizeNumber(ws.Cells(dayStartRow + lowerOffset, c + 1).value)

                        If cellSerial <> "" And Left(cellSerial, Len(searchSerial)) = searchSerial Then
                            company = Trim(ws.Cells(dayStartRow, c).value)
                            amount = ws.Cells(dayStartRow + lowerOffset, c).value
                            serial = ws.Cells(dayStartRow + lowerOffset, c + 1).value
                            status = Trim(ws.Cells(dayStartRow, c + 1).value)
                            chequeDate = FormatJalaliDate(yearNum, monthNum, dayNum)
                            results.Add Array(chequeDate, amount, serial, status, company, ws.Name, dayStartRow, c)
                        End If
                    Next c
                Next dayNum
            End If
        End If
    Next ws

    '--- Nothing found ---
    If results.count = 0 Then
        MsgBox "�� ��� �� ����� " & searchSerial & " ���� ���.", vbExclamation, "����� �����"
        Exit Sub
    End If

    '--- Populate ListBox (same column order as other searches) ---
    Dim i As Long
    Dim companyNationalID As String

    For i = 1 To results.count
        companyNationalID = ConvertPersianNumsToEnglish(GetNationalID(CStr(results(i)(4))))

        With ListBox1
            .AddItem results(i)(0)                                                          ' Col 0: Date
            .List(.ListCount - 1, 1) = Format(results(i)(1), "#,##0")                      ' Col 1: Amount
            .List(.ListCount - 1, 2) = companyNationalID                                    ' Col 2: National ID
            .List(.ListCount - 1, 3) = results(i)(4)                                       ' Col 3: Company
            .List(.ListCount - 1, 4) = IIf(results(i)(3) = "", "��� ����", "��� ���")     ' Col 4: Status
            .List(.ListCount - 1, 5) = ConvertPersianNumsToEnglish(CStr(results(i)(2)))    ' Col 5: Serial
        End With
    Next i

    ' Auto-select the single result so edit/move/delete buttons work immediately
    If results.count = 1 Then
        ListBox1.Selected(0) = True
    End If

    ' Update Label76 with result count
    Me.Label76.Caption = "����� " & results.count & " �� ���� ��"

End Sub



'----------------------------------------------------------------
' ���� ���: ���� ����� ���� �� ��� ��� � ���
' ��� ��� ������� ���� YYYY-MM ���� (����� 1404-01)
'----------------------------------------------------------------
Private Function BuildFullDate(ByVal sName As String, _
                               ByVal dayNum As String) As String
    
    Dim parts() As String
    
    ' ���� ���� parse ���� ��� ��� �� ��ǘ���� "-"
    If InStr(sName, "-") > 0 Then
        parts = Split(sName, "-")
        If UBound(parts) >= 1 Then
            Dim yr As String
            Dim mo As String
            yr = Trim(parts(0))
            mo = Trim(parts(1))
            
            ' ������� �� �� ���� ���� ��� � ���
            If Len(mo) = 1 Then mo = "0" & mo
            If Len(dayNum) = 1 Then dayNum = "0" & dayNum
            
            BuildFullDate = yr & "/" & mo & "/" & dayNum
            Exit Function
        End If
    End If
    
    ' ǐ� parse ���� ���ϡ ��� ��� �� ���흐�����
    BuildFullDate = dayNum
    
End Function


