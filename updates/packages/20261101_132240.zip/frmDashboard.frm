VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmDashboard 
   Caption         =   "���� ��������"
   ClientHeight    =   12150
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   18960
   OleObjectBlob   =   "frmDashboard.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmDashboard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False







Option Explicit

'====================================================================================================
'                                    DASHBOARD FORM - ��� �������
'====================================================================================================
' This form displays:
' - Total factors and cheques (�� �ǘ����� � �����)
' - Unpaid factors and uncleared cheques (�ǘ������ �����ʝ���� � ������ ��ӝ����)
' - Breakdown by company with weighted average due date (������ �� �ݘ� �ј� �� ������ ����� ������)
' - Sort by due date to prioritize payments (���ȝ���� �� ���� ������ ���� �����ʝ���� ������)
'====================================================================================================
'====================================================================================================
'                                    CASH FLOW FORECAST VARIABLES
'====================================================================================================
Private m_AvgDailySales As Double
'====================================================================================================
'                                    CONFIGURATION HELPER
'====================================================================================================
Private m_DFHolidays As Object
Private m_DFSortColumn As Long
Private m_DFSortAscending As Boolean


'----------------------------------------
' Read configuration value from named range
' ������ ����� ������� �� ������ ��㝐���� ���
'----------------------------------------
Private Function ReadConfigValue(configName As String) As Long
    On Error Resume Next
    Dim val As Variant
    val = ThisWorkbook.Sheets("�������").Range(configName).value
    If IsNumeric(val) Then
        ReadConfigValue = CLng(val)
    Else
        ReadConfigValue = 0
    End If
    On Error GoTo 0
End Function

'====================================================================================================
'                                    PERSIAN CALENDAR FUNCTIONS
'                                    ����� ����� ����
'====================================================================================================

'----------------------------------------
' Get days in a Persian month
' ����� ������ � ��� ����
'----------------------------------------
Private Function GetPersianMonthDays(pYear As Long, pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        GetPersianMonthDays = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        GetPersianMonthDays = 30
    ElseIf pMonth = 12 Then
        ' Leap year check - ����� ��� �����
        If ((pYear - 1403) Mod 4 = 0) Then
            GetPersianMonthDays = 30
        Else
            GetPersianMonthDays = 29
        End If
    Else
        GetPersianMonthDays = 0
    End If
End Function

'----------------------------------------
' Convert Persian date (year, month, day) to Gregorian date
' ����� ����� ���� �� ������
'----------------------------------------
Private Function PersianToGregorianDate(pYear As Long, pMonth As Long, pDay As Long) As Date
    Dim i As Long, total_days As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 20) ' 1403/01/01
    
    total_days = 0
    
    ' Add days for complete months - ������ ������ ����
    For i = 1 To pMonth - 1
        total_days = total_days + GetPersianMonthDays(pYear, i)
    Next i
    
    ' Add remaining days - ������ ���������
    total_days = total_days + pDay - 1
    
    ' Adjust for year difference - ����� ���� ������ ���
    If pYear > 1403 Then
        For i = 1403 To pYear - 1
            total_days = total_days + IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    ElseIf pYear < 1403 Then
        For i = pYear To 1402
            total_days = total_days - IIf(((i - 1403) Mod 4 = 0), 366, 365)
        Next i
    End If
    
    PersianToGregorianDate = ref_g_date + total_days
End Function

'----------------------------------------
' Convert Gregorian date to Persian date string
' ����� ����� ������ �� ����
'----------------------------------------
Private Function GregorianToPersian(gDate As Date) As String
    Dim days_diff As Long, p_y As Long, p_m As Long, p_d As Long, days_in_p_year As Long
    Dim ref_g_date As Date: ref_g_date = DateSerial(2024, 3, 20)
    
    days_diff = gDate - ref_g_date
    p_y = 1403
    
    If days_diff < 0 Then
        Do
            p_y = p_y - 1
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            days_diff = days_diff + days_in_p_year
            If days_diff >= 0 Then Exit Do
        Loop
    Else
        Do
            days_in_p_year = IIf(((p_y - 1403) Mod 4 = 0), 366, 365)
            If days_diff >= days_in_p_year Then
                days_diff = days_diff - days_in_p_year
                p_y = p_y + 1
            Else
                Exit Do
            End If
        Loop
    End If
    
    p_m = 1
    Do While p_m <= 12
        Dim p_days_in_month As Long
        p_days_in_month = GetPersianMonthDays(p_y, p_m)
        If days_diff < p_days_in_month Then Exit Do
        days_diff = days_diff - p_days_in_month
        p_m = p_m + 1
    Loop
    
    p_d = days_diff + 1
    GregorianToPersian = p_y & "/" & Format(p_m, "00") & "/" & Format(p_d, "00")
End Function

'----------------------------------------
' Convert Persian date string to sortable Gregorian date
' Returns a very late date for "-" or invalid dates (to put at end of sorted list)
' ����� ���� ����� ���� �� ����� ���� ���ȝ����
'----------------------------------------
Private Function GetSortableDate(dateStr As String) As Date
    On Error GoTo InvalidDate
    
    If dateStr = "-" Or Trim(dateStr) = "" Then
        GetSortableDate = DateSerial(2099, 12, 31)
        Exit Function
    End If
    
    Dim parts() As String
    parts = Split(dateStr, "/")
    
    If UBound(parts) <> 2 Then
        GetSortableDate = DateSerial(2099, 12, 31)
        Exit Function
    End If
    
    GetSortableDate = PersianToGregorianDate(CLng(parts(0)), CLng(parts(1)), CLng(parts(2)))
    Exit Function
    
InvalidDate:
    GetSortableDate = DateSerial(2099, 12, 31)
End Function






Private Sub Textbox_BankBalance_Enter()
SetKeyboardEnglish
End Sub

Private Sub txtoffdays_Enter()
SetKeyboardEnglish
End Sub


Private Sub txtunclearedcheques_Enter()
SetKeyboardEnglish
End Sub

'====================================================================================================
'                                    FORM INITIALIZATION
'                                    �������� ����� ���
'====================================================================================================

Private Sub UserForm_Initialize()
    Dim i As Long
    

    ' --- Populate Year ListBox (multi-select) ---
    ' �� ���� ���� �����
    ListBox1.Clear
    ListBox1.MultiSelect = fmMultiSelectMulti
    On Error Resume Next
    Dim yearList As Variant
    yearList = ThisWorkbook.Sheets("�������").Range("cfg_YearList").value
    If IsArray(yearList) Then
        Dim y As Long
        For y = LBound(yearList) To UBound(yearList)
            If Trim(yearList(y, 1)) <> "" Then
                ListBox1.AddItem yearList(y, 1)
            End If
        Next y
    End If
    On Error GoTo 0
    
    ' --- Populate Month ListBox (multi-select) ---
    ' �� ���� ���� �����
    ListBox2.Clear
    ListBox2.MultiSelect = fmMultiSelectMulti
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    For i = 0 To 11
        ListBox2.AddItem monthNames(i)
    Next i
    
    ' --- Populate Company ListBox (multi-select) ---
    ' �� ���� ���� �јʝ��
    ListBox3.Clear
    ListBox3.MultiSelect = fmMultiSelectMulti
    On Error Resume Next
    Dim wsInfo As Worksheet
    Set wsInfo = ThisWorkbook.Sheets("�������")
    Dim lastRow As Long
    lastRow = wsInfo.Cells(wsInfo.rows.count, "A").End(xlUp).Row
    Dim c As Long
    For c = 2 To lastRow
        Dim compName As String
        compName = CleanCompanyName(wsInfo.Cells(c, "A").value)
        If compName <> "" And compName <> "***" Then
            ListBox3.AddItem compName
        End If
    Next c
    On Error GoTo 0
    
    ' --- Initialize result ListBox with 6 columns ---
    ' �������� ���� ����� �� � ����
    ' Columns: Company | Total Factors | Unpaid Factors | Total Cheques | Uncleared Cheques | Avg Due Date
    ' ������: �ј� | �� �ǘ��� | �ǘ��� �����ʝ���� | �� �� | �� ��ӝ���� | ������ ������
    ListBox4.Clear
    ListBox4.ColumnCount = 6
    ListBox4.ColumnWidths = "120;94;98;94;98;80"
    
    ' --- Initialize summary labels ---
    ' �������� �э�ȝ��� �����
    On Error Resume Next
    Label_TotalFactors.Caption = "0"
    Label_TotalUnpaidFactors.Caption = "0"
    Label_TotalCheques.Caption = "0"
    Label_TotalUnclearedCheques.Caption = "0"
    Label_Balance.Caption = "0"
    On Error GoTo 0
    
    '--- Initialize Cash Flow Forecast Controls ---
    ' Set default month selection to current month
    Dim defaultYearForSelection As Long
    On Error Resume Next
    defaultYearForSelection = CLng(ThisWorkbook.Sheets(DF_Text("1575,1591,1604,1575,1593,1575,1578")).Range("cfg_DefaultYear").Value2)
    On Error GoTo 0
    If defaultYearForSelection > 0 Then
        Dim defaultYearIndex As Long
        For defaultYearIndex = 0 To ListBox1.ListCount - 1
            If CStr(ListBox1.List(defaultYearIndex)) = CStr(defaultYearForSelection) Then
                ListBox1.Selected(defaultYearIndex) = True
                Exit For
            End If
        Next defaultYearIndex
    End If


    Dim defaultMonth As Long
    On Error Resume Next
    defaultMonth = CLng(ThisWorkbook.Sheets("�������").Range("cfg_DefaultMonth").value)
    On Error GoTo 0
    
    If defaultMonth >= 1 And defaultMonth <= 12 Then
        ListBox2.Selected(defaultMonth - 1) = True
    End If
    
    ' Initialize Listbox_next30days
    On Error Resume Next
    With Listbox_next30days
        .ColumnCount = 2
        .ColumnWidths = "130;184"
        .Clear
    End With
    On Error GoTo 0
    
    ' Initialize Label_MonthAverage
    On Error Resume Next
    Label_MonthAverage.Caption = "0"
    On Error GoTo 0
    
    ' Calculate initial month average
    Call UpdateMonthAverage
    
    '--- Set default date to today's Persian date ---
    Dim todayPersian As String
    todayPersian = GregorianToPersian(Date)
    Me.Textbox_DateForCheque.value = todayPersian
    
    '--- Set Page1 as the active page ---
    On Error Resume Next
    Me.MultiPage1.value = 0  ' 0 = Page1, 1 = Page2
    On Error GoTo 0
    Call LoadExpensesFromSheet
    Me.txtpercent.ControlTipText = "���� ���� �� ������ ����� (�� ���� ������ �� �ǘӡ ���� ���� ��� �� ���� ����. �� ���� ������ � ���� ���� ���� : ���� ��ԝ���: 30)"
    Me.txtoffdays.Visible = False
    Me.txtsalarydate.ControlTipText = "��� ���� ����"
    Me.txtinstallment1date.ControlTipText = "��� ���� ����"
    Me.txtinstallment2date.ControlTipText = "��� ���� ����"
    Me.txtinsurancedate.ControlTipText = "��� ���� ����"
    Me.txtotherexpensesdate.ControlTipText = "��� ���� ����"
    Me.txtrent1date.ControlTipText = "��� ���� ����"
    Me.txtrent2date.ControlTipText = "��� ���� ����"

    m_DFSortColumn = -1
End Sub

'====================================================================================================
'                                    HELPER FUNCTIONS
'                                    ����� ���
'====================================================================================================

'----------------------------------------
' Get selected items from ListBox as Collection
' ������ ������� ������ ��� �� ���ʝ�ǘ�
'----------------------------------------
Private Function GetSelectedItems(lb As MSForms.ListBox) As Collection
    Dim col As New Collection
    Dim i As Long
    For i = 0 To lb.ListCount - 1
        If lb.Selected(i) Then
            col.Add lb.List(i)
        End If
    Next i
    Set GetSelectedItems = col
End Function

'----------------------------------------
' Check if value is in collection
' ����� ���� ����� �� �����
'----------------------------------------
Private Function IsInCollection(col As Collection, val As Variant) As Boolean
    Dim item As Variant
    For Each item In col
        If CStr(item) = CStr(val) Then
            IsInCollection = True
            Exit Function
        End If
    Next item
    IsInCollection = False
End Function

'====================================================================================================
'                                    MAIN DASHBOARD FUNCTIONS
'                                    ����� ���� �������
'====================================================================================================

'----------------------------------------
' CommandButton1: Refresh Dashboard - Calculate Totals
' Ϙ�� �: �������� ������� - ������ ��ڝ��
'----------------------------------------
Private Sub CommandButton1_Click()
    Dim ws As Worksheet
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim col As Long
    
    ' --- Read Dynamic Configuration ---
    ' ������ ������� ����
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")
    
    ' Calculate column positions - ������ ������ ������
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    
    ' Calculate row layout - ������ ������ ���ݝ��
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' --- Get selected filters ---
    ' ������ �������� ������ ���
    Dim selectedYears As Collection: Set selectedYears = GetSelectedItems(ListBox1)
    Dim selectedMonths As Collection: Set selectedMonths = GetSelectedItems(ListBox2)
    Dim selectedCompanies As Collection: Set selectedCompanies = GetSelectedItems(ListBox3)
    
    ' If nothing selected, include all - ǐ� ���� ������ ���� ��� �� ���� ��
    Dim filterAllYears As Boolean: filterAllYears = (selectedYears.count = 0)
    Dim filterAllMonths As Boolean: filterAllMonths = (selectedMonths.count = 0)
    Dim filterAllCompanies As Boolean: filterAllCompanies = (selectedCompanies.count = 0)
    
    ' Convert month names to numbers for matching
    ' ����� ��� ����� �� ����� ���� ������
    Dim selectedMonthNums As Collection: Set selectedMonthNums = New Collection
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    Dim m As Variant, mn As Long
    For Each m In selectedMonths
        For mn = 0 To 11
            If m = monthNames(mn) Then
                selectedMonthNums.Add mn + 1
                Exit For
            End If
        Next mn
    Next m
    
    ' --- Initialize Totals ---
    ' �������� ����� ��ڝ��
    Dim totalUnpaidFactors As Double: totalUnpaidFactors = 0
    Dim totalUnclearedCheques As Double: totalUnclearedCheques = 0
    Dim totalFactors As Double: totalFactors = 0
    Dim totalCheques As Double: totalCheques = 0
    
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    Application.ScreenUpdating = False
    
    ' --- Loop through all sheets ---
    ' ���� ��� ���� ��ʝ��
    For Each ws In ThisWorkbook.Worksheets
        ' Skip non-data sheets - �� ���� ��ʝ��� ��� ������
        If ws.Name <> "�������" And ws.Name <> "�������" And ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0
            
            If yearNum >= startYear And yearNum <= endYear Then
                
                ' Check year filter - ����� ����� ���
                Dim matchYear As Boolean
                matchYear = filterAllYears Or IsInCollection(selectedYears, CStr(yearNum))
                
                ' Check month filter - ����� ����� ���
                Dim matchMonth As Boolean
                matchMonth = filterAllMonths Or IsInCollection(selectedMonthNums, monthNum)
                
                If matchYear And matchMonth Then
                    Dim dayStartRow As Long
                    For dayNum = 1 To 31
                        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                        If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For
                        
                        ' --- Count Factors - ����� �ǘ����� ---
                        For col = firstFactorCol To lastFactorCol Step 2
                            Dim factorCompany As String: factorCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim factorStatus As String: factorStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            Dim factorAmount As Double
                            
                            If factorCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchFactorCompany As Boolean
                                matchFactorCompany = filterAllCompanies Or IsInCollection(selectedCompanies, factorCompany)
                                
                                If matchFactorCompany Then
                                    factorAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Add to totals - ������ �� ��ڝ��
                                    totalFactors = totalFactors + factorAmount
                                    
                                    ' If unpaid (status is empty) - ǐ� ������ ���� (����� ����)
                                    If factorStatus = "" Then
                                        totalUnpaidFactors = totalUnpaidFactors + factorAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                        ' --- Count Cheques - ����� ����� ---
                        For col = firstChequeCol To lastChequeCol Step 2
                            Dim chequeCompany As String: chequeCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim chequeStatus As String: chequeStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            Dim chequeAmount As Double
                            
                            If chequeCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchChequeCompany As Boolean
                                matchChequeCompany = filterAllCompanies Or IsInCollection(selectedCompanies, chequeCompany)
                                
                                If matchChequeCompany Then
                                    chequeAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Add to totals - ������ �� ��ڝ��
                                    totalCheques = totalCheques + chequeAmount
                                    
                                    ' If uncleared (status is empty) - ǐ� ��� ���� (����� ����)
                                    If chequeStatus = "" Then
                                        totalUnclearedCheques = totalUnclearedCheques + chequeAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                    Next dayNum
                End If
            End If
        End If
    Next ws
    
    Application.ScreenUpdating = True
    
    ' --- Update summary labels ---
    ' ��������� �э�ȝ��� �����
    On Error Resume Next
    Label_TotalFactors.Caption = Format(totalFactors, "#,##0")
    Label_TotalUnpaidFactors.Caption = Format(totalUnpaidFactors, "#,##0")
    Label_TotalCheques.Caption = Format(totalCheques, "#,##0")
    Label_TotalUnclearedCheques.Caption = Format(totalUnclearedCheques, "#,##0")
    
    ' --- Show balance (Unpaid - Uncleared) ---
    ' ����� ����� (�����ʝ���� - ��ӝ����)
    Dim balance As Double
    balance = totalUnpaidFactors - totalUnclearedCheques
    Label_Balance.Caption = Format(balance, "#,##0")
    
    ' Color code the balance - �䐝���� �����
    If balance > 0 Then
        Label_Balance.ForeColor = RGB(192, 0, 0) ' Red - ����: �������
    ElseIf balance < 0 Then
        Label_Balance.ForeColor = RGB(0, 128, 0) ' Green - ���: ��Ș����
    Else
        Label_Balance.ForeColor = RGB(0, 0, 0)   ' Black - �Ԙ�: ������
    End If
    On Error GoTo 0
    
    MsgBox "������� ��������� ��.", vbInformation, "���������"
End Sub

'----------------------------------------
' CommandButton3: Show Breakdown by Company with Weighted Average Due Date
' Ϙ�� �: ����� ������ �� �ݘ� �ј� �� ������ ����� ������
'----------------------------------------
Private Sub CommandButton3_Click()
    Dim ws As Worksheet
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim col As Long
    
    ' --- Read Dynamic Configuration ---
    ' ������ ������� ����
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")
    
    ' Calculate column positions - ������ ������ ������
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    
    ' Calculate row layout - ������ ������ ���ݝ��
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' --- Get selected filters ---
    ' ������ �������� ������ ���
    Dim selectedYears As Collection: Set selectedYears = GetSelectedItems(ListBox1)
    Dim selectedMonths As Collection: Set selectedMonths = GetSelectedItems(ListBox2)
    Dim selectedCompanies As Collection: Set selectedCompanies = GetSelectedItems(ListBox3)
    
    Dim filterAllYears As Boolean: filterAllYears = (selectedYears.count = 0)
    Dim filterAllMonths As Boolean: filterAllMonths = (selectedMonths.count = 0)
    Dim filterAllCompanies As Boolean: filterAllCompanies = (selectedCompanies.count = 0)
    
    ' Convert month names to numbers
    ' ����� ��� ����� �� �����
    Dim selectedMonthNums As Collection: Set selectedMonthNums = New Collection
    Dim monthNames As Variant
    monthNames = Array("�������", "��������", "�����", "���", "�����", "������", _
                       "���", "����", "���", "��", "����", "�����")
    Dim m As Variant, mn As Long
    For Each m In selectedMonths
        For mn = 0 To 11
            If m = monthNames(mn) Then
                selectedMonthNums.Add mn + 1
                Exit For
            End If
        Next mn
    Next m
    
    ' --- Dictionaries to store company totals ---
    ' �������� ���� ����� ��ڝ��� �� �ј�
    Dim companyFactors As Object: Set companyFactors = CreateObject("Scripting.Dictionary")
    Dim companyCheques As Object: Set companyCheques = CreateObject("Scripting.Dictionary")
    Dim companyUnpaidFactors As Object: Set companyUnpaidFactors = CreateObject("Scripting.Dictionary")
    Dim companyUnclearedCheques As Object: Set companyUnclearedCheques = CreateObject("Scripting.Dictionary")
    
    ' NEW: Dictionaries for weighted average due date calculation
    ' ����: �������� ���� ������ ������ ����� ������
    ' Formula: Weighted Avg Due Date = Sum(Amount * DueDate) / Sum(Amount)
    ' �����: ������ ����� ������ = �����(���� � ����� ������) / �����(����)
    Dim companyWeightedDueDateSum As Object: Set companyWeightedDueDateSum = CreateObject("Scripting.Dictionary")
    Dim companyUnpaidAmountSum As Object: Set companyUnpaidAmountSum = CreateObject("Scripting.Dictionary")
    
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    Application.ScreenUpdating = False
    
    ' --- Loop through all sheets ---
    ' ���� ��� ���� ��ʝ��
    For Each ws In ThisWorkbook.Worksheets
        ' Skip non-data sheets - �� ���� ��ʝ��� ��� ������
        If ws.Name <> "�������" And ws.Name <> "�������" And ws.Name <> "��" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0
            
            If yearNum >= startYear And yearNum <= endYear Then
                ' Check year filter - ����� ����� ���
                Dim matchYear As Boolean
                matchYear = filterAllYears Or IsInCollection(selectedYears, CStr(yearNum))
                
                ' Check month filter - ����� ����� ���
                Dim matchMonth As Boolean
                matchMonth = filterAllMonths Or IsInCollection(selectedMonthNums, monthNum)
                
                If matchYear And matchMonth Then
                    Dim dayStartRow As Long
                    For dayNum = 1 To 31
                        dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                        If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For
                        
                        ' --- Process Factors - ������ �ǘ����� ---
                        For col = firstFactorCol To lastFactorCol Step 2
                            Dim factorCompany As String: factorCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim factorStatus As String: factorStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            
                            If factorCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchFactorCompany As Boolean
                                matchFactorCompany = filterAllCompanies Or IsInCollection(selectedCompanies, factorCompany)
                                
                                If matchFactorCompany Then
                                    ' Get factor amount - ������ ���� �ǘ���
                                    Dim factorAmount As Double
                                    factorAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Initialize dictionaries for this company if not exists
                                    ' �������� ����� �������� ���� ��� �ј� ǐ� ���� �����
                                    If Not companyFactors.exists(factorCompany) Then
                                        companyFactors.Add factorCompany, 0
                                        companyUnpaidFactors.Add factorCompany, 0
                                        companyWeightedDueDateSum.Add factorCompany, 0
                                        companyUnpaidAmountSum.Add factorCompany, 0
                                    End If
                                    
                                    ' Add to total factors - ������ �� �� �ǘ�����
                                    companyFactors(factorCompany) = companyFactors(factorCompany) + factorAmount
                                    
                                    ' If unpaid, calculate due date - ǐ� �����ʝ���� ������ ������
                                    If factorStatus = "" Then
                                        companyUnpaidFactors(factorCompany) = companyUnpaidFactors(factorCompany) + factorAmount
                                        
                                        ' Get forjeh (credit period in days) from the cell next to amount
                                        ' ������ ���� (���� ������ �� ���) �� ���� ���� ����
                                        Dim forjeh As Long
                                        forjeh = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col + 1).value)
                                        
                                        ' Calculate factor date - ������ ����� �ǘ���
                                        Dim factorDate As Date
                                        factorDate = PersianToGregorianDate(yearNum, monthNum, dayNum)
                                        
                                        ' Calculate due date = factor date + forjeh
                                        ' ������ ����� ������ = ����� �ǘ��� + ����
                                        Dim dueDate As Date
                                        dueDate = factorDate + forjeh
                                        
                                        ' Add to weighted sum: amount * date (as numeric)
                                        ' ������ �� ����� �����: ���� � ����� (�� ���� ����)
                                        companyWeightedDueDateSum(factorCompany) = companyWeightedDueDateSum(factorCompany) + (factorAmount * CDbl(dueDate))
                                        companyUnpaidAmountSum(factorCompany) = companyUnpaidAmountSum(factorCompany) + factorAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                        ' --- Process Cheques - ������ ����� ---
                        For col = firstChequeCol To lastChequeCol Step 2
                            Dim chequeCompany As String: chequeCompany = CleanCompanyName(ws.Cells(dayStartRow, col).value)
                            Dim chequeStatus As String: chequeStatus = Trim(ws.Cells(dayStartRow, col + 1).value)
                            
                            If chequeCompany <> "" Then
                                ' Check company filter - ����� ����� �ј�
                                Dim matchChequeCompany As Boolean
                                matchChequeCompany = filterAllCompanies Or IsInCollection(selectedCompanies, chequeCompany)
                                
                                If matchChequeCompany Then
                                    ' Get cheque amount - ������ ���� ��
                                    Dim chequeAmount As Double
                                    chequeAmount = val(ws.Cells(dayStartRow + lowerHalfStartOffset, col).value)
                                    
                                    ' Initialize dictionaries for this company if not exists
                                    ' �������� ����� �������� ���� ��� �ј� ǐ� ���� �����
                                    If Not companyCheques.exists(chequeCompany) Then
                                        companyCheques.Add chequeCompany, 0
                                        companyUnclearedCheques.Add chequeCompany, 0
                                    End If
                                    
                                    ' Add to total cheques - ������ �� �� �����
                                    companyCheques(chequeCompany) = companyCheques(chequeCompany) + chequeAmount
                                    
                                    ' If uncleared - ǐ� ��� ����
                                    If chequeStatus = "" Then
                                        companyUnclearedCheques(chequeCompany) = companyUnclearedCheques(chequeCompany) + chequeAmount
                                    End If
                                End If
                            End If
                        Next col
                        
                    Next dayNum
                End If
            End If
        End If
    Next ws
    
    Application.ScreenUpdating = True
    
    ' --- Populate ListBox4 with breakdown ---
    ' �� ���� ���ʝ�ǘ�� �� ������
    ListBox4.Clear
    
    ' Get all unique companies - ������ ���� �јʝ��� ���
    Dim allCompanies As Object: Set allCompanies = CreateObject("Scripting.Dictionary")
    Dim k As Variant
    For Each k In companyFactors.keys
        If Not allCompanies.exists(k) Then allCompanies.Add k, True
    Next k
    For Each k In companyCheques.keys
        If Not allCompanies.exists(k) Then allCompanies.Add k, True
    Next k
    
    ' Add rows to ListBox4 - ������ ���ݝ�� �� ���ʝ�ǘ��
    For Each k In allCompanies.keys
        Dim fTotal As Double: fTotal = 0
        Dim fUnpaid As Double: fUnpaid = 0
        Dim cTotal As Double: cTotal = 0
        Dim cUncleared As Double: cUncleared = 0
        Dim avgDueDateStr As String: avgDueDateStr = "-"
        
        ' Get values from dictionaries - ������ ������ �� ��������
        If companyFactors.exists(k) Then fTotal = companyFactors(k)
        If companyUnpaidFactors.exists(k) Then fUnpaid = companyUnpaidFactors(k)
        If companyCheques.exists(k) Then cTotal = companyCheques(k)
        If companyUnclearedCheques.exists(k) Then cUncleared = companyUnclearedCheques(k)
        
        ' Calculate weighted average due date
        ' ������ ������ ����� ������
        If companyUnpaidAmountSum.exists(k) Then
            If companyUnpaidAmountSum(k) > 0 Then
                Dim avgDueDate As Date
                avgDueDate = CDate(companyWeightedDueDateSum(k) / companyUnpaidAmountSum(k))
                avgDueDateStr = GregorianToPersian(avgDueDate)
            End If
        End If
        
        ' Add row to ListBox4 - ������ ���� �� ���ʝ�ǘ��
        With ListBox4
            .AddItem k                                      ' Column 0: Company - �ј�
            .List(.ListCount - 1, 1) = Format(fTotal, "#,##0")      ' Column 1: Total Factors - �� �ǘ���
            .List(.ListCount - 1, 2) = Format(fUnpaid, "#,##0")     ' Column 2: Unpaid Factors - �ǘ��� �����ʝ����
            .List(.ListCount - 1, 3) = Format(cTotal, "#,##0")      ' Column 3: Total Cheques - �� ��
            .List(.ListCount - 1, 4) = Format(cUncleared, "#,##0")  ' Column 4: Uncleared Cheques - �� ��ӝ����
            .List(.ListCount - 1, 5) = avgDueDateStr                ' Column 5: Avg Due Date - ������ ������
        End With
    Next k
    
    MsgBox "������ �� �ݘ� �ј� ��ѐ���� ��." & vbCrLf & _
           "����� �ј�: " & allCompanies.count, vbInformation, "������"
End Sub

'----------------------------------------
' CommandButton7: Sort ListBox4 by Average Due Date (earliest first = most urgent)
' Ϙ�� �: ���ȝ���� ���ʝ�ǘ�� �� ���� ������ ������ (������� = ��������)
'----------------------------------------
Private Sub CommandButton7_Click()
    If ListBox4.ListCount <= 1 Then
        MsgBox "������ ���� ���ȝ���� ���� �����.", vbExclamation, "���ȝ����"
        Exit Sub
    End If
    
    Dim i As Long, j As Long
    Dim itemCount As Long
    itemCount = ListBox4.ListCount
    
    ' Copy ListBox4 data to array - ��� ������� ���ʝ�ǘ� �� �����
    Dim data() As Variant
    ReDim data(0 To itemCount - 1, 0 To 5)
    
    For i = 0 To itemCount - 1
        data(i, 0) = ListBox4.List(i, 0)  ' Company - �ј�
        data(i, 1) = ListBox4.List(i, 1)  ' Total Factors - �� �ǘ���
        data(i, 2) = ListBox4.List(i, 2)  ' Unpaid Factors - �ǘ��� �����ʝ����
        data(i, 3) = ListBox4.List(i, 3)  ' Total Cheques - �� ��
        data(i, 4) = ListBox4.List(i, 4)  ' Uncleared Cheques - �� ��ӝ����
        data(i, 5) = ListBox4.List(i, 5)  ' Avg Due Date - ������ ������
    Next i
    
    ' Bubble sort by date (column 5) - earliest first
    ' ���ȝ���� ����� �� ���� ����� (���� �) - ������� ���
    Dim tempRow(0 To 5) As Variant
    Dim date1 As Date, date2 As Date
    
    For i = 0 To itemCount - 2
        For j = i + 1 To itemCount - 1
            ' Convert dates for comparison - ����� ����Ν�� ���� ������
            date1 = GetSortableDate(CStr(data(i, 5)))
            date2 = GetSortableDate(CStr(data(j, 5)))
            
            ' Sort ascending (earliest first) - ���ȝ���� ����� (������� ���)
            If date1 > date2 Then
                ' Swap rows - ������� ���ݝ��
                Dim colIdx As Long
                For colIdx = 0 To 5
                    tempRow(colIdx) = data(i, colIdx)
                    data(i, colIdx) = data(j, colIdx)
                    data(j, colIdx) = tempRow(colIdx)
                Next colIdx
            End If
        Next j
    Next i
    
    ' Reload ListBox4 with sorted data - ��ѐ���� ���� ���ʝ�ǘ� �� ������� ���� ���
    ListBox4.Clear
    For i = 0 To itemCount - 1
        With ListBox4
            .AddItem data(i, 0)
            .List(.ListCount - 1, 1) = data(i, 1)
            .List(.ListCount - 1, 2) = data(i, 2)
            .List(.ListCount - 1, 3) = data(i, 3)
            .List(.ListCount - 1, 4) = data(i, 4)
            .List(.ListCount - 1, 5) = data(i, 5)
        End With
    Next i
    
    MsgBox "���� �� ���� ����� ������ ���� ��." & vbCrLf & _
           "(�������� �� ����)", vbInformation, "���ȝ����"
End Sub

'----------------------------------------
' CommandButton2: Clear All Filters
' Ϙ�� �: �ǘ ���� ��� �������
'----------------------------------------
Private Sub CommandButton2_Click()
    Dim i As Long
    
    ' Clear year selection - �ǘ ���� ������ ���
    For i = 0 To ListBox1.ListCount - 1
        ListBox1.Selected(i) = False
    Next i
    
    ' Clear month selection - �ǘ ���� ������ ���
    For i = 0 To ListBox2.ListCount - 1
        ListBox2.Selected(i) = False
    Next i
    
    ' Clear company selection - �ǘ ���� ������ �ј�
    For i = 0 To ListBox3.ListCount - 1
        ListBox3.Selected(i) = False
    Next i
    
    ' Clear results - �ǘ ���� �����
    ListBox4.Clear
    
    ' Reset labels - �������� �э�ȝ��
    On Error Resume Next
    Label_TotalFactors.Caption = "0"
    Label_TotalUnpaidFactors.Caption = "0"
    Label_TotalCheques.Caption = "0"
    Label_TotalUnclearedCheques.Caption = "0"
    Label_Balance.Caption = "0"
    Label_Balance.ForeColor = RGB(0, 0, 0)
    On Error GoTo 0
    
    MsgBox "������� �ǘ ����.", vbInformation, "�ǘ ����"
    UpdateMonthAverage
    CalculateCashFlowForecast
End Sub

'----------------------------------------
' ListBox4 Double-Click: Show details for selected company
' ���᝘�� ��� ���ʝ�ǘ��: ����� ������ �ј� ������ ���
'----------------------------------------
Private Sub ListBox4_DblClick(ByVal CANCEL As MSForms.ReturnBoolean)
    If ListBox4.listIndex < 0 Then Exit Sub
    
    Dim selectedCompany As String
    selectedCompany = ListBox4.List(ListBox4.listIndex, 0)
    
    Dim msg As String
    msg = "������ �ј�: " & selectedCompany & vbCrLf & vbCrLf
    msg = msg & "�� �ǘ���: " & ListBox4.List(ListBox4.listIndex, 1) & vbCrLf
    msg = msg & "�ǘ��� �����ʝ����: " & ListBox4.List(ListBox4.listIndex, 2) & vbCrLf
    msg = msg & "�� ��: " & ListBox4.List(ListBox4.listIndex, 3) & vbCrLf
    msg = msg & "�� ��ӝ����: " & ListBox4.List(ListBox4.listIndex, 4) & vbCrLf
    msg = msg & "������ ������: " & ListBox4.List(ListBox4.listIndex, 5)
    
    MsgBox msg, vbInformation, "������ �ј�"
End Sub
Private Sub UpdateMonthAverage()
    Dim dfWs As Worksheet, dfParts As Variant, dfDate As String
    Dim dfY As Long, dfM As Long, dfI As Long, dfDay As Long
    Dim dfCenter As Long, dfRow As Long, dfStep As Long, dfCenters As Long
    Dim dfCash As Variant, dfCard As Variant, dfTotal As Double, dfDaily As Double, dfSales As Variant
    Dim dfDays As Long, dfYears As Object, dfMonths As Object
    Set dfYears = CreateObject("Scripting.Dictionary")
    Set dfMonths = CreateObject("Scripting.Dictionary")
    For dfI = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(dfI) Then dfYears(CStr(Me.ListBox1.List(dfI))) = True
    Next dfI
    For dfI = 0 To Me.ListBox2.ListCount - 1
        If Me.ListBox2.Selected(dfI) Then dfMonths(CStr(dfI + 1)) = True
    Next dfI
    dfCenters = ReadConfigValue("cfg_ActualUserCenters")
    dfStep = IIf(dfCenters = 1, 2, ReadConfigValue("cfg_TotalCenters")) + 1
    If dfCenters < 1 Or dfStep < 2 Then Exit Sub
    For Each dfWs In ThisWorkbook.Worksheets
        If IsError(dfWs.Range("B1").Value2) Then GoTo DFNextSheet
        dfDate = ConvertPersianNumsToEnglishDashboard(Trim$(CStr(dfWs.Range("B1").Value2)))
        dfParts = Split(dfDate, "/")
        If UBound(dfParts) <> 1 Then GoTo DFNextSheet
        If Not IsNumeric(dfParts(0)) Or Not IsNumeric(dfParts(1)) Then GoTo DFNextSheet
        dfY = CLng(dfParts(0)): dfM = CLng(dfParts(1))
        If dfY < ReadConfigValue("cfg_StartYear") Or dfY >= ReadConfigValue("cfg_StartYear") + ReadConfigValue("cfg_YearCount") Then GoTo DFNextSheet
        If dfM < 1 Or dfM > 12 Then GoTo DFNextSheet
        If dfYears.count > 0 Then
            If Not dfYears.exists(CStr(dfY)) Then GoTo DFNextSheet
        End If
        If dfMonths.count > 0 Then
            If Not dfMonths.exists(CStr(dfM)) Then GoTo DFNextSheet
        End If
        dfSales = dfWs.Range(dfWs.Cells(1, 1), dfWs.Cells(2 + 30 * dfStep + dfCenters, 4)).Value2
        For dfDay = 1 To GetPersianMonthDays(dfY, dfM)
            dfRow = 2 + (dfDay - 1) * dfStep
            If IsError(dfSales(dfRow, 1)) Then GoTo DFNextDay
            If val(CStr(dfSales(dfRow, 1))) <> dfDay Then GoTo DFNextDay
            dfDaily = 0
            For dfCenter = 0 To dfCenters - 1
                dfCash = dfSales(dfRow + dfCenter, 3)
                dfCard = dfSales(dfRow + dfCenter, 4)
                If Not IsError(dfCash) Then
                    If IsNumeric(dfCash) Then dfDaily = dfDaily + CDbl(dfCash)
                End If
                If Not IsError(dfCard) Then
                    If IsNumeric(dfCard) Then dfDaily = dfDaily + CDbl(dfCard)
                End If
            Next dfCenter
            If dfDaily > 0 Then dfTotal = dfTotal + dfDaily: dfDays = dfDays + 1
DFNextDay:
        Next dfDay
DFNextSheet:
    Next dfWs
    m_AvgDailySales = 0
    If dfDays > 0 Then m_AvgDailySales = dfTotal / dfDays
    Me.Label_MonthAverage.Caption = Format(m_AvgDailySales, "#,##0")
End Sub



'

'----------------------------------------
' ListBox1 Click - Year selection changed
'----------------------------------------
Private Sub ListBox1_Click()
    Call UpdateMonthAverage
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' ListBox2 Click - Month selection changed
'----------------------------------------
Private Sub ListBox2_Click()
    Call UpdateMonthAverage
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' Textbox_BankBalance Exit - Format and recalculate
'----------------------------------------

Private Sub Textbox_BankBalance_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    
    rawValue = Trim(Me.Textbox_BankBalance.value)
    If rawValue = "" Then Exit Sub
    
    ' Remove existing formatting
    rawValue = Replace(rawValue, ",", "")
    rawValue = ConvertPersianNumsToEnglishDashboard(rawValue)
    
    If IsNumeric(rawValue) Then
        Me.Textbox_BankBalance.value = Format(CDbl(rawValue), "#,##0")
    End If
    
    Call CalculateCashFlowForecast
End Sub
'----------------------------------------
' Textbox_DateForCheque Exit - Format date and recalculate
'----------------------------------------

Private Sub Textbox_DateForCheque_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim rawValue As String
    Dim formattedDate As String
    
    rawValue = Trim(Me.Textbox_DateForCheque.value)
    If rawValue = "" Then Exit Sub
    
    formattedDate = FormatPersianDateInput(rawValue)
    
    If formattedDate <> "" Then
        Me.Textbox_DateForCheque.value = formattedDate
        Call CalculateCashFlowForecast
    Else
        MsgBox "���� ����� ������� ���." & vbCrLf & "����: 1404/01/15 �� 14040115", vbExclamation, "���"
        Me.Textbox_DateForCheque.value = ""
    End If
    
End Sub
'----------------------------------------
' Format Persian date input (accepts yyyy/mm/dd or yyyymmdd)
'----------------------------------------
Private Function FormatPersianDateInput(ByVal inputDate As String) As String
    Dim cleanDate As String
    Dim y As Long, m As Long, d As Long
    
    On Error GoTo InvalidDate
    
    ' Clean input
    cleanDate = Trim(inputDate)
    cleanDate = ConvertPersianNumsToEnglishDashboard(cleanDate)
    
    ' Remove any existing slashes to normalize
    cleanDate = Replace(cleanDate, "/", "")
    cleanDate = Replace(cleanDate, "-", "")
    cleanDate = Replace(cleanDate, " ", "")
    
    ' Should be 8 digits now (yyyymmdd)
    If Len(cleanDate) <> 8 Then GoTo InvalidDate
    If Not IsNumeric(cleanDate) Then GoTo InvalidDate
    
    y = CLng(Left(cleanDate, 4))
    m = CLng(Mid(cleanDate, 5, 2))
    d = CLng(Right(cleanDate, 2))
    
    ' Validate ranges
    If y < 1300 Or y > 1500 Then GoTo InvalidDate
    If m < 1 Or m > 12 Then GoTo InvalidDate
    If d < 1 Or d > 31 Then GoTo InvalidDate
    
    ' Validate days in month
    If m >= 1 And m <= 6 And d > 31 Then GoTo InvalidDate
    If m >= 7 And m <= 11 And d > 30 Then GoTo InvalidDate
    If m = 12 Then
        Dim maxDay As Long
        maxDay = IIf(((y - 1403) Mod 4 = 0), 30, 29)
        If d > maxDay Then GoTo InvalidDate
    End If
    
    FormatPersianDateInput = y & "/" & Format(m, "00") & "/" & Format(d, "00")
    Exit Function
    
InvalidDate:
    FormatPersianDateInput = ""
End Function

'----------------------------------------
' Convert Persian/Arabic digits to English
'----------------------------------------
Private Function ConvertPersianNumsToEnglishDashboard(ByVal s As String) As String
    Dim i As Long
    Dim result As String
    result = s
    
    ' Persian digits
    For i = 0 To 9
        result = Replace(result, ChrW(1776 + i), CStr(i))
    Next i
    
    ' Arabic-Indic digits
    For i = 0 To 9
        result = Replace(result, ChrW(1632 + i), CStr(i))
    Next i
    
    ConvertPersianNumsToEnglishDashboard = result
End Function



'----------------------------------------
' Get total cheques clearing on a specific day
'----------------------------------------
Private Function GetDayCheques(persianDate As String) As Double
    Dim ws As Worksheet
    Dim parts() As String
    Dim ym As String
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim total As Double
    Dim c As Long
    
    On Error GoTo ErrHandler
    
    parts = Split(persianDate, "/")
    ym = parts(0) & "/" & parts(1)
    dayNum = CLng(parts(2))
    
    ' Find the sheet
    Set ws = Nothing
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set ws = sht
            Exit For
        End If
    Next sht
    
    If ws Is Nothing Then
        GetDayCheques = 0
        Exit Function
    End If
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstChequeCol As Long: firstChequeCol = 14
    Dim lastChequeCol As Long: lastChequeCol = firstChequeCol + (numCheques * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Find day row
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
    
    ' Check if day exists
    If ws.Cells(dayStartRow, "A").value <> dayNum Then
        GetDayCheques = 0
        Exit Function
    End If
    
    ' Sum all cheques for this day
    total = 0
    For c = firstChequeCol To lastChequeCol Step 2
        If ws.Cells(dayStartRow, c).value <> "" Then
            Dim chequeAmount As Variant
            chequeAmount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
            If IsNumeric(chequeAmount) And Not IsEmpty(chequeAmount) Then
                total = total + CDbl(chequeAmount)
            End If
        End If
    Next c
    
    GetDayCheques = total
    Exit Function
    
ErrHandler:
    GetDayCheques = 0
End Function

'----------------------------------------
' Get total direct pays on a specific day
'----------------------------------------
Private Function GetDayDirectPays(persianDate As String) As Double
    Dim ws As Worksheet
    Dim parts() As String
    Dim ym As String
    Dim dayNum As Long
    Dim dayStartRow As Long
    Dim total As Double
    Dim c As Long
    
    On Error GoTo ErrHandler
    
    parts = Split(persianDate, "/")
    ym = parts(0) & "/" & parts(1)
    dayNum = CLng(parts(2))
    
    ' Find the sheet
    Set ws = Nothing
    Dim sht As Worksheet
    For Each sht In ThisWorkbook.Worksheets
        If Trim(sht.Range("B1").value) = ym Then
            Set ws = sht
            Exit For
        End If
    Next sht
    
    If ws Is Nothing Then
        GetDayDirectPays = 0
        Exit Function
    End If
    
    ' Read config
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim numDirectPays As Long: numDirectPays = ReadConfigValue("cfg_NumDirectPays")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim firstDirectPayCol As Long: firstDirectPayCol = lastFactorCol + 2 + 1
    Dim lastDirectPayCol As Long: lastDirectPayCol = firstDirectPayCol + numDirectPays - 1
    
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2
    
    ' Find day row
    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
    
    ' Check if day exists
    If ws.Cells(dayStartRow, "A").value <> dayNum Then
        GetDayDirectPays = 0
        Exit Function
    End If
    
    ' Sum all direct pays for this day
    total = 0
    For c = firstDirectPayCol To lastDirectPayCol
        If ws.Cells(dayStartRow, c).value <> "" Then
            Dim payAmount As Variant
            payAmount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
            If IsNumeric(payAmount) And Not IsEmpty(payAmount) Then
                total = total + CDbl(payAmount)
            End If
        End If
    Next c
    
    GetDayDirectPays = total
    Exit Function
    
ErrHandler:
    GetDayDirectPays = 0
End Function
'----------------------------------------
' Get total planned expenses on a specific day (based on due dates)
'----------------------------------------
Private Function GetDayExpenses(persianDate As String) As Double
    Dim total As Double: total = 0
    
    total = total + CheckExpense(Me.txtrent1, Me.txtrent1date, persianDate)
    total = total + CheckExpense(Me.txtrent2, Me.txtrent2date, persianDate)
    total = total + CheckExpense(Me.txtsalary, Me.txtsalarydate, persianDate)
    total = total + CheckExpense(Me.txtinsurance, Me.txtinsurancedate, persianDate)
    total = total + CheckExpense(Me.txtinstallment1, Me.txtinstallment1date, persianDate)
    total = total + CheckExpense(Me.txtinstallment2, Me.txtinstallment2date, persianDate)
    total = total + CheckExpense(Me.txtotherexpenses, Me.txtotherexpensesdate, persianDate)

    GetDayExpenses = total
End Function

'----------------------------------------
' Calculate 30-day cash flow forecast
'----------------------------------------
Private Sub CalculateCashFlowForecast()
    Dim startDate As String
    Dim bankBalance As Double
    Dim avgSales As Double
    Dim gStartDate As Date
    Dim i As Long
    Dim checkDate As Date
    Dim persianDate As String
    Dim chequesAmount As Double
    Dim directPaysAmount As Double
    Dim expensesAmount As Double
    Dim currentBalance As Double
    Dim dayBalance As Double
    Dim balanceText As String
    Dim unclearedText As String
    Dim unclearedAmount As Double
'    Dim percent As Double
    
    On Error Resume Next
    DF_LoadHolidays
    
    ' Validate inputs
    startDate = Trim(Me.Textbox_DateForCheque.value)
    If startDate = "" Then
        Me.Listbox_next30days.Clear
        Exit Sub
    End If
    
    ' Get bank balance
    balanceText = Trim(Me.Textbox_BankBalance.value)
    balanceText = Replace(balanceText, ",", "")
    balanceText = ConvertPersianNumsToEnglishDashboard(balanceText)
    If IsNumeric(balanceText) Then
        bankBalance = CDbl(balanceText)
    Else
        bankBalance = 0
    End If

    ' Get average sales
    avgSales = m_AvgDailySales

    ' Get uncleared cheques (assumed already past due)
    unclearedText = Trim(Me.txtunclearedcheques.text)
    unclearedText = Replace(unclearedText, ",", "")
    unclearedText = ConvertPersianNumsToEnglishDashboard(unclearedText)
    If IsNumeric(unclearedText) Then
        unclearedAmount = CDbl(unclearedText)
    Else
        unclearedAmount = 0
    End If

    ' Convert start date to Gregorian
    gStartDate = PersianToGregorianDate( _
        CLng(Split(startDate, "/")(0)), _
        CLng(Split(startDate, "/")(1)), _
        CLng(Split(startDate, "/")(2)))
    
    ' Clear listbox
    Me.Listbox_next30days.Clear
    
    ' Calculate for 30 days
    currentBalance = bankBalance
    
    For i = 0 To 29
        checkDate = gStartDate + i
        persianDate = GregorianToPersian(checkDate)
        
        ' Get cheques clearing on this day
        chequesAmount = GetDayCheques(persianDate)
        
        ' Get direct pays on this day
        directPaysAmount = GetDayDirectPays(persianDate)
        
        ' Get planned expenses on this day (rent, salary, etc.)
        expensesAmount = GetDayExpenses(persianDate)
        
        ' Calculate balance for this day
        ' Start with previous balance, add sales, subtract cheques, direct pays and expenses
dayBalance = currentBalance + GetDaySalesAmount(persianDate, avgSales) - chequesAmount - directPaysAmount - expensesAmount
        
        ' Apply uncleared cheques on first day (they are already overdue)
        If i = 0 And unclearedAmount <> 0 Then
            dayBalance = dayBalance - unclearedAmount
        End If
        
        ' Add to listbox
        With Me.Listbox_next30days
            .AddItem persianDate
            If dayBalance < 0 Then
                .List(.ListCount - 1, 1) = "*** -" & Application.text(Abs(dayBalance), "#,##0")
            Else
                .List(.ListCount - 1, 1) = Application.text(dayBalance, "#,##0")
            End If
        End With
        
        ' Update current balance for next day
        currentBalance = dayBalance
    Next i
End Sub
'----------------------------------------
' Helper: if txtDate = persianDate then return numeric amount in txtAmount
'----------------------------------------
Private Function CheckExpense(txtAmount As Object, _
                              txtDate As Object, _
                              persianDate As String) As Double
    Dim amountText As String
    Dim dueDayText As String
    Dim dueDay As Long
    Dim currentDay As Long

    CheckExpense = 0

    ' Current forecast day (dd)
    currentDay = CLng(Split(persianDate, "/")(2))

    ' Read user due-day (dd format)
    dueDayText = Trim(txtDate.text)
    dueDayText = ConvertPersianNumsToEnglishDashboard(dueDayText)

    If Not IsNumeric(dueDayText) Then Exit Function
    dueDay = CLng(dueDayText)

    ' Match exact day number
    If currentDay = dueDay Then
        amountText = Trim(txtAmount.text)
        amountText = Replace(amountText, ",", "")
        amountText = ConvertPersianNumsToEnglishDashboard(amountText)
        If IsNumeric(amountText) Then
            CheckExpense = CDbl(amountText)
        End If
    End If
End Function


'----------------------------------------
' Color negative balances in Listbox_next30days red
' Note: ListBox doesn't support per-row coloring, so we'll add a marker
'----------------------------------------

Private Sub ColorNegativeBalances()
    Dim i            As Long
    Dim balanceText  As String
    Dim cleanText    As String
    Dim j            As Long

    On Error Resume Next

    For i = 0 To Me.Listbox_next30days.ListCount - 1
        balanceText = Me.Listbox_next30days.List(i, 1)

        ' Already marked by Fix 1 � nothing to do
        If Left(balanceText, 4) = "*** " Then GoTo NextRow

        ' Remove commas and thousand separators to get a raw number string
        cleanText = Replace(balanceText, ",", "")

        ' Convert Persian/Arabic digits to ASCII (safety net)
        For j = 0 To 9
            cleanText = Replace(cleanText, ChrW(1776 + j), CStr(j))  ' Persian
            cleanText = Replace(cleanText, ChrW(1632 + j), CStr(j))  ' Arabic-Indic
        Next j
        cleanText = Replace(cleanText, ChrW(1548), "")  ' Arabic comma �
        cleanText = Trim(cleanText)

        ' Detect trailing minus (Persian RTL locale) or leading minus
        Dim isNeg As Boolean: isNeg = False
        If Right(cleanText, 1) = "-" Then
            isNeg = True
            cleanText = Left(cleanText, Len(cleanText) - 1)
        ElseIf Left(cleanText, 1) = "-" Then
            isNeg = True
            cleanText = Mid(cleanText, 2)
        End If

        If IsNumeric(cleanText) And cleanText <> "" Then
            If isNeg Or CDbl(cleanText) < 0 Then
                Me.Listbox_next30days.List(i, 1) = _
                    "*** -" & Application.text(Abs(CDbl(cleanText)), "#,##0")
            End If
        End If

NextRow:
    Next i

    On Error GoTo 0
End Sub

'----------------------------------------
' CommandButton_Refresh - Refresh all values
'----------------------------------------
Private Sub CommandButton_Refresh_Click()
    Application.ScreenUpdating = False
    
    ' Update month average
    Call UpdateMonthAverage
    
    ' Recalculate cash flow forecast
    Call CalculateCashFlowForecast
    
    ' Save expense settings to sheet "�������"
    Call SaveExpensesToSheet
    
    Call FormatAllExpenseTextboxes
    
    Application.ScreenUpdating = True
    
'    MsgBox "������ ��������� ��.", vbInformation, "���������"
End Sub


'----------------------------------------
' CommandButton4: Select All Years
' Ϙ�� �: ������ ��� �����
'----------------------------------------
Private Sub CommandButton4_Click()
    Dim i As Long
    For i = 0 To ListBox1.ListCount - 1
        ListBox1.Selected(i) = True
    Next i
    UpdateMonthAverage
    CalculateCashFlowForecast
End Sub

'----------------------------------------
' CommandButton5: Select All Months
' Ϙ�� �: ������ ��� �����
'----------------------------------------
Private Sub CommandButton5_Click()
    Dim i As Long
    For i = 0 To ListBox2.ListCount - 1
        ListBox2.Selected(i) = True
    Next i
    UpdateMonthAverage
    CalculateCashFlowForecast
End Sub

'----------------------------------------
' CommandButton6: Select All Companies
' Ϙ�� �: ������ ��� �јʝ��
'----------------------------------------
Private Sub CommandButton6_Click()
    Dim i As Long
    For i = 0 To ListBox3.ListCount - 1
        ListBox3.Selected(i) = True
    Next i
End Sub

'----------------------------------------
' Save expense values and due dates to sheet "�������"
'----------------------------------------
Private Sub SaveExpensesToSheet()
    Dim ws As Worksheet
    Dim r As Long
    Dim c As Long
    
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("�������")
    On Error GoTo 0
    
    If ws Is Nothing Then Exit Sub
    
    r = 7          ' row 7
    c = 29         ' column AC = 29
    
    ws.Cells(r, c).value = Me.txtrent1.text:              r = r + 1
    ws.Cells(r, c).value = Me.txtrent1date.text:          r = r + 1
    
    ws.Cells(r, c).value = Me.txtrent2.text:              r = r + 1
    ws.Cells(r, c).value = Me.txtrent2date.text:          r = r + 1
    
    ws.Cells(r, c).value = Me.txtsalary.text:             r = r + 1
    ws.Cells(r, c).value = Me.txtsalarydate.text:         r = r + 1
    
    ws.Cells(r, c).value = Me.txtinsurance.text:          r = r + 1
    ws.Cells(r, c).value = Me.txtinsurancedate.text:      r = r + 1
    
    ws.Cells(r, c).value = Me.txtinstallment1.text:       r = r + 1
    ws.Cells(r, c).value = Me.txtinstallment1date.text:   r = r + 1
    
    ws.Cells(r, c).value = Me.txtinstallment2.text:       r = r + 1
    ws.Cells(r, c).value = Me.txtinstallment2date.text:   r = r + 1
    
    ws.Cells(r, c).value = Me.txtotherexpenses.text:      r = r + 1
    ws.Cells(r, c).value = Me.txtotherexpensesdate.text
End Sub


Private Sub LoadExpensesFromSheet()
    Dim ws As Worksheet
    Dim r As Long: r = 7
    Dim c As Long: c = 29
    
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("�������")
    On Error GoTo 0
    If ws Is Nothing Then Exit Sub
    
    Me.txtrent1.text = ws.Cells(r, c).value:                r = r + 1
    Me.txtrent1date.text = ws.Cells(r, c).value:        r = r + 1

    Me.txtrent2.text = ws.Cells(r, c).value:              r = r + 1
    Me.txtrent2date.text = ws.Cells(r, c).value:          r = r + 1

    Me.txtsalary.text = ws.Cells(r, c).value:             r = r + 1
    Me.txtsalarydate.text = ws.Cells(r, c).value:         r = r + 1

    Me.txtinsurance.text = ws.Cells(r, c).value:          r = r + 1
    Me.txtinsurancedate.text = ws.Cells(r, c).value:      r = r + 1

    Me.txtinstallment1.text = ws.Cells(r, c).value:       r = r + 1
    Me.txtinstallment1date.text = ws.Cells(r, c).value:   r = r + 1

    Me.txtinstallment2.text = ws.Cells(r, c).value:       r = r + 1
    Me.txtinstallment2date.text = ws.Cells(r, c).value:   r = r + 1

    Me.txtotherexpenses.text = ws.Cells(r, c).value:      r = r + 1
    Me.txtotherexpensesdate.text = ws.Cells(r, c).value
        Call FormatAllExpenseTextboxes
End Sub
Private Function GetDaySalesAmount(persianDate As String, avgSales As Double) As Double
    Dim dfPercentText As String, dfPercent As Double
    If m_DFHolidays Is Nothing Then DF_LoadHolidays
    GetDaySalesAmount = avgSales
    If Not m_DFHolidays.exists(persianDate) Then Exit Function
    GetDaySalesAmount = 0
    If Me.CheckBox1.value Then
        dfPercent = 30
        dfPercentText = ConvertPersianNumsToEnglishDashboard(Replace(Trim$(Me.txtpercent.value), ",", ""))
        If IsNumeric(dfPercentText) Then dfPercent = CDbl(dfPercentText)
        If dfPercent < 0 Or dfPercent > 100 Then dfPercent = 30
        GetDaySalesAmount = avgSales * dfPercent / 100
    End If
End Function


'----------------------------------------
' txtunclearedcheques Exit - Format and recalculate
'----------------------------------------
Private Sub txtunclearedcheques_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'
'----------------------------------------
' txtsalary Exit - Format and recalculate
'----------------------------------------

Private Sub txtsalary_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtrent1 Exit - Format and recalculate
'----------------------------------------

Private Sub txtrent1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtrent2 Exit - Format and recalculate
'----------------------------------------

Private Sub txtrent2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'----------------------------------------
' txtinsurance Exit - Format and recalculate
'----------------------------------------
Private Sub txtinsurance_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


'----------------------------------------
' txtinstallment1 Exit - Format and recalculate
'----------------------------------------
Private Sub txtinstallment1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtinstallment2 Exit - Format and recalculate
'----------------------------------------
Private Sub txtinstallment2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub

'----------------------------------------
' txtotherexpenses Exit - Format and recalculate
'----------------------------------------

Private Sub txtotherexpenses_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    FormatAllExpenseTextboxes
    Call CalculateCashFlowForecast
End Sub


Private Sub FormatExpenseTextbox(tb As MSForms.TextBox)

    Dim rawValue As String
    
    rawValue = Trim(tb.value)
    If rawValue = "" Then Exit Sub

    ' Remove formatting
    rawValue = Replace(rawValue, ",", "")
    rawValue = ConvertPersianNumsToEnglishDashboard(rawValue)

    If IsNumeric(rawValue) Then
        tb.value = Format(CDbl(rawValue), "#,##0")
    End If

End Sub

Private Sub FormatAllExpenseTextboxes()

    FormatExpenseTextbox Me.txtrent1
    FormatExpenseTextbox Me.txtrent2
    FormatExpenseTextbox Me.txtsalary
    FormatExpenseTextbox Me.txtinstallment1
    FormatExpenseTextbox Me.txtinstallment2
    FormatExpenseTextbox Me.txtinsurance
    FormatExpenseTextbox Me.txtotherexpenses
    FormatExpenseTextbox Me.txtunclearedcheques

    Call CalculateCashFlowForecast

End Sub
Private Function CleanCompanyName(ByVal companyText As String) As String
      Dim p As Long

      companyText = Trim(companyText)
      p = InStr(1, companyText, "(")

      If p > 0 Then
          companyText = Trim(Left(companyText, p - 1))
      End If

      CleanCompanyName = companyText
  End Function



Private Sub DF_LoadHolidays()
    Dim dfInfo As Worksheet, dfVals As Variant, dfLast As Long
    Dim dfR As Long, dfHolidayDate As String
    Set m_DFHolidays = CreateObject("Scripting.Dictionary")
    Set dfInfo = ThisWorkbook.Worksheets(DF_Text("1575,1591,1604,1575,1593,1575,1578"))
    dfLast = dfInfo.Cells(dfInfo.rows.count, 21).End(xlUp).Row
    dfVals = dfInfo.Range(dfInfo.Cells(1, 19), dfInfo.Cells(dfLast, 21)).Value2
    For dfR = 1 To UBound(dfVals, 1)
        If Not IsError(dfVals(dfR, 1)) And Not IsError(dfVals(dfR, 3)) Then
            If Trim$(CStr(dfVals(dfR, 1))) = "*" Then
                dfHolidayDate = FormatPersianDateInput(CStr(dfVals(dfR, 3)))
                If Len(dfHolidayDate) > 0 Then m_DFHolidays(dfHolidayDate) = True
            End If
        End If
    Next dfR
End Sub



Private Sub DF_Sort(ByVal dfCol As Long)
    Dim dfData As Variant, dfR As Long, dfK As Long, dfC As Long
    Dim dfHeld(0 To 5) As Variant, dfCompare As Long
    If Me.ListBox4.ListCount < 2 Then Exit Sub
    If m_DFSortColumn = dfCol Then
        m_DFSortAscending = Not m_DFSortAscending
    Else
        m_DFSortAscending = (dfCol = 0 Or dfCol = 5)
    End If
    m_DFSortColumn = dfCol
    dfData = Me.ListBox4.List
    For dfR = 1 To UBound(dfData, 1)
        For dfC = 0 To 5: dfHeld(dfC) = dfData(dfR, dfC): Next dfC
        dfK = dfR - 1
        Do While dfK >= 0
            dfCompare = DF_Compare(dfData(dfK, dfCol), dfHeld(dfCol), dfCol, m_DFSortAscending)
            If dfCompare <= 0 Then Exit Do
            For dfC = 0 To 5: dfData(dfK + 1, dfC) = dfData(dfK, dfC): Next dfC
            dfK = dfK - 1
        Loop
        For dfC = 0 To 5: dfData(dfK + 1, dfC) = dfHeld(dfC): Next dfC
    Next dfR
    Me.ListBox4.List = dfData
    Dim dfHeaders As Variant, dfHeader As Long
    dfHeaders = Array("Label9", "Label12", "Label11", "Label10", "Label13", "Label14")
    For dfHeader = 0 To 5
        Me.Controls(dfHeaders(dfHeader)).ForeColor = RGB(98, 115, 134)
        Me.Controls(dfHeaders(dfHeader)).Caption = Replace(Replace(Me.Controls(dfHeaders(dfHeader)).Caption, " [ASC]", ""), " [DESC]", "")
    Next dfHeader
    Me.Controls(dfHeaders(dfCol)).ForeColor = RGB(0, 123, 117)
    Me.Controls(dfHeaders(dfCol)).Caption = Me.Controls(dfHeaders(dfCol)).Caption & IIf(m_DFSortAscending, " [ASC]", " [DESC]")
End Sub

Private Function DF_Compare(ByVal dfA As Variant, ByVal dfB As Variant, ByVal dfCol As Long, ByVal dfAsc As Boolean) As Long
    Dim dfKeyA As Double, dfKeyB As Double, dfTextA As String, dfTextB As String
    dfTextA = CStr(dfA): dfTextB = CStr(dfB)
    If dfCol = 0 Then
        DF_Compare = StrComp(dfTextA, dfTextB, vbTextCompare)
    ElseIf dfCol = 5 Then
        If dfTextA = "-" Or Len(Trim$(dfTextA)) = 0 Then
            If dfTextB <> "-" And Len(Trim$(dfTextB)) > 0 Then DF_Compare = 1
            Exit Function
        End If
        If dfTextB = "-" Or Len(Trim$(dfTextB)) = 0 Then DF_Compare = -1: Exit Function
        DF_Compare = Sgn(CDbl(GetSortableDate(dfTextA)) - CDbl(GetSortableDate(dfTextB)))
    Else
        dfKeyA = val(Replace(ConvertPersianNumsToEnglishDashboard(dfTextA), ",", ""))
        dfKeyB = val(Replace(ConvertPersianNumsToEnglishDashboard(dfTextB), ",", ""))
        DF_Compare = Sgn(dfKeyA - dfKeyB)
    End If
    If Not dfAsc Then DF_Compare = -DF_Compare
End Function

Private Sub Label9_Click()
    DF_Sort 0
End Sub
Private Sub Label12_Click()
    DF_Sort 1
End Sub
Private Sub Label11_Click()
    DF_Sort 2
End Sub
Private Sub Label10_Click()
    DF_Sort 3
End Sub
Private Sub Label13_Click()
    DF_Sort 4
End Sub
Private Sub Label14_Click()
    DF_Sort 5
End Sub
Private Sub CheckBox1_Click()
    CalculateCashFlowForecast
End Sub
Private Sub txtpercent_AfterUpdate()
    CalculateCashFlowForecast
End Sub
Private Function DF_Text(ByVal dfCodes As String) As String
    Dim dfCode As Variant
    For Each dfCode In Split(dfCodes, ",")
        DF_Text = DF_Text & ChrW$(CLng(dfCode))
    Next dfCode
End Function

