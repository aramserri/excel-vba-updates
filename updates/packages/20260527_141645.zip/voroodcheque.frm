VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} voroodcheque 
   Caption         =   "��� ��"
   ClientHeight    =   6412
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   6979
   OleObjectBlob   =   "voroodcheque.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "voroodcheque"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False







'=====================================================
' UserForm: voroodCheque (FIXED - No .NET Dependency)
'=====================================================
Option Explicit

'--- Module-level variables for configuration ---
Private m_NumCheques As Long
Private m_TotalCenters As Long
Private m_UserCenters As Long

'--- Module-level variables for Undo functionality ---
Private g_UndoSheet As Worksheet
Private g_UndoRow As Long
Private g_UndoCol As Long
Private g_OriginalCompValue As String
Private g_OriginalAmtValue As String
Private g_OriginalSerialValue As String
Private g_IsUndoAvailable As Boolean

Private Sub ComboBox1_Enter()
SetKeyboardPersian
End Sub
Private Sub TextBox1_Enter()
SetKeyboardEnglish
End Sub
Private Sub TextBox2_Enter()
SetKeyboardEnglish
End Sub
'----------------------------------------
' Initialize the form
'----------------------------------------
Private Sub UserForm_Initialize()
    ' 1. Read the workbook's configuration.
    If Not ReadConfiguration() Then
        MsgBox "���: ������� ���� ���� ���. ��� �������� ��ѐ��� ���.", vbCritical, "���� �������"
        Unload Me
        Exit Sub
    End If

    On Error GoTo ErrInit

    ' 2. Populate ComboBox1 (Companies) - skip empty, sort, handle *** separator
    Call PopulateCompanyComboBox
    
    ' 3. Populate ComboBox2 (Years)
    Me.ComboBox2.RowSource = "cfg_YearList"

    On Error Resume Next
    Me.ComboBox2.value = CStr(ThisWorkbook.Sheets("�������").Range("cfg_DefaultYear").value)
    On Error GoTo 0

    If Me.ComboBox2.value = "" And Me.ComboBox2.ListCount > 0 Then
        Me.ComboBox2.listIndex = 0
    End If

    ' 4. Populate months ComboBox.
    Dim i As Long
    Dim defaultMonth As Variant
    Me.ComboBox3.Clear
    For i = 1 To 12
        Me.ComboBox3.AddItem CStr(i)
    Next i
    
    On Error Resume Next
    defaultMonth = ThisWorkbook.Sheets("�������").Range("AC2").value
    On Error GoTo 0

    If IsNumeric(defaultMonth) And CLng(defaultMonth) >= 1 And CLng(defaultMonth) <= 12 Then
        Me.ComboBox3.value = CStr(CLng(defaultMonth))
    Else
        Me.ComboBox3.listIndex = 0
    End If

    ' 5. Set the initial state of the form.
    Me.Label6.Caption = ""
    Me.CommandButton3.Enabled = False
    g_IsUndoAvailable = False

    Me.ComboBox1.SetFocus
    
    Exit Sub
ErrInit:
    MsgBox "An error occurred while initializing the form: " & Err.description, vbCritical, "Initialization Error"
End Sub

'----------------------------------------
' Populate ComboBox1 with company names
' FIXED: Uses VBA arrays instead of ArrayList (no .NET dependency)
'----------------------------------------
Private Sub PopulateCompanyComboBox()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim companyList() As String
    Dim otherList() As String
    Dim companyCount As Long
    Dim otherCount As Long
    Dim i As Long
    Dim foundSeparator As Boolean
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        MsgBox "���: ��� ������� ���� ���.", vbCritical
        Exit Sub
    End If
    
    Me.ComboBox1.Clear
    
    ' Initialize arrays
    companyCount = 0
    otherCount = 0
    ReDim companyList(1 To 500)
    ReDim otherList(1 To 500)
    
    ' Find last row
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).row
    
    ' Collect names - split by *** separator
    foundSeparator = False
    
    If lastRow > 1 Then
        For Each cell In configSheet.Range("A2:A" & lastRow)
            If Len(Trim(cell.value)) > 0 Then
                If Trim(cell.value) = "***" Then
                    foundSeparator = True
                ElseIf Not foundSeparator Then
                    companyCount = companyCount + 1
                    companyList(companyCount) = GetCompanyName(cell.value)
                Else
                    otherCount = otherCount + 1
                    otherList(otherCount) = GetCompanyName(cell.value)
                End If
            End If
        Next cell
    End If
    
    ' Resize arrays and sort
    If companyCount > 0 Then
        ReDim Preserve companyList(1 To companyCount)
        Call SortStringArray(companyList, 1, companyCount)
    End If
    
    If otherCount > 0 Then
        ReDim Preserve otherList(1 To otherCount)
        Call SortStringArray(otherList, 1, otherCount)
    End If
    
    ' Add sorted company names to ComboBox
    For i = 1 To companyCount
        Me.ComboBox1.AddItem companyList(i)
    Next i
    
    ' Add separator line if there are other names
    If otherCount > 0 Then
        Me.ComboBox1.AddItem "-------------"
        
        For i = 1 To otherCount
            Me.ComboBox1.AddItem otherList(i)
        Next i
    End If
    
    If Me.ComboBox1.ListCount = 0 Then
        MsgBox "���: ���� �ј��� ���� ���.", vbCritical
    End If
End Sub

'----------------------------------------
' Sort string array using QuickSort (VBA native - no .NET)
'----------------------------------------
Private Sub SortStringArray(arr() As String, ByVal low As Long, ByVal high As Long)
    Dim pivot As String
    Dim temp As String
    Dim i As Long, j As Long
    
    If low >= high Then Exit Sub
    
    pivot = arr((low + high) \ 2)
    i = low
    j = high
    
    Do While i <= j
        Do While StrComp(arr(i), pivot, vbTextCompare) < 0
            i = i + 1
        Loop
        Do While StrComp(arr(j), pivot, vbTextCompare) > 0
            j = j - 1
        Loop
        
        If i <= j Then
            temp = arr(i)
            arr(i) = arr(j)
            arr(j) = temp
            i = i + 1
            j = j - 1
        End If
    Loop
    
    If low < j Then SortStringArray arr, low, j
    If i < high Then SortStringArray arr, i, high
End Sub

'----------------------------------------
' Check if company exists in ComboBox1 list
'----------------------------------------
Private Function IsValidCompany(companyName As String) As Boolean
    Dim i As Long
    
    IsValidCompany = False
    
    If Len(Trim(companyName)) = 0 Then Exit Function
    If companyName = "-------------" Then Exit Function
    
    For i = 0 To Me.ComboBox1.ListCount - 1
        If Me.ComboBox1.List(i) = companyName Then
            IsValidCompany = True
            Exit Function
        End If
    Next i
End Function

'----------------------------------------
' ComboBox1 Change - Handle separator
'----------------------------------------
Private Sub ComboBox1_Change()
    If Me.ComboBox1.value = "-------------" Then
        Me.ComboBox1.value = ""
        Me.ComboBox1.DropDown
        Exit Sub
    End If
End Sub

'----------------------------------------
' Helper function to read the configuration
'----------------------------------------
Private Function ReadConfiguration() As Boolean
    On Error Resume Next
    m_NumCheques = ThisWorkbook.names("cfg_NumCheques").RefersToRange.value
    m_TotalCenters = ThisWorkbook.names("cfg_TotalCenters").RefersToRange.value
    m_UserCenters = ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.value
    
    If Err.Number <> 0 Or m_NumCheques = 0 Or m_TotalCenters = 0 Or m_UserCenters = 0 Then
        ReadConfiguration = False
    Else
        ReadConfiguration = True
    End If
    On Error GoTo 0
End Function

'----------------------------------------
' Clean up when form is closing
'----------------------------------------
Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
    On Error Resume Next
    Unload frmDayPicker
    On Error GoTo 0
End Sub

'----------------------------------------
' Day picker button (CommandButton2)
'----------------------------------------
Private Sub CommandButton2_Click()
    On Error GoTo ErrDay

    If Me.ComboBox2.value = "" Or Me.ComboBox3.value = "" Then
        MsgBox "����� ��� � ��� �� ������ ����.", vbExclamation, "����� ����"
        Exit Sub
    End If

    frmDayPicker.currentYear = CLng(Me.ComboBox2.value)
    frmDayPicker.currentMonth = CInt(Me.ComboBox3.value)
    frmDayPicker.selectedDay = ""
    frmDayPicker.Show vbModal
    
    If Len(frmDayPicker.selectedDay) > 0 Then
        Me.Label6.Caption = frmDayPicker.selectedDay
    End If
    Me.CommandButton1.SetFocus
    Unload frmDayPicker
    
    Exit Sub
ErrDay:
    On Error Resume Next
    Unload frmDayPicker
    On Error GoTo 0
    MsgBox "��� �� ������ ���: " & Err.description, vbCritical
End Sub

'----------------------------------------
' Submit cheque button (CommandButton1)
'----------------------------------------
Private Sub CommandButton1_Click()
    Dim targetSheet As Worksheet
    Dim yy As String, mm As Integer
    Dim ws As Worksheet
    Dim targetDateString As String
    Dim foundCell As Range, foundRow As Long
    Dim comp As String, serial As String
    Dim amountRaw As String, amountConverted As String
    Dim firstChequeCol As Long, lastChequeCol As Long, col As Long

    amountRaw = Trim(Me.TextBox1.value)
    amountConverted = ConvertPersianNumsToEnglish(Replace(amountRaw, ",", ""))

    If Me.ComboBox1.value = "" Or Me.Label6.Caption = "" Or Not IsNumeric(amountConverted) Or amountRaw = "" Then
        MsgBox "����� ���� ������ �� ���� �� ����.", vbExclamation, "����� ����"
        Exit Sub
    End If

    If Not IsValidCompany(Me.ComboBox1.value) Then
        MsgBox "�ј� '" & Me.ComboBox1.value & "' �� ���� ���� �����." & vbCrLf & vbCrLf & _
               "����� �� ���� ������ ���� �� ����� �ј� ���� ����� ����.", vbExclamation, "�ј� �������"
        Me.ComboBox1.SetFocus
        Exit Sub
    End If

    comp = Me.ComboBox1.value
    yy = Me.ComboBox2.value
    mm = CInt(Me.ComboBox3.value)
    serial = Trim(Me.TextBox2.value)

    targetDateString = yy & "/" & Format(mm, "00")
    
    Set targetSheet = Nothing
    For Each ws In ThisWorkbook.Worksheets
        If CStr(ws.Range("B1").value) = targetDateString Then
            Set targetSheet = ws
            Exit For
        End If
    Next ws
    
    If targetSheet Is Nothing Then
        MsgBox "���� �� ����� '" & targetDateString & "' �� ���� B1 ���� ���.", vbExclamation, "���"
        Exit Sub
    End If

    Set foundCell = targetSheet.Columns("A").Find(What:=CLng(Me.Label6.Caption), LookIn:=xlFormulas, LookAt:=xlWhole)
    If foundCell Is Nothing Then
        MsgBox "��� '" & Me.Label6.Caption & "' ���� ���.", vbExclamation, "���"
        Exit Sub
    End If
    foundRow = foundCell.row

    firstChequeCol = 14
    lastChequeCol = firstChequeCol + (m_NumCheques * 2) - 2

    For col = firstChequeCol To lastChequeCol Step 2
        If Len(Trim(targetSheet.Cells(foundRow, col).value)) = 0 Then
            
            Dim amountRowOffset As Long
            Dim rowsPerDayBlock As Long
            rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
            amountRowOffset = rowsPerDayBlock / 2
            
            Set g_UndoSheet = targetSheet
            g_UndoRow = foundRow
            g_UndoCol = col
            g_OriginalCompValue = ""
            g_OriginalAmtValue = ""
            g_OriginalSerialValue = ""
            
            With targetSheet
                .Cells(foundRow, col).value = comp
                .Cells(foundRow + amountRowOffset, col).value = CDbl(amountConverted)
                .Cells(foundRow + amountRowOffset, col + 1).value = serial
            End With
            
            g_IsUndoAvailable = True
            Me.CommandButton3.Enabled = True
            
            MsgBox "�� �� ������ ��� ��.", vbInformation, "����"
            Me.TextBox1.value = "": Me.TextBox2.value = ""
            Me.TextBox1.SetFocus
            Exit Sub
        End If
    Next col

    MsgBox "��� ��� ���� ������� ���� �� �� ������.", vbExclamation, "����� ʘ���"
End Sub

'----------------------------------------
' Undo button (CommandButton3)
'----------------------------------------
Private Sub CommandButton3_Click()
    If Not g_IsUndoAvailable Or g_UndoSheet Is Nothing Then
        MsgBox "�� ���� ���� ��� ���� ���� �����.", vbExclamation, "���"
        Exit Sub
    End If

    Dim amountRowOffset As Long
    Dim rowsPerDayBlock As Long
    rowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters)
    amountRowOffset = rowsPerDayBlock / 2

    With g_UndoSheet
        .Cells(g_UndoRow, g_UndoCol).value = g_OriginalCompValue
        .Cells(g_UndoRow + amountRowOffset, g_UndoCol).value = g_OriginalAmtValue
        .Cells(g_UndoRow + amountRowOffset, g_UndoCol + 1).value = g_OriginalSerialValue
    End With

    g_IsUndoAvailable = False
    Me.CommandButton3.Enabled = False
    MsgBox "����� �� �� ������ ��� ��.", vbInformation, "��� ��"
End Sub

'----------------------------------------
' Format amount TextBox on exit
'----------------------------------------
Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    On Error Resume Next
    Dim amountConverted As String
    amountConverted = ConvertPersianNumsToEnglish(Replace(Me.TextBox1.value, ",", ""))
    
    If IsNumeric(amountConverted) And Len(Trim(amountConverted)) > 0 Then
        Me.TextBox1.value = Format(CDbl(amountConverted), "#,##0")
    End If
    On Error GoTo 0
End Sub

'----------------------------------------
' Helper function for number conversion
'----------------------------------------
Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    result = inputText
    
    result = Replace(result, ChrW(1776), "0")
    result = Replace(result, ChrW(1777), "1")
    result = Replace(result, ChrW(1778), "2")
    result = Replace(result, ChrW(1779), "3")
    result = Replace(result, ChrW(1780), "4")
    result = Replace(result, ChrW(1781), "5")
    result = Replace(result, ChrW(1782), "6")
    result = Replace(result, ChrW(1783), "7")
    result = Replace(result, ChrW(1784), "8")
    result = Replace(result, ChrW(1785), "9")
    
    ConvertPersianNumsToEnglish = result
End Function

