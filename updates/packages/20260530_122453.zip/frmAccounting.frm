VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmAccounting 
   Caption         =   "UserForm1"
   ClientHeight    =   10626
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   16142
   OleObjectBlob   =   "frmAccounting.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmAccounting"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

  Private Const ACCOUNTING_SHEET As String = "��������"
  Private Const INFO_SHEET As String = "�������"

  Private Const COL_CFG_KEY As Long = 1
  Private Const COL_CFG_VAL As Long = 2

  Private Const COL_EXP_ID As Long = 4
  Private Const COL_EXP_NAME As Long = 5
  Private Const COL_EXP_CREATED As Long = 6

  Private Const COL_FIXED_ID As Long = 8
  Private Const COL_FIXED_EXP_ID As Long = 9
  Private Const COL_FIXED_NAME As Long = 10
  Private Const COL_FIXED_AMOUNT As Long = 11
  Private Const COL_FIXED_DAY As Long = 12
  Private Const COL_FIXED_FREQ As Long = 13
  Private Const COL_FIXED_REMAIN As Long = 14
  Private Const COL_FIXED_ACTIVE As Long = 15
  Private Const COL_FIXED_ACT_DATE As Long = 16
  Private Const COL_FIXED_DEACT_DATE As Long = 17
  Private Const COL_FIXED_PAID_FROM As Long = 18
  Private Const COL_FIXED_USED As Long = 19

  Private Const COL_IRR_ID As Long = 21
  Private Const COL_IRR_EXP_ID As Long = 22
  Private Const COL_IRR_NAME As Long = 23
  Private Const COL_IRR_AMOUNT As Long = 24
  Private Const COL_IRR_DATE As Long = 25
  Private Const COL_IRR_ACTIVE As Long = 26
  Private Const COL_IRR_PAID_FROM As Long = 27
  Private Const COL_IRR_USED As Long = 28

  Private Const COL_TR_ID As Long = 30
  Private Const COL_TR_DATE As Long = 31
  Private Const COL_TR_TYPE As Long = 32
  Private Const COL_TR_AMOUNT As Long = 33
  Private Const COL_TR_CREATED As Long = 34

  Private Sub UserForm_Initialize()
      EnsureAccountingSheet
      PrepareControls
      LoadInitialValues
      RefreshAllLists
  End Sub

  Private Sub PrepareControls()
      txtStartDate.IMEMode = fmIMEModeDisable
      txtInitialBank.IMEMode = fmIMEModeDisable
      txtInitialCash.IMEMode = fmIMEModeDisable
      txtTransferDate.IMEMode = fmIMEModeDisable
      txtTransferAmount.IMEMode = fmIMEModeDisable
      txtCurrentDate.IMEMode = fmIMEModeDisable

      txtCurrentBank.Locked = True
      txtCurrentCash.Locked = True
      txtGrandTotal.Locked = True

      cboTransferType.Clear
      cboTransferType.AddItem "Deposit"
      cboTransferType.AddItem "Withdraw"
      cboTransferType.listIndex = 0

      lstExpenses.ColumnCount = 2
      lstExpenses.ColumnWidths = "0 pt;180 pt"

      lstFixedExpenses.ColumnCount = 10
      lstFixedExpenses.ColumnWidths = "0 pt;120 pt;80 pt;40 pt;70 pt;70 pt;50 pt;80 pt;80 pt;60 pt"

      lstIrregularExpenses.ColumnCount = 8
      lstIrregularExpenses.ColumnWidths = "0 pt;120 pt;80 pt;80 pt;50 pt;60 pt;50 pt;0 pt"

      lstTransfers.ColumnCount = 5
      lstTransfers.ColumnWidths = "0 pt;80 pt;80 pt;90 pt;130 pt"
  End Sub

  Private Sub LoadInitialValues()

      txtStartDate.value = ReadCfg("StartDate", CurrentShamsiDate())
      txtInitialBank.value = FormatMoney(ReadCfg("InitialBank", 0))
      txtInitialCash.value = FormatMoney(ReadCfg("InitialCash", 0))
      txtCurrentDate.value = CurrentShamsiDate()
  End Sub

  Private Sub RefreshAllLists()
      LoadExpenses
      LoadFixedExpenses
      LoadIrregularExpenses
      LoadTransfers
  End Sub

  Private Sub txtStartDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtInitialBank_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtInitialCash_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtTransferDate_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtTransferAmount_Enter(): SetKeyboardEnglish: End Sub
  Private Sub txtCurrentDate_Enter(): SetKeyboardEnglish: End Sub

  Private Sub txtStartDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtStartDate.value = NormalizeDateText(txtStartDate.value)
      WriteCfg "StartDate", txtStartDate.value
  End Sub

  Private Sub txtInitialBank_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtInitialBank.value = FormatMoney(txtInitialBank.value)
      WriteCfg "InitialBank", MoneyValue(txtInitialBank.value)
  End Sub

  Private Sub txtInitialCash_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtInitialCash.value = FormatMoney(txtInitialCash.value)
      WriteCfg "InitialCash", MoneyValue(txtInitialCash.value)
  End Sub

  Private Sub txtTransferDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtTransferDate.value = NormalizeDateText(txtTransferDate.value)
  End Sub

  Private Sub txtTransferAmount_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtTransferAmount.value = FormatMoney(txtTransferAmount.value)
  End Sub

  Private Sub txtCurrentDate_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
      txtCurrentDate.value = NormalizeDateText(txtCurrentDate.value)
  End Sub

  Private Sub cmdExpenseAdd_Click()
      Dim expenseName As String

      SetKeyboardPersian
      expenseName = Trim$(InputBox("��� ����� �� ���� ����:", "������ �����"))

      If Len(expenseName) = 0 Then Exit Sub
      If ExpenseNameExists(expenseName) Then
          MsgBox "��� ����� ����� ��� ��� ���.", vbExclamation
          Exit Sub
      End If

      AddExpense expenseName
      LoadExpenses
  End Sub

  Private Sub cmdExpenseEdit_Click()
      Dim expenseId As Long
      Dim newName As String

      If lstExpenses.listIndex < 0 Then
          MsgBox "� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      expenseId = CLng(lstExpenses.List(lstExpenses.listIndex, 0))

      SetKeyboardPersian
      newName = Trim$(InputBox("��� ���� �����:", "������ �����", lstExpenses.List(lstExpenses.listIndex, 1)))

      If Len(newName) = 0 Then Exit Sub

      RenameExpense expenseId, newName
      RefreshAllLists
  End Sub

  Private Sub cmdExpenseDelete_Click()
      Dim expenseId As Long

      If lstExpenses.listIndex < 0 Then
          MsgBox "� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      expenseId = CLng(lstExpenses.List(lstExpenses.listIndex, 0))

      If ExpenseIsReferenced(expenseId) Then
          MsgBox "��� ����� ������� ��� �� �� �������� ����/����� ��� ��� � ���� ��� ����.", vbCritical
          Exit Sub
      End If

      If MsgBox("��� ��Ͽ", vbYesNo + vbQuestion) = vbNo Then Exit Sub

      DeleteRowById COL_EXP_ID, expenseId
      LoadExpenses
  End Sub

  Private Sub cmdFixedAdd_Click()
      Dim expenseId As Long
      Dim expenseName As String
      Dim amount As Currency
      Dim dayNo As Long
      Dim frequency As String
      Dim remainText As String
      Dim remainCount As Long
      Dim activeDate As String
      Dim paidFrom As String

      If Not PickExpense(expenseId, expenseName) Then Exit Sub

      amount = MoneyValue(InputBox("����:", "����� ����"))
      dayNo = CLng(val(InputBox("��� ��� �� ���� ���ϡ ���� 05 �� 25:", "����� ����")))
      frequency = PickFrequency()
      remainText = Trim$(InputBox("����� ���������. ǐ� ������� ��� ���� Ȑ�����:", "����� ����"))
      activeDate = NormalizeDateText(InputBox("����� ��������:", "����� ����", txtStartDate.value))
      paidFrom = PickPaidFrom()

      If amount <= 0 Or dayNo < 1 Or dayNo > 31 Or Len(frequency) = 0 Or Len(activeDate) = 0 Or Len(paidFrom) = 0 Then
          MsgBox "������� ���� ��� ���� ����.", vbExclamation
          Exit Sub
      End If

      If Len(remainText) = 0 Then
          remainCount = -1
      Else
          remainCount = CLng(val(remainText))
      End If

      AddFixedExpense expenseId, expenseName, amount, dayNo, frequency, remainCount, activeDate, paidFrom
      LoadFixedExpenses
  End Sub

  Private Sub cmdFixedEdit_Click()
      Dim fixedId As Long
      Dim expenseId As Long
      Dim expenseName As String
      Dim activeText As String
      Dim deactivationDate As String

      If lstFixedExpenses.listIndex < 0 Then
          MsgBox "� ����� ���� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      fixedId = CLng(lstFixedExpenses.List(lstFixedExpenses.listIndex, 0))

      If Not PickExpense(expenseId, expenseName) Then Exit Sub

      activeText = InputBox("���� ���Ͽ yes/no", "������ ����� ����", lstFixedExpenses.List(lstFixedExpenses.listIndex, 6))
      deactivationDate = NormalizeDateText(InputBox("����� ������������ ǐ� ���� ��� ���� Ȑ�����:", "������ ����� ����"))

      EditFixedExpense fixedId, expenseId, expenseName, IsYes(activeText), deactivationDate
      LoadFixedExpenses
  End Sub

  Private Sub cmdFixedDelete_Click()
      Dim fixedId As Long

      If lstFixedExpenses.listIndex < 0 Then
          MsgBox "� ����� ���� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      fixedId = CLng(lstFixedExpenses.List(lstFixedExpenses.listIndex, 0))

      If FixedExpenseUsed(fixedId) Then
          MsgBox "��� ����� ���� ����� �� ������ ������� ��� � ���� ��� ����. �� �� ������� ����.", vbCritical
          Exit Sub
      End If

      If MsgBox("��� ��Ͽ", vbYesNo + vbQuestion) = vbNo Then Exit Sub

      DeleteRowById COL_FIXED_ID, fixedId
      LoadFixedExpenses
  End Sub

  Private Sub cmdIrregularAdd_Click()
      Dim expenseId As Long
      Dim expenseName As String
      Dim amount As Currency
      Dim expenseDate As String
      Dim paidFrom As String

      If Not PickExpense(expenseId, expenseName) Then Exit Sub

      amount = MoneyValue(InputBox("����:", "����� �����"))
      expenseDate = NormalizeDateText(InputBox("�����:", "����� �����", txtCurrentDate.value))
      paidFrom = PickPaidFrom()

      If amount <= 0 Or Len(expenseDate) = 0 Or Len(paidFrom) = 0 Then
          MsgBox "������� ���� ��� ���� ����.", vbExclamation
          Exit Sub
      End If

      AddIrregularExpense expenseId, expenseName, amount, expenseDate, paidFrom
      LoadIrregularExpenses
  End Sub

  Private Sub cmdIrregularEdit_Click()
      Dim irregularId As Long
      Dim expenseId As Long
      Dim expenseName As String
      Dim activeText As String

      If lstIrregularExpenses.listIndex < 0 Then
          MsgBox "� ����� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      irregularId = CLng(lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 0))

      If IrregularExpenseUsed(irregularId) Then
          MsgBox "��� ����� ����� ������� ��� � ��� ����� ����/������� ���� ����� ���.", vbInformation
          expenseId = 0
          expenseName = ""
      Else
          If Not PickExpense(expenseId, expenseName) Then Exit Sub
      End If

      activeText = InputBox("���� ���Ͽ yes/no", "������ ����� �����", lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 4))

      EditIrregularExpense irregularId, expenseId, expenseName, IsYes(activeText)
      LoadIrregularExpenses
  End Sub

  Private Sub cmdIrregularDelete_Click()
      Dim irregularId As Long

      If lstIrregularExpenses.listIndex < 0 Then
          MsgBox "� ����� ����� �� ������ ����.", vbExclamation
          Exit Sub
      End If

      irregularId = CLng(lstIrregularExpenses.List(lstIrregularExpenses.listIndex, 0))

      If IrregularExpenseUsed(irregularId) Then
          MsgBox "��� ����� ����� ����� �� ������ ������� ��� � ���� ��� ����.", vbCritical
          Exit Sub
      End If

      If MsgBox("��� ��Ͽ", vbYesNo + vbQuestion) = vbNo Then Exit Sub

      DeleteRowById COL_IRR_ID, irregularId
      LoadIrregularExpenses
  End Sub

  Private Sub cmdTransferSubmit_Click()
      Dim transferDate As String
      Dim transferType As String
      Dim amount As Currency

      transferDate = NormalizeDateText(txtTransferDate.value)
      transferType = CStr(cboTransferType.value)
      amount = MoneyValue(txtTransferAmount.value)

      If Len(transferDate) = 0 Or amount <= 0 Or Len(transferType) = 0 Then
          MsgBox "������� �����/������ ���� ����.", vbExclamation
          Exit Sub
      End If

      AddTransfer transferDate, transferType, amount

      txtTransferDate.value = ""
      txtTransferAmount.value = ""
      LoadTransfers
  End Sub

  Private Sub cmdCalculateNow_Click()
      CalculateBalances
  End Sub

  Private Sub CalculateBalances()
      Dim startDate As String
      Dim endDate As String
      Dim bankBalance As Currency
      Dim cashBalance As Currency

      startDate = NormalizeDateText(txtStartDate.value)
      endDate = NormalizeDateText(txtCurrentDate.value)

      If Len(startDate) = 0 Or Len(endDate) = 0 Then
          MsgBox "����� ���� � ����� ������ �� ���� ����.", vbExclamation
          Exit Sub
      End If

      bankBalance = MoneyValue(txtInitialBank.value)
      cashBalance = MoneyValue(txtInitialCash.value)

      ApplyWorkbookMovements startDate, endDate, bankBalance, cashBalance
      ApplyFixedExpenses startDate, endDate, bankBalance, cashBalance
      ApplyIrregularExpenses startDate, endDate, bankBalance, cashBalance
      ApplyTransfers startDate, endDate, bankBalance, cashBalance

      txtCurrentBank.value = FormatMoney(bankBalance)
      txtCurrentCash.value = FormatMoney(cashBalance)
      txtGrandTotal.value = FormatMoney(bankBalance + cashBalance)

      RefreshAllLists
  End Sub
  
    '==============================
  ' Sheet creation / headers
  '==============================
  Private Sub EnsureAccountingSheet()
      Dim ws As Worksheet

      Set ws = GetOrCreateSheet(ACCOUNTING_SHEET)

      ws.Cells(1, COL_CFG_KEY).value = "ConfigKey"
      ws.Cells(1, COL_CFG_VAL).value = "ConfigValue"

      ws.Cells(1, COL_EXP_ID).value = "ExpenseID"
      ws.Cells(1, COL_EXP_NAME).value = "ExpenseName"
      ws.Cells(1, COL_EXP_CREATED).value = "CreatedAt"

      ws.Cells(1, COL_FIXED_ID).value = "FixedID"
      ws.Cells(1, COL_FIXED_EXP_ID).value = "ExpenseID"
      ws.Cells(1, COL_FIXED_NAME).value = "ExpenseName"
      ws.Cells(1, COL_FIXED_AMOUNT).value = "Amount"
      ws.Cells(1, COL_FIXED_DAY).value = "Day"
      ws.Cells(1, COL_FIXED_FREQ).value = "Frequency"
      ws.Cells(1, COL_FIXED_REMAIN).value = "Remaining"
      ws.Cells(1, COL_FIXED_ACTIVE).value = "Active"
      ws.Cells(1, COL_FIXED_ACT_DATE).value = "ActivationDate"
      ws.Cells(1, COL_FIXED_DEACT_DATE).value = "DeactivationDate"
      ws.Cells(1, COL_FIXED_PAID_FROM).value = "PaidFrom"
      ws.Cells(1, COL_FIXED_USED).value = "Used"

      ws.Cells(1, COL_IRR_ID).value = "IrregularID"
      ws.Cells(1, COL_IRR_EXP_ID).value = "ExpenseID"
      ws.Cells(1, COL_IRR_NAME).value = "ExpenseName"
      ws.Cells(1, COL_IRR_AMOUNT).value = "Amount"
      ws.Cells(1, COL_IRR_DATE).value = "Date"
      ws.Cells(1, COL_IRR_ACTIVE).value = "Active"
      ws.Cells(1, COL_IRR_PAID_FROM).value = "PaidFrom"
      ws.Cells(1, COL_IRR_USED).value = "Used"

      ws.Cells(1, COL_TR_ID).value = "TransferID"
      ws.Cells(1, COL_TR_DATE).value = "Date"
      ws.Cells(1, COL_TR_TYPE).value = "Type"
      ws.Cells(1, COL_TR_AMOUNT).value = "Amount"
      ws.Cells(1, COL_TR_CREATED).value = "CreatedAt"
  End Sub

  Private Function GetOrCreateSheet(ByVal sheetName As String) As Worksheet
      On Error Resume Next
      Set GetOrCreateSheet = ThisWorkbook.Worksheets(sheetName)
      On Error GoTo 0

      If GetOrCreateSheet Is Nothing Then
          Set GetOrCreateSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
          GetOrCreateSheet.Name = sheetName
      End If
  End Function

  Private Function AccountingWs() As Worksheet
      Set AccountingWs = GetOrCreateSheet(ACCOUNTING_SHEET)
  End Function

  '==============================
  ' Config storage
  '==============================
  Private Function ReadCfg(ByVal keyName As String, Optional ByVal defaultValue As Variant = "") As Variant
      Dim ws As Worksheet
      Dim f As Range

      Set ws = AccountingWs()

      Set f = ws.Columns(COL_CFG_KEY).Find( _
          What:=keyName, LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)

      If f Is Nothing Then
          ReadCfg = defaultValue
      Else
          ReadCfg = f.Offset(0, 1).value
      End If
  End Function

  Private Sub WriteCfg(ByVal keyName As String, ByVal valueIn As Variant)
      Dim ws As Worksheet
      Dim f As Range
      Dim nextRow As Long

      Set ws = AccountingWs()

      Set f = ws.Columns(COL_CFG_KEY).Find( _
          What:=keyName, LookIn:=xlValues, LookAt:=xlWhole, MatchCase:=False)

      If f Is Nothing Then
          nextRow = ws.Cells(ws.rows.Count, COL_CFG_KEY).End(xlUp).Row + 1
          If nextRow < 2 Then nextRow = 2
          ws.Cells(nextRow, COL_CFG_KEY).value = keyName
          ws.Cells(nextRow, COL_CFG_VAL).value = valueIn
      Else
          f.Offset(0, 1).value = valueIn
      End If
  End Sub

  '==============================
  ' Expenses master list
  '==============================
  Private Sub AddExpense(ByVal expenseName As String)
      Dim ws As Worksheet
      Dim nextRow As Long

      Set ws = AccountingWs()
      nextRow = NextRowInColumn(ws, COL_EXP_ID)

      ws.Cells(nextRow, COL_EXP_ID).value = NextId(COL_EXP_ID)
      ws.Cells(nextRow, COL_EXP_NAME).value = expenseName
      ws.Cells(nextRow, COL_EXP_CREATED).value = Now
  End Sub

  Private Sub LoadExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim rowsData() As Variant
      Dim rowCount As Long

      Set ws = AccountingWs()
      lstExpenses.Clear

      lastRow = ws.Cells(ws.rows.Count, COL_EXP_ID).End(xlUp).Row
      If lastRow < 2 Then Exit Sub

      ReDim rowsData(1 To lastRow - 1, 1 To 2)

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_EXP_ID).value)) > 0 Then
              rowCount = rowCount + 1
              rowsData(rowCount, 1) = ws.Cells(r, COL_EXP_ID).value
              rowsData(rowCount, 2) = ws.Cells(r, COL_EXP_NAME).value
          End If
      Next r

      If rowCount = 0 Then Exit Sub

      Sort2DBySecondColumn rowsData, rowCount

      For r = 1 To rowCount
          lstExpenses.AddItem rowsData(r, 1)
          lstExpenses.List(lstExpenses.ListCount - 1, 1) = rowsData(r, 2)
      Next r
  End Sub

  Private Function ExpenseNameExists(ByVal expenseName As String) As Boolean
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, COL_EXP_ID).End(xlUp).Row

      For r = 2 To lastRow
          If StrComp(Trim$(CStr(ws.Cells(r, COL_EXP_NAME).value)), Trim$(expenseName), vbTextCompare) = 0 Then
              ExpenseNameExists = True
              Exit Function
          End If
      Next r
  End Function

  Private Sub RenameExpense(ByVal expenseId As Long, ByVal newName As String)
      Dim ws As Worksheet
      Dim rowNo As Long

      Set ws = AccountingWs()
      rowNo = FindRowById(COL_EXP_ID, expenseId)
      If rowNo = 0 Then Exit Sub

      ws.Cells(rowNo, COL_EXP_NAME).value = newName
      RenameExpenseReferences expenseId, newName
  End Sub

  Private Sub RenameExpenseReferences(ByVal expenseId As Long, ByVal newName As String)
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()

      lastRow = ws.Cells(ws.rows.Count, COL_FIXED_ID).End(xlUp).Row
      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, COL_FIXED_EXP_ID).value)) = expenseId Then
              ws.Cells(r, COL_FIXED_NAME).value = newName
          End If
      Next r

      lastRow = ws.Cells(ws.rows.Count, COL_IRR_ID).End(xlUp).Row
      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, COL_IRR_EXP_ID).value)) = expenseId Then
              ws.Cells(r, COL_IRR_NAME).value = newName
          End If
      Next r
  End Sub

  Private Function ExpenseIsReferenced(ByVal expenseId As Long) As Boolean
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()

      lastRow = ws.Cells(ws.rows.Count, COL_FIXED_ID).End(xlUp).Row
      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, COL_FIXED_EXP_ID).value)) = expenseId Then
              ExpenseIsReferenced = True
              Exit Function
          End If
      Next r

      lastRow = ws.Cells(ws.rows.Count, COL_IRR_ID).End(xlUp).Row
      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, COL_IRR_EXP_ID).value)) = expenseId Then
              ExpenseIsReferenced = True
              Exit Function
          End If
      Next r
  End Function

  '==============================
  ' Fixed expenses
  '==============================
  Private Sub AddFixedExpense(ByVal expenseId As Long, ByVal expenseName As String, ByVal amount As Currency, ByVal dayNo As Long, ByVal frequency As String, ByVal remainCount As Long, ByVal activeDate As String, ByVal paidFrom As String)
      Dim ws As Worksheet
      Dim nextRow As Long

      Set ws = AccountingWs()
      nextRow = NextRowInColumn(ws, COL_FIXED_ID)

      ws.Cells(nextRow, COL_FIXED_ID).value = NextId(COL_FIXED_ID)
      ws.Cells(nextRow, COL_FIXED_EXP_ID).value = expenseId
      ws.Cells(nextRow, COL_FIXED_NAME).value = expenseName
      ws.Cells(nextRow, COL_FIXED_AMOUNT).value = amount
      ws.Cells(nextRow, COL_FIXED_DAY).value = dayNo
      ws.Cells(nextRow, COL_FIXED_FREQ).value = frequency
      ws.Cells(nextRow, COL_FIXED_REMAIN).value = remainCount
      ws.Cells(nextRow, COL_FIXED_ACTIVE).value = True
      ws.Cells(nextRow, COL_FIXED_ACT_DATE).value = activeDate
      ws.Cells(nextRow, COL_FIXED_DEACT_DATE).value = ""
      ws.Cells(nextRow, COL_FIXED_PAID_FROM).value = paidFrom
      ws.Cells(nextRow, COL_FIXED_USED).value = False
  End Sub

  Private Sub LoadFixedExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lstFixedExpenses.Clear

      lastRow = ws.Cells(ws.rows.Count, COL_FIXED_ID).End(xlUp).Row
      If lastRow < 2 Then Exit Sub

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_FIXED_ID).value)) > 0 Then
              lstFixedExpenses.AddItem ws.Cells(r, COL_FIXED_ID).value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 1) = ws.Cells(r, COL_FIXED_NAME).value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 2) = FormatMoney(ws.Cells(r, COL_FIXED_AMOUNT).value)
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 3) = Format(CLng(val(ws.Cells(r, COL_FIXED_DAY).value)), "00")
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 4) = ws.Cells(r, COL_FIXED_FREQ).value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 5) = RemainingText(ws.Cells(r, COL_FIXED_REMAIN).value)
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 6) = YesNoText(ws.Cells(r, COL_FIXED_ACTIVE).value)
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 7) = ws.Cells(r, COL_FIXED_ACT_DATE).value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 8) = ws.Cells(r, COL_FIXED_DEACT_DATE).value
              lstFixedExpenses.List(lstFixedExpenses.ListCount - 1, 9) = ws.Cells(r, COL_FIXED_PAID_FROM).value
          End If
      Next r
  End Sub

  Private Sub EditFixedExpense(ByVal fixedId As Long, ByVal expenseId As Long, ByVal expenseName As String, ByVal isActive As Boolean, ByVal deactivationDate As String)
      Dim ws As Worksheet
      Dim rowNo As Long

      Set ws = AccountingWs()
      rowNo = FindRowById(COL_FIXED_ID, fixedId)
      If rowNo = 0 Then Exit Sub

      ws.Cells(rowNo, COL_FIXED_EXP_ID).value = expenseId
      ws.Cells(rowNo, COL_FIXED_NAME).value = expenseName
      ws.Cells(rowNo, COL_FIXED_ACTIVE).value = isActive
      ws.Cells(rowNo, COL_FIXED_DEACT_DATE).value = deactivationDate
  End Sub

  Private Function FixedExpenseUsed(ByVal fixedId As Long) As Boolean
      Dim rowNo As Long

      rowNo = FindRowById(COL_FIXED_ID, fixedId)
      If rowNo = 0 Then Exit Function

      FixedExpenseUsed = CBool(AccountingWs().Cells(rowNo, COL_FIXED_USED).value)
  End Function

  '==============================
  ' Irregular expenses
  '==============================
  Private Sub AddIrregularExpense(ByVal expenseId As Long, ByVal expenseName As String, ByVal amount As Currency, ByVal expenseDate As String, ByVal paidFrom As String)
      Dim ws As Worksheet
      Dim nextRow As Long

      Set ws = AccountingWs()
      nextRow = NextRowInColumn(ws, COL_IRR_ID)

      ws.Cells(nextRow, COL_IRR_ID).value = NextId(COL_IRR_ID)
      ws.Cells(nextRow, COL_IRR_EXP_ID).value = expenseId
      ws.Cells(nextRow, COL_IRR_NAME).value = expenseName
      ws.Cells(nextRow, COL_IRR_AMOUNT).value = amount
      ws.Cells(nextRow, COL_IRR_DATE).value = expenseDate
      ws.Cells(nextRow, COL_IRR_ACTIVE).value = True
      ws.Cells(nextRow, COL_IRR_PAID_FROM).value = paidFrom
      ws.Cells(nextRow, COL_IRR_USED).value = False
  End Sub

  Private Sub LoadIrregularExpenses()
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lstIrregularExpenses.Clear

      lastRow = ws.Cells(ws.rows.Count, COL_IRR_ID).End(xlUp).Row
      If lastRow < 2 Then Exit Sub

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_IRR_ID).value)) > 0 Then
              lstIrregularExpenses.AddItem ws.Cells(r, COL_IRR_ID).value
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 1) = ws.Cells(r, COL_IRR_NAME).value
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 2) = FormatMoney(ws.Cells(r, COL_IRR_AMOUNT).value)
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 3) = ws.Cells(r, COL_IRR_DATE).value
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 4) = YesNoText(ws.Cells(r, COL_IRR_ACTIVE).value)
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 5) = ws.Cells(r, COL_IRR_PAID_FROM).value
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 6) = YesNoText(ws.Cells(r, COL_IRR_USED).value)
              lstIrregularExpenses.List(lstIrregularExpenses.ListCount - 1, 7) = ws.Cells(r, COL_IRR_EXP_ID).value
          End If
      Next r
  End Sub

  Private Sub EditIrregularExpense(ByVal irregularId As Long, ByVal expenseId As Long, ByVal expenseName As String, ByVal isActive As Boolean)
      Dim ws As Worksheet
      Dim rowNo As Long

      Set ws = AccountingWs()
      rowNo = FindRowById(COL_IRR_ID, irregularId)
      If rowNo = 0 Then Exit Sub

      If expenseId > 0 Then
          ws.Cells(rowNo, COL_IRR_EXP_ID).value = expenseId
          ws.Cells(rowNo, COL_IRR_NAME).value = expenseName
      End If

      ws.Cells(rowNo, COL_IRR_ACTIVE).value = isActive
  End Sub

  Private Function IrregularExpenseUsed(ByVal irregularId As Long) As Boolean
      Dim rowNo As Long

      rowNo = FindRowById(COL_IRR_ID, irregularId)
      If rowNo = 0 Then Exit Function

      IrregularExpenseUsed = CBool(AccountingWs().Cells(rowNo, COL_IRR_USED).value)
  End Function



'==============================
  ' Transfers: deposit / withdraw
  '==============================
  Private Sub AddTransfer(ByVal transferDate As String, ByVal transferType As String, ByVal amount As Currency)
      Dim ws As Worksheet
      Dim nextRow As Long

      Set ws = AccountingWs()
      nextRow = NextRowInColumn(ws, COL_TR_ID)

      ws.Cells(nextRow, COL_TR_ID).value = NextId(COL_TR_ID)
      ws.Cells(nextRow, COL_TR_DATE).value = NormalizeDateText(transferDate)
      ws.Cells(nextRow, COL_TR_TYPE).value = transferType
      ws.Cells(nextRow, COL_TR_AMOUNT).value = amount
      ws.Cells(nextRow, COL_TR_CREATED).value = Now
  End Sub

  Private Sub LoadTransfers()
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lstTransfers.Clear

      lastRow = ws.Cells(ws.rows.Count, COL_TR_ID).End(xlUp).Row
      If lastRow < 2 Then Exit Sub

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_TR_ID).value)) > 0 Then
              lstTransfers.AddItem ws.Cells(r, COL_TR_ID).value
              lstTransfers.List(lstTransfers.ListCount - 1, 1) = ws.Cells(r, COL_TR_DATE).value
              lstTransfers.List(lstTransfers.ListCount - 1, 2) = ws.Cells(r, COL_TR_TYPE).value
              lstTransfers.List(lstTransfers.ListCount - 1, 3) = FormatMoney(ws.Cells(r, COL_TR_AMOUNT).value)
              lstTransfers.List(lstTransfers.ListCount - 1, 4) = ws.Cells(r, COL_TR_CREATED).value
          End If
      Next r
  End Sub

  Private Sub ApplyTransfers(ByVal startDate As String, ByVal endDate As String, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim txDate As String
      Dim txType As String
      Dim amount As Currency

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, COL_TR_ID).End(xlUp).Row

      For r = 2 To lastRow
          txDate = NormalizeDateText(CStr(ws.Cells(r, COL_TR_DATE).value))

          If DateInRange(txDate, startDate, endDate) Then
              txType = LCase$(Trim$(CStr(ws.Cells(r, COL_TR_TYPE).value)))
              amount = MoneyValue(ws.Cells(r, COL_TR_AMOUNT).value)

              Select Case txType
                  Case "deposit"
                      cashBalance = cashBalance - amount
                      bankBalance = bankBalance + amount

                  Case "withdraw"
                      bankBalance = bankBalance - amount
                      cashBalance = cashBalance + amount
              End Select
          End If
      Next r
  End Sub

  '==============================
  ' Balance calculation: workbook movements
  '==============================
  Private Sub ApplyWorkbookMovements(ByVal startDate As String, ByVal endDate As String, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Dim wsInfo As Worksheet
      Dim startRow As Long
      Dim endRow As Long
      Dim r As Long
      Dim currentDate As String
      Dim cardSales As Currency
      Dim cashSales As Currency
      Dim chequeCleared As Currency
      Dim directPays As Currency

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Worksheets(INFO_SHEET)
      On Error GoTo 0

      If wsInfo Is Nothing Then
          MsgBox "Sheet '" & INFO_SHEET & "' was not found. Sales, cheques, and direct pays were skipped.", vbExclamation
          Exit Sub
      End If

      startRow = FindDateRow(startDate)
      endRow = FindDateRow(endDate)

      If startRow = 0 Or endRow = 0 Then
          MsgBox "Start date or current date was not found in '" & INFO_SHEET & "' column U. Sales, cheques, and direct pays were skipped.", vbExclamation
          Exit Sub
      End If

      If endRow < startRow Then
          MsgBox "Current date is before start date.", vbExclamation
          Exit Sub
      End If

      For r = startRow To endRow
          currentDate = NormalizeDateText(CStr(wsInfo.Cells(r, "U").value))

          cardSales = DailySalesTotal(currentDate, "D")
          cashSales = DailySalesTotal(currentDate, "C")
          chequeCleared = ClearingAmountForDate(r)
          directPays = DailyDirectPayTotal(currentDate)

          bankBalance = bankBalance + cardSales + chequeCleared - directPays
          cashBalance = cashBalance + cashSales
      Next r
  End Sub

  Private Function DailySalesTotal(ByVal persianDate As String, ByVal salesColumn As String) As Currency
      Dim wsMonth As Worksheet
      Dim dayNumber As Long
      Dim rowsPerDayCount As Long
      Dim dayStartRow As Long

      Set wsMonth = MonthSheetForDate(persianDate)
      If wsMonth Is Nothing Then Exit Function

      dayNumber = CLng(val(Right$(NormalizeDateText(persianDate), 2)))
      rowsPerDayCount = RowsPerDay()
      dayStartRow = 2 + (dayNumber - 1) * (rowsPerDayCount + 1)

      DailySalesTotal = MoneyValue(Application.WorksheetFunction.Sum(wsMonth.Range(salesColumn & dayStartRow).Resize(rowsPerDayCount, 1)))
  End Function

  Private Function DailyDirectPayTotal(ByVal persianDate As String) As Currency
      Dim wsMonth As Worksheet
      Dim dayNumber As Long
      Dim rowsPerDayCount As Long
      Dim dayStartRow As Long
      Dim lowerHalfOffset As Long
      Dim numCheques As Long
      Dim numFactors As Long
      Dim numDirectPays As Long
      Dim firstFactorCol As Long
      Dim lastFactorCol As Long
      Dim firstDirectPayCol As Long
      Dim c As Long

      Set wsMonth = MonthSheetForDate(persianDate)
      If wsMonth Is Nothing Then Exit Function

      numCheques = SafeNameLong("cfg_NumCheques")
      numFactors = SafeNameLong("cfg_NumFactors")
      numDirectPays = SafeNameLong("cfg_NumDirectPays")

      If numDirectPays <= 0 Then Exit Function

      dayNumber = CLng(val(Right$(NormalizeDateText(persianDate), 2)))
      rowsPerDayCount = RowsPerDay()
      lowerHalfOffset = rowsPerDayCount \ 2
      dayStartRow = 2 + (dayNumber - 1) * (rowsPerDayCount + 1)

      firstFactorCol = 14 + (numCheques * 2) + 1
      lastFactorCol = firstFactorCol + (numFactors * 2) - 2
      firstDirectPayCol = lastFactorCol + 3

      For c = firstDirectPayCol To firstDirectPayCol + numDirectPays - 1
          DailyDirectPayTotal = DailyDirectPayTotal + MoneyValue(wsMonth.Cells(dayStartRow + lowerHalfOffset, c).value)
      Next c
  End Function

  Private Function ClearingAmountForDate(ByVal infoDateRow As Long) As Currency
      Dim ws As Worksheet
      Dim checkRow As Long

      Set ws = ThisWorkbook.Worksheets(INFO_SHEET)

      If CStr(ws.Cells(infoDateRow, "S").value) = "*" Then Exit Function

      checkRow = infoDateRow

      Do While checkRow >= 2
          ClearingAmountForDate = ClearingAmountForDate + MoneyValue(ws.Cells(checkRow, "Y").value)

          checkRow = checkRow - 1
          If checkRow < 2 Then Exit Do
          If CStr(ws.Cells(checkRow, "S").value) <> "*" Then Exit Do
      Loop
  End Function

  Private Function FindDateRow(ByVal persianDate As String) As Long
      Dim ws As Worksheet
      Dim f As Range

      On Error Resume Next
      Set ws = ThisWorkbook.Worksheets(INFO_SHEET)
      On Error GoTo 0

      If ws Is Nothing Then Exit Function

      Set f = ws.Columns("U").Find( _
          What:=NormalizeDateText(persianDate), LookIn:=xlValues, LookAt:=xlWhole)

      If f Is Nothing Then
          FindDateRow = 0
      Else
          FindDateRow = f.Row
      End If
  End Function

  Private Function MonthSheetForDate(ByVal persianDate As String) As Worksheet
      Dim ws As Worksheet
      Dim monthKey As String

      monthKey = Left$(NormalizeDateText(persianDate), 7)

      For Each ws In ThisWorkbook.Worksheets
          If CStr(ws.Range("B1").value) = monthKey Then
              Set MonthSheetForDate = ws
              Exit Function
          End If
      Next ws
  End Function

  Private Function RowsPerDay() As Long
      Dim actualCenters As Long
      Dim totalCenters As Long

      actualCenters = SafeNameLong("cfg_ActualUserCenters")
      totalCenters = SafeNameLong("cfg_TotalCenters")

      If actualCenters = 1 Then
          RowsPerDay = 2
      ElseIf totalCenters > 0 Then
          RowsPerDay = totalCenters
      Else
          RowsPerDay = 2
      End If
  End Function

  Private Function SafeNameLong(ByVal nameText As String) As Long
      On Error GoTo SafeExit
      SafeNameLong = CLng(val(ThisWorkbook.names(nameText).RefersToRange.value))
      Exit Function

SafeExit:
      SafeNameLong = 0
  End Function

  '==============================
  ' Balance calculation: expenses
  '==============================
  Private Sub ApplyFixedExpenses(ByVal startDate As String, ByVal endDate As String, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim currentDate As String
      Dim amount As Currency
      Dim paidFrom As String
      Dim appliedCount As Long

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, COL_FIXED_ID).End(xlUp).Row

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_FIXED_ID).value)) > 0 Then
              appliedCount = 0

              ForEachInfoDate startDate, endDate, r, appliedCount, bankBalance, cashBalance
          End If
      Next r
  End Sub

  Private Sub ForEachInfoDate(ByVal startDate As String, ByVal endDate As String, ByVal fixedRow As Long, ByRef appliedCount As Long, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Dim wsInfo As Worksheet
      Dim wsAcc As Worksheet
      Dim startRow As Long
      Dim endRow As Long
      Dim infoRow As Long
      Dim currentDate As String
      Dim amount As Currency
      Dim paidFrom As String
      Dim remainCount As Long

      Set wsAcc = AccountingWs()

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Worksheets(INFO_SHEET)
      On Error GoTo 0

      If wsInfo Is Nothing Then Exit Sub

      startRow = FindDateRow(startDate)
      endRow = FindDateRow(endDate)

      If startRow = 0 Or endRow = 0 Or endRow < startRow Then Exit Sub

      remainCount = CLng(val(wsAcc.Cells(fixedRow, COL_FIXED_REMAIN).value))

      For infoRow = startRow To endRow
          currentDate = NormalizeDateText(CStr(wsInfo.Cells(infoRow, "U").value))

          If FixedExpenseAppliesOnDate(fixedRow, currentDate) Then
              If remainCount <> -1 Then
                  If appliedCount >= remainCount Then Exit For
              End If

              amount = MoneyValue(wsAcc.Cells(fixedRow, COL_FIXED_AMOUNT).value)
              paidFrom = CStr(wsAcc.Cells(fixedRow, COL_FIXED_PAID_FROM).value)

              ApplyExpenseAmount amount, paidFrom, bankBalance, cashBalance

              appliedCount = appliedCount + 1
              wsAcc.Cells(fixedRow, COL_FIXED_USED).value = True
          End If
      Next infoRow
  End Sub

  Private Function FixedExpenseAppliesOnDate(ByVal fixedRow As Long, ByVal checkDate As String) As Boolean
      Dim ws As Worksheet
      Dim dayNo As Long
      Dim frequency As String
      Dim isActive As Boolean
      Dim activationDate As String
      Dim deactivationDate As String

      Set ws = AccountingWs()

      isActive = CBool(ws.Cells(fixedRow, COL_FIXED_ACTIVE).value)
      If Not isActive Then Exit Function

      checkDate = NormalizeDateText(checkDate)
      activationDate = NormalizeDateText(CStr(ws.Cells(fixedRow, COL_FIXED_ACT_DATE).value))
      deactivationDate = NormalizeDateText(CStr(ws.Cells(fixedRow, COL_FIXED_DEACT_DATE).value))

      If Len(activationDate) > 0 Then
          If checkDate < activationDate Then Exit Function
      End If

      If Len(deactivationDate) > 0 Then
          If checkDate > deactivationDate Then Exit Function
      End If

      dayNo = CLng(val(ws.Cells(fixedRow, COL_FIXED_DAY).value))
      If CLng(val(Right$(checkDate, 2))) <> dayNo Then Exit Function

      frequency = LCase$(Trim$(CStr(ws.Cells(fixedRow, COL_FIXED_FREQ).value)))

      Select Case frequency
          Case "monthly"
              FixedExpenseAppliesOnDate = True

          Case "yearly"
              ' Yearly expenses happen in the same month as the activation date, on the stored day.
              If Len(activationDate) > 0 Then
                  FixedExpenseAppliesOnDate = Mid$(checkDate, 6, 2) = Mid$(activationDate, 6, 2)
              End If

          Case Else
              FixedExpenseAppliesOnDate = True
      End Select
  End Function

  Private Sub ApplyIrregularExpenses(ByVal startDate As String, ByVal endDate As String, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim expenseDate As String
      Dim amount As Currency
      Dim paidFrom As String

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, COL_IRR_ID).End(xlUp).Row

      For r = 2 To lastRow
          If Len(CStr(ws.Cells(r, COL_IRR_ID).value)) > 0 Then
              If CBool(ws.Cells(r, COL_IRR_ACTIVE).value) Then
                  expenseDate = NormalizeDateText(CStr(ws.Cells(r, COL_IRR_DATE).value))

                  If DateInRange(expenseDate, startDate, endDate) Then
                      amount = MoneyValue(ws.Cells(r, COL_IRR_AMOUNT).value)
                      paidFrom = CStr(ws.Cells(r, COL_IRR_PAID_FROM).value)

                      ApplyExpenseAmount amount, paidFrom, bankBalance, cashBalance
                      ws.Cells(r, COL_IRR_USED).value = True
                  End If
              End If
          End If
      Next r
  End Sub

  Private Sub ApplyExpenseAmount(ByVal amount As Currency, ByVal paidFrom As String, ByRef bankBalance As Currency, ByRef cashBalance As Currency)
      Select Case LCase$(Trim$(paidFrom))
          Case "cash"
              cashBalance = cashBalance - amount

          Case "bank"
              bankBalance = bankBalance - amount

          Case Else
              bankBalance = bankBalance - amount
      End Select
  End Sub

  '==============================
  ' Picker helpers
  '==============================
  Private Function PickExpense(ByRef expenseId As Long, ByRef expenseName As String) As Boolean
      Dim typedName As String
      Dim foundId As Long

      If lstExpenses.listIndex >= 0 Then
          expenseId = CLng(lstExpenses.List(lstExpenses.listIndex, 0))
          expenseName = CStr(lstExpenses.List(lstExpenses.listIndex, 1))
          PickExpense = True
          Exit Function
      End If

      SetKeyboardPersian
      typedName = Trim$(InputBox("��� ����� �� ���� ����. ���� ��� ����� �� ���� ������� ������ ����:", "������ �����"))

      If Len(typedName) = 0 Then Exit Function

      foundId = FindExpenseIdByName(typedName)
      If foundId = 0 Then
          MsgBox "��� ����� �� ���� ������� ���� �����.", vbExclamation
          Exit Function
      End If

      expenseId = foundId
      expenseName = typedName
      PickExpense = True
  End Function

  Private Function PickFrequency() As String
      Dim answer As String

      SetKeyboardEnglish
      answer = LCase$(Trim$(InputBox("Frequency: monthly or yearly", "Frequency", "monthly")))

      Select Case answer
          Case "monthly", "m", "������"
              PickFrequency = "Monthly"

          Case "yearly", "y", "������"
              PickFrequency = "Yearly"

          Case Else
              PickFrequency = ""
      End Select
  End Function

  Private Function PickPaidFrom() As String
      Dim answer As String

      SetKeyboardEnglish
      answer = LCase$(Trim$(InputBox("Paid from: bank or cash", "Paid From", "bank")))

      Select Case answer
          Case "bank", "b", "���"
              PickPaidFrom = "Bank"

          Case "cash", "c", "���"
              PickPaidFrom = "Cash"

          Case Else
              PickPaidFrom = ""
      End Select
  End Function

  Private Function FindExpenseIdByName(ByVal expenseName As String) As Long
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, COL_EXP_ID).End(xlUp).Row

      For r = 2 To lastRow
          If StrComp(Trim$(CStr(ws.Cells(r, COL_EXP_NAME).value)), Trim$(expenseName), vbTextCompare) = 0 Then
              FindExpenseIdByName = CLng(val(ws.Cells(r, COL_EXP_ID).value))
              Exit Function
          End If
      Next r
  End Function

  '==============================
  ' Date / money helpers
  '==============================
  Private Function CurrentShamsiDate() As String
      Dim ws As Worksheet
      Dim y As String
      Dim m As String
      Dim d As String

      On Error Resume Next
      Set ws = ThisWorkbook.Worksheets(INFO_SHEET)
      On Error GoTo 0

      If ws Is Nothing Then
          CurrentShamsiDate = ""
          Exit Function
      End If

      y = CStr(ws.Range("AC1").value)
      m = Format(CLng(val(ws.Range("AC2").value)), "00")
      d = Format(CLng(val(ws.Range("AE1").value)), "00")

      CurrentShamsiDate = y & "/" & m & "/" & d
  End Function

  Public Function NormalizeDateText(ByVal valueIn As String) As String
      Dim s As String
      Dim parts() As String

      s = Trim$(CStr(valueIn))
      If Len(s) = 0 Then Exit Function

      s = ReplacePersianDigits(s)
      s = Replace(s, "-", "/")
      s = Replace(s, ".", "/")
      s = Replace(s, "\", "/")
      s = Replace(s, " ", "")

      If InStr(1, s, "/", vbTextCompare) = 0 And Len(s) = 8 Then
          s = Left$(s, 4) & "/" & Mid$(s, 5, 2) & "/" & Right$(s, 2)
      End If

      parts = Split(s, "/")
      If UBound(parts) <> 2 Then
          NormalizeDateText = s
          Exit Function
      End If

      NormalizeDateText = Format(CLng(val(parts(0))), "0000") & "/" & _
                          Format(CLng(val(parts(1))), "00") & "/" & _
                          Format(CLng(val(parts(2))), "00")
  End Function

  Private Function DateInRange(ByVal checkDate As String, ByVal startDate As String, ByVal endDate As String) As Boolean
      checkDate = NormalizeDateText(checkDate)
      startDate = NormalizeDateText(startDate)
      endDate = NormalizeDateText(endDate)

      If Len(checkDate) = 0 Or Len(startDate) = 0 Or Len(endDate) = 0 Then Exit Function

      DateInRange = checkDate >= startDate And checkDate <= endDate
  End Function

  Private Function ReplacePersianDigits(ByVal valueIn As String) As String
      Dim s As String

      s = CStr(valueIn)

      s = Replace(s, "�", "0")
      s = Replace(s, "�", "1")
      s = Replace(s, "�", "2")
      s = Replace(s, "�", "3")
      s = Replace(s, "�", "4")
      s = Replace(s, "�", "5")
      s = Replace(s, "�", "6")
      s = Replace(s, "�", "7")
      s = Replace(s, "�", "8")
      s = Replace(s, "�", "9")

      s = Replace(s, "�", "0")
      s = Replace(s, "�", "1")
      s = Replace(s, "�", "2")
      s = Replace(s, "�", "3")
      s = Replace(s, "�", "4")
      s = Replace(s, "�", "5")
      s = Replace(s, "�", "6")
      s = Replace(s, "�", "7")
      s = Replace(s, "�", "8")
      s = Replace(s, "�", "9")

      ReplacePersianDigits = s
  End Function

  Public Function MoneyValue(ByVal valueIn As Variant) As Currency
      Dim s As String

      s = CStr(valueIn)
      s = ReplacePersianDigits(s)
      s = Replace(s, ",", "")
      s = Replace(s, "�", "")
      s = Replace(s, " ", "")

      If Len(s) = 0 Then
          MoneyValue = 0
      Else
          MoneyValue = CCur(val(s))
      End If
  End Function

  Private Function FormatMoney(ByVal valueIn As Variant) As String
      FormatMoney = Format(MoneyValue(valueIn), "#,##0")
  End Function

  '==============================
  ' Generic storage helpers
  '==============================
  Private Function NextRowInColumn(ByVal ws As Worksheet, ByVal colNo As Long) As Long
      NextRowInColumn = ws.Cells(ws.rows.Count, colNo).End(xlUp).Row + 1
      If NextRowInColumn < 2 Then NextRowInColumn = 2
  End Function

  Private Function NextId(ByVal idColumn As Long) As Long
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim maxId As Long

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, idColumn).End(xlUp).Row

      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, idColumn).value)) > maxId Then
              maxId = CLng(val(ws.Cells(r, idColumn).value))
          End If
      Next r

      NextId = maxId + 1
  End Function

  Private Function FindRowById(ByVal idColumn As Long, ByVal idValue As Long) As Long
      Dim ws As Worksheet
      Dim lastRow As Long
      Dim r As Long

      Set ws = AccountingWs()
      lastRow = ws.Cells(ws.rows.Count, idColumn).End(xlUp).Row

      For r = 2 To lastRow
          If CLng(val(ws.Cells(r, idColumn).value)) = idValue Then
              FindRowById = r
              Exit Function
          End If
      Next r
  End Function

  Private Sub DeleteRowById(ByVal idColumn As Long, ByVal idValue As Long)
      Dim rowNo As Long

      rowNo = FindRowById(idColumn, idValue)
      If rowNo = 0 Then Exit Sub

      AccountingWs().rows(rowNo).Delete
  End Sub

  Private Sub Sort2DBySecondColumn(ByRef arr As Variant, ByVal itemCount As Long)
      Dim i As Long
      Dim j As Long
      Dim tempId As Variant
      Dim tempName As Variant

      For i = 1 To itemCount - 1
          For j = i + 1 To itemCount
              If StrComp(CStr(arr(i, 2)), CStr(arr(j, 2)), vbTextCompare) > 0 Then
                  tempId = arr(i, 1)
                  tempName = arr(i, 2)

                  arr(i, 1) = arr(j, 1)
                  arr(i, 2) = arr(j, 2)

                  arr(j, 1) = tempId
                  arr(j, 2) = tempName
              End If
          Next j
      Next i
  End Sub

  Private Function YesNoText(ByVal valueIn As Variant) As String
      If IsYes(valueIn) Then
          YesNoText = "Yes"
      Else
          YesNoText = "No"
      End If
  End Function

  Private Function IsYes(ByVal valueIn As Variant) As Boolean
      Dim s As String

      If VarType(valueIn) = vbBoolean Then
          IsYes = CBool(valueIn)
          Exit Function
      End If

      s = LCase$(Trim$(CStr(valueIn)))

      Select Case s
          Case "yes", "y", "true", "1", "����", "���"
              IsYes = True

          Case Else
              IsYes = False
      End Select
  End Function

  Private Function RemainingText(ByVal valueIn As Variant) As String
      If CLng(val(valueIn)) = -1 Then
          RemainingText = "Unlimited"
      Else
          RemainingText = CStr(CLng(val(valueIn)))
      End If
  End Function
