Attribute VB_Name = "modAccounting"
Sub ShowfrmChequeEdit()
    frmAccounting.Show
End Sub


