Attribute VB_Name = "modDashboardApp"
Option Explicit
Private mCanvasSelectionAccepted As Boolean

' App-style home dashboard. Settings are stored in the unused AZ column of "اطلاعات".
Private Const CFG_ROW As Long = 200
Private Const CFG_COL As Long = 52 ' AZ
Private mValue(1 To 15) As Double
Private mDetail(1 To 15) As String
Private mSales30 As Double
Private mChecks30 As Double
Private mDirects30 As Double
Private mExpenses30 As Double
Private mFirstBusinessDay As String
Private mCanvasLeft As Single
Private mCanvasTop As Single
Private mResolvedFont As String
Private mFontResolved As Boolean
Private mAutoFitPending As Boolean

Private Function p(ByVal codes As String) As String
    Dim a() As String, i As Long
    a = Split(codes, ",")
    For i = LBound(a) To UBound(a)
        p = p & ChrW$(CLng(a(i)))
    Next i
End Function

Private Function Info() As Worksheet
    Set Info = ThisWorkbook.Worksheets(p("1575,1591,1604,1575,1593,1575,1578"))
End Function

Private Function Dash() As Worksheet
    Set Dash = ThisWorkbook.Worksheets(p("1583,1575,1588,1576,1608,1585,1583"))
End Function

Private Function Cfg(ByVal offset As Long, Optional ByVal defaultValue As String = "") As String
    On Error Resume Next
    Cfg = Trim$(CStr(Info.Cells(CFG_ROW + offset, CFG_COL).Value2))
    On Error GoTo 0
    If Cfg = "" Then Cfg = defaultValue
End Function

Private Sub SetCfg(ByVal offset As Long, ByVal valueText As String)
    Info.Cells(CFG_ROW + offset, CFG_COL).value = valueText
End Sub

Private Sub EnsureConfig()
    If Cfg(0) <> "DASHBOARD_APP_V1" Then
        SetCfg 0, "DASHBOARD_APP_V1"
        SetCfg 1, "1": SetCfg 2, "2": SetCfg 3, "6": SetCfg 4, "7"
        SetCfg 5, "ADV": SetCfg 6, "NAVY": SetCfg 7, "ZERO": SetCfg 8, "30"
        SetCfg 9, "YES": SetCfg 10, "YES": SetCfg 11, "YES"
    End If
End Sub

Public Sub InstallDashboardApp()
    RefreshDashboardApp
End Sub

Public Sub RefreshDashboardApp()
    Dim oldCalc As XlCalculation
    Dim previousEvents As Boolean, previousUpdating As Boolean
    Dim failureText As String
    oldCalc = Application.Calculation
    previousEvents = Application.EnableEvents
    previousUpdating = Application.ScreenUpdating
    On Error GoTo CleanFail
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual
    Dash.Unprotect
    EnsureConfig
    CalculateMetrics
    PrepareDashboardSheet
    UpdateCards
    ReflowDashboardApp
CleanExit:
    On Error Resume Next
    ProtectDashboard
    Application.Calculation = oldCalc
    Application.EnableEvents = previousEvents
    Application.ScreenUpdating = previousUpdating
    On Error GoTo 0
    If failureText <> "" Then MsgBox failureText, vbExclamation, "Dashboard"
    Exit Sub
CleanFail:
    failureText = Err.description
    Resume CleanExit
End Sub

Public Sub ProtectDashboard()
    Dim dashboardSheet As Worksheet, dashboardShape As Shape
    Set dashboardSheet = Dash
    dashboardSheet.Protect DrawingObjects:=True, Contents:=True, Scenarios:=True, UserInterfaceOnly:=True
    For Each dashboardShape In dashboardSheet.shapes
        dashboardShape.Locked = True
        dashboardShape.Placement = xlFreeFloating
    Next dashboardShape
    dashboardSheet.EnableSelection = xlNoSelection
End Sub

Public Sub InitializeDashboardApp()
    ProtectDashboard
    UpdateDashboardDate
End Sub

Public Sub ShowDashboardSettings()
    Dim answer As String, i As Long, item As Variant, chosen As Object
    Dim backupConfig As Variant, cardCount As Long, slot As Long
    Dim selectedIds(1 To 8) As Long, selectedCount As Long, token As String
    Dim invalidSelection As Boolean, settingsError As String
    backupConfig = Info.Cells(CFG_ROW, CFG_COL).Resize(51, 1).Formula
    On Error GoTo SettingsFailed
    EnsureConfig
    answer = inputBox(p("1578,1593,1583,1575,1583,32,1705,1575,1585,1578,32,1607,1575") & vbCrLf & _
        "4 - " & p("1670,1607,1575,1585,32,1705,1575,1585,1578,32,1583,1585,32,1740,1705,32,1585,1583,1740,1601") & vbCrLf & _
        "8 - " & p("1607,1588,1578,32,1705,1575,1585,1578,32,1583,1585,32,1583,1608,32,1585,1583,1740,1601"), p("1578,1606,1592,1740,1605,1575,1578"), Cfg(30, "4"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(Trim$(answer))
    If answer <> "4" And answer <> "8" Then GoTo InvalidSettings
    cardCount = CLng(answer)
    Set chosen = CreateObject("Scripting.Dictionary")
    answer = inputBox(p("1705,1583,32,1588,1575,1582,1589,32,1607,1575,32,1585,1575,32,1576,1607,32,1578,1585,1578,1740,1576,32,1608,32,1576,1575,32,1608,1740,1585,1711,1608,1604,32,1608,1575,1585,1583,32,1705,1606,1740,1583,58") & " " & cardCount & vbCrLf & DashboardKpiMenu(), p("1578,1606,1592,1740,1605,1575,1578"), DashboardSelectionDefault(cardCount))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(Replace(Replace(Replace(answer, " ", ""), ChrW(1548), ","), ";", ","))
    For Each item In Split(answer, ",")
        token = Trim$(CStr(item))
        If Not IsNumeric(token) Then GoTo InvalidSettings
        If CDbl(token) <> Fix(CDbl(token)) Then GoTo InvalidSettings
        If CDbl(token) < 1 Or CDbl(token) > 15 Then GoTo InvalidSettings
        i = CLng(token)
        If chosen.exists(CStr(i)) Then GoTo InvalidSettings
        selectedCount = selectedCount + 1
        If selectedCount > cardCount Then GoTo InvalidSettings
        selectedIds(selectedCount) = i
        chosen.Add CStr(i), True
    Next item
    If selectedCount <> cardCount Then GoTo InvalidSettings
    SetCfg 30, CStr(cardCount)
    For slot = 1 To cardCount
        If slot <= 4 Then SetCfg slot, CStr(selectedIds(slot)) Else SetCfg 26 + slot, CStr(selectedIds(slot))
    Next slot
    answer = inputBox(p("1606,1608,1593,32,1583,1575,1588,1576,1608,1585,1583") & vbCrLf & "1 - " & p("1587,1575,1583,1607") & vbCrLf & "2 - " & p("1662,1740,1588,1585,1601,1578,1607"), p("1578,1606,1592,1740,1605,1575,1578"), IIf(Cfg(5) = "ADV", "2", "1"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If answer = "1" Then SetCfg 5, "SIMPLE"
    If answer = "2" Then SetCfg 5, "ADV"
    answer = inputBox("Theme" & vbCrLf & "1 - Blue" & vbCrLf & "2 - Navy Blue" & vbCrLf & "3 - Green" & vbCrLf & "4 - Black" & vbCrLf & "5 - Orange" & vbCrLf & "6 - Pink" & vbCrLf & "7 - Purple" & vbCrLf & "8 - Gray" & vbCrLf & "9 - Red" & vbCrLf & "10 - Yellow" & vbCrLf & "11 - Brown", p("1578,1606,1592,1740,1605,1575,1578"), ThemeNo())
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If IsNumeric(answer) Then
        Select Case CLng(answer)
            Case 1: SetCfg 6, "BLUE"
            Case 2: SetCfg 6, "NAVY"
            Case 3: SetCfg 6, "GREEN"
            Case 4: SetCfg 6, "BLACK"
            Case 5: SetCfg 6, "ORANGE"
            Case 6: SetCfg 6, "PINK"
            Case 7: SetCfg 6, "PURPLE"
            Case 8: SetCfg 6, "GRAY"
            Case 9: SetCfg 6, "RED"
            Case 10: SetCfg 6, "YELLOW"
            Case 11: SetCfg 6, "BROWN"
        End Select
    End If
    answer = inputBox(p("1601,1585,1608,1588,32,1585,1608,1586,32,1578,1593,1591,1740,1604") & vbCrLf & "1 - " & p("1589,1601,1585") & vbCrLf & "2 - " & p("1583,1585,1589,1583,1740,32,1575,1586,32,1605,1740,1575,1606,1711,1740,1606"), p("1578,1606,1592,1740,1605,1575,1578"), IIf(Cfg(7) = "PCT", "2", "1"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If answer = "1" Then SetCfg 7, "ZERO"
    If answer = "2" Then
        SetCfg 7, "PCT"
        answer = inputBox(p("1583,1585,1589,1583,32,1601,1585,1608,1588,32,1585,1608,1586,1607,1575,1740,32,1578,1593,1591,1740,1604,32,40,1575,1586,32,48,32,1578,1575,32,49,48,48,41"), p("1578,1606,1592,1740,1605,1575,1578"), Cfg(8, "30"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
        answer = NormalizeDigits(answer)
        If IsNumeric(answer) Then SetCfg 8, CStr(Application.Max(0, Application.Min(100, CDbl(answer))))
    End If
    answer = inputBox(p("1606,1605,1575,1740,1588,32,1583,1705,1605,1607,32,1582,1585,1608,1580,1740") & vbCrLf & "1 - " & p("1576,1604,1607") & vbCrLf & "2 - " & p("1582,1740,1585"), p("1578,1606,1592,1740,1605,1575,1578"), IIf(Cfg(11, "YES") = "YES", "1", "2"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If answer = "1" Then SetCfg 11, "YES"
    If answer = "2" Then SetCfg 11, "NO"
    answer = inputBox(p("1605,1581,1583,1608,1583,1607,32,1583,1575,1588,1576,1608,1585,1583") & vbCrLf & "1 - " & p("1575,1606,1578,1582,1575,1576,32,1605,1581,1583,1608,1583,1607") & vbCrLf & "2 - " & p("1581,1575,1604,1578,32,1582,1608,1583,1705,1575,1585") & vbCrLf & "3 - " & p("1576,1583,1608,1606,32,1578,1594,1740,1740,1585"), p("1578,1606,1592,1740,1605,1575,1578"), IIf(Cfg(13, "AUTO") = "CUSTOM", "1", "2"))
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If answer = "1" Then
        mCanvasSelectionAccepted = False
        SelectDashboardCanvas
        If Not mCanvasSelectionAccepted Then GoTo CancelSettings
    End If
    If answer = "2" Then
        SetCfg 13, "AUTO"
        SetCfg 12, ""
        CaptureDashboardCanvas True
    End If
    answer = inputBox(p("1575,1606,1578,1582,1575,1576,32,1602,1604,1605,32,1583,1575,1588,1576,1608,1585,1583") & vbCrLf & "1 - Vazirmatn" & vbCrLf & "2 - Tahoma" & vbCrLf & "3 - Segoe UI" & vbCrLf & "4 - Arial", p("1578,1606,1592,1740,1605,1575,1578"), FontOptionNo())
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If IsNumeric(answer) Then
        Select Case CLng(answer)
            Case 1: SetCfg 14, "VAZIRMATN"
            Case 2: SetCfg 14, "TAHOMA"
            Case 3: SetCfg 14, "SEGOE"
            Case 4: SetCfg 14, "ARIAL"
        End Select
        mFontResolved = False
        ' Font availability is checked after all settings are accepted.
    End If
    answer = inputBox(p("1575,1606,1583,1575,1586,1607,32,1605,1578,1606") & vbCrLf & "1 - " & p("1605,1593,1605,1608,1604,1740") & vbCrLf & "2 - " & p("1576,1586,1585,1711") & vbCrLf & "3 - " & p("1576,1587,1740,1575,1585,32,1576,1586,1585,1711") & vbCrLf & "4 - " & p("1576,1583,1608,1606,32,1578,1594,1740,1740,1585"), p("1578,1606,1592,1740,1605,1575,1578"), ScaleOptionNo())
    If answer = "" Then GoTo CancelSettings
    answer = NormalizeDigits(answer)
    If answer = "1" Then SetCfg 15, "NORMAL"
    If answer = "2" Then SetCfg 15, "LARGE"
    If answer = "3" Then SetCfg 15, "XL"
    If Not ConfigureWorkbookOpeningPassword() Then GoTo CancelSettings
    MsgBox p("1578,1606,1592,1740,1605,1575,1578,32,1584,1582,1740,1585,1607,32,1588,1583,46"), vbInformation
    ResolveDashboardFont True
    RefreshDashboardApp
    Exit Sub
InvalidSettings:
    MsgBox p("1608,1585,1608,1583,1740,32,1606,1575,1605,1593,1578,1576,1585,32,1575,1587,1578,46,32,1578,1606,1592,1740,1605,1575,1578,32,1578,1594,1740,1740,1585,32,1606,1705,1585,1583,46"), vbExclamation
    GoTo CancelSettings
SettingsFailed:
    settingsError = Err.description
CancelSettings:
    On Error Resume Next
    Info.Cells(CFG_ROW, CFG_COL).Resize(51, 1).Formula = backupConfig
    mFontResolved = False
    mAutoFitPending = False
    ProtectDashboard
    On Error GoTo 0
    If settingsError <> "" Then MsgBox settingsError, vbExclamation
End Sub

Public Sub SelectDashboardCanvas()
    mCanvasSelectionAccepted = False
    Dim selectedRange As Range
    On Error GoTo RestoreProtection
    Dash.Unprotect
    Dash.EnableSelection = xlNoRestrictions
    On Error Resume Next
    Set selectedRange = Application.inputBox(p("1605,1581,1583,1608,1583,1607,32,1605,1587,1578,1591,1740,1604,1740,32,1583,1575,1588,1576,1608,1585,1583,32,1585,1575,32,1575,1606,1578,1582,1575,1576,32,1705,1606,1740,1583,46"), p("1578,1606,1592,1740,1605,1575,1578"), Type:=8)
    On Error GoTo RestoreProtection
    If selectedRange Is Nothing Then GoTo RestoreProtection
    If selectedRange.Worksheet.name <> Dash.name Then
        MsgBox p("1605,1581,1583,1608,1583,1607,32,1576,1575,1740,1583,32,1583,1585,32,1588,1740,1578,32,1583,1575,1588,1576,1608,1585,1583,32,1575,1606,1578,1582,1575,1576,32,1588,1608,1583,46"), vbExclamation
        GoTo RestoreProtection
    End If
    If selectedRange.Width < 650 Or selectedRange.Height < 650 Then
        MsgBox p("1605,1581,1608,1591,1607,32,1575,1606,1578,1582,1575,1576,8204,1588,1583,1607,32,1576,1585,1575,1740,32,1670,1740,1583,1605,1575,1606,32,1583,1575,1588,1576,1608,1585,1583,32,1705,1608,1670,1705,32,1575,1587,1578,46,32,1604,1591,1601,1575,1611,32,1605,1581,1583,1608,1583,1607,32,1576,1586,1585,1711,8204,1578,1585,1740,32,1575,1606,1578,1582,1575,1576,32,1705,1606,1740,1583,46"), vbExclamation
        GoTo RestoreProtection
    End If
    mCanvasSelectionAccepted = True
    SetCfg 12, selectedRange.Address(False, False)
    SetCfg 13, "CUSTOM"
    CaptureDashboardCanvas True
    MsgBox p("1605,1581,1583,1608,1583,1607,32,1583,1575,1588,1576,1608,1585,1583,32,1584,1582,1740,1585,1607,32,1588,1583,46"), vbInformation
RestoreProtection:
    ProtectDashboard
End Sub

Private Function ThemeNo() As Long
    Select Case Cfg(6, "NAVY")
        Case "BLUE": ThemeNo = 1
        Case "GREEN": ThemeNo = 3
        Case "BLACK": ThemeNo = 4
        Case "ORANGE": ThemeNo = 5
        Case "PINK": ThemeNo = 6
        Case "PURPLE": ThemeNo = 7
        Case "GRAY": ThemeNo = 8
        Case "RED": ThemeNo = 9
        Case "YELLOW": ThemeNo = 10
        Case "BROWN": ThemeNo = 11
        Case Else: ThemeNo = 2
    End Select
End Function

Private Function FontOptionNo() As Long
    Select Case Cfg(14, "VAZIRMATN")
        Case "TAHOMA": FontOptionNo = 2
        Case "SEGOE": FontOptionNo = 3
        Case "ARIAL": FontOptionNo = 4
        Case Else: FontOptionNo = 1
    End Select
End Function

Private Function ScaleOptionNo() As Long
    Select Case Cfg(15, "LARGE")
        Case "NORMAL": ScaleOptionNo = 1
        Case "XL": ScaleOptionNo = 3
        Case Else: ScaleOptionNo = 2
    End Select
End Function

Private Function DashboardFont() As String
    ResolveDashboardFont False
    DashboardFont = mResolvedFont
End Function

Private Function RequestedDashboardFont() As String
    Select Case Cfg(14, "VAZIRMATN")
        Case "TAHOMA": RequestedDashboardFont = "Tahoma"
        Case "SEGOE": RequestedDashboardFont = "Segoe UI"
        Case "ARIAL": RequestedDashboardFont = "Arial"
        Case Else: RequestedDashboardFont = "Vazirmatn"
    End Select
End Function

Private Sub ResolveDashboardFont(Optional ByVal showDownloadPrompt As Boolean = False)
    Dim wantedFont As String
    If mFontResolved Then Exit Sub
    wantedFont = RequestedDashboardFont()
    mFontResolved = True
    If FontInstalled(wantedFont) Then
        mResolvedFont = wantedFont
    Else
        mResolvedFont = "Tahoma"
        If showDownloadPrompt Then
            If MsgBox(p("1601,1608,1606,1578,32,1575,1606,1578,1582,1575,1576,8204,1588,1583,1607,32,1585,1608,1740,32,1575,1740,1606,32,1585,1575,1740,1575,1606,1607,32,1606,1589,1576,32,1606,1740,1587,1578,46,32,1570,1740,1575,32,1605,1575,1740,1604,1740,1583,32,1589,1601,1581,1607,32,1583,1585,1740,1575,1601,1578,32,1608,32,1606,1589,1576,32,1570,1606,32,1583,1585,32,67,104,114,111,109,101,32,1576,1575,1586,32,1588,1608,1583,1567"), vbYesNo + vbQuestion, p("1583,1585,1740,1575,1601,1578,32,1601,1608,1606,1578")) = vbYes Then
                OpenFontDownloadPage wantedFont
            End If
        End If
    End If
End Sub

Private Function FontInstalled(ByVal fontName As String) As Boolean
    Dim probe As Shape
    On Error GoTo SafeExit
    Set probe = Dash.shapes.AddTextbox(msoTextOrientationHorizontal, -1000, -1000, 1, 1)
    probe.TextFrame2.TextRange.text = "A"
    probe.TextFrame2.TextRange.Font.name = fontName
    FontInstalled = (StrComp(CStr(probe.TextFrame2.TextRange.Font.name), fontName, vbTextCompare) = 0)
SafeExit:
    On Error Resume Next
    If Not probe Is Nothing Then probe.Delete
    On Error GoTo 0
End Function

Private Sub OpenFontDownloadPage(ByVal fontName As String)
    Const VAZIRMATN_URL As String = "https://github.com/rastikerdar/vazirmatn/releases/latest"
    Dim url As String
    If StrComp(fontName, "Vazirmatn", vbTextCompare) = 0 Then url = VAZIRMATN_URL
    If url = "" Then Exit Sub
    On Error Resume Next
    Err.Clear
    Shell "cmd.exe /c start """" chrome.exe --new-window """ & url & """", vbHide
    If Err.Number <> 0 Then
        Err.Clear
        ThisWorkbook.FollowHyperlink Address:=url, NewWindow:=True
    End If
    On Error GoTo 0
End Sub

Private Function DashboardTextScale() As Double
    Select Case Cfg(15, "LARGE")
        Case "NORMAL": DashboardTextScale = 1
        Case "XL": DashboardTextScale = 1.3
        Case Else: DashboardTextScale = 1.15
    End Select
End Function

Private Function KpiTitle(ByVal id As Long) As String
    If id >= 8 And id <= 11 Then KpiTitle = StockKpiTitle(id): Exit Function
    If id >= 12 And id <= 15 Then KpiTitle = DashboardForecastTitle(id): Exit Function
    Select Case id
        Case 1: KpiTitle = p("1580,1605,1593,32,1601,1575,1705,1578,1608,1585,1607,1575,1740,32,1576,1575,1586")
        Case 2: KpiTitle = p("1580,1605,1593,32,1670,1705,8204,1607,1575,1740,32,1662,1575,1587,8204,1606,1588,1583,1607")
        Case 3: KpiTitle = p("1670,1705,8204,1607,1575,1740,32") & "3" & p("32,1605,1575,1607,32,1570,1740,1606,1583,1607")
        Case 4: KpiTitle = p("1670,1705,8204,1607,1575,1740,32,1587,1585,1585,1587,1740,1583,32,1575,1608,1604,1740,1606,32,1585,1608,1586,32,1594,1740,1585,1578,1593,1591,1740,1604")
        Case 5: KpiTitle = p("1605,1740,1575,1606,1711,1740,1606,32,1601,1585,1608,1588,32,1605,1575,1607,32,1711,1584,1588,1578,1607")
        Case 6: KpiTitle = p("1670,1705,8204,1607,1575,1740,32,1587,1585,1585,1587,1740,1583,32") & "7" & p("32,1585,1608,1586,32,1570,1740,1606,1583,1607")
        Case 7: KpiTitle = p("1578,1594,1740,1740,1585,32,1582,1575,1604,1589,32,1606,1602,1583,1740,1606,1711,1740,32") & "30" & p("32,1585,1608,1586,32,1570,1740,1606,1583,1607")
    End Select
End Function

Private Sub PrepareDashboardSheet()
    Dim ws As Worksheet, shp As Shape
    Set ws = Dash
    ws.DisplayRightToLeft = True
    ActiveWindow.DisplayGridlines = False
    ' Paint the complete visible Dashboard canvas, including the columns left of the action shapes.
    ws.Range("A1:AZ80").Interior.color = RGB(245, 247, 250)
    ws.Range("A1:AZ80").Font.name = "Tahoma"
    ws.Range("A1:AZ80").Font.size = 10
    ws.Range("A1:AZ80").Borders.LineStyle = xlNone
    ws.Range("A1:AZ80").ClearContents
    EnsureShape ws, "DashApp_Header", msoShapeRectangle
    EnsureShape ws, "DashApp_Title", msoShapeRectangle
    EnsureShape ws, "DashApp_Date", msoShapeRectangle
    EnsureShape ws, "DashApp_Settings", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_Refresh", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_Privacy", msoShapeRoundedRectangle
    Dim i As Long
    For i = 1 To 8: EnsureShape ws, "DashApp_KPI" & i, msoShapeRoundedRectangle: Next i
    EnsureShape ws, "DashApp_Advanced", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_AdvSales", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_AdvCheque", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_AdvNet", msoShapeRoundedRectangle
    EnsureShape ws, "DashApp_Actions", msoShapeRectangle
    UngroupActionButtonGroups ws
    StyleAllActionShapes ws
End Sub

Private Sub UngroupActionButtonGroups(ByVal ws As Worksheet)
    Dim shp As Shape, childShape As Shape, groupName As Variant
    Dim groupNames As Collection, ungroupedShapes As ShapeRange, hasActionButton As Boolean
    Set groupNames = New Collection

    ' First collect names, because ungrouping while iterating ws.Shapes changes
    ' the collection and can otherwise skip shapes.
    For Each shp In ws.shapes
        If shp.Type = msoGroup Then
            hasActionButton = False
            On Error Resume Next
            For Each childShape In shp.groupItems
                If Len(Trim$(CStr(childShape.OnAction))) > 0 Then
                    hasActionButton = True
                    Exit For
                End If
            Next childShape
            On Error GoTo 0
            If hasActionButton Then groupNames.Add shp.name
        End If
    Next shp

    ' Only groups containing actionable child buttons are ungrouped. Decorative
    ' groups, logos, and other visual components remain grouped.
    For Each groupName In groupNames
        On Error Resume Next
        Set ungroupedShapes = ws.shapes.item(CStr(groupName)).Ungroup
        Set ungroupedShapes = Nothing
        On Error GoTo 0
    Next groupName
End Sub

Private Function EnsureShape(ByVal ws As Worksheet, ByVal shapeName As String, ByVal shapeType As MsoAutoShapeType) As Shape
    On Error Resume Next
    Set EnsureShape = ws.shapes(shapeName)
    On Error GoTo 0
    If EnsureShape Is Nothing Then
        Set EnsureShape = ws.shapes.AddShape(shapeType, 10, 10, 100, 30)
        EnsureShape.name = shapeName
    End If
End Function

Private Sub SetShapeText(ByVal shp As Shape, ByVal textValue As String, ByVal size As Single, ByVal color As Long, Optional ByVal bold As Boolean = False)
    With shp.TextFrame2
        .TextRange.text = textValue
        .TextRange.Font.name = DashboardFont()
        .TextRange.Font.size = size * DashboardTextScale()
        .TextRange.Font.Fill.ForeColor.RGB = color
        .TextRange.Font.bold = bold
        .VerticalAnchor = msoAnchorMiddle
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .MarginLeft = 12: .MarginRight = 12: .MarginTop = 6: .MarginBottom = 6
        .AutoSize = msoAutoSizeTextToFitShape
    End With
End Sub

Private Sub StyleAllActionShapes(ByVal ws As Worksheet)
    Dim shp As Shape, primary As Boolean
    For Each shp In ws.shapes
        ' A grouped shape has no single TextRange. Its individual members are
        ' intentionally left untouched by the dashboard button formatter.
        If shp.Type <> msoGroup And Left$(shp.name, 8) <> "DashApp_" Then
            primary = IsPrimaryAction(ActionName(shp))
            shp.Fill.Visible = msoTrue
            shp.Fill.Solid
            shp.Shadow.Visible = msoFalse
            shp.line.Visible = msoTrue
            shp.line.Weight = 0.75
            shp.Fill.ForeColor.RGB = IIf(primary, ThemeColor(2), RGB(255, 255, 255))
            shp.line.ForeColor.RGB = IIf(primary, ThemeColor(2), RGB(218, 226, 234))
            SetShapeText shp, shp.TextFrame2.TextRange.text, IIf(primary, 15, 11), IIf(primary, RGB(255, 255, 255), RGB(49, 61, 72)), primary
        End If
    Next shp
End Sub

Private Sub UpdateCards()
    Dim ws As Worksheet, i As Long, id As Long, shp As Shape, valueText As String
    Set ws = Dash
    SetShapeText ws.shapes("DashApp_Title"), p("1583,1575,1588,1576,1608,1585,1583,32,1605,1575,1604,1740"), 28, RGB(255, 255, 255), True
    UpdateDashboardDate
    SetShapeText ws.shapes("DashApp_Settings"), p("1578,1606,1592,1740,1605,1575,1578,32,1583,1575,1588,1576,1608,1585,1583"), 13, RGB(255, 255, 255), True
    ws.shapes("DashApp_Settings").OnAction = "ShowDashboardSettings"
    SetShapeText ws.shapes("DashApp_Refresh"), p("1576,1607,8204,1585,1608,1586,1585,1587,1575,1606,1740"), 13, RGB(255, 255, 255), True
    ws.shapes("DashApp_Refresh").OnAction = "RefreshDashboardApp"
    For i = 1 To 8
        ws.shapes("DashApp_KPI" & i).Visible = IIf(i <= DashboardCardCount(), msoTrue, msoFalse)
    Next i
    For i = 1 To DashboardCardCount()
        id = DashboardCardId(i)
        Set shp = ws.shapes("DashApp_KPI" & i)
        valueText = MetricText(id)
        SetShapeText shp, KpiTitle(id) & vbCrLf & vbCrLf & valueText & IIf(mDetail(id) <> "", vbCrLf & mDetail(id), ""), 19, RGB(37, 49, 62), True
        If id = 7 Or (id >= 8 And id <= 11) Then
            shp.TextFrame2.TextRange.Paragraphs(3).ParagraphFormat.TextDirection = msoTextDirectionLeftToRight
            shp.TextFrame2.TextRange.Paragraphs(3).LanguageID = msoLanguageIDEnglishUS
        End If
        shp.AlternativeText = CStr(id)
    Next i
    If Cfg(5, "ADV") = "ADV" Then
        ws.shapes("DashApp_Advanced").Visible = msoTrue
        SetShapeText ws.shapes("DashApp_Advanced"), p("1580,1586,1740,1740,1575,1578,32,1608,32,1607,1588,1583,1575,1585,1607,1575"), 18, RGB(37, 49, 62), True
        SetShapeText ws.shapes("DashApp_AdvSales"), p("1601,1585,1608,1588,32,1779,1776,32,1585,1608,1586,32,1570,1740,1606,1583,1607") & vbCrLf & Format$(mSales30, "#,##0"), 17, RGB(37, 49, 62), True
        SetShapeText ws.shapes("DashApp_AdvCheque"), p("1670,1705,8204,1607,1575,1740,32,1779,1776,32,1585,1608,1586,32,1570,1740,1606,1583,1607") & vbCrLf & Format$(mChecks30, "#,##0"), 17, RGB(37, 49, 62), True
        SetShapeText ws.shapes("DashApp_AdvNet"), p("1578,1594,1740,1740,1585,32,1582,1575,1604,1589,32,1779,1776,32,1585,1608,1586,32,1570,1740,1606,1583,1607") & vbCrLf & SignedAmountText(mValue(7)), 17, IIf(mValue(7) >= 0, RGB(23, 119, 82), RGB(180, 55, 55)), True
        ws.shapes("DashApp_AdvNet").TextFrame2.TextRange.Paragraphs(2).ParagraphFormat.TextDirection = msoTextDirectionLeftToRight
        ws.shapes("DashApp_AdvNet").TextFrame2.TextRange.Paragraphs(2).LanguageID = msoLanguageIDEnglishUS
    Else
        ws.shapes("DashApp_Advanced").Visible = msoFalse
        ws.shapes("DashApp_AdvSales").Visible = msoFalse
        ws.shapes("DashApp_AdvCheque").Visible = msoFalse
        ws.shapes("DashApp_AdvNet").Visible = msoFalse
    End If
    ApplyDashboardPrivacy
End Sub

Private Function MetricText(ByVal id As Long) As String
    If id = 14 Then MetricText = DashboardCoverageText(): Exit Function
    If id = 7 Or (id >= 8 And id <= 11) Then
        MetricText = SignedAmountText(mValue(id))
    Else
        MetricText = Format$(mValue(id), "#,##0") & " " & p("1585,1740,1575,1604")
    End If
End Function

Private Function PersianDigits(ByVal value As String) As String
    Dim digit As Long
    For digit = 0 To 9
        value = Replace(value, Chr$(48 + digit), ChrW$(1776 + digit))
    Next digit
    PersianDigits = value
End Function

Private Function SignedAmountText(ByVal amount As Double) As String
    SignedAmountText = ChrW$(8237) & ChrW$(8206) & IIf(amount < 0, "- ", "+ ") & _
        PersianDigits(Format$(Abs(amount), "#,##0")) & ChrW$(8206) & ChrW$(8236)
End Function

Private Function DashboardTodayText() As String
    Dim dateParts() As String, todayJ As String, englishMonths As Variant
    englishMonths = Split("January February March April May June July August September October November December", " ")
    todayJ = DashboardGregorianToPersian(Date)
    dateParts = Split(todayJ, "/")
    DashboardTodayText = ChrW$(8206) & CStr(day(Date)) & " " & englishMonths(Month(Date) - 1) & " " & _
        CStr(Year(Date)) & " (" & Format$(Date, "mm") & ")" & ChrW$(8206) & "   |   " & ChrW$(8235) & ChrW$(8207) & _
        p("1575,1605,1585,1608,1586,58") & " " & PersianDigits(CStr(CLng(dateParts(2)))) & " " & _
        PersianMonthName(CLng(dateParts(1))) & " " & PersianDigits(dateParts(0)) & " (" & PersianDigits(dateParts(1)) & ")" & ChrW$(8207) & ChrW$(8236)
End Function

Private Sub UpdateDashboardDate()
    Dim persianStart As Long
    SetShapeText Dash.shapes("DashApp_Date"), DashboardTodayText(), 16, RGB(255, 255, 255), False
    With Dash.shapes("DashApp_Date").TextFrame2.TextRange
        .ParagraphFormat.TextDirection = msoTextDirectionLeftToRight
        .LanguageID = msoLanguageIDEnglishUS
        persianStart = InStr(1, .text, p("1575,1605,1585,1608,1586,58"))
        If persianStart > 0 Then .Characters(persianStart, .Length - persianStart + 1).LanguageID = msoLanguageIDFarsi
    End With
End Sub

Private Function AdvancedText() As String
    AdvancedText = p("1580,1586,1740,1740,1575,1578,32,1608,32,1607,1588,1583,1575,1585,1607,1575") & vbCrLf & _
        p("1601,1585,1608,1588,32,1662,1740,1588,8204,1576,1740,1606,1740,32,1779,1776,32,1585,1608,1586,58") & " " & Format$(mSales30, "#,##0") & vbCrLf & _
        p("1670,1705,8204,1607,1575,1740,32,1779,1776,32,1585,1608,1586,58") & " " & Format$(mChecks30, "#,##0") & vbCrLf & _
        p("1582,1575,1604,1589,32,1662,1740,1588,8204,1607,1575,32,1583,1585,32,1779,1776,32,1585,1608,1586,58") & " " & Format$(mValue(7), "+#,##0;-#,##0")
End Function

Public Sub ReflowDashboardApp()
    Dim ws As Worksheet, w As Single, cols As Long, gap As Single, cardW As Single, x As Single, y As Single, i As Long, shp As Shape
    Dim rowStart As Long, rowEnd As Long, rowHeight As Single, requiredHeight As Single
    Dim failureNumber As Long, failureDescription As String
    On Error GoTo LayoutFailed
    Set ws = Dash
    ws.Unprotect
    CaptureDashboardCanvas False
    w = CSng(Cfg(16, "980"))
    mCanvasLeft = CSng(Cfg(17, "0"))
    mCanvasTop = CSng(Cfg(18, "0"))
    cols = 4
    gap = 12: cardW = (w - gap * (cols + 1)) / cols
    With ws.shapes("DashApp_Header"): .Width = w: .Height = 112: .Left = mCanvasLeft: .Top = mCanvasTop: .Fill.Visible = msoTrue: .Fill.Solid: .Fill.ForeColor.RGB = ThemeColor(1): .line.Visible = msoFalse: End With
    ' Excel reverses the physical position of shapes on an RTL sheet: low Left is screen-right.
    With ws.shapes("DashApp_Title"): .Width = Application.Max(100, Application.Min(360, w - 490)): .Height = 44: .Left = mCanvasLeft + 20: .Top = mCanvasTop + 11: .Fill.Visible = msoFalse: .line.Visible = msoFalse: End With
    With ws.shapes("DashApp_Date"): .Width = w - 40: .Height = 40: .Left = mCanvasLeft + 20: .Top = mCanvasTop + 66: .Fill.Visible = msoFalse: .line.Visible = msoFalse: End With
    With ws.shapes("DashApp_Settings"): .Width = 160: .Height = 38: .Left = mCanvasLeft + w - 180: .Top = mCanvasTop + 24: .Fill.Visible = msoTrue: .Fill.Solid: .Fill.ForeColor.RGB = ThemeColor(2): .line.Visible = msoFalse: End With
    With ws.shapes("DashApp_Refresh"): .Width = 118: .Height = 38: .Left = mCanvasLeft + w - 312: .Top = mCanvasTop + 24: .Fill.Visible = msoTrue: .Fill.Solid: .Fill.ForeColor.RGB = ThemeColor(3): .line.Visible = msoFalse: End With
    With ws.shapes("DashApp_Privacy"): .Width = 130: .Height = 38: .Left = mCanvasLeft + w - 456: .Top = mCanvasTop + 24: .Fill.Visible = msoTrue: .Fill.Solid: .Fill.ForeColor.RGB = ThemeColor(2): .line.Visible = msoFalse: End With
    y = mCanvasTop + 136
    For rowStart = 1 To DashboardCardCount() Step cols
        rowEnd = Application.Min(DashboardCardCount(), rowStart + cols - 1)
        rowHeight = 142
        For i = rowStart To rowEnd
            Set shp = ws.shapes("DashApp_KPI" & i)
            x = mCanvasLeft + gap + (i - rowStart) * (cardW + gap)
            shp.Width = cardW: shp.Left = x: shp.Top = y
            requiredHeight = FitCardHeight(shp, 142, 19)
            If requiredHeight > rowHeight Then rowHeight = requiredHeight
            shp.Fill.Visible = msoTrue: shp.Fill.Solid: shp.Fill.ForeColor.RGB = RGB(255, 255, 255): shp.line.ForeColor.RGB = RGB(209, 220, 230): shp.line.Weight = 1
        Next i
        For i = rowStart To rowEnd
            ws.shapes("DashApp_KPI" & i).Height = rowHeight
        Next i
        y = y + rowHeight + 24
    Next rowStart
    If ws.shapes("DashApp_Advanced").Visible Then
        With ws.shapes("DashApp_Advanced"): .Width = w - gap * 2: .Height = 164: .Left = mCanvasLeft + gap: .Top = y: .Fill.Visible = msoTrue: .Fill.Solid: .Fill.ForeColor.RGB = RGB(235, 247, 249): .line.ForeColor.RGB = ThemeColor(2): .line.Weight = 0.75: .TextFrame2.VerticalAnchor = msoAnchorTop: End With
        requiredHeight = LayoutAdvancedCards(ws, w, y)
        ws.shapes("DashApp_Advanced").Height = requiredHeight
        y = y + requiredHeight + 24
    End If
    With ws.shapes("DashApp_Actions"): .Width = w: .Height = 2: .Left = mCanvasLeft: .Top = y: .Fill.ForeColor.RGB = RGB(220, 225, 230): .line.Visible = msoFalse: End With
    LayoutActionShapes ws, w, y + 18
    If mAutoFitPending Then FitDashboardViewport
    ProtectDashboard
    Exit Sub
LayoutFailed:
    failureNumber = Err.Number
    failureDescription = Err.description
    On Error Resume Next
    ProtectDashboard
    On Error GoTo 0
    Err.Raise failureNumber, "ReflowDashboardApp", failureDescription
End Sub

Private Sub CaptureDashboardCanvas(ByVal recapture As Boolean)
    Dim canvas As Range, canvasWidth As Single, canvasLeft As Single, canvasTop As Single
    If Not recapture And IsNumeric(Cfg(16)) Then
        If CSng(Cfg(16)) >= 650 Then Exit Sub
    End If
    canvasWidth = 980
    If Cfg(13, "AUTO") = "CUSTOM" And Cfg(12) <> "" Then
        Set canvas = Dash.Range(Cfg(12))
        canvasWidth = canvas.Width
        canvasLeft = canvas.Left
        canvasTop = canvas.Top
    Else
        canvasWidth = 1400
        mAutoFitPending = True
    End If
    Info.Cells(CFG_ROW + 16, CFG_COL).Value2 = canvasWidth
    Info.Cells(CFG_ROW + 17, CFG_COL).Value2 = canvasLeft
    Info.Cells(CFG_ROW + 18, CFG_COL).Value2 = canvasTop
End Sub

Public Sub AutoSizeDashboardApp()
    SetCfg 13, "AUTO"
    SetCfg 12, ""
    CaptureDashboardCanvas True
    RefreshDashboardApp
End Sub

Private Sub FitDashboardViewport()
    Dim viewport As Range, viewportWidth As Double, viewportHeight As Double
    Dim canvasHeight As Double, canvasWidth As Double, fitZoom As Long
    Dim iteration As Long, item As Shape
    mAutoFitPending = False
    Dash.Activate
    ActiveWindow.Zoom = 100
    ActiveWindow.ScrollRow = 1
    ActiveWindow.ScrollColumn = 1
    Set viewport = ActiveWindow.VisibleRange
    viewportWidth = viewport.Width - viewport.Columns(viewport.Columns.count).Width - 12
    viewportHeight = viewport.Height - viewport.rows(viewport.rows.count).Height - 12
    If viewportWidth <= 0 Or viewportHeight <= 0 Then Exit Sub
    For iteration = 1 To 4
        canvasHeight = 0
        For Each item In Dash.shapes
            If item.Visible Then canvasHeight = Application.Max(canvasHeight, item.Top + item.Height + 12)
        Next item
        canvasWidth = Application.Max(980, Application.Min(2600, canvasHeight * viewportWidth / viewportHeight))
        Info.Cells(CFG_ROW + 16, CFG_COL).Value2 = canvasWidth
        ReflowDashboardApp
    Next iteration
    canvasHeight = 0
    For Each item In Dash.shapes
        If item.Visible Then canvasHeight = Application.Max(canvasHeight, item.Top + item.Height + 12)
    Next item
    fitZoom = Int(100 * Application.Min(viewportWidth / canvasWidth, viewportHeight / canvasHeight))
    ActiveWindow.Zoom = Application.Max(10, Application.Min(400, fitZoom))
    ActiveWindow.ScrollRow = 1
    ActiveWindow.ScrollColumn = 1
End Sub

Private Function FitCardHeight(ByVal card As Shape, ByVal minimumHeight As Single, ByVal fontSize As Single) As Single
    Dim measuredHeight As Single
    With card.TextFrame2
        .AutoSize = msoAutoSizeNone
        .WordWrap = msoTrue
        .TextRange.Font.size = fontSize * DashboardTextScale()
        card.Height = 2000
        measuredHeight = .TextRange.BoundHeight + .MarginTop + .MarginBottom + 24
    End With
    FitCardHeight = Application.Max(minimumHeight, measuredHeight)
    card.Height = FitCardHeight
End Function

Private Function ThemeColor(ByVal which As Long) As Long
    Dim theme As String: theme = Cfg(6, "NAVY")
    Select Case theme
        Case "BLUE": ThemeColor = IIf(which = 1, RGB(25, 91, 150), IIf(which = 2, RGB(33, 150, 243), RGB(25, 118, 210)))
        Case "NAVY": ThemeColor = IIf(which = 1, RGB(19, 54, 82), IIf(which = 2, RGB(41, 102, 171), RGB(30, 80, 137)))
        Case "GREEN": ThemeColor = IIf(which = 1, RGB(26, 102, 83), IIf(which = 2, RGB(54, 143, 111), RGB(44, 124, 96)))
        Case "BLACK": ThemeColor = IIf(which = 1, RGB(32, 36, 40), IIf(which = 2, RGB(80, 88, 96), RGB(55, 61, 68)))
        Case "ORANGE": ThemeColor = IIf(which = 1, RGB(151, 69, 0), IIf(which = 2, RGB(239, 108, 0), RGB(198, 86, 0)))
        Case "PINK": ThemeColor = IIf(which = 1, RGB(136, 14, 79), IIf(which = 2, RGB(216, 27, 96), RGB(173, 20, 87)))
        Case "PURPLE": ThemeColor = IIf(which = 1, RGB(74, 20, 140), IIf(which = 2, RGB(123, 31, 162), RGB(96, 28, 135)))
        Case "GRAY": ThemeColor = IIf(which = 1, RGB(55, 63, 70), IIf(which = 2, RGB(104, 113, 122), RGB(79, 88, 97)))
        Case "RED": ThemeColor = IIf(which = 1, RGB(136, 20, 20), IIf(which = 2, RGB(198, 40, 40), RGB(165, 30, 30)))
        Case "YELLOW": ThemeColor = IIf(which = 1, RGB(124, 97, 0), IIf(which = 2, RGB(207, 158, 0), RGB(172, 128, 0)))
        Case "BROWN": ThemeColor = IIf(which = 1, RGB(91, 64, 55), IIf(which = 2, RGB(121, 85, 72), RGB(102, 72, 61)))
        Case Else: ThemeColor = IIf(which = 1, RGB(19, 54, 82), IIf(which = 2, RGB(41, 102, 171), RGB(30, 80, 137)))
    End Select
End Function

Private Sub LayoutActionShapes(ByVal ws As Worksheet, ByVal w As Single, ByVal topY As Single)
    Dim primary As Collection, secondary As Collection, admin As Collection, shp As Shape
    Dim action As String
    Set primary = New Collection: Set secondary = New Collection: Set admin = New Collection
    For Each shp In ws.shapes
        If Left$(shp.name, 8) <> "DashApp_" And shp.Type <> msoGroup Then
            action = ActionName(shp)
            If action = "increaseoneinformula" Or action = "reduceoneinformula" Then
                shp.Visible = msoFalse
                GoTo NextShape
            End If
            If Trim$(shp.TextFrame2.TextRange.text) = "" Then
                shp.Visible = msoFalse
                GoTo NextShape
            End If
            If InStr(1, shp.OnAction, "ExportSelectedComponents", vbTextCompare) > 0 Or InStr(1, shp.OnAction, "RunVBAUpdater", vbTextCompare) > 0 Then
                If InStr(1, shp.OnAction, "ExportSelectedComponents", vbTextCompare) > 0 And Cfg(11, "YES") <> "YES" Then
                    shp.Visible = msoFalse
                Else
                    LocalizeUtilityCaption shp
                    admin.Add shp
                End If
            Else
                If IsPrimaryAction(action) Then primary.Add shp Else secondary.Add shp
            End If
        End If
NextShape:
    Next shp
    Set primary = OrderedActionShapes(primary, "showvoroodfaktorform,showcheckform,showsoorathesabform,showpaschequeform,showdailysalesform,showvoroodbimeha")
    Set secondary = OrderedActionShapes(secondary, "showeslahfaktor,showfrmdashboardform,showfrmchequeedit,showfrmaccounting,showfrmpaymentlinksform")
    Set admin = OrderedActionShapes(admin, "runvbaupdateronline,exportselectedcomponents,runvbaupdater")
    topY = LayoutShapeGroup(ws, primary, w, topY, 3, 180, 76, True) + 18
    topY = LayoutShapeGroup(ws, secondary, w, topY, 5, 150, 52, False) + 16
    If Cfg(10, "YES") = "YES" Then
        ' When export is hidden, let the two update buttons share the entire last row equally.
        Call LayoutShapeGroup(ws, admin, w, topY, IIf(admin.count = 2, 2, 3), 140, 38, False)
    Else
        HideShapeGroup ws, admin
    End If
End Sub

Private Function ActionName(ByVal actionShape As Shape) As String
    Dim macroName As String
    macroName = Trim$(actionShape.OnAction)
    If InStrRev(macroName, "!") > 0 Then macroName = Mid$(macroName, InStrRev(macroName, "!") + 1)
    If InStrRev(macroName, ".") > 0 Then macroName = Mid$(macroName, InStrRev(macroName, ".") + 1)
    ActionName = LCase$(macroName)
End Function

Private Function IsPrimaryAction(ByVal macroName As String) As Boolean
    Select Case macroName
        Case "showvoroodfaktorform", "showcheckform", "showsoorathesabform", "showpaschequeform", "showdailysalesform", "showvoroodbimeha"
            IsPrimaryAction = True
    End Select
End Function

Private Function OrderedActionShapes(ByVal shapes As Collection, ByVal macroOrder As String) As Collection
    Dim result As New Collection, actionShape As Shape, existingShape As Shape
    Dim shapeKey As String, existingKey As String, position As Long, inserted As Boolean
    For Each actionShape In shapes
        shapeKey = ActionSortKey(actionShape, macroOrder)
        inserted = False
        For position = 1 To result.count
            Set existingShape = result(position)
            existingKey = ActionSortKey(existingShape, macroOrder)
            If StrComp(shapeKey, existingKey, vbTextCompare) < 0 Then
                result.Add actionShape, Before:=position
                inserted = True
                Exit For
            End If
        Next position
        If Not inserted Then result.Add actionShape
    Next actionShape
    Set OrderedActionShapes = result
End Function

Private Function ActionSortKey(ByVal actionShape As Shape, ByVal macroOrder As String) As String
    Dim actions() As String, position As Long, rank As Long, macroName As String
    actions = Split(macroOrder, ",")
    macroName = ActionName(actionShape)
    rank = 999
    For position = LBound(actions) To UBound(actions)
        If actions(position) = macroName Then
            rank = position
            Exit For
        End If
    Next position
    ActionSortKey = Format$(rank, "000") & "|" & macroName & "|" & actionShape.name
End Function

Private Sub LocalizeUtilityCaption(ByVal shp As Shape)
    If InStr(1, shp.OnAction, "RunVBAUpdaterOnline", vbTextCompare) > 0 Then shp.TextFrame2.TextRange.text = p("1570,1662,1583,1740,1578,32,1570,1606,1604,1575,1740,1606")
    If InStr(1, shp.OnAction, "RunVBAUpdater", vbTextCompare) > 0 And InStr(1, shp.OnAction, "Online", vbTextCompare) = 0 Then shp.TextFrame2.TextRange.text = p("1570,1662,1583,1740,1578,32,1570,1601,1604,1575,1740,1606")
    If InStr(1, shp.OnAction, "ExportSelectedComponents", vbTextCompare) > 0 Then shp.TextFrame2.TextRange.text = p("1582,1585,1608,1580,1740")
End Sub

Private Function LayoutAdvancedCards(ByVal ws As Worksheet, ByVal w As Single, ByVal topY As Single) As Single
    Dim gap As Single, cardW As Single, names As Variant, i As Long, shp As Shape
    Dim rowHeight As Single, requiredHeight As Single
    gap = 18: cardW = (w - 2 * gap - 36) / 3
    names = Array("DashApp_AdvSales", "DashApp_AdvCheque", "DashApp_AdvNet")
    rowHeight = 96
    For i = 0 To 2
        Set shp = ws.shapes(CStr(names(i)))
        With shp
            .Visible = msoTrue
            .Width = cardW: .Height = 96: .Left = mCanvasLeft + gap + i * (cardW + 18): .Top = topY + 48
            .Fill.Visible = msoTrue: .Fill.Solid
            .Fill.ForeColor.RGB = IIf(i = 2, RGB(232, 247, 238), RGB(255, 255, 255))
            .line.Visible = msoTrue: .line.ForeColor.RGB = RGB(208, 222, 229): .line.Weight = 0.75
            .Shadow.Visible = msoFalse
        End With
        requiredHeight = FitCardHeight(shp, 96, 17)
        If requiredHeight > rowHeight Then rowHeight = requiredHeight
    Next i
    For i = 0 To 2
        ws.shapes(CStr(names(i))).Height = rowHeight
    Next i
    LayoutAdvancedCards = rowHeight + 68
End Function

Private Function LayoutShapeGroup(ByVal ws As Worksheet, ByVal group As Collection, ByVal w As Single, ByVal topY As Single, ByVal perRow As Long, ByVal btnW As Single, ByVal btnH As Single, ByVal isPrimary As Boolean) As Single
    Dim i As Long, gap As Single, usableW As Single, actualW As Single, shp As Shape
    If group.count = 0 Then LayoutShapeGroup = topY: Exit Function
    gap = 12: usableW = w - 2 * gap
    actualW = (usableW - gap * (perRow - 1)) / perRow
    For i = 1 To group.count
        Set shp = group(i)
        With shp
            .Visible = msoTrue
            .Width = actualW: .Height = btnH
            .Left = mCanvasLeft + w - gap - actualW - (((i - 1) Mod perRow) * (actualW + gap))
            .Top = topY + Int((i - 1) / perRow) * (btnH + gap)
            .Fill.Visible = msoTrue
            .Fill.Solid
            .Shadow.Visible = msoFalse
            .line.Visible = msoTrue
            .line.Weight = 0.75
            If isPrimary Then
                .Fill.ForeColor.RGB = ThemeColor(2)
                .line.ForeColor.RGB = ThemeColor(2)
                SetShapeText shp, shp.TextFrame2.TextRange.text, 21, RGB(255, 255, 255), True
            Else
                .Fill.ForeColor.RGB = RGB(248, 250, 252)
                .line.ForeColor.RGB = RGB(218, 226, 234)
                SetShapeText shp, shp.TextFrame2.TextRange.text, IIf(btnH < 45, 14, 16), RGB(49, 61, 72), True
            End If
        End With
    Next i
    LayoutShapeGroup = topY + (Int((group.count - 1) / perRow) + 1) * (btnH + gap)
End Function

Private Sub HideShapeGroup(ByVal ws As Worksheet, ByVal group As Collection)
    Dim i As Long, shp As Shape
    For i = 1 To group.count
        Set shp = group(i)
        shp.Visible = msoFalse
    Next i
End Sub

Private Function ReadConfigValue(ByVal configName As String) As Long
    On Error Resume Next
    ReadConfigValue = CLng(Info.Range(configName).Value2)
    On Error GoTo 0
End Function

Private Function ValidMonthlySheet(ByVal ws As Worksheet) As Boolean
    Dim a() As String, s As String
    On Error Resume Next
    s = NormalizeDigits(Trim$(CStr(ws.Range("B1").Value2)))
    On Error GoTo 0
    a = Split(s, "/")
    If UBound(a) <> 1 Then Exit Function
    If Not IsNumeric(a(0)) Then Exit Function
    If Not IsNumeric(a(1)) Then Exit Function
    ' Dashboard intentionally uses recent operational history only: year 1403 onward.
    ValidMonthlySheet = (CLng(a(0)) >= 1403)
End Function

Private Function FindMonthSheet(ByVal ym As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ValidMonthlySheet(ws) Then If NormalizeDigits(Trim$(CStr(ws.Range("B1").Value2))) = ym Then Set FindMonthSheet = ws: Exit Function
    Next ws
End Function

Private Function NormalizeDigits(ByVal valueText As String) As String
    Dim i As Long
    For i = 0 To 9
        valueText = Replace(valueText, ChrW$(1776 + i), CStr(i))
        valueText = Replace(valueText, ChrW$(1632 + i), CStr(i))
    Next i
    NormalizeDigits = valueText
End Function

' Dashboard-local Persian-date helpers. Keeping these private makes this
' module portable: it does not require modAddNewYear or legacy date modules.
Private Function DashboardPersianMonthDays(ByVal pYear As Long, ByVal pMonth As Long) As Long
    If pMonth >= 1 And pMonth <= 6 Then
        DashboardPersianMonthDays = 31
    ElseIf pMonth >= 7 And pMonth <= 11 Then
        DashboardPersianMonthDays = 30
    ElseIf pMonth = 12 Then
        DashboardPersianMonthDays = IIf(((pYear - 1403) Mod 4 = 0), 30, 29)
    End If
End Function

Private Function DashboardGregorianToPersian(ByVal gDate As Date) As String
    Dim daysDiff As Long, pYear As Long, pMonth As Long, pDay As Long
    Dim daysInYear As Long, daysInMonth As Long
    ' 1403/01/01 was 20 March 2024. Using 21 March shifts every dashboard
    ' date one day backward and makes tomorrow's cheque card read the wrong day.
    Const REF_GREGORIAN As Date = #3/20/2024#

    daysDiff = CLng(gDate - REF_GREGORIAN)
    pYear = 1403

    If daysDiff < 0 Then
        Do
            pYear = pYear - 1
            daysInYear = IIf(((pYear - 1403) Mod 4 = 0), 366, 365)
            daysDiff = daysDiff + daysInYear
        Loop While daysDiff < 0
    Else
        Do
            daysInYear = IIf(((pYear - 1403) Mod 4 = 0), 366, 365)
            If daysDiff < daysInYear Then Exit Do
            daysDiff = daysDiff - daysInYear
            pYear = pYear + 1
        Loop
    End If

    For pMonth = 1 To 12
        daysInMonth = DashboardPersianMonthDays(pYear, pMonth)
        If daysDiff < daysInMonth Then Exit For
        daysDiff = daysDiff - daysInMonth
    Next pMonth

    pDay = daysDiff + 1
    DashboardGregorianToPersian = CStr(pYear) & "/" & Format$(pMonth, "00") & "/" & Format$(pDay, "00")
End Function

Private Sub CalculateMetrics()
    Dim numCheques As Long, numFactors As Long, totalCenters As Long, userCenters As Long, rowsPerDay As Long, blockRows As Long, lower As Long
    Dim stepName As String
    On Error GoTo MetricError
    Erase mValue
    Erase mDetail
    mSales30 = 0: mChecks30 = 0: mDirects30 = 0: mExpenses30 = 0: mFirstBusinessDay = ""
    stepName = "config"
    numCheques = ReadConfigValue("cfg_NumCheques"): numFactors = ReadConfigValue("cfg_NumFactors")
    totalCenters = ReadConfigValue("cfg_TotalCenters"): userCenters = ReadConfigValue("cfg_ActualUserCenters")
    If numCheques <= 0 Or numFactors <= 0 Or totalCenters <= 0 Then Exit Sub
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters): blockRows = rowsPerDay + 1: lower = rowsPerDay \ 2
    stepName = "open factors"
    mValue(1) = ScanOutstanding(False, 14 + numCheques * 2 + 1, numFactors, blockRows, lower)
    stepName = "open cheques"
    mValue(2) = ScanOutstanding(True, 14, numCheques, blockRows, lower)
    stepName = "last month sales"
    mValue(5) = LastMonthAverage(blockRows, userCenters)
    stepName = "future forecast"
    CalculateFuture blockRows, lower, numCheques, numFactors, totalCenters, userCenters
    CalculateStockKpis blockRows, lower, numCheques, numFactors, userCenters, totalCenters
    mValue(12) = mSales30: mValue(13) = mChecks30
    mValue(14) = 0
    If mChecks30 + mExpenses30 > 0 Then mValue(14) = mSales30 / (mChecks30 + mExpenses30) * 100
    mValue(15) = mExpenses30
    mDetail(14) = p("1601,1585,1608,1588,58,32") & Format$(mSales30, "#,##0") & vbCrLf & p("1578,1593,1607,1583,1575,1578,58,32") & Format$(mChecks30 + mExpenses30, "#,##0")
    mDetail(1) = ""
    mDetail(2) = ""
    mDetail(5) = ""
    Info.Cells(CFG_ROW + 20, CFG_COL).value = "OK"
    Exit Sub
MetricError:
    Info.Cells(CFG_ROW + 20, CFG_COL).value = stepName & " | " & Err.Number & " | " & Err.description
End Sub

Private Function ScanOutstanding(ByVal isCheque As Boolean, ByVal firstCol As Long, ByVal count As Long, ByVal blockRows As Long, ByVal lower As Long) As Double
    Dim ws As Worksheet, d As Long, r As Long, c As Long, lastRow As Long
    For Each ws In ThisWorkbook.Worksheets
        If ValidMonthlySheet(ws) Then
            lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
            For d = 1 To 31
                r = 2 + (d - 1) * blockRows
                If r + lower > lastRow Then Exit For
                If Len(Trim$(CStr(ws.Cells(r, 1).Value2))) = 0 Then Exit For
                For c = firstCol To firstCol + count * 2 - 2 Step 2
                    If Trim$(CStr(ws.Cells(r, c).Value2)) <> "" And Trim$(CStr(ws.Cells(r, c + 1).Value2)) = "" Then
                        If IsNumeric(ws.Cells(r + lower, c).Value2) Then ScanOutstanding = ScanOutstanding + CDbl(ws.Cells(r + lower, c).Value2)
                    End If
                Next c
            Next d
        End If
    Next ws
End Function

Private Function LastMonthAverage(ByVal blockRows As Long, ByVal userCenters As Long) As Double
    Dim jd As String, a() As String, y As Long, m As Long, ws As Worksheet, vals As Variant, d As Long, r As Long, cr As Long, daily As Double, total As Double, monthDays As Long
    jd = DashboardGregorianToPersian(Date): a = Split(jd, "/"): y = CLng(a(0)): m = CLng(a(1)) - 1
    If m = 0 Then m = 12: y = y - 1
    Set ws = FindMonthSheet(y & "/" & Format$(m, "00"))
    If ws Is Nothing Then Exit Function
    monthDays = DashboardPersianMonthDays(y, m)
    If monthDays <= 0 Then Exit Function
    vals = ws.UsedRange.Value2
    For d = 1 To monthDays
        r = 2 + (d - 1) * blockRows: If r > UBound(vals, 1) Then Exit For
        daily = 0
        If r + IIf(userCenters = 1, 0, userCenters - 1) <= UBound(vals, 1) Then
            For cr = 0 To IIf(userCenters = 1, 0, userCenters - 1)
                If IsNumeric(vals(r + cr, 3)) Then daily = daily + CDbl(vals(r + cr, 3))
                If IsNumeric(vals(r + cr, 4)) Then daily = daily + CDbl(vals(r + cr, 4))
            Next cr
        End If
        total = total + daily
    Next d
    LastMonthAverage = total / monthDays
End Function

Private Sub CalculateFuture(ByVal blockRows As Long, ByVal lower As Long, ByVal nCheque As Long, ByVal nFactor As Long, ByVal totalCenters As Long, ByVal userCenters As Long)
    Dim i As Long, jd As String, checks As Double, directs As Double, expenses As Double, sales As Double, firstDone As Boolean
    Dim part() As String, offset As Long, stageName As String
    Dim mth(1 To 3) As Double
    On Error GoTo FutureError
    ' 92 days covers the rest of the current Persian month plus two full following Persian months.
    For i = 1 To 92
        jd = DashboardGregorianToPersian(Date + i)
        checks = DayChequeTotal(jd, blockRows, lower, nCheque)
        directs = DayDirectTotal(jd, blockRows, lower, nCheque, nFactor)
        expenses = DayExpenseTotal(jd)
        If IsHoliday(jd) Then sales = IIf(Cfg(7, "ZERO") = "PCT", mValue(5) * val(Cfg(8, "30")) / 100, 0) Else sales = mValue(5)
        If i <= 30 Then
            mSales30 = mSales30 + sales
            mChecks30 = mChecks30 + checks
            mDirects30 = mDirects30 + directs
            mExpenses30 = mExpenses30 + expenses
            mValue(7) = mValue(7) + sales - checks - directs - expenses
        End If
        If i <= 7 Then mValue(6) = mValue(6) + checks
        If Not firstDone And Not IsHoliday(jd) Then
            mValue(4) = NextWorkingDayChequeTotal(Date + i, blockRows, lower, nCheque)
            mFirstBusinessDay = jd
            firstDone = True
        End If
        part = Split(jd, "/")
        offset = MonthOffset(CLng(part(0)), CLng(part(1)))
        If offset >= 1 And offset <= 3 Then mth(offset) = mth(offset) + checks
    Next i
    stageName = "three-month total"
    mValue(3) = mth(1) + mth(2) + mth(3)
    stageName = "month detail"
    mDetail(3) = UpcomingMonthName(0) & ": " & amountText(mth(1)) & vbCrLf & _
                 UpcomingMonthName(1) & ": " & amountText(mth(2)) & vbCrLf & _
                 UpcomingMonthName(2) & ": " & amountText(mth(3))
    If mFirstBusinessDay <> "" Then mDetail(4) = p("1578,1575,1585,1740,1582,32,1587,1585,1585,1587,1740,1583,58") & " " & mFirstBusinessDay
    mDetail(6) = ""
    mDetail(7) = ""
    Exit Sub
FutureError:
    Err.Raise vbObjectError + 513, "CalculateFuture", "Day " & CStr(i) & " (" & jd & ") / " & stageName & ": " & Err.description
End Sub

Private Function amountText(ByVal amount As Double) As String
    On Error GoTo Fallback
    amountText = Application.WorksheetFunction.text(amount, "#,##0")
    Exit Function
Fallback:
    amountText = CStr(CDec(amount))
End Function

Private Function UpcomingMonthName(ByVal offset As Long) As String
    Dim p() As String, m As Long
    p = Split(DashboardGregorianToPersian(Date), "/")
    m = CLng(p(1)) + offset
    Do While m > 12: m = m - 12: Loop
    UpcomingMonthName = PersianMonthName(m)
End Function

Private Function PersianMonthName(ByVal m As Long) As String
    Select Case m
        Case 1: PersianMonthName = p("1601,1585,1608,1585,1583,1740,1606")
        Case 2: PersianMonthName = p("1575,1585,1583,1740,1576,1607,1588,1578")
        Case 3: PersianMonthName = p("1582,1585,1583,1575,1583")
        Case 4: PersianMonthName = p("1578,1740,1585")
        Case 5: PersianMonthName = p("1605,1585,1583,1575,1583")
        Case 6: PersianMonthName = p("1588,1607,1585,1740,1608,1585")
        Case 7: PersianMonthName = p("1605,1607,1585")
        Case 8: PersianMonthName = p("1570,1576,1575,1606")
        Case 9: PersianMonthName = p("1570,1584,1585")
        Case 10: PersianMonthName = p("1583,1740")
        Case 11: PersianMonthName = p("1576,1607,1605,1606")
        Case 12: PersianMonthName = p("1575,1587,1601,1606,1583")
    End Select
End Function

Private Function MonthOffset(ByVal y As Long, ByVal m As Long) As Long
    Dim nowJ As Variant, a() As String, ny As Long, nm As Long
    nowJ = DashboardGregorianToPersian(Date): a = Split(CStr(nowJ), "/"): ny = CLng(a(0)): nm = CLng(a(1))
    MonthOffset = (y - ny) * 12 + (m - nm) + 1
End Function

Private Function DayChequeTotal(ByVal jd As String, ByVal blockRows As Long, ByVal lower As Long, ByVal nCheque As Long) As Double
    Dim p() As String, ws As Worksheet, r As Long, c As Long
    p = Split(jd, "/"): Set ws = FindMonthSheet(p(0) & "/" & p(1)): If ws Is Nothing Then Exit Function
    r = 2 + (CLng(p(2)) - 1) * blockRows
    For c = 14 To 14 + nCheque * 2 - 2 Step 2
        If Trim$(CStr(ws.Cells(r, c).Value2)) <> "" And Trim$(CStr(ws.Cells(r, c + 1).Value2)) = "" Then If IsNumeric(ws.Cells(r + lower, c).Value2) Then DayChequeTotal = DayChequeTotal + CDbl(ws.Cells(r + lower, c).Value2)
    Next c
End Function

Private Function NextWorkingDayChequeTotal(ByVal targetDate As Date, ByVal blockRows As Long, ByVal lower As Long, ByVal numCheques As Long) As Double
    Dim dayOffset As Long, dateParts() As String, monthlySheet As Worksheet
    Dim chequeRow As Long, chequeColumn As Long, clearedLabel As String
    clearedLabel = Trim$(CStr(Info.Range("C1").Value2))
    If clearedLabel = "" Then Err.Raise vbObjectError + 514, "NextWorkingDayChequeTotal", "Missing cleared-cheque status in information sheet C1"
    For dayOffset = -15 To 0
        dateParts = Split(DashboardGregorianToPersian(targetDate + dayOffset), "/")
        Set monthlySheet = FindMonthSheet(dateParts(0) & "/" & dateParts(1))
        If Not monthlySheet Is Nothing Then
            chequeRow = 2 + (CLng(dateParts(2)) - 1) * blockRows
            For chequeColumn = 14 To 14 + numCheques * 2 - 2 Step 2
                If Trim$(CStr(monthlySheet.Cells(chequeRow, chequeColumn).Value2)) <> "" And _
                    Trim$(CStr(monthlySheet.Cells(chequeRow, chequeColumn + 1).Value2)) <> clearedLabel Then
                    If IsNumeric(monthlySheet.Cells(chequeRow + lower, chequeColumn).Value2) Then
                        NextWorkingDayChequeTotal = NextWorkingDayChequeTotal + CDbl(monthlySheet.Cells(chequeRow + lower, chequeColumn).Value2)
                    End If
                End If
            Next chequeColumn
        End If
    Next dayOffset
End Function

Private Function DayDirectTotal(ByVal jd As String, ByVal blockRows As Long, ByVal lower As Long, ByVal nCheque As Long, ByVal nFactor As Long) As Double
    Dim p() As String, ws As Worksheet, r As Long, c As Long, firstCol As Long, nDirect As Long
    nDirect = ReadConfigValue("cfg_NumDirectPays"): If nDirect <= 0 Then Exit Function
    p = Split(jd, "/"): Set ws = FindMonthSheet(p(0) & "/" & p(1)): If ws Is Nothing Then Exit Function
    r = 2 + (CLng(p(2)) - 1) * blockRows: firstCol = 14 + nCheque * 2 + 1 + nFactor * 2 + 1
    For c = firstCol To firstCol + nDirect - 1
        If Trim$(CStr(ws.Cells(r, c).Value2)) <> "" Then If IsNumeric(ws.Cells(r + lower, c).Value2) Then DayDirectTotal = DayDirectTotal + CDbl(ws.Cells(r + lower, c).Value2)
    Next c
End Function

Private Function DayExpenseTotal(ByVal jd As String) As Double
    Dim r As Long, amountText As String, dueText As String
    For r = 7 To 19 Step 2
        amountText = Replace(CStr(Info.Cells(r, 29).Value2), ",", "")
        dueText = Trim$(CStr(Info.Cells(r + 1, 29).Value2))
        If IsNumeric(amountText) Then If DueMatches(dueText, jd) Then DayExpenseTotal = DayExpenseTotal + CDbl(amountText)
    Next r
End Function

Private Function DueMatches(ByVal dueText As String, ByVal jd As String) As Boolean
    Dim a() As String, b() As String
    dueText = Replace(dueText, "-", "/"): a = Split(dueText, "/"): b = Split(jd, "/")
    If UBound(a) = 2 Then DueMatches = (val(a(2)) = val(b(2))) Else DueMatches = (val(dueText) = val(b(2)))
End Function

Private Function IsHoliday(ByVal jd As String) As Boolean
    Dim lastRow As Long, vals As Variant, i As Long
    ' S contains the holiday marker (*) and U contains the corresponding Persian date.
    lastRow = Info.Cells(Info.rows.count, 21).End(xlUp).Row
    If lastRow < 1 Then Exit Function
    vals = Info.Range(Info.Cells(1, 19), Info.Cells(lastRow, 21)).Value2
    For i = 1 To UBound(vals, 1)
        If Trim$(CStr(vals(i, 1))) = "*" And NormalizeDigits(Trim$(CStr(vals(i, 3)))) = jd Then IsHoliday = True: Exit Function
    Next i
End Function

Public Function DashboardDateTest() As String
    DashboardDateTest = DashboardGregorianToPersian(Date)
End Function

Public Function DashboardTodayTest() As String
    DashboardTodayTest = DashboardTodayText()
End Function


Private Function StockKpiTitle(ByVal id As Long) As String
    Dim title As String
    title = p("1578,1594,1740,1740,1585,32,1576,1585,1570,1608,1585,1583,1740,32,1605,1608,1580,1608,1583,1740,32,8212,32")
    Select Case id
        Case 8: title = title & p("1605,1575,1607,32,1580,1575,1585,1740")
        Case 9: title = title & p("1605,1575,1607,32,1602,1576,1604")
        Case 10: title = title & p("1587,1607,32,1605,1575,1607,32,1575,1582,1740,1585")
        Case 11: title = title & p("1705,1604,32,1587,1575,1604,32,1602,1576,1604")
    End Select
    StockKpiTitle = title
End Function

Private Function DashboardKpiMenu() As String
    Dim i As Long
    For i = 1 To 15
        DashboardKpiMenu = DashboardKpiMenu & i & " - " & KpiTitle(i) & vbCrLf
    Next i
End Function

Private Function StockNumber(ByVal v As Variant) As Double
    If IsError(v) Or IsEmpty(v) Then Exit Function
    If IsNumeric(v) Then StockNumber = CDbl(v)
End Function

Private Sub CalculateStockKpis(ByVal blockRows As Long, ByVal lower As Long, ByVal nCheque As Long, ByVal nFactor As Long, ByVal userCenters As Long, ByVal totalCenters As Long)
    Dim parts() As String, y As Long, m As Long, ym As Long, offset As Long
    Dim yearNo As Long, monthNo As Long, ws As Worksheet, vals As Variant
    Dim d As Long, r As Long, c As Long, center As Long, firstCol As Long
    Dim bought As Double, sold As Double, purchases(0 To 14) As Double, sales(0 To 14) As Double
    Dim exists(0 To 14) As Boolean, funds As Collection, fund As Variant
    Dim i As Long, j As Long, startOffset As Long, endOffset As Long, missing As String, validDay As Boolean
    parts = Split(DashboardGregorianToPersian(Date), "/")
    y = CLng(parts(0)): m = CLng(parts(1))
    firstCol = 14 + nCheque * 2 + 1
    Set funds = InsuranceFundItems(userCenters, totalCenters)
    For offset = 0 To 14
        If offset <= 2 Then
            ym = y * 12 + m - 1 - offset
            yearNo = ym \ 12: monthNo = ym Mod 12 + 1
        Else
            yearNo = y - 1: monthNo = offset - 2
        End If
        Set ws = FindMonthSheet(yearNo & "/" & Format$(monthNo, "00"))
        If Not ws Is Nothing Then
            exists(offset) = True
            vals = ws.Range(ws.Cells(1, 1), ws.Cells(2 + 31 * blockRows, firstCol + nFactor * 2 - 1)).Value2
            For d = 1 To DashboardPersianMonthDays(yearNo, monthNo)
                validDay = True
                If yearNo = y And monthNo = m Then validDay = (d <= CLng(parts(2)))
                If validDay Then
                    r = 2 + (d - 1) * blockRows
                    If StockNumber(vals(r, 1)) = d Then
                        For center = 0 To userCenters - 1
                            sales(offset) = sales(offset) + StockNumber(vals(r + center, 3)) + StockNumber(vals(r + center, 4))
                        Next center
                        For c = firstCol To firstCol + nFactor * 2 - 2 Step 2
                            If Not IsError(vals(r, c)) Then
                                If Len(Trim$(CStr(vals(r, c)))) > 0 Then purchases(offset) = purchases(offset) + StockNumber(vals(r + lower, c))
                            End If
                        Next c
                    End If
                End If
            Next d
            For Each fund In funds
                sales(offset) = sales(offset) + StockNumber(ws.Cells(CLng(fund("Row")), 3).Value2)
            Next fund
        End If
    Next offset
    For i = 8 To 11
        Select Case i
            Case 8: startOffset = 0: endOffset = 0
            Case 9: startOffset = 1: endOffset = 1
            Case 10: startOffset = 0: endOffset = 2
            Case 11: startOffset = 3: endOffset = 14
        End Select
        bought = 0: sold = 0: missing = ""
        For j = startOffset To endOffset
            bought = bought + purchases(j): sold = sold + sales(j)
            If Not exists(j) Then missing = missing & " *"
        Next j
        mValue(i) = bought - sold
        mDetail(i) = p("1582,1585,1740,1583,58,32") & Format$(bought, "#,##0") & vbCrLf & p("1601,1585,1608,1588,32,1576,1575,32,1576,1740,1605,1607,58,32") & Format$(sold, "#,##0")
        If missing <> "" Then mDetail(i) = mDetail(i) & vbCrLf & p("1607,1588,1583,1575,1585,58,32,1576,1585,1582,1740,32,1605,1575,1607,32,1607,1575,32,1605,1608,1580,1608,1583,32,1606,1740,1587,1578")
    Next i
End Sub


Private Function DashboardCardCount() As Long
    DashboardCardCount = 4
    If Cfg(30, "4") = "8" Then DashboardCardCount = 8
End Function

Private Function DashboardCardId(ByVal slot As Long) As Long
    Dim defaults As Variant
    defaults = Array(1, 2, 6, 7, 12, 13, 14, 15)
    If slot <= 4 Then
        DashboardCardId = CLng(Cfg(slot, CStr(defaults(slot - 1))))
    Else
        DashboardCardId = CLng(Cfg(26 + slot, CStr(defaults(slot - 1))))
    End If
End Function

Private Function DashboardSelectionDefault(ByVal count As Long) As String
    Dim i As Long, id As Long, used As Object, candidate As Long
    Set used = CreateObject("Scripting.Dictionary")
    For i = 1 To count
        id = DashboardCardId(i)
        If used.exists(CStr(id)) Then
            For candidate = 1 To 15
                If Not used.exists(CStr(candidate)) Then id = candidate: Exit For
            Next candidate
        End If
        used.Add CStr(id), True
        If i > 1 Then DashboardSelectionDefault = DashboardSelectionDefault & ","
        DashboardSelectionDefault = DashboardSelectionDefault & id
    Next i
End Function

Private Function DashboardForecastTitle(ByVal id As Long) As String
    Select Case id
        Case 12: DashboardForecastTitle = p("1601,1585,1608,1588,32,1662,1740,1588,32,1576,1740,1606,1740,32,1588,1583,1607,32,1587,1740,32,1585,1608,1586,32,1570,1740,1606,1583,1607")
        Case 13: DashboardForecastTitle = p("1670,1705,32,1607,1575,1740,32,1587,1740,32,1585,1608,1586,32,1570,1740,1606,1583,1607")
        Case 14: DashboardForecastTitle = p("1662,1608,1588,1588,32,1601,1585,1608,1588,32,1606,1587,1576,1578,32,1576,1607,32,1578,1593,1607,1583,1575,1578,32,1587,1740,32,1585,1608,1586,32,1570,1740,1606,1583,1607")
        Case 15: DashboardForecastTitle = p("1607,1586,1740,1606,1607,32,1607,1575,1740,32,1587,1740,32,1585,1608,1586,32,1570,1740,1606,1583,1607")
    End Select
End Function


Private Function DashboardCoverageText() As String
    If mChecks30 + mExpenses30 <= 0 Then
        DashboardCoverageText = p("1576,1583,1608,1606,32,1578,1593,1607,1583")
    Else
        DashboardCoverageText = ChrW(8206) & Format$(mValue(14), "0.0") & "%" & ChrW(8206)
    End If
End Function

Public Sub ToggleDashboardPrivacy()
    Dim previousUpdating As Boolean, previousFlag As String, failure As String
    previousUpdating = Application.ScreenUpdating
    previousFlag = Cfg(35, "SHOW")
    On Error GoTo PrivacyFailed
    Application.ScreenUpdating = False
    If previousFlag = "HIDE" Then SetCfg 35, "SHOW" Else SetCfg 35, "HIDE"
    RefreshDashboardApp
PrivacyExit:
    Application.ScreenUpdating = previousUpdating
    If failure <> "" Then MsgBox failure, vbExclamation
    Exit Sub
PrivacyFailed:
    failure = Err.description
    On Error Resume Next
    SetCfg 35, previousFlag
    ProtectDashboard
    On Error GoTo 0
    GoTo PrivacyExit
End Sub

Private Sub ApplyDashboardPrivacy()
    Dim ws As Worksheet, i As Long, hidden As Boolean, names As Variant, name As Variant
    Dim shp As Shape, title As String, text As String, breakAt As Long, mask As String
    Set ws = Dash
    hidden = (Cfg(35, "SHOW") = "HIDE")
    mask = ChrW(8226) & ChrW(8226) & ChrW(8226) & ChrW(8226)
    title = p("1662,1606,1607,1575,1606,32,1705,1585,1583,1606,32,1605,1576,1575,1604,1594")
    If hidden Then title = p("1606,1605,1575,1740,1588,32,1605,1576,1575,1604,1594")
    SetShapeText ws.shapes("DashApp_Privacy"), title, 12, vbWhite, True
    ws.shapes("DashApp_Privacy").OnAction = "ToggleDashboardPrivacy"
    If Not hidden Then Exit Sub
    For i = 1 To 8
        Set shp = ws.shapes("DashApp_KPI" & i)
        SetShapeText shp, KpiTitle(DashboardCardId(i)) & vbCrLf & vbCrLf & mask, 19, RGB(37, 49, 62), True
    Next i
    names = Array("DashApp_AdvSales", "DashApp_AdvCheque", "DashApp_AdvNet")
    For Each name In names
        Set shp = ws.shapes(CStr(name))
        text = shp.TextFrame2.TextRange.text
        breakAt = InStr(text, vbCr)
        If breakAt = 0 Then breakAt = InStr(text, vbLf)
        If breakAt > 0 Then text = Left$(text, breakAt - 1)
        SetShapeText shp, text & vbCrLf & mask, 17, RGB(37, 49, 62), True
    Next name
End Sub



