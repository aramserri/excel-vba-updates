Attribute VB_Name = "modWorkbookPassword"
Option Explicit

Public Function WPText(ByVal codes As String) As String
    Dim item As Variant
    For Each item In Split(codes, ",")
        WPText = WPText & ChrW(CLng(item))
    Next item
End Function

Private Function WPInfo() As Worksheet
    Set WPInfo = ThisWorkbook.Worksheets(WPText("1575,1591,1604,1575,1593,1575,1578"))
End Function

Private Function WPVerifyOldPassword(ByVal suppliedPassword As String) As Boolean
    Dim verifier As Object, checkBook As Object
    On Error GoTo CleanUp
    Set verifier = CreateObject("Excel.Application")
    verifier.Visible = False
    verifier.DisplayAlerts = False
    verifier.EnableEvents = False
    verifier.AutomationSecurity = 3
    Set checkBook = verifier.Workbooks.Open(fileName:=ThisWorkbook.FullName, _
        UpdateLinks:=0, ReadOnly:=True, Password:=suppliedPassword, _
        WriteResPassword:="", IgnoreReadOnlyRecommended:=True, AddToMru:=False, Notify:=False)
    WPVerifyOldPassword = Not checkBook Is Nothing
CleanUp:
    On Error Resume Next
    If Not checkBook Is Nothing Then checkBook.Close False
    If Not verifier Is Nothing Then verifier.Quit
    Set checkBook = Nothing
    Set verifier = Nothing
    On Error GoTo 0
End Function

' False means cancel the whole dashboard settings process.
Public Function ConfigureWorkbookOpeningPassword() As Boolean
    Dim protected As Boolean, response As VbMsgBoxResult, removing As Boolean
    Dim dlg As frmWorkbookPasswordSetup, hintCell As Range
    Dim oldHint As Variant, oldPassword As String, newPassword As String
    Dim backupPath As String, passwordAssigned As Boolean, saved As Boolean, writeStarted As Boolean
    Dim previousEvents As Boolean, errorText As String
    On Error GoTo Failed
    previousEvents = Application.EnableEvents
    protected = ThisWorkbook.HasPassword
    If protected Then
        response = MsgBox(WPText("1608,1590,1593,1740,1578,32,1601,1575,1740,1604,58,32,1583,1575,1585,1575,1740,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604") & vbCrLf & _
            WPText("1570,1740,1575,32,1605,1740,8204,1582,1608,1575,1607,1740,1583,32,1585,1605,1586,32,1585,1575,32,1578,1594,1740,1740,1585,32,1583,1607,1740,1583,1567"), vbYesNoCancel + vbQuestion + vbDefaultButton2, WPText("1575,1605,1606,1740,1578,32,1601,1575,1740,1604"))
    Else
        response = MsgBox(WPText("1608,1590,1593,1740,1578,32,1601,1575,1740,1604,58,32,1576,1583,1608,1606,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604") & vbCrLf & _
            WPText("1570,1740,1575,32,1605,1740,8204,1582,1608,1575,1607,1740,1583,32,1576,1585,1575,1740,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604,32,1585,1605,1586,32,1578,1593,1740,1740,1606,32,1705,1606,1740,1583,1567"), vbYesNoCancel + vbQuestion + vbDefaultButton2, WPText("1575,1605,1606,1740,1578,32,1601,1575,1740,1604"))
    End If
    If response = vbCancel Then Exit Function
    If protected And response = vbNo Then
        response = MsgBox(WPText("1570,1740,1575,32,1605,1740,8204,1582,1608,1575,1607,1740,1583,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604,32,1585,1575,32,1581,1584,1601,32,1705,1606,1740,1583,1567"), _
            vbYesNoCancel + vbQuestion + vbDefaultButton2, WPText("1581,1584,1601,32,1585,1605,1586,32,1601,1575,1740,1604"))
        If response = vbCancel Then Exit Function
        removing = (response = vbYes)
    End If
    If response = vbNo Then
        ConfigureWorkbookOpeningPassword = True
        Exit Function
    End If
    If ThisWorkbook.ReadOnly Or Len(ThisWorkbook.path) = 0 Then
        MsgBox WPText("1601,1575,1740,1604,32,1576,1575,1740,1583,32,1602,1576,1604,1575,1611,32,1584,1582,1740,1585,1607,32,1588,1583,1607,32,1608,32,1602,1575,1576,1604,32,1606,1608,1588,1578,1606,32,1576,1575,1588,1583,46"), vbExclamation
        Exit Function
    End If
    Set hintCell = WPInfo.Range("J4")
    oldHint = hintCell.Formula
    Set dlg = New frmWorkbookPasswordSetup
    dlg.Configure protected, CStr(hintCell.Value2), removing
    Do
        dlg.Accepted = False
        dlg.Show vbModal
        If Not dlg.Accepted Then GoTo CleanUp
        oldPassword = CStr(dlg.txtOld.value)
        If removing Then newPassword = "" Else newPassword = CStr(dlg.txtNew.value)
        If Not protected Then Exit Do
        If WPVerifyOldPassword(oldPassword) Then Exit Do
        MsgBox WPText("1585,1605,1586,32,1601,1593,1604,1740,32,1578,1571,1740,1740,1583,32,1606,1588,1583,46,32,1585,1605,1586,32,1740,1575,32,1583,1587,1578,1585,1587,1740,32,1576,1607,32,1601,1575,1740,1604,32,1585,1575,32,1576,1585,1585,1587,1740,32,1705,1606,1740,1583,46"), vbExclamation
        dlg.txtOld.value = ""
    Loop
    backupPath = ThisWorkbook.path & Application.PathSeparator & _
        Left$(ThisWorkbook.name, InStrRev(ThisWorkbook.name, ".") - 1) & _
        "_before_password_" & Format$(Now, "yyyymmdd_hhnnss") & ".xlsm"
    If Len(Dir$(backupPath)) > 0 Then
        Err.Raise vbObjectError + 2201, , "Backup path already exists. Please retry."
    End If
    If removing Then
        response = MsgBox(WPText("1662,1587,32,1575,1586,32,1584,1582,1740,1585,1607,1548,32,1601,1575,1740,1604,32,1576,1583,1608,1606,32,1585,1605,1586,32,1576,1575,1586,32,1605,1740,8204,1588,1608,1583,32,1608,32,1585,1575,1607,1606,1605,1575,1740,32,1585,1605,1586,32,1662,1575,1705,32,1582,1608,1575,1607,1583,32,1588,1583,46,32,1570,1740,1575,32,1575,1586,32,1581,1584,1601,32,1585,1605,1586,32,1605,1591,1605,1574,1606,32,1607,1587,1578,1740,1583,1567"), _
            vbYesNo + vbExclamation + vbDefaultButton2, WPText("1578,1571,1740,1740,1583,32,1581,1584,1601,32,1585,1605,1586"))
        If response <> vbYes Then GoTo CleanUp
    End If
    response = MsgBox(WPText("1575,1740,1606,32,1705,1575,1585,32,1578,1605,1575,1605,32,1578,1594,1740,1740,1585,1575,1578,32,1601,1593,1604,1740,32,1601,1575,1740,1604,32,1585,1575,32,1584,1582,1740,1585,1607,32,1605,1740,8204,1705,1606,1583,46") & vbCrLf & _
        WPText("1606,1587,1582,1607,32,1662,1588,1578,1740,1576,1575,1606,32,1576,1575,32,1608,1590,1593,1740,1578,32,1585,1605,1586,32,1602,1576,1604,1740,32,1606,1711,1607,1583,1575,1585,1740,32,1605,1740,8204,1588,1608,1583,1563,32,1575,1711,1585,32,1601,1575,1740,1604,32,1576,1583,1608,1606,32,1585,1605,1586,32,1575,1587,1578,1548,32,1662,1588,1578,1740,1576,1575,1606,32,1607,1605,32,1576,1583,1608,1606,32,1585,1605,1586,32,1582,1608,1575,1607,1583,32,1576,1608,1583,46") & vbCrLf & _
        WPText("1585,1605,1586,32,1601,1585,1575,1605,1608,1588,8204,1588,1583,1607,32,1602,1575,1576,1604,32,1576,1575,1586,1740,1575,1576,1740,32,1606,1740,1587,1578,46,32,1585,1575,1607,1606,1605,1575,32,1601,1602,1591,32,1662,1587,32,1575,1586,32,1576,1575,1586,32,1588,1583,1606,32,1601,1575,1740,1604,32,1583,1585,32,1583,1587,1578,1585,1587,32,1575,1587,1578,46") & vbCrLf & _
        WPText("1570,1740,1575,32,1575,1583,1575,1605,1607,32,1605,1740,8204,1583,1607,1740,1583,1567"), vbYesNo + vbExclamation + vbDefaultButton2, WPText("1578,1571,1740,1740,1583,32,1584,1582,1740,1585,1607,32,1585,1605,1586"))
    If response <> vbYes Then GoTo CleanUp
    ' Finish layout before saving; no further cancellable settings follow this call.
    RefreshDashboardApp
    ThisWorkbook.SaveCopyAs backupPath
    Application.EnableEvents = False
    writeStarted = True
    If removing Then hintCell.ClearContents Else hintCell.Value2 = CStr(dlg.txtHint.value)
    ThisWorkbook.Password = newPassword
    passwordAssigned = True
    ThisWorkbook.Save
    saved = True
    If ThisWorkbook.HasPassword <> (Not removing) Then Err.Raise vbObjectError + 2202, , "Password status was not retained."
    ConfigureWorkbookOpeningPassword = True
    If removing Then
        MsgBox WPText("1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604,32,1581,1584,1601,32,1588,1583,32,1608,32,1585,1575,1607,1606,1605,1575,1740,32,1585,1605,1586,32,1662,1575,1705,32,1588,1583,46") & vbCrLf & _
            WPText("1606,1587,1582,1607,32,1662,1588,1578,1740,1576,1575,1606,32,1607,1605,1670,1606,1575,1606,32,1585,1605,1586,32,1602,1576,1604,1740,32,1585,1575,32,1583,1575,1585,1583,58") & vbCrLf & backupPath, vbInformation
    Else
        MsgBox WPText("1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604,32,1608,32,1585,1575,1607,1606,1605,1575,32,1584,1582,1740,1585,1607,32,1588,1583,1606,1583,46") & vbCrLf & _
        WPText("1662,1588,1578,1740,1576,1575,1606,32,1576,1575,32,1608,1590,1593,1740,1578,32,1602,1576,1604,1740,58") & vbCrLf & backupPath, vbInformation
    End If
CleanUp:
    On Error Resume Next
    Application.EnableEvents = previousEvents
    If Not dlg Is Nothing Then
        dlg.txtOld.value = ""
        dlg.txtNew.value = ""
        dlg.txtConfirm.value = ""
        Unload dlg
    End If
    Set dlg = Nothing
    oldPassword = ""
    newPassword = ""
    On Error GoTo 0
    Exit Function
Failed:
    errorText = Err.description
    On Error Resume Next
    If passwordAssigned And Not saved Then
        ThisWorkbook.Password = oldPassword
    End If
    If writeStarted And Not saved Then hintCell.Formula = oldHint
    On Error GoTo 0
    MsgBox WPText("1578,1606,1592,1740,1605,32,1585,1605,1586,32,1705,1575,1605,1604,32,1606,1588,1583,46,32,1601,1575,1740,1604,32,1585,1575,32,1606,1576,1606,1583,1740,1583,1563,32,1662,1740,1575,1605,32,1582,1591,1575,32,1585,1575,32,1576,1585,1585,1587,1740,32,1705,1606,1740,1583,46") & vbCrLf & errorText & _
        IIf(Len(backupPath) > 0, vbCrLf & backupPath, ""), vbCritical
    GoTo CleanUp
End Function


