VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmWorkbookPasswordSetup 
   Caption         =   "UserForm1"
   ClientHeight    =   7170
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   9600.001
   OleObjectBlob   =   "frmWorkbookPasswordSetup.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmWorkbookPasswordSetup"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public Accepted As Boolean
Public RemovePassword As Boolean

Private Sub UserForm_Initialize()
    Dim control As Object
    Me.Caption = WPText("1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604")
    Me.BackColor = RGB(239, 243, 248)
    Me.Font.name = "Tahoma"
    Me.Font.size = 10
    For Each control In Me.Controls
        control.Font.name = "Tahoma"
        control.Font.size = 10
    Next control
    Me.lblTitle.Font.size = 17
    Me.lblTitle.Font.bold = True
    Me.btnApply.Font.bold = True
    Me.lblTitle.Caption = WPText("1575,1605,1606,1740,1578,32,1601,1575,1740,1604,32,1575,1705,1587,1604")
    Me.lblStatus.Caption = WPText("1585,1605,1586,32,1601,1602,1591,32,1576,1585,1575,1740,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604,32,1575,1587,1578,1563,32,1606,1607,32,1605,1581,1575,1601,1592,1578,32,1588,1740,1578,32,1740,1575,32,1705,1583,1607,1575,46")
    Me.lblOld.Caption = WPText("1585,1605,1586,32,1601,1593,1604,1740")
    Me.lblNew.Caption = WPText("1585,1605,1586,32,1580,1583,1740,1583")
    Me.lblConfirm.Caption = WPText("1578,1705,1585,1575,1585,32,1585,1605,1586,32,1580,1583,1740,1583")
    Me.lblHint.Caption = WPText("1585,1575,1607,1606,1605,1575,1740,32,1585,1605,1586")
    Me.lblWarning.Caption = WPText("1585,1605,1586,32,1585,1575,32,1583,1585,32,1580,1575,1740,32,1575,1605,1606,32,1606,1711,1607,32,1583,1575,1585,1740,1583,46,32,1585,1575,1607,1606,1605,1575,32,1606,1576,1575,1740,1583,32,1582,1608,1583,32,1585,1605,1586,32,1585,1575,32,1570,1588,1705,1575,1585,32,1705,1606,1583,46")
    Me.btnApply.Caption = WPText("1575,1583,1575,1605,1607,32,1608,32,1584,1582,1740,1585,1607")
    Me.btnCancel.Caption = WPText("1575,1606,1589,1585,1575,1601")
    Me.txtOld.PasswordChar = "*"
    Me.txtNew.PasswordChar = "*"
    Me.txtConfirm.PasswordChar = "*"
    Me.txtOld.MaxLength = 255
    Me.txtNew.MaxLength = 255
    Me.txtConfirm.MaxLength = 255
End Sub

Public Sub Configure(ByVal alreadyProtected As Boolean, ByVal hint As String, Optional ByVal removing As Boolean = False)
    RemovePassword = removing
    Me.lblOld.Visible = alreadyProtected
    Me.txtOld.Visible = alreadyProtected
    Me.txtOld.enabled = alreadyProtected
    Me.txtHint.value = hint
    If alreadyProtected Then
        Me.lblStatus.Caption = WPText("1608,1590,1593,1740,1578,58,32,1583,1575,1585,1575,1740,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604")
    Else
        Me.lblStatus.Caption = WPText("1608,1590,1593,1740,1578,58,32,1576,1583,1608,1606,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604")
    End If
    Me.lblNew.Visible = Not removing
    Me.txtNew.Visible = Not removing
    Me.txtNew.enabled = Not removing
    Me.lblConfirm.Visible = Not removing
    Me.txtConfirm.Visible = Not removing
    Me.txtConfirm.enabled = Not removing
    Me.txtHint.enabled = Not removing
    If removing Then
        Me.lblTitle.Caption = WPText("1581,1584,1601,32,1585,1605,1586,32,1576,1575,1586,32,1705,1585,1583,1606,32,1601,1575,1740,1604")
        Me.lblWarning.Caption = WPText("1662,1587,32,1575,1586,32,1578,1571,1740,1740,1583,32,1608,32,1584,1582,1740,1585,1607,1548,32,1575,1740,1606,32,1601,1575,1740,1604,32,1576,1583,1608,1606,32,1585,1605,1586,32,1576,1575,1586,32,1582,1608,1575,1607,1583,32,1588,1583,32,1608,32,1585,1575,1607,1606,1605,1575,1740,32,1585,1605,1586,32,1662,1575,1705,32,1605,1740,8204,1588,1608,1583,46")
        Me.btnApply.Caption = WPText("1581,1584,1601,32,1585,1605,1586,32,1608,32,1584,1582,1740,1585,1607")
    End If
End Sub

Private Sub btnApply_Click()
    If Me.txtOld.Visible And Len(CStr(Me.txtOld.value)) = 0 Then
        MsgBox WPText("1585,1605,1586,32,1601,1593,1604,1740,32,1585,1575,32,1608,1575,1585,1583,32,1705,1606,1740,1583,46"), vbExclamation
        Me.txtOld.SetFocus
        Exit Sub
    End If
    If RemovePassword Then
        Accepted = True
        Me.Hide
        Exit Sub
    End If
    If Len(CStr(Me.txtNew.value)) < 8 Then
        MsgBox WPText("1585,1605,1586,32,1580,1583,1740,1583,32,1576,1575,1740,1583,32,1581,1583,1575,1602,1604,32,1607,1588,1578,32,1606,1608,1740,1587,1607,32,1583,1575,1588,1578,1607,32,1576,1575,1588,1583,46"), vbExclamation
        Me.txtNew.SetFocus
        Exit Sub
    End If
    If StrComp(CStr(Me.txtNew.value), CStr(Me.txtConfirm.value), vbBinaryCompare) <> 0 Then
        MsgBox WPText("1585,1605,1586,32,1580,1583,1740,1583,32,1608,32,1578,1705,1585,1575,1585,32,1570,1606,32,1740,1705,1587,1575,1606,32,1606,1740,1587,1578,1606,1583,46"), vbExclamation
        Me.txtConfirm.SetFocus
        Exit Sub
    End If
    Accepted = True
    Me.Hide
End Sub

Private Sub btnCancel_Click()
    Accepted = False
    Me.Hide
End Sub

Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)
    If CloseMode = 0 Then
        Cancel = True
        Accepted = False
        Me.Hide
    End If
End Sub

