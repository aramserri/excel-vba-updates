Attribute VB_Name = "ModUpdater"
Option Explicit
Private Const QUEUE_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/queue-v3.txt"
Private Const PACKAGE_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/packages/"

Public Sub RunVBAUpdater()
    Dim answer As VbMsgBoxResult, path As String
    answer = MsgBox("Select an update ZIP?" & vbCrLf & "Yes: ZIP file" & vbCrLf & "No: extracted version 2 package folder", vbYesNoCancel + vbQuestion)
    If answer = vbCancel Then Exit Sub
    If answer = vbYes Then
        With Application.FileDialog(3)
            .title = "Select an update ZIP": .AllowMultiSelect = False
            .Filters.Clear: .Filters.Add "Update ZIP", "*.zip"
            If .Show <> -1 Then Exit Sub
            path = .selectedItems(1)
        End With
    Else
        With Application.FileDialog(4)
            .title = "Select an extracted version 2 update package"
            If .Show <> -1 Then Exit Sub
            path = .selectedItems(1)
        End With
    End If
    LaunchUpdateTool path, False, False
End Sub

Public Sub RunVBARepair()
    Dim path As String
    With Application.FileDialog(3)
        .title = "Select a FULL REPAIR package": .AllowMultiSelect = False
        .Filters.Clear: .Filters.Add "Repair ZIP", "*.zip"
        If .Show <> -1 Then Exit Sub
        path = .selectedItems(1)
    End With
    LaunchUpdateTool path, True, False
End Sub

Public Sub RunVBAUpdaterOnline()
    Dim session As String, rows As Variant, row As Variant, version As String
    Dim current As String, path As String, folder As String, package As Object
    On Error GoTo Failed
    If ThisWorkbook.ReadOnly Then Err.Raise 5, , "Workbook is read-only."
    session = UPNewFolder(Environ$("LOCALAPPDATA"), "VBAOnlineV2_")
    Application.StatusBar = "Checking the update queue..."
    UHDownload QUEUE_URL, UPPath(session, "queue.txt")
    rows = Split(Replace(UPRead(UPPath(session, "queue.txt")), vbCr, ""), vbLf)
    current = UPVersion(ThisWorkbook)
    For Each row In rows
        version = Trim$(CStr(row))
        If version <> "" And Left$(version, 1) <> "#" Then
            If Not version Like "########_######" Then Err.Raise 5, , "Invalid queue entry: " & version
            If current = "" Or StrComp(version, current, vbBinaryCompare) > 0 Then
                path = UPPath(session, version & ".zip")
                Application.StatusBar = "Downloading update " & version
                UHDownload PACKAGE_URL & version & ".zip", path
                folder = UPExpand(path)
                Set package = UPValidate(folder, False)
                If package("Version") <> version Then Err.Raise 5, , "Queue/package version mismatch."
                If package("Mode") <> "UPDATE" Then Err.Raise 5, , "Online queue cannot apply a full repair package."
                Application.StatusBar = False
                LaunchUpdateTool folder, False, True
                Exit Sub
            End If
        End If
    Next row
    Application.StatusBar = False
    MsgBox "No newer queued update. Workbook version: " & IIf(current = "", "not recorded", current), vbInformation
    Exit Sub
Failed:
    Application.StatusBar = False
    MsgBox "Online update stopped before replacement: " & Err.description & vbCrLf & _
        "Use queue-v3.txt for upgraded workbooks. Publish its packages and tools/helper.tsv first. No failed update is marked installed.", vbExclamation
End Sub

Private Sub LaunchUpdateTool(ByVal packagePath As String, ByVal repair As Boolean, ByVal online As Boolean)
    Dim toolPath As String, tool As Workbook, target As String, book As Workbook
    On Error GoTo Failed
    target = ThisWorkbook.FullName
    If ThisWorkbook.ReadOnly Or ThisWorkbook.path = "" Then Err.Raise 5, , "Save the writable workbook first."
    Application.StatusBar = "Obtaining the verified update helper..."
    toolPath = UHResolve(online)
    Application.StatusBar = False
    For Each book In Application.Workbooks
        If StrComp(book.FullName, toolPath, vbTextCompare) = 0 Then Set tool = book: Exit For
        If StrComp(book.name, "RepairTool.xlsm", vbTextCompare) = 0 Then Err.Raise 5, , "Close the other RepairTool.xlsm before starting an automatic update."
    Next book
    If tool Is Nothing Then Set tool = Application.Workbooks.Open(toolPath, UpdateLinks:=0, ReadOnly:=True)
    If Application.Run("'" & Replace(tool.name, "'", "''") & "'!modUpdateRunnerV2.RunnerProtocol") <> 3 Then Err.Raise 5, , "The helper is not compatible with this updater."
    If Application.Workbooks.count > 1 Then tool.Windows(1).Visible = False
    Application.Run "'" & Replace(tool.name, "'", "''") & "'!modUpdateRunnerV2.StageUpdate", target, packagePath, repair, True
    If Not CBool(Application.Run("'" & Replace(tool.name, "'", "''") & "'!modUpdateRunnerV2.RunnerPending")) Then tool.Close SaveChanges:=False
    Exit Sub
Failed:
    Application.StatusBar = False
    MsgBox "Update was not started: " & Err.description & vbCrLf & _
        "Online updates obtain the helper from GitHub. Offline updates can use a verified cached or bundled helper. Excel macro-security approval may still be required.", vbExclamation
End Sub

' Compatibility entry point retained; there is no live self-replacement anymore.
Public Sub FinalizeModUpdaterSelfUpdate()
    MsgBox "Version 2 uses the external update tool. There is no pending in-place self-update to finalize.", vbInformation
End Sub


