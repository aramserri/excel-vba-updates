VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmManualChequeDatePicker 
   Caption         =   "������ ���� ����� �� ��"
   ClientHeight    =   12593
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   19460
   OleObjectBlob   =   "frmManualChequeDatePicker.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmManualChequeDatePicker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

  Private Const CONFIG_SHEET_NAME As String = "�������"
  Private Const CONFIG_HOLIDAY_FLAG_COL As String = "S"
  Private Const CONFIG_DATE_LIST_COL As String = "U"
  Private Const CONFIG_REAL_TOTAL_COL As String = "V"

  Public selectedDates As Collection
  Private m_Cancelled As Boolean

  Public Property Get WasCancelled() As Boolean
      WasCancelled = m_Cancelled
  End Property

  Public Sub InitializePicker(ByVal centerPersianDate As String)
      Dim cleanDate As String
      Dim parts() As String
      Dim centerYM As String
      Dim i As Long
      Dim ym As String
      Dim lb As MSForms.ListBox
      Dim lbl As MSForms.Label

      Set selectedDates = New Collection
      m_Cancelled = True

      cleanDate = ConvertPersianNumsToEnglishKeepSlash_MP(centerPersianDate)

      If InStr(cleanDate, "/") = 0 Then
          MsgBox "����� TextBox6 ����� ����.", vbExclamation, "������ �����"
          Exit Sub
      End If

      parts = Split(cleanDate, "/")
      If UBound(parts) <> 2 Then
          MsgBox "����� TextBox6 ����� ����.", vbExclamation, "������ �����"
          Exit Sub
      End If

      centerYM = CLng(parts(0)) & "/" & Format(CLng(parts(1)), "00")

      For i = 1 To 13
          Set lb = Me.Controls("ListBox" & i)
          Set lbl = Me.Controls("Label" & i)

          ym = AddPersianMonths_MP(centerYM, i - 7)

          lbl.Caption = ym

          With lb
              .Clear
              .ColumnCount = 3
              .ColumnWidths = "35;90;0"
              .MultiSelect = fmMultiSelectMulti
          End With

          Call PopulateMonthListBox_MP(lb, ym)
      Next i
  End Sub

  Private Sub PopulateMonthListBox_MP(ByVal lb As MSForms.ListBox, ByVal ym As String)
      Dim wsInfo As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim pDate As String
      Dim cleanDate As String
      Dim parts() As String
      Dim dayText As String
      Dim amountVal As Double
      Dim rowIndex As Long

      On Error Resume Next
      Set wsInfo = ThisWorkbook.Sheets(CONFIG_SHEET_NAME)
      On Error GoTo 0

      If wsInfo Is Nothing Then Exit Sub

      lastRow = wsInfo.Cells(wsInfo.rows.count, CONFIG_DATE_LIST_COL).End(xlUp).row

      For r = 2 To lastRow
          pDate = Trim(CStr(wsInfo.Cells(r, CONFIG_DATE_LIST_COL).value))
          If pDate <> "" Then
              cleanDate = ConvertPersianNumsToEnglishKeepSlash_MP(pDate)

              If Left$(cleanDate, 7) = ym Then
                  parts = Split(cleanDate, "/")
                  If UBound(parts) = 2 Then
                      dayText = CStr(CLng(parts(2)))

                      If Trim(CStr(wsInfo.Cells(r, CONFIG_HOLIDAY_FLAG_COL).value)) = "*" Then
                          dayText = "*" & dayText
                      End If

                      amountVal = 0
                      If Not IsError(wsInfo.Cells(r, CONFIG_REAL_TOTAL_COL).value) Then
                          If IsNumeric(wsInfo.Cells(r, CONFIG_REAL_TOTAL_COL).value) Then
                              amountVal = CDbl(wsInfo.Cells(r, CONFIG_REAL_TOTAL_COL).value)
                          End If
                      End If

                      lb.AddItem dayText
                      rowIndex = lb.ListCount - 1
                      lb.List(rowIndex, 1) = Format(amountVal, "#,##0")
                      lb.List(rowIndex, 2) = cleanDate
                  End If
              End If
          End If
      Next r
  End Sub

  Private Function AddPersianMonths_MP(ByVal ym As String, ByVal monthOffset As Long) As String
      Dim parts() As String
      Dim y As Long
      Dim m As Long
      Dim totalMonth As Long

      parts = Split(ym, "/")
      y = CLng(parts(0))
      m = CLng(parts(1))

      totalMonth = (y * 12) + (m - 1) + monthOffset

      y = totalMonth \ 12
      m = (totalMonth Mod 12) + 1

      AddPersianMonths_MP = y & "/" & Format(m, "00")
  End Function

  Private Function ConvertPersianNumsToEnglishKeepSlash_MP(ByVal s As Variant) As String
      Dim i As Long
      Dim out As String
      Dim ch As String
      Dim code As Long

      If IsNull(s) Or IsEmpty(s) Then
          ConvertPersianNumsToEnglishKeepSlash_MP = ""
          Exit Function
      End If

      s = CStr(s)
      out = ""

      For i = 1 To Len(s)
          ch = Mid$(s, i, 1)
          code = AscW(ch)

          Select Case code
              Case 1776 To 1785
                  out = out & CStr(code - 1776)
              Case 1632 To 1641
                  out = out & CStr(code - 1632)
              Case 48 To 57
                  out = out & ch
              Case 47
                  out = out & "/"
              Case Else
                  If ch >= "0" And ch <= "9" Then
                      out = out & ch
                  ElseIf ch = "/" Then
                      out = out & "/"
                  End If
          End Select
      Next i

      ConvertPersianNumsToEnglishKeepSlash_MP = Trim(out)
  End Function

  Private Sub CommandButtonOK_Click()
      Dim i As Long
      Dim j As Long
      Dim lb As MSForms.ListBox
      Dim selectedDate As String

      Set selectedDates = New Collection

      For i = 1 To 13
          Set lb = Me.Controls("ListBox" & i)

          For j = 0 To lb.ListCount - 1
              If lb.Selected(j) Then
                  selectedDate = Trim(CStr(lb.List(j, 2)))
                  If selectedDate <> "" Then
                      selectedDates.Add selectedDate
                  End If
              End If
          Next j
      Next i

      If selectedDates.count = 0 Then
          MsgBox "�� ������ ������ ���� ���.", vbExclamation, "������ �����"
          Exit Sub
      End If

      m_Cancelled = False
      Me.Hide
  End Sub

  Private Sub CommandButtonCancel_Click()
      m_Cancelled = True
      Me.Hide
  End Sub

  Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
      If CloseMode = vbFormControlMenu Then
          m_Cancelled = True
          CANCEL = True
          Me.Hide
      End If
  End Sub
