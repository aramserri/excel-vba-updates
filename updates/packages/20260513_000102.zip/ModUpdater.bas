Attribute VB_Name = "ModUpdater"
' Option Explicit
'
'  ' =============================================================================
'  ' ModUpdater
'  ' Safe VBA component updater for Excel workbooks
'  '
'  ' Features:
'  ' - Replace/add standard modules (.bas)
'  ' - Replace/add class modules (.cls)
'  ' - Replace/add userforms (.frm + .frx)
'  ' - Update document modules by code injection (ThisWorkbook / Sheet modules)
'  ' - Safe self-update of this updater module
'  ' - Optional cell update via cell_update.txt
'  '
'  ' Recommended module name: ModUpdater
'  ' =============================================================================
'
'  Private Const UPDATER_MODULE_NAME As String = "ModUpdater"
'  Private Const TEMP_SUFFIX As String = "_OLD_TEMP"
'  Private Const INFO_SHEET_NAME As String = "�������"
'  Private Const REMOTE_UPDATE_DETAILS_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/UpdateDetails.txt"
'  Private Const LOCAL_UPDATE_DETAILS_FILE_NAME As String = "UpdateDetails.txt"
'  Private Const REMOTE_VERSION_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/version.txt"
'  Private Const REMOTE_ZIP_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/update.zip"
'  Private Const CACHE_FOLDER_NAME As String = "VBAUpdaterCache"
'  Private Const LOCAL_VERSION_FILE_NAME As String = "version.txt"
'  Private Const LOCAL_ZIP_FILE_NAME As String = "update.zip"
'  Private Const EXTRACT_FOLDER_NAME As String = "extracted"
'
'  ' =============================================================================
'  ' Public Entry Point
'  ' =============================================================================
'  Public Sub RunVBAUpdater()
'      Dim folderPath As String
'
'      If Not HasVBProjectAccess() Then
'        MsgBox "Trust access to the VBA project object model is not enabled." & vbCrLf & vbCrLf & "Please enable:" & vbCrLf & "Trust Center > Macro Settings > Trust access to the VBA project object model", vbCritical, "No VBA Access"
'
'          Exit Sub
'      End If
'
'      folderPath = PickUpdateFolder()
'      If folderPath = "" Then Exit Sub
'
'      Call RunVBAUpdaterFromFolder(folderPath)
'  End Sub
'
'
'Public Sub RunVBAUpdaterOnline()
'      Dim fso As Object
'      Dim cacheFolder As String
'      Dim extractFolder As String
'      Dim localVersionPath As String
'      Dim localZipPath As String
'      Dim remoteVersion As String
'      Dim localVersion As String
'      Dim updateOk As Boolean
'      Dim localUpdateDetailsPath As String
'
'      If Not HasVBProjectAccess() Then
'          MsgBox "Trust access to the VBA project object model is not enabled." & vbCrLf & vbCrLf & "Please enable:" & vbCrLf & "Trust Center > Macro Settings > Trust access to the  VBA project object model", vbCritical, "No VBA Access"
'          Exit Sub
'      End If
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'
'      cacheFolder = Environ$("LOCALAPPDATA") & "\" & CACHE_FOLDER_NAME
'      extractFolder = cacheFolder & "\" & EXTRACT_FOLDER_NAME
'      localVersionPath = cacheFolder & "\" & LOCAL_VERSION_FILE_NAME
'      localZipPath = cacheFolder & "\" & LOCAL_ZIP_FILE_NAME
'      localUpdateDetailsPath = cacheFolder & "\" & LOCAL_UPDATE_DETAILS_FILE_NAME
'
'      EnsureFolderExists cacheFolder, fso
'
'      remoteVersion = Trim$(ReadUrlText(REMOTE_VERSION_URL))
'
'
'  remoteVersion = Trim$(ReadUrlText(REMOTE_VERSION_URL))
'
'  If remoteVersion = "" Then
'      MsgBox "Could not read online version file." & vbCrLf & vbCrLf & "URL used:" & vbCrLf & REMOTE_VERSION_URL & vbCrLf & vbCrLf & "Try opening this exact URL in your browser from the same computer.", vbExclamation, "Update Check Failed"
'      Exit Sub
'  End If
'      If fso.FileExists(localVersionPath) Then
'          If Not ReadTextFile(localVersionPath, localVersion) Then
'              localVersion = ""
'          End If
'          localVersion = Trim$(localVersion)
'      Else
'          localVersion = ""
'      End If
'
'      If StrComp(remoteVersion, localVersion, vbTextCompare) = 0 Then
'          MsgBox "No update needed." & vbCrLf & vbCrLf & "Current version: " & localVersion, vbInformation, "Updater"
'          Exit Sub
'      End If
'
'      If fso.FileExists(localZipPath) Then
'          On Error Resume Next
'          fso.DeleteFile localZipPath, True
'          On Error GoTo 0
'      End If
'
'      If Not DownloadUrlToFile(REMOTE_ZIP_URL, localZipPath) Then
'          MsgBox "Could not download update package.", vbExclamation, "Download Failed"
'          Exit Sub
'      End If
'If Not IsZipFile(localZipPath) Then
'      MsgBox "Downloaded update.zip is not a valid ZIP file." & vbCrLf & vbCrLf & "File:" & vbCrLf & localZipPath & vbCrLf & vbCrLf & "Check that the GitHub URL points directly to update.zip.", vbExclamation, "Invalid ZIP"
'      Exit Sub
'  End If
'      If fso.FolderExists(extractFolder) Then
'          On Error Resume Next
'          fso.DeleteFolder extractFolder, True
'          On Error GoTo 0
'      End If
'
'      EnsureFolderExists extractFolder, fso
'
'      If Not UnzipFile(localZipPath, extractFolder) Then
'          MsgBox "Could not extract update package.", vbExclamation, "Extract Failed"
'          Exit Sub
'      End If
'
'      updateOk = RunVBAUpdaterFromFolder(extractFolder)
'
'      If updateOk Then
'      WriteTextFile localVersionPath, remoteVersion
'
'      If DownloadUrlToFile(REMOTE_UPDATE_DETAILS_URL, localUpdateDetailsPath) Then
'          ShowUpdateDetailsFromFile localUpdateDetailsPath, REMOTE_UPDATE_DETAILS_URL
'      Else
'          MsgBox "Update was successful, but update details could not be downloaded." & vbCrLf & vbCrLf & _
'                 "You can check update details manually from:" & vbCrLf & _
'                 REMOTE_UPDATE_DETAILS_URL, _
'                 vbInformation, "Update Details"
'      End If
'  End If
'  End Sub
'
'
'  Private Function RunVBAUpdaterFromFolder(ByVal folderPath As String) As Boolean
'      Dim fso As Object
'      Dim fileMap As Object
'      Dim failedItems As Collection
'      Dim replacedCount As Long
'      Dim addedCount As Long
'      Dim failedCount As Long
'      Dim selfUpdatePending As Boolean
'      Dim key As Variant
'      Dim filePath As String
'      Dim existingComp As VBIDE.VBComponent
'
'      RunVBAUpdaterFromFolder = False
'
'      If Right$(folderPath, 1) <> "\" Then
'          folderPath = folderPath & "\"
'      End If
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'
'      If Not fso.FolderExists(folderPath) Then
'          MsgBox "Update folder not found:" & vbCrLf & folderPath, vbExclamation, "Error"
'          Exit Function
'      End If
'
'      Set failedItems = New Collection
'      Set fileMap = BuildUpdateFileMap(folderPath, fso, failedItems, failedCount)
'
'      If fileMap Is Nothing Or fileMap.count = 0 Then
'          MsgBox "No updateable VBA files found." & vbCrLf & _
'                 "Allowed files: .bas, .cls, .frm", _
'                 vbExclamation, "No Files"
'          Exit Function
'      End If
'
'      For Each key In fileMap.Keys
'          filePath = CStr(fileMap(key))
'          Set existingComp = GetComponentByName(CStr(key))
'
'          If existingComp Is Nothing Then
'              If AddNewComponentFromFile(filePath, CStr(key), failedItems) Then
'                  addedCount = addedCount + 1
'              Else
'                  failedCount = failedCount + 1
'              End If
'          Else
'              If existingComp.Type = vbext_ct_Document Then
'                  If UpdateDocumentModuleFromFile(existingComp, filePath, failedItems) Then
'                      replacedCount = replacedCount + 1
'                  Else
'                      failedCount = failedCount + 1
'                  End If
'              ElseIf StrComp(existingComp.Name, UPDATER_MODULE_NAME, vbTextCompare) = 0 Then
'              If ReplaceSelfUpdater(existingComp, filePath, failedItems) Then
'              replacedCount = replacedCount + 1
'                      selfUpdatePending = True
'                  Else
'                      failedCount = failedCount + 1
'                  End If
'              Else
'                  If ReplaceComponentSafely(existingComp, filePath, CStr(key), failedItems) Then
'                      replacedCount = replacedCount + 1
'                  Else
'                      failedCount = failedCount + 1
'                  End If
'              End If
'          End If
'
'          Set existingComp = Nothing
'      Next key
'
'      Call ApplyCellUpdateFile(folderPath, fso, failedItems, failedCount)
'
'      Call ShowUpdateSummary(replacedCount, addedCount, failedCount, failedItems, selfUpdatePending)
'
'      If selfUpdatePending Then
'          Application.OnTime Now + TimeSerial(0, 0, 3), BuildOnTimeMacroName("FinalizeModUpdaterSelfUpdate")
'      End If
'
'      RunVBAUpdaterFromFolder = (failedCount = 0)
'  End Function
'
'  ' =============================================================================
'  ' Folder Picker
'  ' =============================================================================
'  Private Function PickUpdateFolder() As String
'      Dim dlg As FileDialog
'
'      Set dlg = Application.FileDialog(msoFileDialogFolderPicker)
'
'      With dlg
'          .Title = "���� ���� ������� VBA �� ������ ����"
'          If .Show <> -1 Then
'              PickUpdateFolder = ""
'              Exit Function
'          End If
'
'          PickUpdateFolder = .selectedItems(1)
'          If Right$(PickUpdateFolder, 1) <> "\" Then
'              PickUpdateFolder = PickUpdateFolder & "\"
'          End If
'      End With
'  End Function
'
'  ' =============================================================================
'  ' Build file map
'  ' Key = component name
'  ' Value = full file path
'  ' =============================================================================
'  Private Function BuildUpdateFileMap(ByVal folderPath As String, _
'                                      ByVal fso As Object, _
'                                      ByRef failedItems As Collection, _
'                                      ByRef failedCount As Long) As Object
'      Dim result As Object
'      Dim folderObj As Object
'      Dim fileObj As Object
'      Dim baseName As String
'      Dim ext As String
'      Dim frxPath As String
'
'      Set result = CreateObject("Scripting.Dictionary")
'      result.CompareMode = vbTextCompare
'
'      Set folderObj = fso.GetFolder(folderPath)
'
'      For Each fileObj In folderObj.files
'          ext = LCase$(fso.GetExtensionName(fileObj.Name))
'
'          Select Case ext
'              Case "bas", "cls"
'                  baseName = fso.GetBaseName(fileObj.Name)
'
'                  If result.exists(baseName) Then
'                      failedCount = failedCount + 1
'                      failedItems.Add "��� ʘ���� ���� ��� VBA: " & fileObj.Name
'                  Else
'                      result.Add baseName, fileObj.path
'                  End If
'
'              Case "frm"
'                  baseName = fso.GetBaseName(fileObj.Name)
'
'                  If result.exists(baseName) Then
'                      failedCount = failedCount + 1
'                      failedItems.Add "��� ʘ���� ���� ���: " & fileObj.Name
'                  Else
'                      frxPath = folderPath & baseName & ".frx"
'                      If Not fso.FileExists(frxPath) Then
'                          failedCount = failedCount + 1
'                          failedItems.Add "���� .frx ���� ��� ���� ���: " & fileObj.Name
'                      Else
'                          result.Add baseName, fileObj.path
'                      End If
'                  End If
'          End Select
'      Next fileObj
'
'      Set BuildUpdateFileMap = result
'  End Function
'
'  ' =============================================================================
'  ' Get Component By Name
'  ' =============================================================================
'  Private Function GetComponentByName(ByVal compName As String) As VBIDE.VBComponent
'      On Error Resume Next
'      Set GetComponentByName = ThisWorkbook.VBProject.VBComponents(compName)
'      On Error GoTo 0
'  End Function
'
'  ' =============================================================================
'  ' Add new component
'  ' =============================================================================
'  Private Function AddNewComponentFromFile(ByVal filePath As String, _
'                                           ByVal expectedName As String, _
'                                           ByRef failedItems As Collection) As Boolean
'      Dim importedComp As VBIDE.VBComponent
'      Dim errText As String
'
'      AddNewComponentFromFile = ImportComponentValidated(filePath, expectedName, importedComp, errText)
'
'      If Not AddNewComponentFromFile Then
'          failedItems.Add "��� �� ����� ���� '" & expectedName & "': " & errText
'      End If
'
'      Set importedComp = Nothing
'  End Function
'
'  ' =============================================================================
'  ' Replace normal component safely
'  ' - rename old
'  ' - import new
'  ' - remove old
'  ' - rollback on failure
'  ' =============================================================================
'  Private Function ReplaceComponentSafely(ByVal oldComp As VBIDE.VBComponent, _
'                                          ByVal filePath As String, _
'                                          ByVal expectedName As String, _
'                                          ByRef failedItems As Collection) As Boolean
'      Dim oldName As String
'      Dim tempName As String
'      Dim newComp As VBIDE.VBComponent
'      Dim errText As String
'
'      ReplaceComponentSafely = False
'
'      oldName = oldComp.Name
'      tempName = oldName & TEMP_SUFFIX
'
'      If Not EnsureTempNameFree(tempName, failedItems) Then Exit Function
'
'      On Error Resume Next
'      oldComp.Name = tempName
'      If Err.Number <> 0 Then
'          failedItems.Add "��� �� ����� ��� ���� '" & oldName & "': " & Err.description
'          Err.Clear
'          On Error GoTo 0
'          Exit Function
'      End If
'      On Error GoTo 0
'
'      If ImportComponentValidated(filePath, expectedName, newComp, errText) Then
'          On Error Resume Next
'          ThisWorkbook.VBProject.VBComponents.Remove oldComp
'          If Err.Number <> 0 Then
'              failedItems.Add "���� ���� '" & expectedName & "' ���� �� ��� ��� ���� ����� ������ ���: " & Err.description
'              Err.Clear
'              On Error GoTo 0
'              Exit Function
'          End If
'          On Error GoTo 0
'
'          ReplaceComponentSafely = True
'      Else
'          On Error Resume Next
'          oldComp.Name = oldName
'          On Error GoTo 0
'
'          failedItems.Add "��� �� ������� '" & expectedName & "': " & errText
'      End If
'
'      Set newComp = Nothing
'  End Function
'
'  ' =============================================================================
'  ' Replace self updater safely
'  ' =============================================================================
'  Private Function ReplaceSelfUpdater(ByVal oldComp As VBIDE.VBComponent, _
'                                      ByVal filePath As String, _
'                                      ByRef failedItems As Collection) As Boolean
'      Dim tempName As String
'      Dim newComp As VBIDE.VBComponent
'      Dim errText As String
'
'      ReplaceSelfUpdater = False
'
'      tempName = UPDATER_MODULE_NAME & TEMP_SUFFIX
'
'      If Not EnsureTempNameFree(tempName, failedItems) Then Exit Function
'
'      On Error Resume Next
'      oldComp.Name = tempName
'      If Err.Number <> 0 Then
'          failedItems.Add "��� �� ����� ��� ���� ����: " & Err.description
'          Err.Clear
'          On Error GoTo 0
'          Exit Function
'      End If
'      On Error GoTo 0
'
'      If ImportComponentValidated(filePath, UPDATER_MODULE_NAME, newComp, errText) Then
'          ReplaceSelfUpdater = True
'      Else
'          On Error Resume Next
'          oldComp.Name = UPDATER_MODULE_NAME
'          On Error GoTo 0
'
'          failedItems.Add "��� �� ���������? ���� ����: " & errText
'      End If
'
'      Set newComp = Nothing
'  End Function
'
'  ' =============================================================================
'  ' Finalize self update
'  ' =============================================================================
'  Public Sub FinalizeModUpdaterSelfUpdate()
'      Dim oldComp As VBIDE.VBComponent
'
'      On Error Resume Next
'      Set oldComp = ThisWorkbook.VBProject.VBComponents(UPDATER_MODULE_NAME & TEMP_SUFFIX)
'
'      If oldComp Is Nothing Then
'          MsgBox "�ǎ�� ���� ���� ���� ��� ���� ���.", vbExclamation, "�����"
'          Exit Sub
'      End If
'
'      ThisWorkbook.VBProject.VBComponents.Remove oldComp
'      If Err.Number <> 0 Then
'          MsgBox "��� �� ��� ���� ����� ����:" & vbCrLf & Err.description, vbExclamation, "�����"
'          Err.Clear
'          On Error GoTo 0
'          Exit Sub
'      End If
'      On Error GoTo 0
'
'      MsgBox "���� �� ������ ���������? ��.", vbInformation, "����"
'  End Sub
'
'  ' =============================================================================
'  ' Update document module from exported file
'  ' =============================================================================
'  Private Function UpdateDocumentModuleFromFile(ByVal targetComp As VBIDE.VBComponent, _
'                                                ByVal filePath As String, _
'                                                ByRef failedItems As Collection) As Boolean
'      Dim fileText As String
'      Dim newCode As String
'      Dim oldCode As String
'
'      UpdateDocumentModuleFromFile = False
'
'      If Not ReadTextFile(filePath, fileText) Then
'          failedItems.Add "��� �� ������ ���� �ǎ�� ���: " & filePath
'          Exit Function
'      End If
'
'      newCode = ExtractCodeBodyFromExport(fileText)
'
'      With targetComp.codeModule
'          If .CountOfLines > 0 Then
'              oldCode = .lines(1, .CountOfLines)
'          Else
'              oldCode = ""
'          End If
'      End With
'
'      On Error Resume Next
'      With targetComp.codeModule
'          If .CountOfLines > 0 Then .DeleteLines 1, .CountOfLines
'          If Len(newCode) > 0 Then .InsertLines 1, newCode
'      End With
'
'      If Err.Number <> 0 Then
'          Dim writeErr As String
'          writeErr = Err.description
'          Err.Clear
'
'          On Error Resume Next
'          With targetComp.codeModule
'              If .CountOfLines > 0 Then .DeleteLines 1, .CountOfLines
'              If Len(oldCode) > 0 Then .InsertLines 1, oldCode
'          End With
'          On Error GoTo 0
'
'          failedItems.Add "��� �� ������� �� �ǎ�� ��� '" & targetComp.Name & "': " & writeErr
'          Exit Function
'      End If
'      On Error GoTo 0
'
'      UpdateDocumentModuleFromFile = True
'  End Function
'
'  ' =============================================================================
'  ' Import component and validate name
'  ' =============================================================================
'  Private Function ImportComponentValidated(ByVal filePath As String, _
'                                            ByVal expectedName As String, _
'                                            ByRef importedComp As VBIDE.VBComponent, _
'                                            ByRef errText As String) As Boolean
'      Dim actualName As String
'
'      ImportComponentValidated = False
'      errText = ""
'
'      On Error Resume Next
'      Set importedComp = ThisWorkbook.VBProject.VBComponents.Import(filePath)
'
'      If Err.Number <> 0 Or importedComp Is Nothing Then
'          errText = Err.description
'          Err.Clear
'          On Error GoTo 0
'          Exit Function
'      End If
'      On Error GoTo 0
'
'      actualName = importedComp.Name
'
'      If StrComp(actualName, expectedName, vbTextCompare) <> 0 Then
'          On Error Resume Next
'          importedComp.Name = expectedName
'
'          If Err.Number <> 0 Then
'              errText = "��� ��� ������� �� ��� ���� ���� ����. ��� ����: " & _
'                        actualName & " / ��� ���� ������: " & expectedName & _
'                        " / ���: " & Err.description
'              Err.Clear
'
'              On Error Resume Next
'              ThisWorkbook.VBProject.VBComponents.Remove importedComp
'              On Error GoTo 0
'              Set importedComp = Nothing
'              Exit Function
'          End If
'          On Error GoTo 0
'      End If
'
'      ImportComponentValidated = True
'  End Function
'
'  ' =============================================================================
'  ' Apply cell_update.txt
'  '
'  ' Format:
'  ' line 1 = cell address
'  ' line 2+ = value or formula
'  ' =============================================================================
'  Private Sub ApplyCellUpdateFile(ByVal folderPath As String, _
'                                  ByVal fso As Object, _
'                                  ByRef failedItems As Collection, _
'                                  ByRef failedCount As Long)
'      Dim filePath As String
'      Dim fileText As String
'      Dim lines() As String
'      Dim cellAddr As String
'      Dim cellVal As String
'      Dim i As Long
'      Dim ws As Worksheet
'      Dim targetCell As Range
'      Dim answer As VbMsgBoxResult
'
'      filePath = folderPath & "cell_update.txt"
'      If Not fso.FileExists(filePath) Then Exit Sub
'
'      If Not ReadTextFile(filePath, fileText) Then
'          failedCount = failedCount + 1
'          failedItems.Add "������ cell_update.txt ������ ���."
'          Exit Sub
'      End If
'
'      fileText = NormalizeLineBreaks(fileText)
'      lines = Split(fileText, vbLf)
'
'      If UBound(lines) < 1 Then
'          failedCount = failedCount + 1
'          failedItems.Add "cell_update.txt ���� ����� �� �� ����� ����."
'          Exit Sub
'      End If
'
'      cellAddr = CleanString(lines(0))
'      cellVal = ""
'
'      For i = 1 To UBound(lines)
'          If i = 1 Then
'              cellVal = lines(i)
'          Else
'              cellVal = cellVal & vbCrLf & lines(i)
'          End If
'      Next i
'
'      cellVal = CleanString(cellVal)
'
'      If cellAddr = "" Or cellVal = "" Then
'          failedCount = failedCount + 1
'          failedItems.Add "������ cell_update.txt ���� ���."
'          Exit Sub
'      End If
'
'      On Error Resume Next
'      Set ws = ThisWorkbook.Worksheets(INFO_SHEET_NAME)
'      On Error GoTo 0
'
'      If ws Is Nothing Then
'          failedCount = failedCount + 1
'          failedItems.Add "��� '" & INFO_SHEET_NAME & "' ���� cell_update.txt ���� ���."
'          Exit Sub
'      End If
'
'      On Error Resume Next
'      Set targetCell = ws.Range(cellAddr)
'      On Error GoTo 0
'
'      If targetCell Is Nothing Then
'          failedCount = failedCount + 1
'          failedItems.Add "���� ���� ������� �� cell_update.txt: " & cellAddr
'          Exit Sub
'      End If
'
'      If Trim$(CStr(targetCell.value)) <> "" Then
'          answer = MsgBox("���� " & cellAddr & " �� ��� ����� ����." & vbCrLf & vbCrLf & _
'                          "����� ����:" & vbCrLf & CStr(targetCell.value) & vbCrLf & vbCrLf & _
'                          "����� ����:" & vbCrLf & cellVal & vbCrLf & vbCrLf & _
'                          "��� ������ ��Ͽ", _
'                          vbYesNo + vbQuestion, "����� �������")
'          If answer = vbNo Then Exit Sub
'      End If
'
'      On Error Resume Next
'      If Left$(cellVal, 1) = "=" Then
'          targetCell.FormulaLocal = cellVal
'          If Err.Number <> 0 Then
'              Err.Clear
'              targetCell.Formula = cellVal
'              If Err.Number <> 0 Then
'                  Err.Clear
'                  targetCell.value = cellVal
'              End If
'          End If
'      Else
'          targetCell.value = cellVal
'      End If
'
'      If Err.Number <> 0 Then
'          failedCount = failedCount + 1
'          failedItems.Add "��� �� ����� �� ���� " & cellAddr & ": " & Err.description
'          Err.Clear
'      End If
'      On Error GoTo 0
'  End Sub
'
'  ' =============================================================================
'  ' Helpers
'  ' =============================================================================
'  Private Function HasVBProjectAccess() As Boolean
'      Dim n As Long
'
'      On Error Resume Next
'      n = ThisWorkbook.VBProject.VBComponents.count
'      HasVBProjectAccess = (Err.Number = 0)
'      Err.Clear
'      On Error GoTo 0
'  End Function
'
'  Private Function EnsureTempNameFree(ByVal tempName As String, _
'                                      ByRef failedItems As Collection) As Boolean
'      EnsureTempNameFree = False
'
'      If GetComponentByName(tempName) Is Nothing Then
'          EnsureTempNameFree = True
'      Else
'          failedItems.Add "��� ���� �� ��� �� ���� ���� ����: " & tempName
'      End If
'  End Function
'
'  Private Function ReadTextFile(ByVal filePath As String, ByRef fileText As String) As Boolean
'      Dim fso As Object
'      Dim ts As Object
'
'      ReadTextFile = False
'      fileText = ""
'
'      On Error Resume Next
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      If Not fso.FileExists(filePath) Then
'          On Error GoTo 0
'          Exit Function
'      End If
'
'      Set ts = fso.OpenTextFile(filePath, 1, False)
'      If Err.Number <> 0 Then
'          Err.Clear
'          On Error GoTo 0
'          Exit Function
'      End If
'
'      fileText = ts.ReadAll
'      ts.Close
'      Set ts = Nothing
'      Set fso = Nothing
'
'      On Error GoTo 0
'      ReadTextFile = True
'  End Function
'
'  Private Function NormalizeLineBreaks(ByVal s As String) As String
'      s = Replace(s, vbCrLf, vbLf)
'      s = Replace(s, vbCr, vbLf)
'      NormalizeLineBreaks = s
'  End Function
'
'  Private Function ExtractCodeBodyFromExport(ByVal fullText As String) As String
'      Dim lines() As String
'      Dim i As Long
'      Dim j As Long
'      Dim startLine As Long
'      Dim currentLine As String
'      Dim isHeaderLine As Boolean
'      Dim codeLines() As String
'
'      fullText = NormalizeLineBreaks(fullText)
'      lines = Split(fullText, vbLf)
'      startLine = 0
'
'      For i = 0 To UBound(lines)
'          currentLine = Trim$(lines(i))
'          isHeaderLine = False
'
'          If currentLine = "" Then isHeaderLine = True
'          If UCase$(Left$(currentLine, 7)) = "VERSION" Then isHeaderLine = True
'          If UCase$(currentLine) = "BEGIN" Then isHeaderLine = True
'          If UCase$(currentLine) = "END" Then isHeaderLine = True
'          If UCase$(Left$(currentLine, 9)) = "MULTIUSE " Then isHeaderLine = True
'          If UCase$(Left$(currentLine, 9)) = "MULTIUSE=" Then isHeaderLine = True
'          If UCase$(Left$(currentLine, 9)) = "ATTRIBUTE" Then isHeaderLine = True
'
'          If isHeaderLine Then
'              startLine = i + 1
'          Else
'              Exit For
'          End If
'      Next i
'
'      If startLine > UBound(lines) Then
'          ExtractCodeBodyFromExport = ""
'          Exit Function
'      End If
'
'      ReDim codeLines(0 To UBound(lines) - startLine)
'      For j = 0 To UBound(codeLines)
'          codeLines(j) = lines(startLine + j)
'      Next j
'
'      ExtractCodeBodyFromExport = Join(codeLines, vbCrLf)
'  End Function
'
'  Private Function CleanString(ByVal s As String) As String
'      Dim i As Long
'      Dim ch As String
'      Dim code As Long
'      Dim result As String
'
'      s = Replace(s, ChrW$(&HFEFF), "")
'      s = Replace(s, ChrW$(160), " ")
'
'      result = ""
'      For i = 1 To Len(s)
'          ch = Mid$(s, i, 1)
'          code = AscW(ch)
'
'          If code = 9 Or code >= 32 Then
'              result = result & ch
'          End If
'      Next i
'
'      CleanString = Trim$(result)
'  End Function
'
'  Private Function BuildOnTimeMacroName(ByVal procName As String) As String
'      BuildOnTimeMacroName = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & procName
'  End Function
'Private Function ReadUrlText(ByVal url As String) As String
'      Dim tempPath As String
'      Dim fso As Object
'
'      tempPath = Environ$("TEMP") & "\vba_online_version_" & Format$(Now, "yyyymmddhhnnss") & ".txt"
'
'      If Not DownloadUrlToFile(url, tempPath) Then
'          ReadUrlText = ""
'          Exit Function
'      End If
'
'      If ReadTextFile(tempPath, ReadUrlText) Then
'          On Error Resume Next
'          Set fso = CreateObject("Scripting.FileSystemObject")
'          fso.DeleteFile tempPath, True
'          On Error GoTo 0
'      Else
'          ReadUrlText = ""
'      End If
'  End Function
'
'  Private Function DownloadUrlToFile(ByVal url As String, ByVal filePath As String) As Boolean
'      Dim fso As Object
'      Dim wsh As Object
'      Dim cmd As String
'      Dim exitCode As Long
'
'      On Error GoTo Failed
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set wsh = CreateObject("WScript.Shell")
'
'      If fso.FileExists(filePath) Then
'          fso.DeleteFile filePath, True
'      End If
'
'  cmd = "cmd.exe /c curl.exe -k -L -f -s -S -o " & CmdQuote(filePath) & " " & CmdQuote(url)
'  exitCode = wsh.Run(cmd, 0, True)
'
'      If exitCode <> 0 Then
'          MsgBox "Download command failed." & vbCrLf & vbCrLf & _
'                 "Exit code: " & exitCode & vbCrLf & _
'                 "URL:" & vbCrLf & url, _
'                 vbExclamation, "Download Error"
'          GoTo Failed
'      End If
'
'      If Not fso.FileExists(filePath) Then GoTo Failed
'      If fso.GetFile(filePath).Size = 0 Then GoTo Failed
'
'      DownloadUrlToFile = True
'      Exit Function
'
'Failed:
'      DownloadUrlToFile = False
'  End Function
'
'  Private Function CmdQuote(ByVal value As String) As String
'  CmdQuote = Chr$(34) & Replace(value, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
'  End Function
'
'   Private Function UnzipFile(ByVal zipPath As String, ByVal destFolder As String) As Boolean
'      Dim fso As Object
'      Dim wsh As Object
'      Dim cmd As String
'      Dim exitCode As Long
'      Dim beforeCount As Long
'      Dim afterCount As Long
'
'      On Error GoTo Failed
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set wsh = CreateObject("WScript.Shell")
'
'      If Not fso.FileExists(zipPath) Then GoTo Failed
'
'      If Not fso.FolderExists(destFolder) Then
'          fso.CreateFolder destFolder
'      End If
'
'      beforeCount = fso.GetFolder(destFolder).files.count
'
'      cmd = "cmd.exe /c tar.exe -xf " & CmdQuote(zipPath) & " -C " & CmdQuote(destFolder)
'      exitCode = wsh.Run(cmd, 0, True)
'      If exitCode <> 0 Then
'          MsgBox "Extract command failed." & vbCrLf & vbCrLf & _
'                 "Exit code: " & exitCode & vbCrLf & _
'                 "ZIP:" & vbCrLf & zipPath & vbCrLf & vbCrLf & _
'                 "Destination:" & vbCrLf & destFolder, _
'                 vbExclamation, "Extract Error"
'          GoTo Failed
'      End If
'
'      afterCount = fso.GetFolder(destFolder).files.count
'
'      If afterCount <= beforeCount Then GoTo Failed
'
'      UnzipFile = True
'      Exit Function
'
'Failed:
'      UnzipFile = False
'  End Function
'    Private Function PowerShellQuote(ByVal value As String) As String
'      PowerShellQuote = "'" & Replace(value, "'", "''") & "'"
'  End Function
'
'  Private Sub EnsureFolderExists(ByVal folderPath As String, ByVal fso As Object)
'      If Not fso.FolderExists(folderPath) Then
'          fso.CreateFolder folderPath
'      End If
'  End Sub
'
'  Private Function WriteTextFile(ByVal filePath As String, ByVal fileText As String) As Boolean
'      Dim fso As Object
'      Dim ts As Object
'
'      On Error GoTo Failed
'
'      Set fso = CreateObject("Scripting.FileSystemObject")
'      Set ts = fso.CreateTextFile(filePath, True, False)
'
'      ts.Write fileText
'      ts.Close
'
'      WriteTextFile = True
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If Not ts Is Nothing Then ts.Close
'      WriteTextFile = False
'  End Function
'Private Sub ShowUpdateDetailsFromFile(ByVal filePath As String, _
'                                        ByVal detailsAddress As String)
'      Dim detailsText As String
'      Dim msg As String
'
'      If Not ReadUtf8TextFile(filePath, detailsText) Then Exit Sub
'
'      detailsText = CleanMultilineText(detailsText)
'
'      If detailsText = "" Then Exit Sub
'
'      msg = "������ ����������:" & vbCrLf & vbCrLf & _
'            detailsText & vbCrLf & vbCrLf & _
'            "���� ������ ������ ���������� �� ����� ��� ���� ���� �� �� ���� ��� ����� ����:" & vbCrLf & detailsAddress
'
'      MsgBox msg, vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "������ ����������"
'  End Sub
'  Private Function ReadUtf8TextFile(ByVal filePath As String, ByRef fileText As String) As Boolean
'      Dim stm As Object
'
'      On Error GoTo Failed
'
'      fileText = ""
'
'      Set stm = CreateObject("ADODB.Stream")
'      stm.Type = 2
'      stm.Charset = "utf-8"
'      stm.Open
'      stm.LoadFromFile filePath
'
'      fileText = stm.ReadText(-1)
'
'      stm.Close
'      Set stm = Nothing
'
'      ReadUtf8TextFile = True
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If Not stm Is Nothing Then stm.Close
'      Set stm = Nothing
'      fileText = ""
'      ReadUtf8TextFile = False
'  End Function
'
'  Private Function CleanMultilineText(ByVal s As String) As String
'      s = Replace(s, ChrW$(&HFEFF), "")
'      s = Replace(s, ChrW$(160), " ")
'      s = NormalizeLineBreaks(s)
'      s = Replace(s, vbLf, vbCrLf)
'
'      CleanMultilineText = Trim$(s)
'  End Function
'  ' =============================================================================
'  ' Summary UI
'  ' =============================================================================
'  Private Sub ShowUpdateSummary(ByVal replacedCount As Long, _
'                                ByVal addedCount As Long, _
'                                ByVal failedCount As Long, _
'                                ByVal failedItems As Collection, _
'                                ByVal selfUpdatePending As Boolean)
'      Dim msg As String
'      Dim i As Long
'
'      msg = "����� ������ ���:" & vbCrLf & vbCrLf & _
'            "���������: " & replacedCount & vbCrLf & _
'            "��������: " & addedCount & vbCrLf & _
'            "������: " & failedCount
'
'      If failedItems.count > 0 Then
'          msg = msg & vbCrLf & vbCrLf & "������ �����:" & vbCrLf
'          For i = 1 To failedItems.count
'              msg = msg & " - " & CStr(failedItems(i)) & vbCrLf
'          Next i
'      End If
'
'      If selfUpdatePending Then
'          msg = msg & vbCrLf & "���� ���� ���� �� �� ��� ����� ����� �����."
'      End If
'
'      MsgBox msg, vbInformation, "����� ���"
'  End Sub
'
'Private Function IsZipFile(ByVal filePath As String) As Boolean
'      Dim fileNum As Integer
'      Dim header As String
'
'      On Error GoTo Failed
'
'      If Dir(filePath) = "" Then Exit Function
'      If FileLen(filePath) < 4 Then Exit Function
'
'      fileNum = FreeFile
'      Open filePath For Binary Access Read As #fileNum
'      header = Space$(4)
'      Get #fileNum, , header
'      Close #fileNum
'
'      IsZipFile = (Left$(header, 2) = "PK")
'      Exit Function
'
'Failed:
'      On Error Resume Next
'      If fileNum <> 0 Then Close #fileNum
'      IsZipFile = False
'  End Function
Option Explicit

  ' =============================================================================
  ' ModUpdater
  ' Queue-based safe VBA component updater for Excel workbooks
  '
  ' GitHub expected structure:
  '
  ' updates/
  '   queue.txt
  '   packages/
  '     20261005_181500.zip
  '     20261005_181500.txt    optional update details
  '     20261007_093000.zip
  '     20261007_093000.txt
  '
  ' queue.txt format:
  '   20261005_181500
  '   20261007_093000
  '
  ' Notes:
  ' - Local version means: last successfully applied queued version.
  ' - Updates are applied in queue order.
  ' - If an update fails, the updater stops and does not continue.
  ' - If ModUpdater updates itself, the updater finalizes that change and asks the user
  '   to run the updater again for remaining queued updates. This avoids unsafe runtime replacement.
  ' =============================================================================

  Private Const UPDATER_MODULE_NAME As String = "ModUpdater"
  Private Const TEMP_SUFFIX As String = "_OLD_TEMP"

  Private Const INFO_SHEET_NAME As String = "�������"

  Private Const REMOTE_QUEUE_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/queue.txt"
  Private Const REMOTE_PACKAGE_BASE_URL As String = "https://raw.githubusercontent.com/aramserri/excel-vba-updates/main/updates/packages/"

  Private Const CACHE_FOLDER_NAME As String = "VBAUpdaterCache"
  Private Const LOCAL_VERSION_FILE_NAME As String = "version.txt"
  Private Const LOCAL_ZIP_FILE_NAME As String = "downloaded_update.zip"
  Private Const LOCAL_DETAILS_FILE_NAME As String = "update_details.txt"
  Private Const EXTRACT_FOLDER_NAME As String = "extracted"

  Private mSelfUpdatePending As Boolean

  ' =============================================================================
  ' Public Entry Points
  ' =============================================================================

  Public Sub RunVBAUpdater()
      Dim folderPath As String

      If Not HasVBProjectAccess() Then
          MsgBox "Trust access to the VBA project object model is not enabled." & vbCrLf & vbCrLf & _
                 "Please enable:" & vbCrLf & _
                 "Trust Center > Macro Settings > Trust access to the VBA project object model", _
                 vbCritical, "No VBA Access"
          Exit Sub
      End If

      folderPath = PickUpdateFolder()
      If folderPath = "" Then Exit Sub

      Call RunVBAUpdaterFromFolder(folderPath, True)
  End Sub

  Public Sub RunVBAUpdaterOnline()
      Dim fso As Object
      Dim cacheFolder As String
      Dim extractFolder As String
      Dim localVersionPath As String
      Dim localZipPath As String
      Dim localDetailsPath As String

      Dim queueText As String
      Dim queueLines() As String
      Dim localVersion As String
      Dim versionText As String
      Dim zipUrl As String
      Dim detailsUrl As String

      Dim i As Long
      Dim appliedCount As Long
      Dim foundNewUpdate As Boolean
      Dim updateOk As Boolean

      If Not HasVBProjectAccess() Then
          MsgBox "Trust access to the VBA project object model is not enabled." & vbCrLf & vbCrLf & _
                 "Please enable:" & vbCrLf & _
                 "Trust Center > Macro Settings > Trust access to the VBA project object model", _
                 vbCritical, "No VBA Access"
          Exit Sub
      End If

      Set fso = CreateObject("Scripting.FileSystemObject")

      cacheFolder = Environ$("LOCALAPPDATA") & "\" & CACHE_FOLDER_NAME
      extractFolder = cacheFolder & "\" & EXTRACT_FOLDER_NAME
      localVersionPath = cacheFolder & "\" & LOCAL_VERSION_FILE_NAME
      localZipPath = cacheFolder & "\" & LOCAL_ZIP_FILE_NAME
      localDetailsPath = cacheFolder & "\" & LOCAL_DETAILS_FILE_NAME

      EnsureFolderExists cacheFolder, fso

      queueText = ReadUrlText(REMOTE_QUEUE_URL)
      queueText = CleanMultilineText(queueText)

      If queueText = "" Then
          MsgBox "Could not read online update queue." & vbCrLf & vbCrLf & _
                 "URL used:" & vbCrLf & REMOTE_QUEUE_URL, _
                 vbExclamation, "Update Check Failed"
          Exit Sub
      End If

      If fso.FileExists(localVersionPath) Then
          If Not ReadTextFile(localVersionPath, localVersion) Then localVersion = ""
          localVersion = Trim$(localVersion)
      Else
          localVersion = ""
      End If

      queueText = NormalizeLineBreaks(queueText)
      queueLines = Split(queueText, vbLf)

      For i = LBound(queueLines) To UBound(queueLines)
          versionText = Trim$(queueLines(i))

          ' Allow blank lines and comment lines in queue.txt.
          If versionText <> "" And Left$(versionText, 1) <> "#" Then
              If VersionIsNewer(versionText, localVersion) Then
                  foundNewUpdate = True

                  zipUrl = REMOTE_PACKAGE_BASE_URL & versionText & ".zip"
                  detailsUrl = REMOTE_PACKAGE_BASE_URL & versionText & ".txt"

                  If fso.FileExists(localZipPath) Then
                      On Error Resume Next
                      fso.DeleteFile localZipPath, True
                      On Error GoTo 0
                  End If

                  If fso.FolderExists(extractFolder) Then
                      On Error Resume Next
                      fso.DeleteFolder extractFolder, True
                      On Error GoTo 0
                  End If

                  EnsureFolderExists extractFolder, fso

                  If Not DownloadUrlToFile(zipUrl, localZipPath) Then
                      MsgBox "Could not download update package." & vbCrLf & vbCrLf & _
                             "Version: " & versionText & vbCrLf & _
                             "URL:" & vbCrLf & zipUrl, _
                             vbExclamation, "Download Failed"
                      Exit Sub
                  End If

                  If Not IsZipFile(localZipPath) Then
                      MsgBox "Downloaded package is not a valid ZIP file." & vbCrLf & vbCrLf & _
                             "Version: " & versionText & vbCrLf & _
                             "File:" & vbCrLf & localZipPath, _
                             vbExclamation, "Invalid ZIP"
                      Exit Sub
                  End If

                  If Not UnzipFile(localZipPath, extractFolder) Then
                      MsgBox "Could not extract update package." & vbCrLf & vbCrLf & _
                             "Version: " & versionText, _
                             vbExclamation, "Extract Failed"
                      Exit Sub
                  End If

                  mSelfUpdatePending = False
                  updateOk = RunVBAUpdaterFromFolder(extractFolder, False)

                  If updateOk Then
                      WriteTextFile localVersionPath, versionText
                      localVersion = versionText
                      appliedCount = appliedCount + 1

                      If fso.FileExists(localDetailsPath) Then
                          On Error Resume Next
                          fso.DeleteFile localDetailsPath, True
                          On Error GoTo 0
                      End If

                      If DownloadUrlToFile(detailsUrl, localDetailsPath) Then
                          ShowUpdateDetailsFromFile localDetailsPath, detailsUrl
                      End If

                      If mSelfUpdatePending Then
                          Application.OnTime Now + TimeSerial(0, 0, 3), BuildOnTimeMacroName("FinalizeModUpdaterSelfUpdate")

                          MsgBox "Updater module was updated successfully." & vbCrLf & vbCrLf & _
                                 "Applied version: " & versionText & vbCrLf & vbCrLf & _
                                 "Please wait a few seconds, then run the online updater again to continue any remaining queued updates.", vbInformation, "Updater Self-Update"
                          Exit Sub
                      End If
                  Else
                      MsgBox "Update failed. Queue processing stopped." & vbCrLf & vbCrLf & _
                             "Failed version: " & versionText, _
                             vbExclamation, "Update Failed"
                      Exit Sub
                  End If
              End If
          End If
      Next i

      If Not foundNewUpdate Then
          MsgBox "No update needed." & vbCrLf & vbCrLf & _
                 "Current version: " & IIf(localVersion = "", "(none)", localVersion), _
                 vbInformation, "Updater"
      Else
          MsgBox "All queued updates completed successfully." & vbCrLf & vbCrLf & _
                 "Updates applied: " & appliedCount & vbCrLf & _
                 "Current version: " & localVersion, _
                 vbInformation, "Updater"
      End If
  End Sub

  ' =============================================================================
  ' Core Folder Updater
  ' =============================================================================

  Private Function RunVBAUpdaterFromFolder(ByVal folderPath As String, _
                                           Optional ByVal scheduleSelfFinalize As Boolean = True) As Boolean
      Dim fso As Object
      Dim fileMap As Object
      Dim failedItems As Collection
      Dim replacedCount As Long
      Dim addedCount As Long
      Dim failedCount As Long
      Dim selfUpdatePending As Boolean
      Dim key As Variant
      Dim filePath As String
      Dim existingComp As VBIDE.VBComponent

      RunVBAUpdaterFromFolder = False

      If Right$(folderPath, 1) <> "\" Then folderPath = folderPath & "\"

      Set fso = CreateObject("Scripting.FileSystemObject")

      If Not fso.FolderExists(folderPath) Then
          MsgBox "Update folder not found:" & vbCrLf & folderPath, vbExclamation, "Error"
          Exit Function
      End If

      Set failedItems = New Collection
      Set fileMap = BuildUpdateFileMap(folderPath, fso, failedItems, failedCount)

      If fileMap Is Nothing Or fileMap.count = 0 Then
          MsgBox "No updateable VBA files found." & vbCrLf & _
                 "Allowed files: .bas, .cls, .frm", _
                 vbExclamation, "No Files"
          Exit Function
      End If

      For Each key In fileMap.Keys
          filePath = CStr(fileMap(key))
          Set existingComp = GetComponentByName(CStr(key))

          If existingComp Is Nothing Then
              If AddNewComponentFromFile(filePath, CStr(key), failedItems) Then
                  addedCount = addedCount + 1
              Else
                  failedCount = failedCount + 1
              End If

          ElseIf existingComp.Type = vbext_ct_Document Then
              If UpdateDocumentModuleFromFile(existingComp, filePath, failedItems) Then
                  replacedCount = replacedCount + 1
              Else
                  failedCount = failedCount + 1
              End If

          ElseIf StrComp(existingComp.Name, UPDATER_MODULE_NAME, vbTextCompare) = 0 Then
              If ReplaceSelfUpdater(existingComp, filePath, failedItems) Then
                  replacedCount = replacedCount + 1
                  selfUpdatePending = True
                  mSelfUpdatePending = True
              Else
                  failedCount = failedCount + 1
              End If

          Else
              If ReplaceComponentSafely(existingComp, filePath, CStr(key), failedItems) Then
                  replacedCount = replacedCount + 1
              Else
                  failedCount = failedCount + 1
              End If
          End If

          Set existingComp = Nothing
      Next key

      ApplyCellUpdateFile folderPath, fso, failedItems, failedCount

      ShowUpdateSummary replacedCount, addedCount, failedCount, failedItems, selfUpdatePending

      If selfUpdatePending And scheduleSelfFinalize Then
          Application.OnTime Now + TimeSerial(0, 0, 3), BuildOnTimeMacroName("FinalizeModUpdaterSelfUpdate")
      End If

      RunVBAUpdaterFromFolder = (failedCount = 0)
  End Function

  ' =============================================================================
  ' File Map
  ' =============================================================================

  Private Function BuildUpdateFileMap(ByVal folderPath As String, _
                                      ByVal fso As Object, _
                                      ByRef failedItems As Collection, _
                                      ByRef failedCount As Long) As Object
      Dim result As Object
      Dim folderObj As Object
      Dim fileObj As Object
      Dim baseName As String
      Dim ext As String
      Dim frxPath As String

      Set result = CreateObject("Scripting.Dictionary")
      result.CompareMode = vbTextCompare

      Set folderObj = fso.GetFolder(folderPath)

      For Each fileObj In folderObj.files
          ext = LCase$(fso.GetExtensionName(fileObj.Name))

          Select Case ext
              Case "bas", "cls"
                  baseName = fso.GetBaseName(fileObj.Name)

                  If result.exists(baseName) Then
                      failedCount = failedCount + 1
                      failedItems.Add "��� ʘ���� ���� ��� VBA: " & fileObj.Name
                  Else
                      result.Add baseName, fileObj.path
                  End If

              Case "frm"
                  baseName = fso.GetBaseName(fileObj.Name)

                  If result.exists(baseName) Then
                      failedCount = failedCount + 1
                      failedItems.Add "��� ʘ���� ���� ���: " & fileObj.Name
                  Else
                      frxPath = folderPath & baseName & ".frx"
                      If Not fso.FileExists(frxPath) Then
                          failedCount = failedCount + 1
                          failedItems.Add "���� .frx ���� ��� ���� ���: " & fileObj.Name
                      Else
                          result.Add baseName, fileObj.path
                      End If
                  End If
          End Select
      Next fileObj

      Set BuildUpdateFileMap = result
  End Function

  ' =============================================================================
  ' Component Operations
  ' =============================================================================

  Private Function GetComponentByName(ByVal compName As String) As VBIDE.VBComponent
      On Error Resume Next
      Set GetComponentByName = ThisWorkbook.VBProject.VBComponents(compName)
      On Error GoTo 0
  End Function

  Private Function AddNewComponentFromFile(ByVal filePath As String, _
                                           ByVal expectedName As String, _
                                           ByRef failedItems As Collection) As Boolean
      Dim importedComp As VBIDE.VBComponent
      Dim errText As String

      AddNewComponentFromFile = ImportComponentValidated(filePath, expectedName, importedComp, errText)

      If Not AddNewComponentFromFile Then
          failedItems.Add "��� �� ����� ���� '" & expectedName & "': " & errText
      End If

      Set importedComp = Nothing
  End Function

  Private Function ReplaceComponentSafely(ByVal oldComp As VBIDE.VBComponent, _
                                          ByVal filePath As String, _
                                          ByVal expectedName As String, _
                                          ByRef failedItems As Collection) As Boolean
      Dim oldName As String
      Dim tempName As String
      Dim newComp As VBIDE.VBComponent
      Dim errText As String

      ReplaceComponentSafely = False

      oldName = oldComp.Name
      tempName = oldName & TEMP_SUFFIX

      If Not EnsureTempNameFree(tempName, failedItems) Then Exit Function

      On Error Resume Next
      oldComp.Name = tempName
      If Err.Number <> 0 Then
          failedItems.Add "��� �� ����� ��� ���� '" & oldName & "': " & Err.description
          Err.Clear
          On Error GoTo 0
          Exit Function
      End If
      On Error GoTo 0

      If ImportComponentValidated(filePath, expectedName, newComp, errText) Then
          On Error Resume Next
          ThisWorkbook.VBProject.VBComponents.Remove oldComp
          If Err.Number <> 0 Then
              failedItems.Add "���� ���� '" & expectedName & "' ���� �� ��� ��� ���� ����� ������ ���: " & Err.description
              Err.Clear
              On Error GoTo 0
              Exit Function
          End If
          On Error GoTo 0

          ReplaceComponentSafely = True
      Else
          On Error Resume Next
          oldComp.Name = oldName
          On Error GoTo 0

          failedItems.Add "��� �� ������� '" & expectedName & "': " & errText
      End If

      Set newComp = Nothing
  End Function

  Private Function ReplaceSelfUpdater(ByVal oldComp As VBIDE.VBComponent, _
                                      ByVal filePath As String, _
                                      ByRef failedItems As Collection) As Boolean
      Dim tempName As String
      Dim newComp As VBIDE.VBComponent
      Dim errText As String

      ReplaceSelfUpdater = False

      tempName = UPDATER_MODULE_NAME & TEMP_SUFFIX

      If Not EnsureTempNameFree(tempName, failedItems) Then Exit Function

      On Error Resume Next
      oldComp.Name = tempName
      If Err.Number <> 0 Then
          failedItems.Add "��� �� ����� ��� ���� ����: " & Err.description
          Err.Clear
          On Error GoTo 0
          Exit Function
      End If
      On Error GoTo 0

      If ImportComponentValidated(filePath, UPDATER_MODULE_NAME, newComp, errText) Then
          ReplaceSelfUpdater = True
      Else
          On Error Resume Next
          oldComp.Name = UPDATER_MODULE_NAME
          On Error GoTo 0

          failedItems.Add "��� �� ���������? ���� ����: " & errText
      End If

      Set newComp = Nothing
  End Function

  Public Sub FinalizeModUpdaterSelfUpdate()
      Dim oldComp As VBIDE.VBComponent

      On Error Resume Next
      Set oldComp = ThisWorkbook.VBProject.VBComponents(UPDATER_MODULE_NAME & TEMP_SUFFIX)

      If oldComp Is Nothing Then
          MsgBox "�ǎ�� ���� ���� ���� ��� ���� ���.", vbExclamation, "�����"
          Exit Sub
      End If

      ThisWorkbook.VBProject.VBComponents.Remove oldComp
      If Err.Number <> 0 Then
          MsgBox "��� �� ��� ���� ����� ����:" & vbCrLf & Err.description, vbExclamation, "�����"
          Err.Clear
          On Error GoTo 0
          Exit Sub
      End If
      On Error GoTo 0

      MsgBox "���� �� ������ ���������? ��.", vbInformation, "����"
  End Sub

  Private Function UpdateDocumentModuleFromFile(ByVal targetComp As VBIDE.VBComponent, _
                                                ByVal filePath As String, _
                                                ByRef failedItems As Collection) As Boolean
      Dim fileText As String
      Dim newCode As String
      Dim oldCode As String
      Dim writeErr As String

      UpdateDocumentModuleFromFile = False

      If Not ReadTextFile(filePath, fileText) Then
          failedItems.Add "��� �� ������ ���� �ǎ�� ���: " & filePath
          Exit Function
      End If

      newCode = ExtractCodeBodyFromExport(fileText)

      With targetComp.codeModule
          If .CountOfLines > 0 Then
              oldCode = .lines(1, .CountOfLines)
          Else
              oldCode = ""
          End If
      End With

      On Error Resume Next
      With targetComp.codeModule
          If .CountOfLines > 0 Then .DeleteLines 1, .CountOfLines
          If Len(newCode) > 0 Then .InsertLines 1, newCode
      End With

      If Err.Number <> 0 Then
          writeErr = Err.description
          Err.Clear

          On Error Resume Next
          With targetComp.codeModule
              If .CountOfLines > 0 Then .DeleteLines 1, .CountOfLines
              If Len(oldCode) > 0 Then .InsertLines 1, oldCode
          End With
          On Error GoTo 0

          failedItems.Add "��� �� ������� �� �ǎ�� ��� '" & targetComp.Name & "': " & writeErr
          Exit Function
      End If
      On Error GoTo 0

      UpdateDocumentModuleFromFile = True
  End Function

  Private Function ImportComponentValidated(ByVal filePath As String, _
                                            ByVal expectedName As String, _
                                            ByRef importedComp As VBIDE.VBComponent, _
                                            ByRef errText As String) As Boolean
      Dim actualName As String

      ImportComponentValidated = False
      errText = ""

      On Error Resume Next
      Set importedComp = ThisWorkbook.VBProject.VBComponents.Import(filePath)

      If Err.Number <> 0 Or importedComp Is Nothing Then
          errText = Err.description
          Err.Clear
          On Error GoTo 0
          Exit Function
      End If
      On Error GoTo 0

      actualName = importedComp.Name

      If StrComp(actualName, expectedName, vbTextCompare) <> 0 Then
          On Error Resume Next
          importedComp.Name = expectedName

          If Err.Number <> 0 Then
              errText = "��� ��� ������� �� ��� ���� ���� ����. ��� ����: " & _
                        actualName & " / ��� ���� ������: " & expectedName & _
                        " / ���: " & Err.description
              Err.Clear

              On Error Resume Next
              ThisWorkbook.VBProject.VBComponents.Remove importedComp
              On Error GoTo 0

              Set importedComp = Nothing
              Exit Function
          End If
          On Error GoTo 0
      End If

      ImportComponentValidated = True
  End Function

  ' =============================================================================
  ' Cell Update
  ' =============================================================================

  Private Sub ApplyCellUpdateFile(ByVal folderPath As String, _
                                  ByVal fso As Object, _
                                  ByRef failedItems As Collection, _
                                  ByRef failedCount As Long)
      Dim filePath As String
      Dim fileText As String
      Dim lines() As String
      Dim cellAddr As String
      Dim cellVal As String
      Dim i As Long
      Dim ws As Worksheet
      Dim targetCell As Range
      Dim answer As VbMsgBoxResult

      filePath = folderPath & "cell_update.txt"
      If Not fso.FileExists(filePath) Then Exit Sub

      If Not ReadTextFile(filePath, fileText) Then
          failedCount = failedCount + 1
          failedItems.Add "������ cell_update.txt ������ ���."
          Exit Sub
      End If

      fileText = NormalizeLineBreaks(fileText)
      lines = Split(fileText, vbLf)

      If UBound(lines) < 1 Then
          failedCount = failedCount + 1
          failedItems.Add "cell_update.txt ���� ����� �� �� ����� ����."
          Exit Sub
      End If

      cellAddr = CleanString(lines(0))
      cellVal = ""

      For i = 1 To UBound(lines)
          If i = 1 Then
              cellVal = lines(i)
          Else
              cellVal = cellVal & vbCrLf & lines(i)
          End If
      Next i

      cellVal = CleanString(cellVal)

      If cellAddr = "" Or cellVal = "" Then
          failedCount = failedCount + 1
          failedItems.Add "������ cell_update.txt ���� ���."
          Exit Sub
      End If

      On Error Resume Next
      Set ws = ThisWorkbook.Worksheets(INFO_SHEET_NAME)
      On Error GoTo 0

      If ws Is Nothing Then
          failedCount = failedCount + 1
          failedItems.Add "��� '" & INFO_SHEET_NAME & "' ���� cell_update.txt ���� ���."
          Exit Sub
      End If

      On Error Resume Next
      Set targetCell = ws.Range(cellAddr)
      On Error GoTo 0

      If targetCell Is Nothing Then
          failedCount = failedCount + 1
          failedItems.Add "���� ���� ������� �� cell_update.txt: " & cellAddr
          Exit Sub
      End If

      If Trim$(CStr(targetCell.value)) <> "" Then
          answer = MsgBox("���� " & cellAddr & " �� ��� ����� ����." & vbCrLf & vbCrLf & _
                          "����� ����:" & vbCrLf & CStr(targetCell.value) & vbCrLf & vbCrLf & _
                          "����� ����:" & vbCrLf & cellVal & vbCrLf & vbCrLf & _
                          "��� ������ ��Ͽ", _
                          vbYesNo + vbQuestion, "����� �������")
          If answer = vbNo Then Exit Sub
      End If

      On Error Resume Next
      If Left$(cellVal, 1) = "=" Then
          targetCell.FormulaLocal = cellVal
          If Err.Number <> 0 Then
              Err.Clear
              targetCell.Formula = cellVal
              If Err.Number <> 0 Then
                  Err.Clear
                  targetCell.value = cellVal
              End If
          End If
      Else
          targetCell.value = cellVal
      End If

      If Err.Number <> 0 Then
          failedCount = failedCount + 1
          failedItems.Add "��� �� ����� �� ���� " & cellAddr & ": " & Err.description
          Err.Clear
      End If
      On Error GoTo 0
  End Sub

  ' =============================================================================
  ' Download / ZIP Helpers
  ' =============================================================================

  Private Function ReadUrlText(ByVal url As String) As String
      Dim tempPath As String
      Dim fso As Object

      tempPath = Environ$("TEMP") & "\vba_url_text_" & Format$(Now, "yyyymmddhhnnss") & "_" & CStr(Int(Rnd() * 100000)) & ".txt"

      If Not DownloadUrlToFile(url, tempPath) Then
          ReadUrlText = ""
          Exit Function
      End If

      If Not ReadUtf8TextFile(tempPath, ReadUrlText) Then
          If Not ReadTextFile(tempPath, ReadUrlText) Then ReadUrlText = ""
      End If

      On Error Resume Next
      Set fso = CreateObject("Scripting.FileSystemObject")
      If fso.FileExists(tempPath) Then fso.DeleteFile tempPath, True
      On Error GoTo 0
  End Function

  Private Function DownloadUrlToFile(ByVal url As String, ByVal filePath As String) As Boolean
      Dim fso As Object
      Dim wsh As Object
      Dim cmd As String
      Dim exitCode As Long

      On Error GoTo Failed

      Set fso = CreateObject("Scripting.FileSystemObject")
      Set wsh = CreateObject("WScript.Shell")

      If fso.FileExists(filePath) Then fso.DeleteFile filePath, True

      cmd = "cmd.exe /c curl.exe -k -L -f -s -S -o " & CmdQuote(filePath) & " " & CmdQuote(url)
      exitCode = wsh.Run(cmd, 0, True)

      If exitCode <> 0 Then GoTo Failed
      If Not fso.FileExists(filePath) Then GoTo Failed
      If fso.GetFile(filePath).Size = 0 Then GoTo Failed

      DownloadUrlToFile = True
      Exit Function

Failed:
      DownloadUrlToFile = False
  End Function

  Private Function UnzipFile(ByVal zipPath As String, ByVal destFolder As String) As Boolean
      Dim fso As Object
      Dim wsh As Object
      Dim cmd As String
      Dim exitCode As Long
      Dim afterCount As Long

      On Error GoTo Failed

      Set fso = CreateObject("Scripting.FileSystemObject")
      Set wsh = CreateObject("WScript.Shell")

      If Not fso.FileExists(zipPath) Then GoTo Failed
      If Not fso.FolderExists(destFolder) Then fso.CreateFolder destFolder

      cmd = "cmd.exe /c tar.exe -xf " & CmdQuote(zipPath) & " -C " & CmdQuote(destFolder)
      exitCode = wsh.Run(cmd, 0, True)
      If exitCode <> 0 Then GoTo Failed

      afterCount = fso.GetFolder(destFolder).files.count
      If afterCount = 0 Then GoTo Failed

      UnzipFile = True
      Exit Function

Failed:
      UnzipFile = False
  End Function

  Private Function IsZipFile(ByVal filePath As String) As Boolean
      Dim fileNum As Integer
      Dim header As String

      On Error GoTo Failed

      If Dir(filePath) = "" Then Exit Function
      If FileLen(filePath) < 4 Then Exit Function

      fileNum = FreeFile
      Open filePath For Binary Access Read As #fileNum
      header = Space$(4)
      Get #fileNum, , header
      Close #fileNum

      IsZipFile = (Left$(header, 2) = "PK")
      Exit Function

Failed:
      On Error Resume Next
      If fileNum <> 0 Then Close #fileNum
      IsZipFile = False
  End Function

  ' =============================================================================
  ' Text / General Helpers
  ' =============================================================================

  Private Function VersionIsNewer(ByVal remoteVersion As String, ByVal localVersion As String) As Boolean
      remoteVersion = Trim$(remoteVersion)
      localVersion = Trim$(localVersion)

      If remoteVersion = "" Then
          VersionIsNewer = False
      ElseIf localVersion = "" Then
          VersionIsNewer = True
      Else
          VersionIsNewer = (StrComp(remoteVersion, localVersion, vbTextCompare) > 0)
      End If
  End Function

  Private Function HasVBProjectAccess() As Boolean
      Dim n As Long

      On Error Resume Next
      n = ThisWorkbook.VBProject.VBComponents.count
      HasVBProjectAccess = (Err.Number = 0)
      Err.Clear
      On Error GoTo 0
  End Function

  Private Function EnsureTempNameFree(ByVal tempName As String, ByRef failedItems As Collection) As Boolean
      EnsureTempNameFree = False

      If GetComponentByName(tempName) Is Nothing Then
          EnsureTempNameFree = True
      Else
          failedItems.Add "��� ���� �� ��� �� ���� ���� ����: " & tempName
      End If
  End Function

  Private Function ReadTextFile(ByVal filePath As String, ByRef fileText As String) As Boolean
      Dim fso As Object
      Dim ts As Object

      ReadTextFile = False
      fileText = ""

      On Error Resume Next
      Set fso = CreateObject("Scripting.FileSystemObject")
      If Not fso.FileExists(filePath) Then
          On Error GoTo 0
          Exit Function
      End If

      Set ts = fso.OpenTextFile(filePath, 1, False)
      If Err.Number <> 0 Then
          Err.Clear
          On Error GoTo 0
          Exit Function
      End If

      fileText = ts.ReadAll
      ts.Close

      On Error GoTo 0
      ReadTextFile = True
  End Function

  Private Function WriteTextFile(ByVal filePath As String, ByVal fileText As String) As Boolean
      Dim fso As Object
      Dim ts As Object

      On Error GoTo Failed

      Set fso = CreateObject("Scripting.FileSystemObject")
      Set ts = fso.CreateTextFile(filePath, True, False)

      ts.Write fileText
      ts.Close

      WriteTextFile = True
      Exit Function

Failed:
      On Error Resume Next
      If Not ts Is Nothing Then ts.Close
      WriteTextFile = False
  End Function

  Private Function ReadUtf8TextFile(ByVal filePath As String, ByRef fileText As String) As Boolean
      Dim stm As Object

      On Error GoTo Failed

      fileText = ""

      Set stm = CreateObject("ADODB.Stream")
      stm.Type = 2
      stm.Charset = "utf-8"
      stm.Open
      stm.LoadFromFile filePath

      fileText = stm.ReadText(-1)

      stm.Close
      Set stm = Nothing

      ReadUtf8TextFile = True
      Exit Function

Failed:
      On Error Resume Next
      If Not stm Is Nothing Then stm.Close
      Set stm = Nothing
      fileText = ""
      ReadUtf8TextFile = False
  End Function

  Private Function NormalizeLineBreaks(ByVal s As String) As String
      s = Replace(s, vbCrLf, vbLf)
      s = Replace(s, vbCr, vbLf)
      NormalizeLineBreaks = s
  End Function

  Private Function CleanString(ByVal s As String) As String
      Dim i As Long
      Dim ch As String
      Dim code As Long
      Dim result As String

      s = Replace(s, ChrW$(&HFEFF), "")
      s = Replace(s, ChrW$(160), " ")

      result = ""
      For i = 1 To Len(s)
          ch = Mid$(s, i, 1)
          code = AscW(ch)

          If code = 9 Or code >= 32 Then result = result & ch
      Next i

      CleanString = Trim$(result)
  End Function

  Private Function CleanMultilineText(ByVal s As String) As String
      s = Replace(s, ChrW$(&HFEFF), "")
      s = Replace(s, ChrW$(160), " ")
      s = NormalizeLineBreaks(s)
      s = Replace(s, vbLf, vbCrLf)

      CleanMultilineText = Trim$(s)
  End Function

  Private Function ExtractCodeBodyFromExport(ByVal fullText As String) As String
      Dim lines() As String
      Dim i As Long
      Dim j As Long
      Dim startLine As Long
      Dim currentLine As String
      Dim isHeaderLine As Boolean
      Dim codeLines() As String

      fullText = NormalizeLineBreaks(fullText)
      lines = Split(fullText, vbLf)
      startLine = 0

      For i = 0 To UBound(lines)
          currentLine = Trim$(lines(i))
          isHeaderLine = False

          If currentLine = "" Then isHeaderLine = True
          If UCase$(Left$(currentLine, 7)) = "VERSION" Then isHeaderLine = True
          If UCase$(currentLine) = "BEGIN" Then isHeaderLine = True
          If UCase$(currentLine) = "END" Then isHeaderLine = True
          If UCase$(Left$(currentLine, 9)) = "MULTIUSE " Then isHeaderLine = True
          If UCase$(Left$(currentLine, 9)) = "MULTIUSE=" Then isHeaderLine = True
          If UCase$(Left$(currentLine, 9)) = "ATTRIBUTE" Then isHeaderLine = True

          If isHeaderLine Then
              startLine = i + 1
          Else
              Exit For
          End If
      Next i

      If startLine > UBound(lines) Then
          ExtractCodeBodyFromExport = ""
          Exit Function
      End If

      ReDim codeLines(0 To UBound(lines) - startLine)
      For j = 0 To UBound(codeLines)
          codeLines(j) = lines(startLine + j)
      Next j

      ExtractCodeBodyFromExport = Join(codeLines, vbCrLf)
  End Function

  Private Function BuildOnTimeMacroName(ByVal procName As String) As String
      BuildOnTimeMacroName = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & procName
  End Function

  Private Function CmdQuote(ByVal value As String) As String
      CmdQuote = Chr$(34) & Replace(value, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
  End Function

  Private Sub EnsureFolderExists(ByVal folderPath As String, ByVal fso As Object)
      If Not fso.FolderExists(folderPath) Then fso.CreateFolder folderPath
  End Sub

  Private Function PickUpdateFolder() As String
      Dim dlg As FileDialog

      Set dlg = Application.FileDialog(msoFileDialogFolderPicker)

      With dlg
          .Title = "���� ���� ������� VBA �� ������ ����"
          If .Show <> -1 Then
              PickUpdateFolder = ""
              Exit Function
          End If

          PickUpdateFolder = .selectedItems(1)
          If Right$(PickUpdateFolder, 1) <> "\" Then PickUpdateFolder = PickUpdateFolder & "\"
      End With
  End Function

  Private Sub ShowUpdateDetailsFromFile(ByVal filePath As String, ByVal detailsAddress As String)
      Dim detailsText As String
      Dim msg As String

      If Not ReadUtf8TextFile(filePath, detailsText) Then Exit Sub

      detailsText = CleanMultilineText(detailsText)
      If detailsText = "" Then Exit Sub

      msg = "������ ����������:" & vbCrLf & vbCrLf & _
            detailsText & vbCrLf & vbCrLf & _
            "���� ������:" & vbCrLf & detailsAddress

      MsgBox msg, vbInformation + vbMsgBoxRight + vbMsgBoxRtlReading, "������ ����������"
  End Sub

  Private Sub ShowUpdateSummary(ByVal replacedCount As Long, _
                                ByVal addedCount As Long, _
                                ByVal failedCount As Long, _
                                ByVal failedItems As Collection, _
                                ByVal selfUpdatePending As Boolean)
      Dim msg As String
      Dim i As Long

      msg = "����� ������ ���:" & vbCrLf & vbCrLf & _
            "���������: " & replacedCount & vbCrLf & _
            "��������: " & addedCount & vbCrLf & _
            "������: " & failedCount

      If failedItems.count > 0 Then
          msg = msg & vbCrLf & vbCrLf & "������ �����:" & vbCrLf
          For i = 1 To failedItems.count
              msg = msg & " - " & CStr(failedItems(i)) & vbCrLf
          Next i
      End If

      If selfUpdatePending Then
          msg = msg & vbCrLf & vbCrLf & "���� ���� ���� �� �� ��� ����� ����� �����."
      End If

      MsgBox msg, vbInformation, "����� ���"
  End Sub

