Attribute VB_Name = "exportnames"
Option Explicit

Sub ShowNamedRangesManager()
    frmexportnames.Show
End Sub

