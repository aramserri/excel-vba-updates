VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmInsurancePayment 
   Caption         =   "��� ������ ���� ��"
   ClientHeight    =   2863
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   4305
   OleObjectBlob   =   "frmInsurancePayment.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmInsurancePayment"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False




'=====================================================
' UserForm: frmInsurancePayment (Payment Entry - WITH PRE-FILL)
'=====================================================
Option Explicit

Private WithEvents m_btnSave As MSForms.CommandButton
Attribute m_btnSave.VB_VarHelpID = -1
Private WithEvents m_btnCancel As MSForms.CommandButton
Attribute m_btnCancel.VB_VarHelpID = -1
Private WithEvents m_btnPickDate As MSForms.CommandButton
Attribute m_btnPickDate.VB_VarHelpID = -1
Private WithEvents m_txtPaymentAmount As MSForms.TextBox
Attribute m_txtPaymentAmount.VB_VarHelpID = -1
Private WithEvents m_cboYearPay As MSForms.ComboBox
Attribute m_cboYearPay.VB_VarHelpID = -1
Private WithEvents m_cboMonthPay As MSForms.ComboBox
Attribute m_cboMonthPay.VB_VarHelpID = -1

Public targetYear As String
Public targetMonth As String
Public InsuranceTypes As Collection
Public userCenters As Long
Public totalCenters As Long

' Pre-fill support
Public PreSelectedInsuranceIndex As Long
Public PreFilledAmount As Double

Private m_Initialized As Boolean

Private Sub UserForm_Initialize()
    Me.Caption = "��� ������ ����"
    Me.Width = 550
    Me.Height = 300
    m_Initialized = False
    PreSelectedInsuranceIndex = 0
    PreFilledAmount = 0
End Sub

Private Sub UserForm_Activate()
    If m_Initialized Then Exit Sub
    m_Initialized = True
    
    If targetYear = "" Or targetMonth = "" Then
        MsgBox "���: ��� �� ��� ���� ���� ���.", vbCritical
        Unload Me
        Exit Sub
    End If
    
    If InsuranceTypes Is Nothing Then
        MsgBox "���: ���� ���� �� ���� ���� ���.", vbCritical
        Unload Me
        Exit Sub
    End If
    
    Dim i As Long
    Dim topPos As Single: topPos = 15
    Dim lbl As MSForms.Label
    Dim formWidth As Single: formWidth = Me.InsideWidth
    
    ' ========== Insurance Type ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsType", True)
    With lbl
        .Caption = ":��� ����"
        .Top = topPos + 4
        .Left = formWidth - 70
        .Width = 60
        .TextAlign = fmTextAlignLeft
    End With
    
    Dim cboInsurance As MSForms.ComboBox
    Set cboInsurance = Me.Controls.Add("Forms.ComboBox.1", "cboInsurance", True)
    With cboInsurance
        .Top = topPos
        .Left = 10
        .Width = formWidth - 90
        .Font.Name = "Tahoma"
        .Font.Size = 10
        .Style = fmStyleDropDownList
        .ListWidth = formWidth + 50
        .TextAlign = fmTextAlignCenter
    End With
    
    For i = 1 To InsuranceTypes.count
        cboInsurance.AddItem InsuranceTypes(i)
    Next i
    If cboInsurance.ListCount > 0 Then cboInsurance.listIndex = 0
    
    topPos = topPos + 35
    
    ' ========== Payment Date ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblDate", True)
    With lbl
        .Caption = ":����� ������"
        .Top = topPos + 4
        .Left = formWidth - 80
        .Width = 70
        .TextAlign = fmTextAlignLeft
    End With
    
    Dim txtDay As MSForms.TextBox
    Set txtDay = Me.Controls.Add("Forms.TextBox.1", "txtPayDay", True)
    With txtDay
        .Top = topPos
        .Left = 10
        .Width = 40
        .TextAlign = fmTextAlignCenter
        .Font.Name = "Tahoma"
        .Font.Size = 10
    End With
    
    Set m_btnPickDate = Me.Controls.Add("Forms.CommandButton.1", "btnPickDate", True)
    With m_btnPickDate
        .Caption = "..."
        .Top = topPos
        .Left = 55
        .Width = 25
        .Height = 22
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSlash1", True)
    With lbl
        .Caption = "/"
        .Top = topPos + 4
        .Left = 85
        .Width = 10
    End With
    
    Set m_cboMonthPay = Me.Controls.Add("Forms.ComboBox.1", "cboMonthPay", True)
    With m_cboMonthPay
        .Top = topPos
        .Left = 95
        .Width = 45
        .Font.Name = "Tahoma"
        .Font.Size = 10
        .Style = fmStyleDropDownList
    End With
    For i = 1 To 12
        m_cboMonthPay.AddItem Format(i, "00")
    Next i
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSlash2", True)
    With lbl
        .Caption = "/"
        .Top = topPos + 4
        .Left = 145
        .Width = 10
    End With
    
    Set m_cboYearPay = Me.Controls.Add("Forms.ComboBox.1", "cboYearPay", True)
    With m_cboYearPay
        .Top = topPos
        .Left = 155
        .Width = 60
        .Font.Name = "Tahoma"
        .Font.Size = 10
        .Style = fmStyleDropDownList
    End With
    
    Dim currentYear As Long
    On Error Resume Next
    currentYear = val(ThisWorkbook.Sheets("�������").Range("AC1").value)
    On Error GoTo 0
    If currentYear = 0 Then currentYear = 1404
    
    For i = currentYear - 3 To currentYear + 1
        m_cboYearPay.AddItem CStr(i)
    Next i
    
    Dim defaultYear As Long, defaultMonth As Long, defaultDay As Long
    On Error Resume Next
    defaultYear = val(ThisWorkbook.Sheets("�������").Range("AC1").value)
    defaultMonth = val(ThisWorkbook.Sheets("�������").Range("AC2").value)
    defaultDay = val(ThisWorkbook.Sheets("�������").Range("AE1").value)
    On Error GoTo 0
    
    If defaultYear = 0 Then defaultYear = 1404
    If defaultMonth = 0 Then defaultMonth = 1
    If defaultDay = 0 Then defaultDay = 1
    
    m_cboYearPay.value = CStr(defaultYear)
    m_cboMonthPay.value = Format(defaultMonth, "00")
    Me.Controls("txtPayDay").value = Format(defaultDay, "00")
    
    topPos = topPos + 35
    
    ' ========== Payment Amount ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblAmount", True)
    With lbl
        .Caption = ":���� �������"
        .Top = topPos + 4
        .Left = formWidth - 80
        .Width = 70
        .TextAlign = fmTextAlignLeft
    End With
    
    Set m_txtPaymentAmount = Me.Controls.Add("Forms.TextBox.1", "txtPaymentAmount", True)
    With m_txtPaymentAmount
        .Top = topPos
        .Left = 10
        .Width = 150
        .TextAlign = fmTextAlignCenter
        .Font.Name = "Tahoma"
        .Font.Size = 10
    End With
    
    topPos = topPos + 35
    
    ' ========== Description ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblDesc", True)
    With lbl
        .Caption = ":�������"
        .Top = topPos + 4
        .Left = formWidth - 70
        .Width = 60
        .TextAlign = fmTextAlignLeft
    End With
    
    Dim txtDesc As MSForms.TextBox
    Set txtDesc = Me.Controls.Add("Forms.TextBox.1", "txtDescription", True)
    With txtDesc
        .Top = topPos
        .Left = 10
        .Width = formWidth - 90
        .Font.Name = "Tahoma"
        .Font.Size = 10
        .TextAlign = fmTextAlignRight
    End With
    
    topPos = topPos + 45
    
    ' ========== Buttons ==========
    Set m_btnSave = Me.Controls.Add("Forms.CommandButton.1", "btnSave", True)
    With m_btnSave
        .Caption = "����� ������"
        .Top = topPos
        .Left = formWidth - 120
        .Width = 100
        .Height = 30
    End With
    
    Set m_btnCancel = Me.Controls.Add("Forms.CommandButton.1", "btnCancel", True)
    With m_btnCancel
        .Caption = "������"
        .Top = topPos
        .Left = formWidth - 230
        .Width = 100
        .Height = 30
    End With
    
    ' ========== APPLY PRE-FILL VALUES ==========
    ' Pre-select insurance if specified
    If PreSelectedInsuranceIndex > 0 Then
        If PreSelectedInsuranceIndex <= cboInsurance.ListCount Then
            cboInsurance.listIndex = PreSelectedInsuranceIndex - 1
        End If
    End If
    
    ' Pre-fill amount if specified
    If PreFilledAmount > 0 Then
        m_txtPaymentAmount.value = Format(PreFilledAmount, "#,##0")
    End If
End Sub

' ... rest of the code remains the same (all event handlers and helper functions) ...

Private Sub m_txtPaymentAmount_AfterUpdate()
    Call FormatAmountTextBox
End Sub

Private Sub m_txtPaymentAmount_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Call FormatAmountTextBox
End Sub

Private Sub m_txtPaymentAmount_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Or KeyCode = vbKeyTab Then
        Call FormatAmountTextBox
    End If
End Sub

Private Sub FormatAmountTextBox()
    If m_txtPaymentAmount Is Nothing Then Exit Sub
    
    Dim rawValue As String
    Dim cleanValue As String
    
    rawValue = Trim(m_txtPaymentAmount.value)
    If rawValue = "" Then Exit Sub
    
    cleanValue = Replace(rawValue, ",", "")
    cleanValue = Replace(cleanValue, " ", "")
    cleanValue = ConvertPersianNumsToEnglish(cleanValue)
    
    If IsNumeric(cleanValue) Then
        m_txtPaymentAmount.value = Format(CDbl(cleanValue), "#,##0")
    End If
End Sub

Private Sub m_btnPickDate_Click()
    On Error Resume Next
    
    Dim payYear As Long, payMonth As Long
    payYear = val(m_cboYearPay.value)
    payMonth = val(m_cboMonthPay.value)
    
    frmDayPicker.currentYear = payYear
    frmDayPicker.currentMonth = payMonth
    frmDayPicker.selectedDay = ""
    
    frmDayPicker.Show vbModal
    
    If frmDayPicker.selectedDay <> "" Then
        Me.Controls("txtPayDay").value = Format(val(frmDayPicker.selectedDay), "00")
    End If
    
    On Error GoTo 0
End Sub

Private Sub m_cboYearPay_Change()
    ValidateDay
End Sub

Private Sub m_cboMonthPay_Change()
    ValidateDay
End Sub

Private Sub ValidateDay()
    On Error Resume Next
    
    Dim payYear As Long, payMonth As Long, payDay As Long, maxDays As Long
    
    payYear = val(m_cboYearPay.value)
    payMonth = val(m_cboMonthPay.value)
    payDay = val(Me.Controls("txtPayDay").value)
    
    If payYear = 0 Or payMonth = 0 Then Exit Sub
    
    maxDays = GetDaysInMonth(payYear, payMonth)
    
    If payDay > maxDays Then
        Me.Controls("txtPayDay").value = Format(maxDays, "00")
    End If
    
    On Error GoTo 0
End Sub

Private Sub m_btnSave_Click()
    Dim ws As Worksheet
    Dim targetDate As String
    Dim insuranceIndex As Long
    Dim paymentDate As String
    Dim paymentAmount As Double
    Dim description As String
    
    If Me.Controls("cboInsurance").listIndex < 0 Then
        MsgBox "����� ��� ���� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    Dim payYear As String, payMonth As String, payDay As String
    payYear = Trim(m_cboYearPay.value)
    payMonth = Trim(m_cboMonthPay.value)
    payDay = Trim(Me.Controls("txtPayDay").value)
    
    If payYear = "" Or payMonth = "" Or payDay = "" Then
        MsgBox "����� ����� ������ �� ���� ���� ����.", vbExclamation
        Exit Sub
    End If
    
    payDay = ConvertPersianNumsToEnglish(payDay)
    If Not IsNumeric(payDay) Or val(payDay) < 1 Or val(payDay) > 31 Then
        MsgBox "��� ���� ��� ����� ����.", vbExclamation
        Me.Controls("txtPayDay").SetFocus
        Exit Sub
    End If
    
    paymentDate = payYear & "/" & payMonth & "/" & Format(val(payDay), "00")
    Call FormatAmountTextBox
    
    Dim amountText As String
    amountText = Trim(Me.Controls("txtPaymentAmount").value)
    amountText = Replace(Replace(amountText, ",", ""), " ", "")
    amountText = ConvertPersianNumsToEnglish(amountText)
    
    If amountText = "" Or Not IsNumeric(amountText) Then
        MsgBox "����� ���� ����� ���� ����.", vbExclamation
        Exit Sub
    End If
    
    If CDbl(amountText) <= 0 Then
        MsgBox "���� ���� ��ѐ�� �� ��� ����.", vbExclamation
        Exit Sub
    End If
    
    paymentAmount = CDbl(amountText)
    insuranceIndex = Me.Controls("cboInsurance").listIndex + 1
    description = Trim(Me.Controls("txtDescription").value)
    
    targetDate = CStr(targetYear) & "/" & Format(val(targetMonth), "00")
    Set ws = FindSheetByDate(targetDate)
    
    If ws Is Nothing Then
        MsgBox "��� ���� ��� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' Validation: Check if total paid exceeds submitted
    Dim insuranceStartRow As Long, insuranceRow As Long
    Dim submittedAmount As Double, totalPaidSoFar As Double, col As Long
    
    insuranceStartRow = GetInsuranceStartRow()
    insuranceRow = InsuranceFundRow(insuranceIndex, userCenters, totalCenters)
    
    On Error Resume Next
    submittedAmount = CDbl(ws.Cells(insuranceRow, "C").value)
    On Error GoTo 0
    
    totalPaidSoFar = 0
    For col = 4 To 50
        If IsEmpty(ws.Cells(insuranceRow, col).value) Then Exit For
        If IsNumeric(ws.Cells(insuranceRow, col).value) Then
            totalPaidSoFar = totalPaidSoFar + CDbl(ws.Cells(insuranceRow, col).value)
        End If
    Next col
    
    If (totalPaidSoFar + paymentAmount) > submittedAmount And submittedAmount > 0 Then
        Dim overAmount As Double
        overAmount = (totalPaidSoFar + paymentAmount) - submittedAmount
        
        Dim userChoice As VbMsgBoxResult
        userChoice = MsgBox("�����: ����� ������� �� �� ���� ������ ����� �� ���!" & vbCrLf & vbCrLf & _
                           "���� ������: " & Format(submittedAmount, "#,##0") & vbCrLf & _
                           "������ ��� ����: " & Format(totalPaidSoFar, "#,##0") & vbCrLf & _
                           "������ ����: " & Format(paymentAmount, "#,##0") & vbCrLf & _
                           "�����: " & Format(overAmount, "#,##0") & vbCrLf & vbCrLf & _
                           "��� ����� ����� �� �� ������ ����� ���Ͽ", _
                           vbYesNo + vbExclamation, "����� ����� ������")
        
        If userChoice = vbNo Then Exit Sub
    End If
    
    Call AddPaymentToInsuranceRow(ws, insuranceIndex, paymentDate, paymentAmount, description)
    MsgBox "������ �� ������ ��� ��.", vbInformation
    Unload Me
End Sub

Private Sub m_btnCancel_Click()
    Unload Me
End Sub

Private Sub AddPaymentToInsuranceRow(ws As Worksheet, insuranceIndex As Long, paymentDate As String, paymentAmount As Double, description As String)
    Dim insuranceStartRow As Long
    Dim insuranceRow As Long
    Dim nextPaymentCol As Long
    Dim col As Long
    
    insuranceStartRow = GetInsuranceStartRow()
    insuranceRow = InsuranceFundRow(insuranceIndex, userCenters, totalCenters)
    
    nextPaymentCol = 4
    For col = 4 To 50
        If IsEmpty(ws.Cells(insuranceRow, col).value) Then
            nextPaymentCol = col
            Exit For
        End If
    Next col
    
    ws.Cells(insuranceRow, nextPaymentCol).value = paymentAmount
    ws.Cells(insuranceRow, nextPaymentCol).NumberFormat = "#,##0"
    
    On Error Resume Next
    ws.Cells(insuranceRow, nextPaymentCol).ClearComments
    ws.Cells(insuranceRow, nextPaymentCol).AddComment paymentDate & IIf(description <> "", vbLf & description, "")
    ws.Cells(insuranceRow, nextPaymentCol).Comment.Visible = False
    On Error GoTo 0
    
    If ws.Cells(insuranceStartRow - 1, nextPaymentCol).value = "" Then
        ws.Cells(insuranceStartRow - 1, nextPaymentCol).value = "������ " & (nextPaymentCol - 3)
    End If
End Sub

Private Function GetInsuranceStartRow() As Long
    Dim totalRowsPerDayBlock As Long
    Dim fixedSummaryStartRow As Long
    
    totalRowsPerDayBlock = IIf(userCenters = 1, 2, totalCenters) + 1
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    
    GetInsuranceStartRow = fixedSummaryStartRow + 10 + userCenters + 1
End Function

Private Function GetDaysInMonth(ByVal y As Long, ByVal m As Long) As Long
    Select Case m
        Case 1 To 6
            GetDaysInMonth = 31
        Case 7 To 11
            GetDaysInMonth = 30
        Case 12
            If IsLeapYear(y) Then
                GetDaysInMonth = 30
            Else
                GetDaysInMonth = 29
            End If
        Case Else
            GetDaysInMonth = 31
    End Select
End Function

Private Function IsLeapYear(y As Long) As Boolean
    Dim rem33 As Long
    rem33 = (y + 2346) Mod 33
    
    Select Case rem33
        Case 1, 5, 9, 13, 17, 22, 26, 30
            IsLeapYear = True
        Case Else
            IsLeapYear = False
    End Select
End Function

Private Function FindSheetByDate(ym As String) As Worksheet
    Dim sht As Worksheet
    Dim sheetYM As String
    Dim searchYM As String
    Dim searchYM_Alt As String
    Dim parts() As String
    
    searchYM = Trim(ym)
    searchYM_Alt = ""
    
    If InStr(ym, "/") > 0 Then
        parts = Split(ym, "/")
        If UBound(parts) = 1 Then
            searchYM = parts(0) & "/" & Format(val(parts(1)), "00")
            searchYM_Alt = parts(0) & "/" & val(parts(1))
        End If
    End If
    
    For Each sht In ThisWorkbook.Worksheets
        On Error Resume Next
        sheetYM = Trim(CStr(sht.Range("B1").value))
        On Error GoTo 0
        
        If sheetYM = searchYM Or sheetYM = searchYM_Alt Then
            Set FindSheetByDate = sht
            Exit Function
        End If
    Next sht
    
    Set FindSheetByDate = Nothing
End Function

Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String, i As Long
    result = inputText
    For i = 1776 To 1785
        result = Replace(result, ChrW(i), CStr(i - 1776))
    Next i
    For i = 1632 To 1641
        result = Replace(result, ChrW(i), CStr(i - 1632))
    Next i
    ConvertPersianNumsToEnglish = result
End Function


