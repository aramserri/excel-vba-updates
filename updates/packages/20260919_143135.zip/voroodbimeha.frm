VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} voroodbimeha 
   Caption         =   "������� ���� ��"
   ClientHeight    =   9863.001
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   10830
   OleObjectBlob   =   "voroodbimeha.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "voroodbimeha"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False





'=====================================================
' UserForm: sabtBimeha (WITH CALCULATOR & BATCH PAYMENT)
'=====================================================
Option Explicit

'--- Module-level variables to hold workbook configuration ---
Private m_UserCenters As Long
Private m_TotalCenters As Long
Private m_CenterNames As Object

'--- Collections to hold dynamic controls and their event handlers ---
Private m_InsuranceTextBoxes As Collection
Private m_PaidLabels As Collection
Private m_RemainingLabels As Collection
Private m_StatusLabels As Collection
Private m_TextBoxEvents As Collection

'--- Control references for easy access ---
Private WithEvents m_btnSubmit As MSForms.CommandButton
Attribute m_btnSubmit.VB_VarHelpID = -1
Private WithEvents m_btnRecordPayment As MSForms.CommandButton
Attribute m_btnRecordPayment.VB_VarHelpID = -1
Private WithEvents m_btnViewPayments As MSForms.CommandButton
Attribute m_btnViewPayments.VB_VarHelpID = -1
Private WithEvents m_btnSearch As MSForms.CommandButton
Attribute m_btnSearch.VB_VarHelpID = -1
Private WithEvents m_btnProcessCalc As MSForms.CommandButton
Attribute m_btnProcessCalc.VB_VarHelpID = -1
Private WithEvents m_btnCalcReset As MSForms.CommandButton
Attribute m_btnCalcReset.VB_VarHelpID = -1
Private WithEvents m_cboYear As MSForms.ComboBox
Attribute m_cboYear.VB_VarHelpID = -1
Private WithEvents m_cboMonth As MSForms.ComboBox
Attribute m_cboMonth.VB_VarHelpID = -1

'--- Insurance types collection (module level for reuse) ---
Private m_InsuranceTypes As Collection

'--- FLAG TO PREVENT INFINITE LOOPS ---
Private m_IsInitializing As Boolean
Private m_IsLoading As Boolean

'--- Store original values for confirmation ---
Private m_OriginalValues() As String
Private m_TextBoxCount As Long

'--- Calculator feature - Store full selection info ---
Private Type CalcSelection
    Year As String
    Month As String
    insuranceIndex As Long
    InsuranceName As String
    amount As Double
End Type

Private m_CalcTotal As Double
Private m_CalcSelections() As CalcSelection
Private m_CalcSelectionCount As Long
Private m_CurrentPageSelections As Object  ' Dictionary for current page highlighting
Private m_RemainingLabelEvents As Collection

'----------------------------------------
' Initialize form
'----------------------------------------
Private Sub UserForm_Initialize()
    Dim i As Long
    
    m_IsInitializing = True
    m_IsLoading = False
    
    If Not ReadConfiguration() Then
        MsgBox "���: ������� ���� ���� ���.", vbCritical, "���"
        Unload Me
        Exit Sub
    End If

    With Me
        .Caption = "��� � ����� ���� ��"
        .Width = 700
        .Height = 610
        .Font.Name = "Tahoma"
        .Font.Size = 10
    End With

    Set m_InsuranceTextBoxes = New Collection
    Set m_PaidLabels = New Collection
    Set m_RemainingLabels = New Collection
    Set m_StatusLabels = New Collection
    Set m_TextBoxEvents = New Collection
    Set m_CurrentPageSelections = CreateObject("Scripting.Dictionary")
    Set m_RemainingLabelEvents = New Collection
    
    ' Initialize calculator
    m_CalcTotal = 0
    m_CalcSelectionCount = 0
    ReDim m_CalcSelections(1 To 100)
    
    Dim lbl As MSForms.Label
    Dim topPosition As Single
    topPosition = 10

    ' Year/Month Selection
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblYear", True)
    With lbl: .Caption = "���:": .Top = topPosition + 4: .Left = 12: .Width = 40: End With
    
    Set m_cboYear = Me.Controls.Add("Forms.ComboBox.1", "cboYear", True)
    With m_cboYear: .Top = topPosition: .Left = 55: .Width = 60: End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblMonth", True)
    With lbl: .Caption = "���:": .Top = topPosition + 4: .Left = 125: .Width = 30: End With
    
    Set m_cboMonth = Me.Controls.Add("Forms.ComboBox.1", "cboMonth", True)
    With m_cboMonth: .Top = topPosition: .Left = 160: .Width = 40: End With

    ' Populate ComboBoxes
    On Error Resume Next
    m_cboYear.RowSource = "cfg_YearList"
    
    Dim defaultYear As String
    defaultYear = CStr(ThisWorkbook.Sheets("�������").Range("cfg_DefaultYear").value)
    If defaultYear <> "" Then
        Dim yi As Long
        For yi = 0 To m_cboYear.ListCount - 1
            If m_cboYear.List(yi) = defaultYear Then
                m_cboYear.listIndex = yi
                Exit For
            End If
        Next yi
    ElseIf m_cboYear.ListCount > 0 Then
        m_cboYear.listIndex = m_cboYear.ListCount - 1
    End If
    On Error GoTo 0

    m_cboMonth.Clear
    For i = 1 To 12: m_cboMonth.AddItem CStr(i): Next i

    Dim defaultMonth As Long
    On Error Resume Next
    defaultMonth = CLng(ThisWorkbook.Sheets("�������").Range("cfg_DefaultMonth").value)
    On Error GoTo 0

    If defaultMonth >= 2 And defaultMonth <= 12 Then
        m_cboMonth.listIndex = defaultMonth - 2
    ElseIf defaultMonth = 1 Then
        m_cboMonth.listIndex = 11
        If m_cboYear.listIndex > 0 Then m_cboYear.listIndex = m_cboYear.listIndex - 1
    Else
        m_cboMonth.listIndex = 0
    End If

    ' Headers
    topPosition = topPosition + 40
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblH1", True)
    With lbl: .Caption = "���� ������": .Top = topPosition: .Left = 20: .Width = 100: .TextAlign = fmTextAlignCenter: .Font.Bold = True: End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblH2", True)
    With lbl: .Caption = "�������": .Top = topPosition: .Left = 125: .Width = 80: .TextAlign = fmTextAlignCenter: .Font.Bold = True: End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblH3", True)
    With lbl: .Caption = "�����": .Top = topPosition: .Left = 210: .Width = 80: .TextAlign = fmTextAlignCenter: .Font.Bold = True: End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblH4", True)
    With lbl: .Caption = "�����": .Top = topPosition: .Left = 295: .Width = 60: .TextAlign = fmTextAlignCenter: .Font.Bold = True: End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblH5", True)
    With lbl: .Caption = "��� ����": .Top = topPosition: .Left = 360: .Width = 280: .TextAlign = fmTextAlignCenter: .Font.Bold = True: End With
    
    topPosition = topPosition + 22

    ' Build insurance types
    Set m_InsuranceTypes = GetInsuranceTypes
    
    Dim insuranceType As Variant
    Dim idx As Long: idx = 0
    
    For Each insuranceType In m_InsuranceTypes
        idx = idx + 1
        
        ' Submitted Amount TextBox
        Dim txtAmount As MSForms.TextBox
        Set txtAmount = Me.Controls.Add("Forms.TextBox.1", "txtAmount" & idx, True)
        With txtAmount
            .Top = topPosition
            .Left = 20
            .Width = 100
            .TextAlign = fmTextAlignCenter
            .TabStop = True
            .TabIndex = idx - 1
        End With
        m_InsuranceTextBoxes.Add txtAmount
        Call HookupTextBoxEvents(txtAmount)
        
        ' Paid Amount Label
        Dim lblPaid As MSForms.Label
        Set lblPaid = Me.Controls.Add("Forms.Label.1", "lblPaid" & idx, True)
        With lblPaid
            .Caption = "0"
            .Top = topPosition + 2
            .Left = 125
            .Width = 80
            .TextAlign = fmTextAlignCenter
            .ForeColor = RGB(0, 100, 0)
        End With
        m_PaidLabels.Add lblPaid
        
        ' Remaining Amount Label - WITH CLICK EVENT
        Dim lblRemaining As MSForms.Label
        Set lblRemaining = Me.Controls.Add("Forms.Label.1", "lblRemaining" & idx, True)
        With lblRemaining
            .Caption = "0"
            .Top = topPosition + 2
            .Left = 210
            .Width = 80
            .Height = 16
            .TextAlign = fmTextAlignCenter
            .ForeColor = RGB(150, 0, 0)
            .BackColor = Me.BackColor
            .Tag = idx
        End With
        m_RemainingLabels.Add lblRemaining
        Call HookupRemainingLabelClick(lblRemaining, idx)
        
        ' Status Label
        Dim lblStatus As MSForms.Label
        Set lblStatus = Me.Controls.Add("Forms.Label.1", "lblStatus" & idx, True)
        With lblStatus
            .Caption = "-"
            .Top = topPosition + 2
            .Left = 295
            .Width = 60
            .TextAlign = fmTextAlignCenter
        End With
        m_StatusLabels.Add lblStatus
        
        ' Insurance Type Label
        Set lbl = Me.Controls.Add("Forms.Label.1", "lblInsName" & idx, True)
        With lbl
            .Caption = insuranceType
            .Top = topPosition + 2
            .Left = 360
            .Width = 280
            .TextAlign = fmTextAlignRight
        End With

        topPosition = topPosition + 24
    Next insuranceType

    ' Sum Display
    topPosition = topPosition + 10
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSumValue", True)
    With lbl: .Caption = "0": .Top = topPosition: .Left = 20: .Width = 100: .TextAlign = fmTextAlignCenter: .Font.Bold = True: .ForeColor = RGB(0, 100, 0): End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSumPaidValue", True)
    With lbl: .Caption = "0": .Top = topPosition: .Left = 125: .Width = 80: .TextAlign = fmTextAlignCenter: .Font.Bold = True: .ForeColor = RGB(0, 100, 0): End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSumRemainingValue", True)
    With lbl: .Caption = "0": .Top = topPosition: .Left = 210: .Width = 80: .TextAlign = fmTextAlignCenter: .Font.Bold = True: .ForeColor = RGB(150, 0, 0): End With
    
    ' ========== Calculator Display ==========
    topPosition = topPosition + 25
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblCalcTitle", True)
    With lbl
        .Caption = "����� ����:"
        .Top = topPosition
        .Left = 360
        .Width = 80
        .TextAlign = fmTextAlignRight
        .Font.Bold = True
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblCalcValue", True)
    With lbl
        .Caption = "0 (0 ����)"
        .Top = topPosition
        .Left = 125
        .Width = 225
        .Height = 20
        .TextAlign = fmTextAlignCenter
        .Font.Bold = True
        .Font.Size = 11
        .ForeColor = RGB(0, 0, 150)
        .BackColor = RGB(255, 255, 200)
        .BorderStyle = fmBorderStyleSingle
    End With
    
    ' Process Calculator Button
    Set m_btnProcessCalc = Me.Controls.Add("Forms.CommandButton.1", "btnProcessCalc", True)
    With m_btnProcessCalc
        .Caption = "��� ������ ��"
        .Top = topPosition - 2
        .Left = 20
        .Width = 90
        .Height = 22
        .BackColor = RGB(200, 255, 200)
    End With
    
    ' Reset Calculator Button
    Set m_btnCalcReset = Me.Controls.Add("Forms.CommandButton.1", "btnCalcReset", True)
    With m_btnCalcReset
        .Caption = "�ǘ"
        .Top = topPosition - 2
        .Left = 450
        .Width = 40
        .Height = 22
    End With

    topPosition = topPosition + 30

    ' Buttons Row
    Set m_btnSubmit = Me.Controls.Add("Forms.CommandButton.1", "btnSubmit", True)
    With m_btnSubmit: .Caption = "��� ������": .Top = topPosition: .Left = 20: .Width = 100: .Height = 28: .BackColor = RGB(240, 200, 150): End With
    
    Set m_btnRecordPayment = Me.Controls.Add("Forms.CommandButton.1", "btnRecordPayment", True)
    With m_btnRecordPayment: .Caption = "��� ������": .Top = topPosition: .Left = 130: .Width = 100: .Height = 28: .BackColor = RGB(200, 255, 200): End With
    
    Set m_btnViewPayments = Me.Controls.Add("Forms.CommandButton.1", "btnViewPayments", True)
    With m_btnViewPayments: .Caption = "����΍� ������": .Top = topPosition: .Left = 240: .Width = 110: .Height = 28: .BackColor = RGB(100, 220, 255): End With

    Set m_btnSearch = Me.Controls.Add("Forms.CommandButton.1", "btnSearch", True)
    With m_btnSearch: .Caption = "������ ����": .Top = topPosition: .Left = 360: .Width = 110: .Height = 28: .BackColor = RGB(200, 220, 255): End With
    
    ' Finalize Form Size
    Dim requiredHeight As Single
    requiredHeight = m_btnSubmit.Top + m_btnSubmit.Height + 50
    
    Me.ScrollBars = fmScrollBarsVertical
    Me.ScrollHeight = requiredHeight - 30
    
    If requiredHeight > 610 Then Me.Height = 610 Else Me.Height = requiredHeight

    m_IsInitializing = False
    Call LoadExistingData
End Sub

'=========================================
' HOOKUP REMAINING LABEL CLICK EVENT
'=========================================
Private Sub HookupRemainingLabelClick(lbl As MSForms.Label, idx As Long)
    Dim lblEvent As clsRemainingLabelClick
    Set lblEvent = New clsRemainingLabelClick
    Set lblEvent.Label = lbl
    lblEvent.labelIndex = idx
    Set lblEvent.ParentForm = Me
    m_RemainingLabelEvents.Add lblEvent
End Sub

'=========================================
' HANDLE REMAINING LABEL CLICK - Called from class
'=========================================
Public Sub OnRemainingLabelClick(labelIndex As Long)
    Dim lbl As MSForms.Label
    Dim labelValue As Double
    Dim labelText As String
    Dim currentYear As String
    Dim currentMonth As String
    Dim selKey As String
    Dim i As Long
    Dim foundIndex As Long
    
    On Error Resume Next
    Set lbl = m_RemainingLabels(labelIndex)
    On Error GoTo 0
    
    If lbl Is Nothing Then Exit Sub
    
    ' Get the numeric value
    labelText = lbl.Caption
    labelText = Replace(labelText, ",", "")
    labelText = ConvertPersianNumsToEnglish(labelText)
    
    If Not IsNumeric(labelText) Then Exit Sub
    labelValue = CDbl(labelText)
    
    ' Skip if value is 0
    If labelValue = 0 Then Exit Sub
    
    ' Get current year/month
    currentYear = CStr(m_cboYear.value)
    currentMonth = Format(val(m_cboMonth.value), "00")
    selKey = currentYear & "/" & currentMonth & "/" & labelIndex
    
    ' Check if already selected
    foundIndex = FindSelectionIndex(currentYear, currentMonth, labelIndex)
    
    If foundIndex > 0 Then
        ' Deselect - remove from selections
        m_CalcTotal = m_CalcTotal - m_CalcSelections(foundIndex).amount
        Call RemoveSelection(foundIndex)
        m_CurrentPageSelections.Remove labelIndex
        lbl.BackColor = Me.BackColor
        lbl.Font.Bold = False
    Else
        ' Select - add to selections
        m_CalcTotal = m_CalcTotal + labelValue
        m_CalcSelectionCount = m_CalcSelectionCount + 1
        
        If m_CalcSelectionCount > UBound(m_CalcSelections) Then
            ReDim Preserve m_CalcSelections(1 To m_CalcSelectionCount + 50)
        End If
        
        m_CalcSelections(m_CalcSelectionCount).Year = currentYear
        m_CalcSelections(m_CalcSelectionCount).Month = currentMonth
        m_CalcSelections(m_CalcSelectionCount).insuranceIndex = labelIndex
        m_CalcSelections(m_CalcSelectionCount).InsuranceName = m_InsuranceTypes(labelIndex)
        m_CalcSelections(m_CalcSelectionCount).amount = labelValue
        
        m_CurrentPageSelections.Add labelIndex, labelValue
        lbl.BackColor = RGB(200, 255, 200)
        lbl.Font.Bold = True
    End If
    
    UpdateCalcDisplay
End Sub

'=========================================
' FIND SELECTION INDEX
'=========================================
Private Function FindSelectionIndex(yr As String, mo As String, insIdx As Long) As Long
    Dim i As Long
    FindSelectionIndex = 0
    
    For i = 1 To m_CalcSelectionCount
        If m_CalcSelections(i).Year = yr And _
           m_CalcSelections(i).Month = mo And _
           m_CalcSelections(i).insuranceIndex = insIdx Then
            FindSelectionIndex = i
            Exit Function
        End If
    Next i
End Function

'=========================================
' REMOVE SELECTION BY INDEX
'=========================================
Private Sub RemoveSelection(idx As Long)
    Dim i As Long
    
    If idx < 1 Or idx > m_CalcSelectionCount Then Exit Sub
    
    ' Shift all items after idx
    For i = idx To m_CalcSelectionCount - 1
        m_CalcSelections(i) = m_CalcSelections(i + 1)
    Next i
    
    m_CalcSelectionCount = m_CalcSelectionCount - 1
End Sub

'=========================================
' UPDATE CALCULATOR DISPLAY
'=========================================
Private Sub UpdateCalcDisplay()
    On Error Resume Next
    Me.Controls("lblCalcValue").Caption = Format(m_CalcTotal, "#,##0") & " (" & m_CalcSelectionCount & " ����)"
    
    ' Enable/disable process button
    m_btnProcessCalc.Enabled = (m_CalcSelectionCount > 0)
    On Error GoTo 0
End Sub

'=========================================
' CLEAR CURRENT PAGE HIGHLIGHTING
'=========================================
Private Sub ClearCurrentPageHighlights()
    Dim key As Variant
    Dim lbl As MSForms.Label
    
    For Each key In m_CurrentPageSelections.keys
        On Error Resume Next
        Set lbl = m_RemainingLabels(CLng(key))
        If Not lbl Is Nothing Then
            lbl.BackColor = Me.BackColor
            lbl.Font.Bold = False
        End If
        On Error GoTo 0
    Next key
    
    Set m_CurrentPageSelections = CreateObject("Scripting.Dictionary")
End Sub

'=========================================
' RESTORE HIGHLIGHTS FOR CURRENT PAGE
'=========================================
Private Sub RestoreCurrentPageHighlights()
    Dim i As Long
    Dim currentYear As String
    Dim currentMonth As String
    Dim lbl As MSForms.Label
    
    currentYear = CStr(m_cboYear.value)
    currentMonth = Format(val(m_cboMonth.value), "00")
    
    Set m_CurrentPageSelections = CreateObject("Scripting.Dictionary")
    
    For i = 1 To m_CalcSelectionCount
        If m_CalcSelections(i).Year = currentYear And m_CalcSelections(i).Month = currentMonth Then
            On Error Resume Next
            Set lbl = m_RemainingLabels(m_CalcSelections(i).insuranceIndex)
            If Not lbl Is Nothing Then
                lbl.BackColor = RGB(200, 255, 200)
                lbl.Font.Bold = True
                m_CurrentPageSelections.Add m_CalcSelections(i).insuranceIndex, m_CalcSelections(i).amount
            End If
            On Error GoTo 0
        End If
    Next i
End Sub

'=========================================
' RESET CALCULATOR - Full reset
'=========================================
Public Sub ResetCalculator()
    ClearCurrentPageHighlights
    m_CalcTotal = 0
    m_CalcSelectionCount = 0
    ReDim m_CalcSelections(1 To 100)
    UpdateCalcDisplay
End Sub

'=========================================
' PROCESS CALCULATOR - Open payment forms one by one
'=========================================
Private Sub m_btnProcessCalc_Click()
    If m_CalcSelectionCount = 0 Then
        MsgBox "�� ����� ������ ���� ���.", vbExclamation
        Exit Sub
    End If
    
    Dim confirmMsg As String
    confirmMsg = "����� " & m_CalcSelectionCount & " ���� ������ ��� ���." & vbCrLf & _
                 "��� ��: " & Format(m_CalcTotal, "#,##0") & " ����" & vbCrLf & vbCrLf & _
                 "���� �� ���� ��� ��� ������ ��� �� ���." & vbCrLf & _
                 "��� ����� �� ���Ͽ"
    
    If MsgBox(confirmMsg, vbYesNo + vbQuestion, "����� ��� ������ ��") = vbNo Then
        Exit Sub
    End If
    
    ' Process each selection
    Dim i As Long
    Dim processedCount As Long
    Dim sel As CalcSelection
    
    processedCount = 0
    
    ' Process from first to last (will modify array, so work with copy)
    Do While m_CalcSelectionCount > 0
        sel = m_CalcSelections(1)  ' Always take first item
        
        ' Navigate to the correct month
        Dim yi As Long, mi As Long
        
        ' Update year
        For yi = 0 To m_cboYear.ListCount - 1
            If m_cboYear.List(yi) = sel.Year Then
                m_cboYear.listIndex = yi
                Exit For
            End If
        Next yi
        
        ' Update month
        For mi = 0 To m_cboMonth.ListCount - 1
            If CStr(m_cboMonth.List(mi)) = CStr(val(sel.Month)) Then
                m_cboMonth.listIndex = mi
                Exit For
            End If
        Next mi
        
        ' Load data for this month (don't reset calculator)
        m_IsLoading = True
        Call LoadExistingDataInternal
        m_IsLoading = False
        
        ' Open payment form
        Dim frmPayment As frmInsurancePayment
        Set frmPayment = New frmInsurancePayment
        
        frmPayment.targetYear = sel.Year
        frmPayment.targetMonth = sel.Month
        Set frmPayment.InsuranceTypes = m_InsuranceTypes
        frmPayment.userCenters = m_UserCenters
        frmPayment.totalCenters = m_TotalCenters
        frmPayment.PreSelectedInsuranceIndex = sel.insuranceIndex
        frmPayment.PreFilledAmount = sel.amount
        
        frmPayment.Show vbModal
        
        On Error Resume Next
        Unload frmPayment
        Set frmPayment = Nothing
        On Error GoTo 0
        
        processedCount = processedCount + 1
        
        ' Remove this item from selections
        m_CalcTotal = m_CalcTotal - sel.amount
        Call RemoveSelection(1)
        
        ' Update display
        UpdateCalcDisplay
        
        ' If more items, ask to continue
        If m_CalcSelectionCount > 0 Then
            Dim continueMsg As String
            continueMsg = "������ " & processedCount & " ��� ��." & vbCrLf & _
                         m_CalcSelectionCount & " ���� ��� ���� �����." & vbCrLf & vbCrLf & _
                         "����� �� ���Ͽ"
            
            If MsgBox(continueMsg, vbYesNo + vbQuestion, "����� ��� ������") = vbNo Then
                Exit Do
            End If
        End If
    Loop
    
    ' Reload current page data
    Call LoadExistingData
    
    MsgBox processedCount & " ������ ��� ��.", vbInformation
End Sub

'----------------------------------------
' Calculator Reset Button
'----------------------------------------
Private Sub m_btnCalcReset_Click()
    Call ResetCalculator
End Sub

'----------------------------------------
' ComboBox Change Events - Keep calculator, restore highlights
'----------------------------------------
Private Sub m_cboYear_Change()
    If Not m_IsInitializing Then
        ClearCurrentPageHighlights
        Call LoadExistingDataInternal
        RestoreCurrentPageHighlights
    End If
End Sub

Private Sub m_cboMonth_Change()
    If Not m_IsInitializing Then
        ClearCurrentPageHighlights
        Call LoadExistingDataInternal
        RestoreCurrentPageHighlights
    End If
End Sub

'----------------------------------------
' Form Click - Do NOT reset calculator (removed)
'----------------------------------------
' Private Sub UserForm_Click()
'     ' Removed - don't reset calculator on form click
' End Sub

'----------------------------------------
' Load existing data (public version - resets calculator)
'----------------------------------------
Private Sub LoadExistingData()
    Call ResetCalculator
    Call LoadExistingDataInternal
End Sub

'----------------------------------------
' Load existing data (internal - doesn't reset calculator)
'----------------------------------------
Private Sub LoadExistingDataInternal()
    If m_IsInitializing Then Exit Sub
    
    On Error GoTo LoadError
    
    Dim ws As Worksheet
    Dim targetDate As String
    Dim j As Long
    
    If m_cboYear.value = "" Or m_cboMonth.value = "" Then
        Exit Sub
    End If
    
    If m_InsuranceTextBoxes Is Nothing Then Exit Sub
    If m_InsuranceTextBoxes.count = 0 Then Exit Sub
    
    targetDate = CStr(m_cboYear.value) & "/" & Format(val(m_cboMonth.value), "00")
    Set ws = FindSheet(targetDate)
    
    For j = 1 To m_InsuranceTextBoxes.count
        m_InsuranceTextBoxes(j).value = ""
        m_PaidLabels(j).Caption = "0"
        m_RemainingLabels(j).Caption = "0"
        m_RemainingLabels(j).BackColor = Me.BackColor
        m_RemainingLabels(j).Font.Bold = False
        m_StatusLabels(j).Caption = "-"
        m_StatusLabels(j).ForeColor = RGB(128, 128, 128)
    Next j
    
    If ws Is Nothing Then
        Call StoreOriginalValues
        Exit Sub
    End If
    
    Dim totalRowsPerDayBlock As Long, fixedSummaryStartRow As Long, insuranceStartRow As Long
    totalRowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters) + 1
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    insuranceStartRow = fixedSummaryStartRow + 10 + m_UserCenters + 1
    
    Dim totalSubmitted As Double, totalPaid As Double, totalRemaining As Double
    totalSubmitted = 0: totalPaid = 0: totalRemaining = 0
    
    For j = 1 To m_InsuranceTextBoxes.count
        Dim submitted As Double, paid As Double, remaining As Double
        Dim cellValue As Variant
        
        cellValue = ws.Cells(InsuranceFundRow(j, m_UserCenters, m_TotalCenters), "C").value
        If IsNumeric(cellValue) And cellValue <> "" Then
            submitted = CDbl(cellValue)
            m_InsuranceTextBoxes(j).value = Format(submitted, "#,##0")
        Else
            submitted = 0
        End If
        
        paid = GetTotalPaidForInsurance(ws, j, insuranceStartRow)
        remaining = submitted - paid
        If remaining < 0 Then remaining = 0
        
        m_PaidLabels(j).Caption = Format(paid, "#,##0")
        m_RemainingLabels(j).Caption = Format(remaining, "#,##0")
        
        If submitted = 0 Then
            m_StatusLabels(j).Caption = "-"
            m_StatusLabels(j).ForeColor = RGB(128, 128, 128)
        ElseIf remaining = 0 Then
            m_StatusLabels(j).Caption = "�����"
            m_StatusLabels(j).ForeColor = RGB(0, 150, 0)
        ElseIf paid > 0 Then
            m_StatusLabels(j).Caption = "����"
            m_StatusLabels(j).ForeColor = RGB(255, 165, 0)
        Else
            m_StatusLabels(j).Caption = "�����"
            m_StatusLabels(j).ForeColor = RGB(200, 0, 0)
        End If
        
        totalSubmitted = totalSubmitted + submitted
        totalPaid = totalPaid + paid
        totalRemaining = totalRemaining + remaining
    Next j
    
    On Error Resume Next
    Me.Controls("lblSumValue").Caption = Format(totalSubmitted, "#,##0")
    Me.Controls("lblSumPaidValue").Caption = Format(totalPaid, "#,##0")
    Me.Controls("lblSumRemainingValue").Caption = Format(totalRemaining, "#,##0")
    On Error GoTo 0
    
    Call StoreOriginalValues
    Exit Sub
    
LoadError:
    Call StoreOriginalValues
End Sub

'----------------------------------------
' Submit Button
'----------------------------------------
Private Sub m_btnSubmit_Click()
    Dim changesDetected As Boolean
    Dim changesList As String
    Dim i As Long
    Dim txtBox As MSForms.TextBox
    Dim currentValue As String
    Dim originalValue As String
    
    changesDetected = False
    changesList = ""
    
    For i = 1 To m_InsuranceTypes.count
        On Error Resume Next
        Set txtBox = m_InsuranceTextBoxes(i)
        On Error GoTo 0
        
        If Not txtBox Is Nothing Then
            currentValue = CleanAmount(txtBox.value)
            
            If i <= UBound(m_OriginalValues) Then
                originalValue = CleanAmount(m_OriginalValues(i))
            Else
                originalValue = "0"
            End If
            
            If originalValue <> "" And originalValue <> "0" Then
                If currentValue <> originalValue Then
                    changesDetected = True
                    changesList = changesList & vbCrLf & "- " & m_InsuranceTypes(i) & ": " & _
                                  Format(val(originalValue), "#,##0") & " � " & _
                                  Format(val(currentValue), "#,##0")
                End If
            End If
        End If
    Next i
    
    If changesDetected Then
        Dim confirmResult As VbMsgBoxResult
        confirmResult = MsgBox("������� ��� ������� ��:" & changesList & vbCrLf & vbCrLf & _
                              "��� �� ����� ��� ������� ������� ����Ͽ", _
                              vbYesNo + vbQuestion, "����� �������")
        
        If confirmResult = vbNo Then Exit Sub
    End If
    
    ' Save code
    Dim ws As Worksheet
    Dim targetDate As String
    Dim j As Long
    Dim rawValue As String
    Dim convertedValue As String
    Dim numericValue As Double
    
    If m_cboYear.value = "" Or m_cboMonth.value = "" Then
        MsgBox "����� ��� � ��� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    targetDate = CStr(m_cboYear.value) & "/" & Format(val(m_cboMonth.value), "00")
    Set ws = FindSheet(targetDate)
    
    If ws Is Nothing Then
        MsgBox "��� ����� �� " & targetDate & " ���� ���.", vbCritical
        Exit Sub
    End If
    
    Dim totalRowsPerDayBlock As Long
    Dim fixedSummaryStartRow As Long
    Dim insuranceStartRow As Long
    
    totalRowsPerDayBlock = IIf(m_UserCenters = 1, 2, m_TotalCenters) + 1
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    insuranceStartRow = fixedSummaryStartRow + 10 + m_UserCenters + 1
    
    For j = 1 To m_InsuranceTextBoxes.count
        rawValue = Trim(m_InsuranceTextBoxes(j).value)
        
        If rawValue = "" Then
            numericValue = 0
        Else
            rawValue = Replace(rawValue, ",", "")
            rawValue = Replace(rawValue, " ", "")
            convertedValue = ConvertPersianNumsToEnglish(rawValue)
            
            If IsNumeric(convertedValue) Then
                numericValue = CDbl(convertedValue)
            Else
                numericValue = 0
            End If
        End If
        
        ws.Cells(InsuranceFundRow(j, m_UserCenters, m_TotalCenters), "C").value = numericValue
        ws.Cells(insuranceStartRow + (j - 1), "C").NumberFormat = "#,##0"
    Next j
    
    MsgBox "������� �� ������ ����� ��.", vbInformation
    
    Call LoadExistingData
End Sub

Private Function CleanAmount(val As String) As String
    Dim result As String
    result = Trim(val)
    result = Replace(result, ",", "")
    result = Replace(result, " ", "")
    result = ConvertPersianNumsToEnglish(result)
    If result = "" Then result = "0"
    CleanAmount = result
End Function

'----------------------------------------
' Record Payment Button
'----------------------------------------
Private Sub m_btnRecordPayment_Click()
    If m_cboYear.value = "" Or m_cboMonth.value = "" Then
        MsgBox "����� ��� � ��� �� ������ ����.", vbExclamation
        Exit Sub
    End If
    
    Dim frmPayment As frmInsurancePayment
    Set frmPayment = New frmInsurancePayment
    
    frmPayment.targetYear = CStr(m_cboYear.value)
    frmPayment.targetMonth = CStr(m_cboMonth.value)
    Set frmPayment.InsuranceTypes = m_InsuranceTypes
    frmPayment.userCenters = m_UserCenters
    frmPayment.totalCenters = m_TotalCenters
    
    frmPayment.Show vbModal
    
    On Error Resume Next
    Unload frmPayment
    Set frmPayment = Nothing
    On Error GoTo 0
    
    Call LoadExistingData
End Sub

'----------------------------------------
' View Payments Button
'----------------------------------------
Private Sub m_btnViewPayments_Click()
    Dim frmHistory As frmPaymentHistory
    Set frmHistory = New frmPaymentHistory
    
    frmHistory.targetYear = CStr(m_cboYear.value)
    frmHistory.targetMonth = CStr(m_cboMonth.value)
    frmHistory.userCenters = m_UserCenters
    frmHistory.totalCenters = m_TotalCenters
    Set frmHistory.InsuranceTypes = m_InsuranceTypes
    
    frmHistory.Show vbModal
    
    On Error Resume Next
    Unload frmHistory
    Set frmHistory = Nothing
    On Error GoTo 0
    
    Call LoadExistingData
End Sub

'----------------------------------------
' Search Button
'----------------------------------------
Private Sub m_btnSearch_Click()
    Dim frm As frmSearchInsurance
    Set frm = New frmSearchInsurance
    
    frm.userCenters = m_UserCenters
    frm.totalCenters = m_TotalCenters
    Set frm.InsuranceTypes = m_InsuranceTypes
    
    frm.Show vbModal
    
    If frm.FormClosed Then
        Unload frm
        Set frm = Nothing
        Exit Sub
    End If
    
    If frm.WasSelected Then
        Dim newYear As String
        Dim newMonth As String
        Dim selectedInsIndex As Long
        Dim remainingAmount As Double
        
        newYear = frm.selectedYear
        newMonth = frm.SelectedMonth
        selectedInsIndex = frm.SelectedInsuranceIndex
        remainingAmount = frm.SelectedRemainingAmount
        
        Unload frm
        Set frm = Nothing
        
        ' Update year
        Dim yi As Long
        For yi = 0 To m_cboYear.ListCount - 1
            If m_cboYear.List(yi) = newYear Then
                m_cboYear.listIndex = yi
                Exit For
            End If
        Next yi
        
        ' Update month
        Dim mi As Long
        For mi = 0 To m_cboMonth.ListCount - 1
            If CStr(m_cboMonth.List(mi)) = CStr(val(newMonth)) Then
                m_cboMonth.listIndex = mi
                Exit For
            End If
        Next mi
        
        ' Open payment form
        Dim frmPayment As frmInsurancePayment
        Set frmPayment = New frmInsurancePayment
        
        frmPayment.targetYear = newYear
        frmPayment.targetMonth = newMonth
        Set frmPayment.InsuranceTypes = m_InsuranceTypes
        frmPayment.userCenters = m_UserCenters
        frmPayment.totalCenters = m_TotalCenters
        frmPayment.PreSelectedInsuranceIndex = selectedInsIndex
        frmPayment.PreFilledAmount = remainingAmount
        
        frmPayment.Show vbModal
        
        On Error Resume Next
        Unload frmPayment
        Set frmPayment = Nothing
        On Error GoTo 0
        
        Call LoadExistingData
    Else
        Unload frm
        Set frm = Nothing
    End If
End Sub

'----------------------------------------
' Helper functions
'----------------------------------------
Private Function GetTotalPaidForInsurance(ws As Worksheet, insuranceIndex As Long, insuranceStartRow As Long) As Double
    Dim total As Double, col As Long, insuranceRow As Long, cellValue As Variant
    insuranceRow = InsuranceFundRow(insuranceIndex, m_UserCenters, m_TotalCenters)
    For col = 4 To 50
        cellValue = ws.Cells(insuranceRow, col).value
        If IsEmpty(cellValue) Or cellValue = "" Then Exit For
        If IsNumeric(cellValue) Then total = total + CDbl(cellValue)
    Next col
    GetTotalPaidForInsurance = total
End Function
Private Sub StoreOriginalValues()
    Dim i As Long
    
    If m_InsuranceTypes Is Nothing Then Exit Sub
    
    m_TextBoxCount = m_InsuranceTypes.count
    ReDim m_OriginalValues(1 To m_TextBoxCount)
    
    For i = 1 To m_TextBoxCount
        On Error Resume Next
        If i <= m_InsuranceTextBoxes.count Then
            m_OriginalValues(i) = m_InsuranceTextBoxes(i).value
        Else
            m_OriginalValues(i) = ""
        End If
        On Error GoTo 0
    Next i
End Sub

Private Function ReadConfiguration() As Boolean
    Dim wsInfo As Worksheet, i As Long
    On Error Resume Next
    Set wsInfo = ThisWorkbook.Sheets("�������")
    If wsInfo Is Nothing Then GoTo ConfigFail
    m_UserCenters = wsInfo.Range("cfg_ActualUserCenters").value
    m_TotalCenters = wsInfo.Range("cfg_TotalCenters").value
    Set m_CenterNames = CreateObject("Scripting.Dictionary")
    For i = 1 To m_UserCenters
        m_CenterNames.Add i, wsInfo.Cells(i + 1, "AA").value
    Next i
    If Err.Number <> 0 Or m_UserCenters = 0 Or m_TotalCenters = 0 Then
ConfigFail:
        ReadConfiguration = False
    Else
        ReadConfiguration = True
    End If
    On Error GoTo 0
End Function
Private Function GetInsuranceTypes() As Collection
    Set GetInsuranceTypes = InsuranceFundNames(m_UserCenters, m_TotalCenters)
End Function
Private Function FindSheet(ym As String) As Worksheet
    Dim sht As Worksheet
    Dim sheetYM As String, searchYM As String, searchYM_Alt As String
    Dim parts() As String
    
    searchYM = Trim(ym)
    searchYM_Alt = ""
    
    If InStr(ym, "/") > 0 Then
        parts = Split(ym, "/")
        If UBound(parts) = 1 Then
            searchYM = parts(0) & "/" & Format(val(parts(1)), "00")
            searchYM_Alt = parts(0) & "/" & val(parts(1))
        End If
    End If
    
    For Each sht In ThisWorkbook.Worksheets
        On Error Resume Next
        sheetYM = Trim(CStr(sht.Range("B1").value))
        On Error GoTo 0
        
        If sheetYM = searchYM Or sheetYM = searchYM_Alt Then
            Set FindSheet = sht
            Exit Function
        End If
    Next sht
    
    Set FindSheet = Nothing
End Function

Private Sub HookupTextBoxEvents(ByVal txtBox As MSForms.TextBox)
    Dim TBoxEvent As clsAdvancedTextBox
    Set TBoxEvent = New clsAdvancedTextBox
    Set TBoxEvent.ParentForm = Me
    Set TBoxEvent.TBox = txtBox
    TBoxEvent.EnableLiveTotalUpdate = True
    m_TextBoxEvents.Add TBoxEvent
End Sub

Public Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String, i As Long
    result = inputText
    For i = 1776 To 1785: result = Replace(result, ChrW(i), CStr(i - 1776)): Next i
    For i = 1632 To 1641: result = Replace(result, ChrW(i), CStr(i - 1632)): Next i
    ConvertPersianNumsToEnglish = result
End Function

Public Sub ForceFormatAll()
    Dim k As Long, raw As String, conv As String
    If m_InsuranceTextBoxes Is Nothing Then Exit Sub
    For k = 1 To m_InsuranceTextBoxes.count
        raw = Trim(m_InsuranceTextBoxes(k).value)
        If raw <> "" Then
            raw = Replace(Replace(raw, ",", ""), " ", "")
            conv = ConvertPersianNumsToEnglish(raw)
            If IsNumeric(conv) Then m_InsuranceTextBoxes(k).value = Format(CDbl(conv), "#,##0")
        End If
    Next k
    DoEvents: Me.Repaint
End Sub

Public Sub UpdateSum()
    If m_IsInitializing Then Exit Sub
    If m_InsuranceTextBoxes Is Nothing Then Exit Sub
    
    Dim j As Long
    Dim total As Double
    Dim rawValue As String
    Dim convertedValue As String
    
    total = 0
    
    For j = 1 To m_InsuranceTextBoxes.count
        rawValue = Trim(m_InsuranceTextBoxes(j).value)
        If rawValue <> "" Then
            rawValue = Replace(rawValue, ",", "")
            rawValue = Replace(rawValue, " ", "")
            convertedValue = ConvertPersianNumsToEnglish(rawValue)
            
            If IsNumeric(convertedValue) Then
                total = total + CDbl(convertedValue)
            End If
        End If
    Next j
    
    On Error Resume Next
    Me.Controls("lblSumValue").Caption = Format(total, "#,##0")
    On Error GoTo 0
End Sub

Private Sub UserForm_Terminate()
    Set m_TextBoxEvents = Nothing
    Set m_InsuranceTextBoxes = Nothing
    Set m_PaidLabels = Nothing
    Set m_RemainingLabels = Nothing
    Set m_StatusLabels = Nothing
    Set m_InsuranceTypes = Nothing
    Set m_CurrentPageSelections = Nothing
    Set m_RemainingLabelEvents = Nothing
End Sub



