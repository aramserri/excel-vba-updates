Attribute VB_Name = "modInsuranceFunds"
Option Explicit

Public Const INSURANCE_CONFIG_FIRST_ROW As Long = 200
Public Const INSURANCE_CONFIG_FIRST_COL As Long = 27   ' Column AA

' Run this once after importing the module, and again after changing the
' number or names of centres. It reads this workbook's cfg_ActualUserCenters
' and cfg_TotalCenters settings; it does not use hard-coded centre counts.
Public Sub UpgradeInsuranceFundsForThisWorkbook(Optional ByVal ShowResult As Boolean = True)
    Dim ws As Worksheet
    Dim userCenters As Long, totalCenters As Long
    Dim checkedSheets As Long, updatedSheets As Long

    On Error GoTo Fail
    Application.ScreenUpdating = False
    Application.EnableEvents = False

    EnsureInsuranceFundConfig
    userCenters = CLng(ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.value)
    totalCenters = CLng(ThisWorkbook.names("cfg_TotalCenters").RefersToRange.value)

    If userCenters < 1 Or totalCenters < userCenters Then
        Err.Raise vbObjectError + 710, , "Invalid centre configuration."
    End If

    For Each ws In ThisWorkbook.Worksheets
        If IsInsuranceMonthlySheet(ws) Then
            checkedSheets = checkedSheets + 1
            If ApplyInsuranceFundLayout(ws, userCenters, totalCenters) Then updatedSheets = updatedSheets + 1
        End If
    Next ws

CleanExit:
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    If ShowResult Then
        If Err.Number = 0 Then
            MsgBox checkedSheets & " monthly sheet(s) checked; " & updatedSheets & " upgraded.", vbInformation, "Insurance fund upgrade"
        Else
            MsgBox "Insurance fund upgrade failed: " & Err.description, vbCritical
        End If
    End If
    Exit Sub

Fail:
    Resume CleanExit
End Sub

Public Sub EnsureInsuranceFundConfig()
    Dim ws As Worksheet, headers As Variant, data As Variant
    Dim r As Long, c As Long

    Set ws = ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.Parent

    If Trim$(CStr(ws.Cells(INSURANCE_CONFIG_FIRST_ROW + 1, INSURANCE_CONFIG_FIRST_COL).value)) <> "" Then Exit Sub

    headers = Array("Code", "Display name / template", "Scope", "Storage group", "Storage order", "Display order", "Active", "Notes")
    For c = 0 To UBound(headers)
        ws.Cells(INSURANCE_CONFIG_FIRST_ROW, INSURANCE_CONFIG_FIRST_COL + c).value = headers(c)
    Next c

    data = Array( _
        Array("SOC_MAIN", U("628,64A,645,647,20,62A,627,645,64A,646,20,627,62C,62A,645,627,639,64A"), "FIXED", "LEGACY_FIXED", 1, 10, True, "Existing storage row"), _
        Array("SOC_PREF", U("628,64A,645,647,20,62A,627,645,64A,646,20,627,62C,62A,645,627,639,64A,20,627,631,632,20,62A,631,62C,64A,62D,64A"), "FIXED", "LEGACY_FIXED", 2, 20, True, "Existing storage row"), _
        Array("SOC_HARD", U("628,64A,645,647,20,62A,627,645,64A,646,20,627,62C,62A,645,627,639,64A,20,635,639,628,20,627,644,639,644,627,62C"), "FIXED", "LEGACY_FIXED", 3, 30, True, "Existing storage row"), _
        Array("MILK_HEALTH", U("627,631,632,20,634,64A,631,20,62E,634,6A9,20,628,64A,645,647,20,633,644,627,645,62A"), "FIXED", "LEGACY_FIXED", 4, 40, True, "Renamed legacy row"), _
        Array("MILK_TTAC", U("627,631,632,20,634,6CC,631,20,62E,634,6A9,20,633,627,645,627,646,647,20,62A,6CC,20,62A,6A9"), "FIXED", "APPENDED_FIXED", 1, 50, True, "New storage row"), _
        Array("PHARM_PREF", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,62F,627,631,648,62E,627,646,647,20,627,631,632,20,62A,631,62C,64A,62D,64A"), "FIXED", "LEGACY_FIXED", 5, 60, True, "Existing storage row"), _
        Array("PHARM_ORG", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,62F,627,631,648,62E,627,646,647,20,633,647,645,20,633,627,632,645,627,646"), "FIXED", "LEGACY_FIXED", 6, 70, True, "Existing storage row"), _
        Array("PHARM_HARD", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,62F,627,631,648,62E,627,646,647,20,635,639,628,20,627,644,639,644,627,62C"), "FIXED", "LEGACY_FIXED", 7, 80, True, "Existing storage row"), _
        Array("PHARM_REF", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,62F,627,631,648,62E,627,646,647,20,627,631,62C,627,639"), "FIXED", "APPENDED_FIXED", 2, 90, True, "New storage row"), _
        Array("ARMED_ORG", U("628,64A,645,647,20,645,633,644,62D,20,633,647,645,20,633,627,632,645,627,646"), "FIXED", "LEGACY_FIXED", 8, 100, True, "Renamed legacy row"), _
        Array("ARMED_PREF", U("628,64A,645,647,20,645,633,644,62D,20,627,631,632,20,62A,631,62C,64A,62D,64A"), "FIXED", "APPENDED_FIXED", 3, 110, True, "New storage row"), _
        Array("CENTER_PREF", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,7B,43,65,6E,74,65,72,7D,20,627,631,632,20,62A,631,62C,64A,62D,64A"), "CENTER", "LEGACY_CENTER", 1, 120, True, "Existing storage row"), _
        Array("CENTER_ORG", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,7B,43,65,6E,74,65,72,7D,20,633,647,645,20,633,627,632,645,627,646"), "CENTER", "LEGACY_CENTER", 2, 130, True, "Existing storage row"), _
        Array("CENTER_HARD", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,7B,43,65,6E,74,65,72,7D,20,635,639,628,20,627,644,639,644,627,62C"), "CENTER", "LEGACY_CENTER", 3, 140, True, "Existing storage row"), _
        Array("CENTER_REF", U("628,64A,645,647,20,633,644,627,645,62A,20,6A9,62F,20,7B,43,65,6E,74,65,72,7D,20,627,631,62C,627,639"), "CENTER", "APPENDED_CENTER", 1, 150, True, "New storage row") _
    )

    For r = 0 To UBound(data)
        For c = 0 To UBound(data(r))
            ws.Cells(INSURANCE_CONFIG_FIRST_ROW + r + 1, INSURANCE_CONFIG_FIRST_COL + c).value = data(r)(c)
        Next c
    Next r

    With ws.Range(ws.Cells(INSURANCE_CONFIG_FIRST_ROW, INSURANCE_CONFIG_FIRST_COL), _
                  ws.Cells(INSURANCE_CONFIG_FIRST_ROW, INSURANCE_CONFIG_FIRST_COL + 7))
        .Font.Bold = True
        .Interior.Color = RGB(70, 130, 180)
        .Font.Color = RGB(255, 255, 255)
    End With
    ws.Range(ws.Cells(INSURANCE_CONFIG_FIRST_ROW, INSURANCE_CONFIG_FIRST_COL), _
             ws.Cells(INSURANCE_CONFIG_FIRST_ROW + 14, INSURANCE_CONFIG_FIRST_COL + 7)).Font.Name = "Tahoma"
    ws.Columns(INSURANCE_CONFIG_FIRST_COL).Resize(, 8).AutoFit
    ws.Columns(INSURANCE_CONFIG_FIRST_COL + 1).ColumnWidth = 46
End Sub

Public Function InsuranceFundNames(ByVal userCenters As Long, ByVal totalCenters As Long) As Collection
    Dim answer As New Collection, items As Collection, item As Variant
    Set items = InsuranceFundItems(userCenters, totalCenters)
    For Each item In items
        answer.Add CStr(item("Name"))
    Next item
    Set InsuranceFundNames = answer
End Function

Public Function ConfiguredInsuranceFundCount(ByVal userCenters As Long, ByVal totalCenters As Long) As Long
    ConfiguredInsuranceFundCount = InsuranceFundItems(userCenters, totalCenters).count
End Function

Public Function ConfiguredInsuranceFundName(ByVal fundIndex As Long, ByVal userCenters As Long, ByVal totalCenters As Long) As String
    Dim items As Collection
    Set items = InsuranceFundItems(userCenters, totalCenters)
    If fundIndex >= 1 And fundIndex <= items.count Then ConfiguredInsuranceFundName = CStr(items(fundIndex)("Name"))
End Function

Public Function InsuranceFundRow(ByVal fundIndex As Long, ByVal userCenters As Long, ByVal totalCenters As Long) As Long
    Dim items As Collection
    Set items = InsuranceFundItems(userCenters, totalCenters)
    If fundIndex >= 1 And fundIndex <= items.count Then InsuranceFundRow = CLng(items(fundIndex)("Row"))
End Function

Public Function InsuranceFundItems(ByVal userCenters As Long, ByVal totalCenters As Long) As Collection
    Dim cfg As Collection, answer As New Collection, used As Object
    Dim entry As Object, centerNo As Long

    Set cfg = ReadInsuranceConfig()
    Set used = CreateObject("Scripting.Dictionary")
    Do
        Set entry = NextConfiguredEntry(cfg, "FIXED", used)
        If entry Is Nothing Then Exit Do
        answer.Add MakeFundItem(entry, 0, userCenters, totalCenters, cfg)
        used.Add entry("Code"), True
    Loop

    For centerNo = 2 To userCenters
        Set used = CreateObject("Scripting.Dictionary")
        Do
            Set entry = NextConfiguredEntry(cfg, "CENTER", used)
            If entry Is Nothing Then Exit Do
            answer.Add MakeFundItem(entry, centerNo, userCenters, totalCenters, cfg)
            used.Add entry("Code"), True
        Loop
    Next centerNo
    Set InsuranceFundItems = answer
End Function

Public Function ApplyInsuranceFundLayout(ByVal ws As Worksheet, ByVal userCenters As Long, ByVal totalCenters As Long) As Boolean
    Dim cfg As Collection, items As Collection, item As Variant
    Dim baseRow As Long, legacyRows As Long, totalRows As Long, addedRows As Long
    Dim firstAppendedRow As Long, i As Long, alreadyUpgraded As Boolean

    EnsureInsuranceFundConfig
    Set cfg = ReadInsuranceConfig()
    Set items = InsuranceFundItems(userCenters, totalCenters)

    baseRow = InsuranceFundStartRow(userCenters, totalCenters)
    legacyRows = CountStorageGroup(cfg, "LEGACY_FIXED") + (userCenters - 1) * CountStorageGroup(cfg, "LEGACY_CENTER")
    totalRows = CountStorageGroup(cfg, "LEGACY_FIXED") + CountStorageGroup(cfg, "APPENDED_FIXED") + _
                (userCenters - 1) * (CountStorageGroup(cfg, "LEGACY_CENTER") + CountStorageGroup(cfg, "APPENDED_CENTER"))
    addedRows = totalRows - legacyRows
    firstAppendedRow = baseRow + legacyRows

    alreadyUpgraded = True
    For Each item In items
        If Trim$(CStr(ws.Cells(CLng(item("Row")), "B").value)) <> CStr(item("Name")) Then
            alreadyUpgraded = False
            Exit For
        End If
    Next item

    If Not alreadyUpgraded Then
        ' Empty space is used first. Rows are inserted only if a populated row
        ' would be displaced. This preserves historical payment values/comments.
        If WorksheetFunction.CountA(ws.rows(firstAppendedRow)) > 0 Then
            ws.rows(firstAppendedRow).Resize(addedRows).Insert Shift:=xlDown
        End If

        For i = 0 To addedRows - 1
            ws.rows(firstAppendedRow - 1).Copy
            ws.rows(firstAppendedRow + i).PasteSpecial xlPasteFormats
            ws.rows(firstAppendedRow + i).RowHeight = ws.rows(firstAppendedRow - 1).RowHeight
            ws.Range(ws.Cells(firstAppendedRow + i, 3), ws.Cells(firstAppendedRow + i, 50)).ClearContents
            ws.Range(ws.Cells(firstAppendedRow + i, 3), ws.Cells(firstAppendedRow + i, 50)).ClearComments
        Next i
        Application.CutCopyMode = False

        For Each item In items
            ws.Cells(CLng(item("Row")), "B").value = CStr(item("Name"))
            ws.Cells(CLng(item("Row")), "C").NumberFormat = "#,##0"
        Next item
        ApplyInsuranceFundLayout = True
    End If

    ws.Cells(baseRow - 8, "C").Formula = "=SUM(C" & baseRow & ":C" & (baseRow + totalRows - 1) & ")"
    ws.Cells(baseRow - 8, "C").NumberFormat = "#,##0"
End Function

Public Function InsuranceFundStartRow(ByVal userCenters As Long, ByVal totalCenters As Long) As Long
    InsuranceFundStartRow = 2 + 31 * (IIf(userCenters = 1, 2, totalCenters) + 1) + 2 + 10 + userCenters + 1
End Function

Private Function ReadInsuranceConfig() As Collection
    Dim ws As Worksheet, answer As New Collection, entry As Object
    Dim r As Long, lastRow As Long

    EnsureInsuranceFundConfig
    Set ws = ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.Parent
    lastRow = ws.Cells(ws.rows.count, INSURANCE_CONFIG_FIRST_COL).End(xlUp).Row

    For r = INSURANCE_CONFIG_FIRST_ROW + 1 To lastRow
        If Trim$(CStr(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL).value)) <> "" Then
            Set entry = CreateObject("Scripting.Dictionary")
            entry.Add "Code", CStr(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL).value)
            entry.Add "NameTemplate", CStr(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 1).value)
            entry.Add "Scope", UCase$(CStr(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 2).value))
            entry.Add "StorageGroup", UCase$(CStr(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 3).value))
            entry.Add "StorageOrder", CLng(val(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 4).value))
            entry.Add "DisplayOrder", CLng(val(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 5).value))
            entry.Add "Active", CBool(ws.Cells(r, INSURANCE_CONFIG_FIRST_COL + 6).value)
            answer.Add entry
        End If
    Next r
    Set ReadInsuranceConfig = answer
End Function

Private Function NextConfiguredEntry(ByVal cfg As Collection, ByVal scope As String, ByVal used As Object) As Object
    Dim entry As Variant, best As Object, bestOrder As Long
    bestOrder = 2147483647
    For Each entry In cfg
        If CStr(entry("Scope")) = scope And CBool(entry("Active")) And Not used.exists(CStr(entry("Code"))) Then
            If CLng(entry("DisplayOrder")) < bestOrder Then
                Set best = entry
                bestOrder = CLng(entry("DisplayOrder"))
            End If
        End If
    Next entry
    Set NextConfiguredEntry = best
End Function

Private Function MakeFundItem(ByVal entry As Object, ByVal centerNo As Long, ByVal userCenters As Long, ByVal totalCenters As Long, ByVal cfg As Collection) As Object
    Dim item As Object, nameText As String
    Set item = CreateObject("Scripting.Dictionary")
    nameText = CStr(entry("NameTemplate"))
    If centerNo > 0 Then nameText = Replace(nameText, "{Center}", InsuranceCenterName(centerNo))
    item.Add "Name", nameText
    item.Add "Row", InsuranceFundStartRow(userCenters, totalCenters) + StorageOffset(entry, centerNo, userCenters, cfg) - 1
    Set MakeFundItem = item
End Function

Private Function StorageOffset(ByVal entry As Object, ByVal centerNo As Long, ByVal userCenters As Long, ByVal cfg As Collection) As Long
    Dim legacyFixed As Long, legacyCenter As Long, appendedFixed As Long, appendedCenter As Long
    legacyFixed = CountStorageGroup(cfg, "LEGACY_FIXED")
    legacyCenter = CountStorageGroup(cfg, "LEGACY_CENTER")
    appendedFixed = CountStorageGroup(cfg, "APPENDED_FIXED")
    appendedCenter = CountStorageGroup(cfg, "APPENDED_CENTER")

    Select Case CStr(entry("StorageGroup"))
        Case "LEGACY_FIXED": StorageOffset = CLng(entry("StorageOrder"))
        Case "LEGACY_CENTER": StorageOffset = legacyFixed + (centerNo - 2) * legacyCenter + CLng(entry("StorageOrder"))
        Case "APPENDED_FIXED": StorageOffset = legacyFixed + (userCenters - 1) * legacyCenter + CLng(entry("StorageOrder"))
        Case "APPENDED_CENTER": StorageOffset = legacyFixed + (userCenters - 1) * legacyCenter + appendedFixed + (centerNo - 2) * appendedCenter + CLng(entry("StorageOrder"))
    End Select
End Function

Private Function CountStorageGroup(ByVal cfg As Collection, ByVal groupName As String) As Long
    Dim entry As Variant
    For Each entry In cfg
        If CStr(entry("StorageGroup")) = groupName Then CountStorageGroup = CountStorageGroup + 1
    Next entry
End Function

Private Function InsuranceCenterName(ByVal centerNo As Long) As String
    Dim infoSheet As Worksheet
    Set infoSheet = ThisWorkbook.names("cfg_ActualUserCenters").RefersToRange.Parent
    InsuranceCenterName = Trim$(CStr(infoSheet.Cells(centerNo + 1, "AA").value))
    If InsuranceCenterName = "" Then InsuranceCenterName = "Center " & centerNo
End Function

Private Function IsInsuranceMonthlySheet(ByVal ws As Worksheet) As Boolean
    Dim dateText As String, parts() As String
    dateText = Trim$(CStr(ws.Range("B1").value))
    If InStr(dateText, "/") = 0 Then Exit Function
    parts = Split(dateText, "/")
    If UBound(parts) < 1 Then Exit Function
    If Not IsNumeric(parts(0)) Or Not IsNumeric(parts(1)) Then Exit Function
    IsInsuranceMonthlySheet = (CLng(parts(0)) >= 1300 And CLng(parts(0)) <= 1500 And CLng(parts(1)) >= 1 And CLng(parts(1)) <= 12)
End Function

Private Function U(ByVal hexList As String) As String
    Dim parts() As String, i As Long
    parts = Split(hexList, ",")
    For i = LBound(parts) To UBound(parts)
        U = U & ChrW(CLng("&H" & parts(i)))
    Next i
End Function
