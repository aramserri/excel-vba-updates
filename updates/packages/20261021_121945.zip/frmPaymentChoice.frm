VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmPaymentChoice 
   Caption         =   "������ ��� ������"
   ClientHeight    =   1005
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   2865
   OleObjectBlob   =   "frmPaymentChoice.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmPaymentChoice"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False



Option Explicit

Public CashSelected As Boolean

Private Sub cmdCash_Click()
    CashSelected = True
    Me.Hide
End Sub

Private Sub cmdNormal_Click()
    CashSelected = False
    Me.Hide
End Sub

Private Sub UserForm_Initialize()
    CashSelected = False
End Sub

