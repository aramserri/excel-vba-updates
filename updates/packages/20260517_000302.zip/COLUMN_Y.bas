Attribute VB_Name = "COLUMN_Y"
Option Explicit

  Private Const INFO_SHEET_NAME As String = "�������"
  Private Const INFO_DATE_LIST_COL As String = "U"
  Private Const INFO_BANK_CLEARING_COL As String = "Y"

  Public Sub FillBankClearingFormulasColumnY()
      Dim wsInfo As Worksheet
      Dim wsMonth As Worksheet
      Dim lastRow As Long
      Dim r As Long
      Dim persianDate As String
      Dim cleanDate As String
      Dim parts() As String
      Dim ym As String
      Dim dayNum As Long

      Dim numCheques As Long
      Dim firstChequeCol As Long
      Dim lastChequeCol As Long
      Dim totalCenters As Long
      Dim userCenters As Long
      Dim rowsPerDay As Long
      Dim totalRowsPerDayBlock As Long
      Dim lowerHalfStartOffset As Long
      Dim dayStartRow As Long
      Dim amountRow As Long

      Dim c As Long
      Dim formulaText As String
      Dim sheetName As String

      Set wsInfo = GetInfoSheetY()
      If wsInfo Is Nothing Then
          MsgBox "Sheet ������� was not found. Check INFO_SHEET_NAME in the module.", vbCritical
          Exit Sub
      End If

      numCheques = ReadConfigValueY("cfg_NumCheques")
      totalCenters = ReadConfigValueY("cfg_TotalCenters")
      userCenters = ReadConfigValueY("cfg_ActualUserCenters")

      If numCheques <= 0 Or totalCenters <= 0 Then
          MsgBox "Config values were not read correctly. Check cfg_NumCheques and cfg_TotalCenters.", vbCritical
          Exit Sub
      End If

      firstChequeCol = 14
      lastChequeCol = firstChequeCol + (numCheques * 2) - 2

      rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
      totalRowsPerDayBlock = rowsPerDay + 1
      lowerHalfStartOffset = rowsPerDay \ 2

      lastRow = wsInfo.Cells(wsInfo.rows.count, INFO_DATE_LIST_COL).End(xlUp).row

      Application.ScreenUpdating = False

      For r = 2 To lastRow
          persianDate = Trim(CStr(wsInfo.Cells(r, INFO_DATE_LIST_COL).value))

          If persianDate <> "" Then
              cleanDate = ConvertPersianNumsToEnglishKeepSlashY(persianDate)

              If IsValidPersianDateY(cleanDate) Then
                  parts = Split(cleanDate, "/")

                  ym = CLng(parts(0)) & "/" & Format(CLng(parts(1)), "00")
                  dayNum = CLng(parts(2))

                  Set wsMonth = FindSheetByYMY(ym)

                  If Not wsMonth Is Nothing Then
                      dayStartRow = FindDayRowY(wsMonth, dayNum, totalRowsPerDayBlock)

                      If dayStartRow > 0 Then
                          amountRow = dayStartRow + lowerHalfStartOffset
                          sheetName = "'" & Replace(wsMonth.Name, "'", "''") & "'"

                          formulaText = "=SUM("

                          For c = firstChequeCol To lastChequeCol Step 2
                              formulaText = formulaText & sheetName & "!" & wsMonth.Cells(amountRow, c).Address(False, False) & ","
                          Next c

                          formulaText = Left$(formulaText, Len(formulaText) - 1) & ")"

                          wsInfo.Cells(r, INFO_BANK_CLEARING_COL).Formula = formulaText
                      Else
                          wsInfo.Cells(r, INFO_BANK_CLEARING_COL).value = 0
                      End If
                  Else
                      wsInfo.Cells(r, INFO_BANK_CLEARING_COL).value = 0
                  End If
              Else
                  wsInfo.Cells(r, INFO_BANK_CLEARING_COL).ClearContents
              End If
          Else
              wsInfo.Cells(r, INFO_BANK_CLEARING_COL).ClearContents
          End If

          Set wsMonth = Nothing
      Next r

      Application.ScreenUpdating = True

      MsgBox "Column Y formulas were created successfully.", vbInformation, "Column Y"
  End Sub

  Private Function GetInfoSheetY() As Worksheet
      On Error Resume Next

      Set GetInfoSheetY = ThisWorkbook.Sheets(INFO_SHEET_NAME)

      If GetInfoSheetY Is Nothing Then
          Set GetInfoSheetY = ThisWorkbook.Sheets("�������")
      End If

      If GetInfoSheetY Is Nothing Then
          Set GetInfoSheetY = ThisWorkbook.Sheets("???????")
      End If

      On Error GoTo 0
  End Function

  Private Function ReadConfigValueY(ByVal configName As String) As Long
      Dim wsInfo As Worksheet
      Dim v As Variant

      Set wsInfo = GetInfoSheetY()
      If wsInfo Is Nothing Then Exit Function

      On Error Resume Next
      v = wsInfo.Range(configName).value

      If IsNumeric(v) Then
          ReadConfigValueY = CLng(v)
      Else
          ReadConfigValueY = 0
      End If

      On Error GoTo 0
  End Function

  Private Function FindSheetByYMY(ByVal ym As String) As Worksheet
      Dim ws As Worksheet

      For Each ws In ThisWorkbook.Worksheets
          If Trim(CStr(ws.Range("B1").value)) = ym Then
              Set FindSheetByYMY = ws
              Exit Function
          End If
      Next ws

      Set FindSheetByYMY = Nothing
  End Function

  Private Function FindDayRowY(ByVal ws As Worksheet, ByVal dayNum As Long, ByVal totalRowsPerDayBlock As Long) As Long
      Dim dayStartRow As Long

      dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock

      If ws.Cells(dayStartRow, "A").value = dayNum Then
          FindDayRowY = dayStartRow
      Else
          FindDayRowY = 0
      End If
  End Function

  Private Function ConvertPersianNumsToEnglishKeepSlashY(ByVal s As Variant) As String
      Dim i As Long
      Dim out As String
      Dim ch As String
      Dim code As Long

      If IsNull(s) Or IsEmpty(s) Then
          ConvertPersianNumsToEnglishKeepSlashY = ""
          Exit Function
      End If

      s = CStr(s)
      out = ""

      For i = 1 To Len(s)
          ch = Mid$(s, i, 1)
          code = AscW(ch)

          Select Case code
              Case 1776 To 1785
                  out = out & CStr(code - 1776)
              Case 1632 To 1641
                  out = out & CStr(code - 1632)
              Case 48 To 57
                  out = out & ch
              Case 47
                  out = out & "/"
              Case 32
                  out = out & " "
              Case Else
                  If ch >= "0" And ch <= "9" Then
                      out = out & ch
                  ElseIf ch = "/" Then
                      out = out & "/"
                  End If
          End Select
      Next i

      ConvertPersianNumsToEnglishKeepSlashY = Trim(out)
  End Function

  Private Function IsValidPersianDateY(ByVal dateStr As String) As Boolean
      Dim parts() As String
      Dim y As Long
      Dim m As Long
      Dim d As Long
      Dim maxDay As Long

      On Error GoTo InvalidDate

      dateStr = ConvertPersianNumsToEnglishKeepSlashY(dateStr)

      If InStr(dateStr, "/") = 0 Then GoTo InvalidDate

      parts = Split(dateStr, "/")
      If UBound(parts) <> 2 Then GoTo InvalidDate

      y = CLng(Trim(parts(0)))
      m = CLng(Trim(parts(1)))
      d = CLng(Trim(parts(2)))

      If y < 1300 Or y > 1500 Then GoTo InvalidDate
      If m < 1 Or m > 12 Then GoTo InvalidDate
      If d < 1 Then GoTo InvalidDate

      If m >= 1 And m <= 6 Then
          maxDay = 31
      ElseIf m >= 7 And m <= 11 Then
          maxDay = 30
      Else
          maxDay = IIf(((y - 1403) Mod 4 = 0), 30, 29)
      End If

      If d > maxDay Then GoTo InvalidDate

      IsValidPersianDateY = True
      Exit Function

InvalidDate:
      IsValidPersianDateY = False
  End Function
