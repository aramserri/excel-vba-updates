VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmScrollableText 
   Caption         =   "���� ����"
   ClientHeight    =   3850
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   3899
   OleObjectBlob   =   "frmScrollableText.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmScrollableText"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 Option Explicit

  Private MouseWheelHandlers As Collection

  Public Sub ShowText(ByVal displayText As String, ByVal windowTitle As String)
      Me.Caption = windowTitle

 With Me
      .Width = 400
      .Height = 520
      .Font.Name = "Tahoma"
      .Font.Size = 10
  End With

  With Me.lstContent
      .Top = 10
      .Left = 10
      .Width = 300
      .Height = 430
      .Font.Name = "Tahoma"
      .Font.Size = 11
      .ColumnCount = 2
      .ColumnWidths = "200 pt;30 pt"
      .TextAlign = fmTextAlignRight
      .Clear
  End With

  With Me.cmdClose
      .Caption = "����"
      .Top = 450
      .Left = 255
      .Width = 90
      .Height = 28
  End With
FillListFromText displayText

      Set MouseWheelHandlers = New Collection
      AttachMouseWheelToControls Me

      Me.Show vbModal
  End Sub

 Private Sub FillListFromText(ByVal displayText As String)
      Dim lines() As String
      Dim i As Long
      Dim rowIndex As Long

      displayText = Replace(displayText, vbCrLf, vbLf)
      displayText = Replace(displayText, vbCr, vbLf)

      lines = Split(displayText, vbLf)

      For i = LBound(lines) To UBound(lines)
          rowIndex = Me.lstContent.ListCount
          Me.lstContent.AddItem
          Me.lstContent.List(rowIndex, 0) = lines(i)
          Me.lstContent.List(rowIndex, 1) = ""
      Next i
  End Sub

  Private Sub cmdClose_Click()
      Unload Me
  End Sub

  Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
      modMouseScroll.StopHook
  End Sub

  Private Sub AttachMouseWheelToControls(ByVal parentObj As Object)
      Dim ctl As Control
      Dim pg As Page
      Dim mw As clsMouseWheel

      On Error Resume Next

      For Each ctl In parentObj.Controls
          If typeName(ctl) = "ListBox" Or typeName(ctl) = "ComboBox" Then
              Set mw = New clsMouseWheel
              mw.Attach ctl
              MouseWheelHandlers.Add mw
          End If

          If typeName(ctl) = "Frame" Then
              AttachMouseWheelToControls ctl
          ElseIf typeName(ctl) = "MultiPage" Then
              For Each pg In ctl.Pages
                  AttachMouseWheelToControls pg
              Next pg
          End If
      Next ctl

      On Error GoTo 0
  End Sub
