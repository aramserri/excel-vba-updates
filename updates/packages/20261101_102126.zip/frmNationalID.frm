VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmNationalID 
   Caption         =   "����� ��� ���� ���"
   ClientHeight    =   5220
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   8565.001
   OleObjectBlob   =   "frmNationalID.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmNationalID"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Public NationalID As String
Public companyName As String
Public Cancelled As Boolean

Private Sub UserForm_Initialize()
    NationalID = ""
    Cancelled = True
    txtNationalID.value = ""
    txtNationalID.MaxLength = 11
End Sub

Private Sub UserForm_Activate()
    lblCompanyName.Caption = companyName
    txtNationalID.SetFocus
End Sub

'----------------------------------------
' Convert Persian/Arabic digits to English on every change
'----------------------------------------
Private Sub txtNationalID_Change()
    Dim oldText As String
    Dim newText As String
    Dim cursorPos As Long
    
    ' Remember cursor position
    cursorPos = txtNationalID.SelStart
    
    oldText = txtNationalID.value
    newText = ConvertToEnglishDigitsOnly(oldText)
    
    ' Only update if changed (prevents infinite loop)
    If newText <> oldText Then
        txtNationalID.value = newText
        ' Restore cursor position (adjust if text got shorter)
        If cursorPos > Len(newText) Then
            txtNationalID.SelStart = Len(newText)
        Else
            txtNationalID.SelStart = cursorPos
        End If
    End If
End Sub

'----------------------------------------
' Convert Persian/Arabic digits to English, keep only digits
'----------------------------------------
Private Function ConvertToEnglishDigitsOnly(ByVal inputText As String) As String
    Dim i As Long
    Dim code As Long
    Dim result As String
    
    result = ""
    
    For i = 1 To Len(inputText)
        code = AscW(Mid(inputText, i, 1))
        
        Select Case code
            ' English digits (0-9)
            Case 48 To 57
                result = result & Chr(code)
            ' Persian digits (�-�)
            Case 1776 To 1785
                result = result & CStr(code - 1776)
            ' Arabic-Indic digits (�-�)
            Case 1632 To 1641
                result = result & CStr(code - 1632)
            ' Skip everything else
        End Select
    Next i
    
    ConvertToEnglishDigitsOnly = result
End Function

'----------------------------------------
' OK button
'----------------------------------------
Private Sub btnOK_Click()
    Dim cleanedID As String
    cleanedID = Trim(txtNationalID.value)
    
    If Len(cleanedID) = 0 Then
        MsgBox "����� ����� ��� �� ���� ����.", vbExclamation, "���"
        txtNationalID.SetFocus
        Exit Sub
    End If
    
    ' Validate length
    If Len(cleanedID) <> 10 And Len(cleanedID) <> 11 Then
        Dim saveAnyway As VbMsgBoxResult
        saveAnyway = MsgBox("����� ��� �јʝ�� ����� ��� � ����� �� ��� ���." & vbCrLf & _
                            "����� ���� ���: " & cleanedID & " (" & Len(cleanedID) & " ���)" & vbCrLf & vbCrLf & _
                            "��� �������� ����� ���Ͽ", _
                            vbYesNo + vbQuestion, "�����")
        If saveAnyway = vbNo Then
            txtNationalID.SetFocus
            Exit Sub
        End If
    End If
    
    NationalID = cleanedID
    Cancelled = False
    Me.Hide
End Sub

'----------------------------------------
' Cancel button
'----------------------------------------
Private Sub btnCancel_Click()
    NationalID = ""
    Cancelled = True
    Me.Hide
End Sub

'----------------------------------------
' Handle Enter and Escape keys
'----------------------------------------
Private Sub txtNationalID_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Then
        Call btnOK_Click
        KeyCode = 0
    ElseIf KeyCode = vbKeyEscape Then
        Call btnCancel_Click
        KeyCode = 0
    End If
End Sub

'----------------------------------------
' Handle X button
'----------------------------------------
Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        NationalID = ""
        Cancelled = True
    End If
End Sub

