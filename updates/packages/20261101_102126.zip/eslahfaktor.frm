VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} eslahfaktor 
   Caption         =   "����� �ǘ���"
   ClientHeight    =   11415
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   14955
   OleObjectBlob   =   "eslahfaktor.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "eslahfaktor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False







Option Explicit

'----------------------------------------------------------------------------------
' Helper Function to Read Configuration from Named Ranges
'----------------------------------------------------------------------------------
Private Function ReadConfigValue(configName As String) As Long
    ' Reads a numeric value from a named range on the "�������" sheet.
    ' Returns 0 if the named range is not found or contains a non-numeric value.
    On Error Resume Next
    Dim val As Variant
    val = ThisWorkbook.Sheets("�������").Range(configName).value
    If IsNumeric(val) Then
        ReadConfigValue = CLng(val)
    Else
        ReadConfigValue = 0
    End If
    On Error GoTo 0
End Function

'-------------------------------
' UserForm Initialize
'-------------------------------
Private Sub UserForm_Initialize()
    Dim configSheet As Worksheet
    Dim cell As Range
    Dim lastRow As Long
    Dim i As Long, j As Long
    Dim tempVal As String
    Dim foundSeparator As Boolean
    
    ' Arrays for companies and others
    Dim companyArr() As String
    Dim otherArr() As String
    Dim companyCount As Long
    Dim otherCount As Long
    
    On Error Resume Next
    Set configSheet = ThisWorkbook.Sheets("�������")
    On Error GoTo 0
    
    If configSheet Is Nothing Then
        MsgBox "���: ��� ������� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ComboBox1.Clear
    
    ' Find last row in column A
    lastRow = configSheet.Cells(configSheet.rows.count, "A").End(xlUp).Row
    If lastRow < 2 Then
        MsgBox "���: ���� �јʝ�� ���� ���.", vbCritical
        Exit Sub
    End If
    
    ' First pass: count items
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
            Else
                otherCount = otherCount + 1
            End If
        End If
    Next cell
    
    ' Initialize arrays
    If companyCount > 0 Then ReDim companyArr(1 To companyCount)
    If otherCount > 0 Then ReDim otherArr(1 To otherCount)
    
    ' Second pass: fill arrays (using GetCompanyName to strip beneficiary)
    companyCount = 0
    otherCount = 0
    foundSeparator = False
    
    For Each cell In configSheet.Range("A2:A" & lastRow)
        If Len(Trim(cell.value)) > 0 Then
            If Trim(cell.value) = "***" Then
                foundSeparator = True
            ElseIf Not foundSeparator Then
                companyCount = companyCount + 1
                companyArr(companyCount) = GetCompanyName(cell.value)
            Else
                otherCount = otherCount + 1
                otherArr(otherCount) = GetCompanyName(cell.value)
            End If
        End If
    Next cell
    
    ' Sort company array (Bubble Sort)
    If companyCount > 1 Then
        For i = 1 To companyCount - 1
            For j = i + 1 To companyCount
                If StrComp(companyArr(i), companyArr(j), vbTextCompare) > 0 Then
                    tempVal = companyArr(i)
                    companyArr(i) = companyArr(j)
                    companyArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Sort other array (Bubble Sort)
    If otherCount > 1 Then
        For i = 1 To otherCount - 1
            For j = i + 1 To otherCount
                If StrComp(otherArr(i), otherArr(j), vbTextCompare) > 0 Then
                    tempVal = otherArr(i)
                    otherArr(i) = otherArr(j)
                    otherArr(j) = tempVal
                End If
            Next j
        Next i
    End If
    
    ' Add companies to ComboBox
    For i = 1 To companyCount
        ComboBox1.AddItem companyArr(i)
    Next i
    
    ' Add separator and others if exists
    If otherCount > 0 Then
        ComboBox1.AddItem "-------------"
        For i = 1 To otherCount
            ComboBox1.AddItem otherArr(i)
        Next i
    End If
    
    ' Initialize other controls
    ListBox1.ColumnCount = 4
    ListBox1.ColumnWidths = "170;220;130;156"
    ListBox1.MultiSelect = fmMultiSelectMulti
    TextBox1.value = ""
    TextBox2.value = ""
    TextBox3.value = ""
    CheckBox1.value = False
    CheckBox2.value = False
End Sub

'-------------------------------
' Search unpaid/paid factors
'-------------------------------
Private Sub CommandButton1_Click()
    Dim ws As Worksheet, r As Long, c As Long
    Dim company As String, factorDate As String
    Dim amount As Variant, forjeh As Variant, status As String
    Dim yearNum As Long, monthNum As Long, dayNum As Long
    Dim results As Collection: Set results = New Collection

    ' --- Read Dynamic Configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")
    Dim startYear As Long: startYear = ReadConfigValue("cfg_StartYear")
    Dim yearCount As Long: yearCount = ReadConfigValue("cfg_YearCount")

    If numFactors = 0 Or totalCenters = 0 Or startYear = 0 Then
        MsgBox "Configuration values could not be read from the '�������' sheet. Please ensure the workbook was generated correctly.", vbCritical
        Exit Sub
    End If

    ' --- Calculate Dynamic Column and Row Offsets ---
    Dim firstFactorCol As Long
    firstFactorCol = 14 + (numCheques * 2) + 1 ' Column N + Cheques Section + 1 spacer column
    Dim lastFactorCol As Long
    lastFactorCol = firstFactorCol + (numFactors * 2) - 2

    Dim rowsPerDay As Long
    rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long
    totalRowsPerDayBlock = rowsPerDay + 1
    
    Dim upperHalfStartOffset As Long: upperHalfStartOffset = 0
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ListBox1.Clear
    company = Trim(ComboBox1.value)
    If company = "" Then MsgBox "����� �ј� �� ������ ����.", vbExclamation: Exit Sub

    ' --- Loop through sheets within the generated year range ---
    Dim endYear As Long: endYear = startYear + yearCount - 1
    
    For Each ws In ThisWorkbook.Worksheets
        If ws.Name <> "�������" And ws.Name <> "�������" And InStr(ws.Name, "�����") = 0 Then
            On Error Resume Next
            yearNum = CLng(Split(ws.Range("B1").value, "/")(0))
            monthNum = CLng(Split(ws.Range("B1").value, "/")(1))
            On Error GoTo 0

            ' Only process sheets within the valid year range
            If yearNum >= startYear And yearNum <= endYear Then
                
                ' Loop through each day block in the sheet
                Dim dayStartRow As Long
                For dayNum = 1 To 31
                    dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                    
                    ' Stop if we've passed the last entry for the month
                    If IsEmpty(ws.Cells(dayStartRow, "A").value) Then Exit For

                    ' Loop through the dynamically calculated factor columns
                    For c = firstFactorCol To lastFactorCol Step 2
                        If Trim(ws.Cells(dayStartRow + upperHalfStartOffset, c).value) = company Then
                            amount = ws.Cells(dayStartRow + lowerHalfStartOffset, c).value
                            forjeh = ws.Cells(dayStartRow + lowerHalfStartOffset, c + 1).value
                            status = Trim(ws.Cells(dayStartRow + upperHalfStartOffset, c + 1).value)
                            factorDate = FormatJalaliDate(yearNum, monthNum, dayNum)

                            ' Add to collection for reverse display
                            results.Add Array(factorDate, amount, forjeh, status, ws.Name, dayStartRow, c)
                        End If
                    Next c
                Next dayNum
            End If
        End If
    Next ws

    ' Populate list in reverse order for chronological display
    Dim i As Long
    For i = results.count To 1 Step -1
        With ListBox1
            .AddItem results(i)(0) ' factorDate
            .List(.ListCount - 1, 1) = Format(results(i)(1), "#,##0") ' amount
            .List(.ListCount - 1, 2) = results(i)(2) ' forjeh
            .List(.ListCount - 1, 3) = IIf(results(i)(3) = "", "����� ����", "����� ���") ' status
        End With
    Next i
End Sub

'-------------------------------
' Edit selected factor
'-------------------------------
Private Sub CommandButton2_Click()
    Dim idx As Long, selectedCount As Long
    Dim parts() As String
    Dim y As String, m As String, d As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim rawDate As String
    Dim foundCol As Boolean

    If Me.ListBox1.listIndex = -1 Then
        MsgBox "�� �ǘ���� ������ ���� ���.", vbExclamation
        Exit Sub
    End If
    
    idx = Me.ListBox1.listIndex
    
    ' --- Read Dynamic Configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    ' --- Calculate Dynamic Column and Row Offsets ---
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    rawDate = Trim(CStr(Me.ListBox1.List(idx, 0)))
    If InStr(rawDate, "/") = 0 Then Exit Sub
    parts = Split(rawDate, "/")
    If UBound(parts) <> 2 Then Exit Sub

    y = parts(0): m = parts(1): d = parts(2)
    Set ws = FindSheet(y & "/" & Format(CInt(m), "00"))
    If ws Is Nothing Then Exit Sub

    r = 2 + (val(d) - 1) * totalRowsPerDayBlock
    foundCol = False

    Dim selectedAmount As Double, selectedForjeh As Double
    selectedAmount = CDbl(Replace(ListBox1.List(idx, 1), ",", ""))
    selectedForjeh = val(ListBox1.List(idx, 2))

    ' Find the exact factor to edit
    For c = firstFactorCol To lastFactorCol Step 2
        If Trim(ws.Cells(r, c).value) = Trim(ComboBox1.value) Then
            If CDbl(ws.Cells(r + lowerHalfStartOffset, c).value) = selectedAmount And _
               val(ws.Cells(r + lowerHalfStartOffset, c + 1).value) = selectedForjeh Then
                foundCol = True
                Exit For
            End If
        End If
    Next c

    If Not foundCol Then
        MsgBox "�ǘ��� ������ ���� ������ ���� ���.", vbExclamation
        Exit Sub
    End If

    ' --- Edit fields ---
    If TextBox2.value <> "" Then
        On Error Resume Next
        ws.Cells(r + lowerHalfStartOffset, c).value = EvaluateExpression(TextBox2.value)
        If Err.Number <> 0 Then
            MsgBox "����� ���� ���� ��� ���� ������ ����.", vbExclamation
            On Error GoTo 0
            Exit Sub
        End If
        On Error GoTo 0
    End If

    If TextBox3.value <> "" Then
        If IsNumeric(TextBox3.value) Then
            ws.Cells(r + lowerHalfStartOffset, c + 1).value = val(TextBox3.value)
        Else
            MsgBox "����� ���� ���� ��� ������� ���.", vbExclamation
            Exit Sub
        End If
    End If

    ' Refresh and clear
    Call CommandButton1_Click
    TextBox1.value = ""
    TextBox2.value = ""
    TextBox3.value = ""
End Sub

'-------------------------------
' Update paid status
'-------------------------------
Private Sub CommandButton3_Click()
    Dim i As Long, selectedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim statusVal As String
    Dim dateStr As String
    Dim listAmount As Double, listForjeh As Double
    Dim cellAmount As Variant, cellForjeh As Variant
    
    ' --- Read Dynamic Configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    ' --- Calculate Dynamic Column and Row Offsets ---
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i

    If selectedCount = 0 Then
        MsgBox "�� �ǘ���� ������ ����.", vbExclamation
        Exit Sub
    End If

    If (CheckBox1.value And CheckBox2.value) Or (Not CheckBox1.value And Not CheckBox2.value) Then
        MsgBox "����� ��� �� �� �������� '����� ���' �� '����� ����' �� ������ ����.", vbExclamation
        Exit Sub
    End If

    If CheckBox1.value Then
        statusVal = ThisWorkbook.Sheets("�������").Range("D1").value ' "����� ��"
    Else
        statusVal = "" ' Unpaid
    End If

    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then
            dateStr = Trim(Me.ListBox1.List(i, 0))
            If InStr(dateStr, "/") > 0 Then
                parts = Split(dateStr, "/")
                If UBound(parts) = 2 Then
                    Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
                    If Not ws Is Nothing Then
                        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
                        listAmount = CDbl(Replace(ListBox1.List(i, 1), ",", ""))
                        listForjeh = val(ListBox1.List(i, 2))

                        For c = firstFactorCol To lastFactorCol Step 2
                            If ws.Cells(r, c).value = ComboBox1.value Then
                                cellAmount = ws.Cells(r + lowerHalfStartOffset, c).value
                                cellForjeh = ws.Cells(r + lowerHalfStartOffset, c + 1).value
                                If CDbl(cellAmount) = listAmount And val(cellForjeh) = listForjeh Then
                                    ws.Cells(r, c + 1).value = statusVal
                                    Exit For
                                End If
                            End If
                        Next c
                    End If
                End If
            End If
        End If
    Next i

    MsgBox "����� �ǘ������ �����ȝ��� ����� ����� ��.", vbInformation
    Call CommandButton1_Click ' Refresh list
End Sub

Private Sub CommandButton4_Click()
    Dim i As Long, deletedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long
    Dim dateStr As String
    Dim listAmtStr As String, listForjStr As String
    Dim cellAmtStr As String, cellForjStr As String
    Dim found As Boolean

    ' --- Read Dynamic Configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    ' --- Calculate Dynamic Column and Row Offsets ---
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ' Count selection
    Dim selectedCount As Long
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i
    If selectedCount = 0 Then
        MsgBox "�� �ǘ���� ������ ����.", vbExclamation
        Exit Sub
    End If

    ' Confirm deletion
    If MsgBox("��� ���� �� ��� �ǘ���(���) �����ȝ��� ����Ͽ ��� ������ ���� ��Ґ�� ����.", vbYesNo + vbExclamation, "����� ���") = vbNo Then Exit Sub

    For i = 0 To Me.ListBox1.ListCount - 1
        If Not Me.ListBox1.Selected(i) Then GoTo NextIterDel

        dateStr = Trim(Me.ListBox1.List(i, 0))
        If InStr(dateStr, "/") = 0 Then GoTo NextIterDel
        parts = Split(dateStr, "/")
        If UBound(parts) <> 2 Then GoTo NextIterDel

        Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
        If ws Is Nothing Then GoTo NextIterDel

        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
        listAmtStr = NormalizeNumber(ListBox1.List(i, 1))
        listForjStr = NormalizeNumber(ListBox1.List(i, 2))

        found = False
        For c = firstFactorCol To lastFactorCol Step 2
            If Trim(ws.Cells(r, c).value) = Trim(ComboBox1.value) Then
                cellAmtStr = NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c).value)
                cellForjStr = NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value)

                If cellAmtStr <> "" And IsNumeric(cellAmtStr) Then
                    If CDbl(cellAmtStr) = IIf(listAmtStr <> "" And IsNumeric(listAmtStr), CDbl(listAmtStr), 0) And _
                       val(cellForjStr) = IIf(listForjStr <> "" And IsNumeric(listForjStr), val(listForjStr), 0) Then
                        ' Clear the factor in both upper and lower rows (name/status and amount/forjeh)
                        ws.Cells(r, c).MergeArea.ClearContents
                        ws.Cells(r, c + 1).MergeArea.ClearContents
                        ws.Cells(r + lowerHalfStartOffset, c).MergeArea.ClearContents
                        ws.Cells(r + lowerHalfStartOffset, c + 1).MergeArea.ClearContents
                        deletedCount = deletedCount + 1
                        found = True
                        Exit For
                    End If
                Else
                    ' fallback string compare on normalized text
                    If cellAmtStr = listAmtStr And cellForjStr = listForjStr Then
                        ws.Cells(r, c).MergeArea.ClearContents
                        ws.Cells(r, c + 1).MergeArea.ClearContents
                        ws.Cells(r + lowerHalfStartOffset, c).MergeArea.ClearContents
                        ws.Cells(r + lowerHalfStartOffset, c + 1).MergeArea.ClearContents
                        deletedCount = deletedCount + 1
                        found = True
                        Exit For
                    End If
                End If
            End If
        Next c

NextIterDel:
    Next i

    If deletedCount > 0 Then
        MsgBox deletedCount & " �ǘ��� ��� ��.", vbInformation
    Else
        MsgBox "�� �ǘ���� ��� ��� (������� ���� ���).", vbInformation
    End If

    ' Refresh the list
    Call CommandButton1_Click
End Sub


Private Sub CommandButton5_Click()
    Dim i As Long, movedCount As Long
    Dim parts() As String
    Dim ws As Worksheet
    Dim r As Long, c As Long, destR As Long
    Dim dateStr As String
    Dim listAmtStr As String, listForjStr As String
    Dim cellAmtStr As String, cellForjStr As String
    Dim found As Boolean
    Dim destY As Long, destM As Long, destD As Long
    Dim destSheet As Worksheet
    Dim overwriteAns As VbMsgBoxResult

    ' --- Read Dynamic Configuration ---
    Dim numCheques As Long: numCheques = ReadConfigValue("cfg_NumCheques")
    Dim numFactors As Long: numFactors = ReadConfigValue("cfg_NumFactors")
    Dim totalCenters As Long: totalCenters = ReadConfigValue("cfg_TotalCenters")
    Dim userCenters As Long: userCenters = ReadConfigValue("cfg_ActualUserCenters")

    ' --- Calculate Dynamic Column and Row Offsets ---
    Dim firstFactorCol As Long: firstFactorCol = 14 + (numCheques * 2) + 1
    Dim lastFactorCol As Long: lastFactorCol = firstFactorCol + (numFactors * 2) - 2
    Dim rowsPerDay As Long: rowsPerDay = IIf(userCenters = 1, 2, totalCenters)
    Dim totalRowsPerDayBlock As Long: totalRowsPerDayBlock = rowsPerDay + 1
    Dim lowerHalfStartOffset As Long: lowerHalfStartOffset = rowsPerDay \ 2

    ' Validate TextBox1 destination date
    If Trim(TextBox1.value) = "" Then
        MsgBox "����� ����� ���� �� �� ���� ���� ���� (yyyy/mm/dd).", vbExclamation
        Exit Sub
    End If

    ' Normalize and parse TextBox1 (allow Persian digits)
    Dim t As String: t = ConvertPersianNumsToEnglish(Trim(TextBox1.value))
    If InStr(t, "/") = 0 Then
        MsgBox "���� ����� �������. ���� ���� yyyy/mm/dd ����.", vbExclamation
        Exit Sub
    End If
    parts = Split(t, "/")
    If UBound(parts) <> 2 Then
        MsgBox "���� ����� �������. ���� ���� yyyy/mm/dd ����.", vbExclamation
        Exit Sub
    End If
    On Error Resume Next
    destY = CLng(parts(0)): destM = CLng(parts(1)): destD = CLng(parts(2))
    On Error GoTo 0
    If destY < 1000 Or destM < 1 Or destM > 12 Or destD < 1 Or destD > 31 Then
        MsgBox "����� ���� ������� ���.", vbExclamation
        Exit Sub
    End If

    ' Find destination sheet
    Set destSheet = FindSheet(destY & "/" & Format(destM, "00"))
    If destSheet Is Nothing Then
        MsgBox "���� �� ����� " & destY & "/" & Format(destM, "00") & " ���� ���.", vbCritical
        Exit Sub
    End If

    ' Count selection
    Dim selectedCount As Long
    For i = 0 To Me.ListBox1.ListCount - 1
        If Me.ListBox1.Selected(i) Then selectedCount = selectedCount + 1
    Next i
    If selectedCount = 0 Then
        MsgBox "�� �ǘ���� ������ ����.", vbExclamation
        Exit Sub
    End If

    ' For each selected item attempt move (can be to different sheet)
    For i = 0 To Me.ListBox1.ListCount - 1
        If Not Me.ListBox1.Selected(i) Then GoTo NextIterMove

        dateStr = Trim(Me.ListBox1.List(i, 0))
        If InStr(dateStr, "/") = 0 Then GoTo NextIterMove
        parts = Split(dateStr, "/")
        If UBound(parts) <> 2 Then GoTo NextIterMove

        Set ws = FindSheet(parts(0) & "/" & Format(CInt(parts(1)), "00"))
        If ws Is Nothing Then GoTo NextIterMove

        r = 2 + (val(parts(2)) - 1) * totalRowsPerDayBlock
        listAmtStr = NormalizeNumber(ListBox1.List(i, 1))
        listForjStr = NormalizeNumber(ListBox1.List(i, 2))

        found = False
        For c = firstFactorCol To lastFactorCol Step 2
            If Trim(ws.Cells(r, c).value) = Trim(ComboBox1.value) Then
                cellAmtStr = NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c).value)
                cellForjStr = NormalizeNumber(ws.Cells(r + lowerHalfStartOffset, c + 1).value)

                If cellAmtStr <> "" And IsNumeric(cellAmtStr) Then
                    If CDbl(cellAmtStr) = IIf(listAmtStr <> "" And IsNumeric(listAmtStr), CDbl(listAmtStr), 0) And _
                       val(cellForjStr) = IIf(listForjStr <> "" And IsNumeric(listForjStr), val(listForjStr), 0) Then
                        found = True
                        Exit For
                    End If
                Else
                    If cellAmtStr = listAmtStr And cellForjStr = listForjStr Then
                        found = True
                        Exit For
                    End If
                End If
            End If
        Next c

        If Not found Then GoTo NextIterMove

        ' compute dest row in destination sheet
        destR = 2 + (destD - 1) * totalRowsPerDayBlock

        ' If destination already has something in the same factor column, confirm overwrite
        If Trim(destSheet.Cells(destR, c).value) <> "" Or Trim(destSheet.Cells(destR + lowerHalfStartOffset, c).value) <> "" Then
            overwriteAns = MsgBox("���� ���� �� ��� " & destD & " �� ��� " & destSheet.Name & " ����� ��� ���. ��� �������� ������ ��Ͽ", vbYesNo + vbQuestion, "����� �������")
            If overwriteAns = vbNo Then GoTo NextIterMove
        End If

        ' Move: copy name/status and amount/forjeh to destination sheet then clear source
        destSheet.Cells(destR, c).value = ws.Cells(r, c).value
        destSheet.Cells(destR, c + 1).value = ws.Cells(r, c + 1).value
        destSheet.Cells(destR + lowerHalfStartOffset, c).value = ws.Cells(r + lowerHalfStartOffset, c).value
        destSheet.Cells(destR + lowerHalfStartOffset, c + 1).value = ws.Cells(r + lowerHalfStartOffset, c + 1).value

        ' Clear source
        ws.Cells(r, c).MergeArea.ClearContents
        ws.Cells(r, c + 1).MergeArea.ClearContents
        ws.Cells(r + lowerHalfStartOffset, c).MergeArea.ClearContents
        ws.Cells(r + lowerHalfStartOffset, c + 1).MergeArea.ClearContents

        movedCount = movedCount + 1

NextIterMove:
    Next i

    If movedCount > 0 Then
        MsgBox movedCount & " �ǘ��� ����� ��.", vbInformation
    Else
        MsgBox "�� �ǘ���� ����� ���.", vbInformation
    End If

    ' Refresh
    Call CommandButton1_Click
End Sub

Private Sub ComboBox1_Enter()
    SetKeyboardPersian
End Sub
'-------------------------------
' ComboBox1 Change - Handle separator
'-------------------------------
Private Sub ComboBox1_Change()
    If Me.ComboBox1.value = "-------------" Then
        Me.ComboBox1.value = ""
        Me.ComboBox1.DropDown
        Exit Sub
    End If

    Call CommandButton1_Click
End Sub
'-------------------------------
' Helper Functions
'-------------------------------
Private Function FormatJalaliDate(y, m, d) As String
    FormatJalaliDate = Format(y, "0000") & "/" & Format(m, "00") & "/" & Format(d, "00")
End Function

Private Function FindSheet(ym As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.Range("B1").value = ym Then
            Set FindSheet = ws
            Exit Function
        End If
    Next ws
    Set FindSheet = Nothing
End Function

Private Function EvaluateExpression(expr As String) As Double
    On Error Resume Next
    EvaluateExpression = Evaluate(Replace(expr, ",", ""))
    If Err.Number <> 0 Then EvaluateExpression = 0
    On Error GoTo 0
End Function

Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Dim Txt As String, digits As String
    Txt = Trim(TextBox1.value)
    If Txt = "" Then Exit Sub

    ' Convert Persian/Arabic digits to ASCII and remove non-digits
    Txt = ConvertPersianNumsToEnglish(Txt)
    Dim i As Long
    digits = ""
    For i = 1 To Len(Txt)
        If Mid$(Txt, i, 1) >= "0" And Mid$(Txt, i, 1) <= "9" Then digits = digits & Mid$(Txt, i, 1)
    Next i

    If Len(digits) = 8 Then
        ' format as yyyy/mm/dd
        TextBox1.value = Left(digits, 4) & "/" & Mid(digits, 5, 2) & "/" & Right(digits, 2)
        Exit Sub
    End If

    ' if user already entered with slashes, normalize digits inside it
    If InStr(Txt, "/") > 0 Then
        Dim parts() As String
        parts = Split(Txt, "/")
        If UBound(parts) = 2 Then
            parts(0) = ConvertPersianNumsToEnglish(parts(0))
            parts(1) = ConvertPersianNumsToEnglish(parts(1))
            parts(2) = ConvertPersianNumsToEnglish(parts(2))
            ' basic sanity checks for numeric lengths
            If Len(parts(0)) = 4 And Len(parts(1)) >= 1 And Len(parts(2)) >= 1 Then
                TextBox1.value = parts(0) & "/" & Format(CInt(parts(1)), "00") & "/" & Format(CInt(parts(2)), "00")
            End If
        End If
    End If
End Sub
' ---------------------------
' TextBox2: format on Tab/Enter and on Exit (only for plain numbers)
' ---------------------------
Private Sub TextBox2_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyTab Or KeyCode = vbKeyReturn Then
        Call FormatTextBox2IfPlainNumber
        ' allow focus movement
    End If
End Sub

Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Call FormatTextBox2IfPlainNumber
End Sub

Private Sub FormatTextBox2IfPlainNumber()
    Dim raw As String, cleaned As String

    raw = Trim(TextBox2.value)
    If raw = "" Then Exit Sub

    ' Convert Persian/Arabic digits -> ASCII and remove commas/spaces for check
    cleaned = ConvertPersianNumsToEnglish(Replace(raw, ",", ""))
    cleaned = Replace(cleaned, " ", "")

    ' If the cleaned string is a plain numeric value (no operators), format it
    ' We treat it as "plain number" only when IsNumeric is True
    If IsNumeric(cleaned) Then
        On Error Resume Next
        TextBox2.value = Format(CDbl(cleaned), "#,##0")
        On Error GoTo 0
        DoEvents
        Me.Repaint
    End If
End Sub

' ---------------------------
' TextBox3: accept Persian digits (e.g. "��") and convert on Tab/Enter or Exit
' ---------------------------
Private Sub TextBox3_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyTab Or KeyCode = vbKeyReturn Then
        Call NormalizeTextBox3
    End If
End Sub

Private Sub TextBox3_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Call NormalizeTextBox3
End Sub

Private Sub NormalizeTextBox3()
    Dim raw As String, cleaned As String
    raw = Trim(TextBox3.value)
    If raw = "" Then Exit Sub

    ' Convert Persian/Arabic digits -> ASCII and trim spaces
    cleaned = ConvertPersianNumsToEnglish(raw)
    cleaned = Replace(cleaned, " ", "")

    ' Keep everything else intact but ensure Persian digits become ASCII digits.
    TextBox3.value = cleaned
    DoEvents
    Me.Repaint
End Sub

'-------------------------------
' Convert Persian/Arabic/Fullwidth digits to ASCII digits
'-------------------------------
Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    Dim i As Long

    result = inputText

    ' Persian digits U+06F0..U+06F9 (ChrW 1776..1785)
    For i = 1776 To 1785
        result = Replace(result, ChrW(i), CStr(i - 1776))
    Next i

    ' Arabic-Indic digits U+0660..U+0669 (ChrW 1632..1641)
    For i = 1632 To 1641
        result = Replace(result, ChrW(i), CStr(i - 1632))
    Next i

    ' Fullwidth digits U+FF10..FF19 (ChrW 65296..65305)
    For i = 65296 To 65305
        result = Replace(result, ChrW(i), CStr(i - 65296))
    Next i

    ConvertPersianNumsToEnglish = result
End Function
'-------------------------------
' NormalizeNumber: strip commas/spaces and convert Persian/Arabic digits -> returns cleaned string
'-------------------------------
Private Function NormalizeNumber(v As Variant) As String
    Dim s As String
    s = Trim(CStr(v))
    If s = "" Then
        NormalizeNumber = ""
        Exit Function
    End If
    s = Replace(s, ",", "")
    s = Replace(s, " ", "")
    s = ConvertPersianNumsToEnglish(s)
    NormalizeNumber = s
End Function

