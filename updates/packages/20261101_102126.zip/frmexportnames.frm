VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmexportnames 
   Caption         =   "export named ranges"
   ClientHeight    =   10815
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   12960
   OleObjectBlob   =   "frmexportnames.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmexportnames"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

  Private Sub UserForm_Initialize()
      Dim nm As Name

      lstNames.Clear

      For Each nm In ThisWorkbook.names
          lstNames.AddItem nm.Name
      Next nm
  End Sub

  Private Sub btnSelectAll_Click()
      Dim i As Long

      For i = 0 To lstNames.ListCount - 1
          lstNames.Selected(i) = True
      Next i
  End Sub

  Private Sub btnExport_Click()
      Dim filePath As Variant
      Dim fileNum As Integer
      Dim nm As Name
      Dim i As Long
      Dim scopeName As String

      If Not AnySelected() Then
          MsgBox "Please select at least one named range.", vbExclamation
          Exit Sub
      End If

      filePath = Application.GetSaveAsFilename( _
          InitialFileName:="NamedRanges.csv", _
          FileFilter:="CSV Files (*.csv), *.csv")

      If filePath = False Then Exit Sub

      fileNum = FreeFile
      Open CStr(filePath) For Output As #fileNum

      Print #fileNum, "Name,RefersTo,Scope"

      For i = 0 To lstNames.ListCount - 1
          If lstNames.Selected(i) Then
              Set nm = ThisWorkbook.names(lstNames.List(i))

              If typeName(nm.Parent) = "Worksheet" Then
                  scopeName = nm.Parent.Name
              Else
                  scopeName = "Workbook"
              End If

              Print #fileNum, CsvField(nm.Name) & "," & _
                              CsvField(nm.RefersTo) & "," & _
                              CsvField(scopeName)
          End If
      Next i

      Close #fileNum

      MsgBox "Exported: " & CStr(filePath), vbInformation
  End Sub

  Private Sub btnImport_Click()
      Dim filePath As Variant
      Dim fileNum As Integer
      Dim line As String
      Dim parts As Variant
      Dim nmName As String
      Dim nmRef As String
      Dim nmScope As String

      filePath = Application.GetOpenFilename("CSV Files (*.csv), *.csv")
      If filePath = False Then Exit Sub

      fileNum = FreeFile
      Open CStr(filePath) For Input As #fileNum

      If Not EOF(fileNum) Then Line Input #fileNum, line

      Do While Not EOF(fileNum)
          Line Input #fileNum, line
          parts = ParseCsvLine(line)

          If UBound(parts) >= 2 Then
              nmName = parts(0)
              nmRef = parts(1)
              nmScope = parts(2)

              On Error Resume Next

              If nmScope = "Workbook" Then
                  ThisWorkbook.names.Add Name:=nmName, RefersTo:=nmRef
              Else
                  ThisWorkbook.Worksheets(nmScope).names.Add Name:=nmName, RefersTo:=nmRef
              End If

              On Error GoTo 0
          End If
      Loop

      Close #fileNum

      MsgBox "Import complete.", vbInformation
  End Sub

  Private Sub btnCancel_Click()
      Unload Me
  End Sub

  Private Function AnySelected() As Boolean
      Dim i As Long

      For i = 0 To lstNames.ListCount - 1
          If lstNames.Selected(i) Then
              AnySelected = True
              Exit Function
          End If
      Next i
  End Function

  Private Function CsvField(ByVal value As String) As String
      CsvField = """" & Replace(value, """", """""") & """"
  End Function

  Private Function ParseCsvLine(ByVal line As String) As Variant
      Dim result() As String
      Dim i As Long
      Dim ch As String
      Dim field As String
      Dim inQuotes As Boolean
      Dim count As Long

      ReDim result(0)

      For i = 1 To Len(line)
          ch = Mid$(line, i, 1)

          If ch = """" Then
              If inQuotes And i < Len(line) And Mid$(line, i + 1, 1) = """" Then
                  field = field & """"
                  i = i + 1
              Else
                  inQuotes = Not inQuotes
              End If
          ElseIf ch = "," And Not inQuotes Then
              result(count) = field
              count = count + 1
              ReDim Preserve result(count)
              field = ""
          Else
              field = field & ch
          End If
      Next i

      result(count) = field
      ParseCsvLine = result
  End Function

