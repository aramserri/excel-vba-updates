VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmNewCompany 
   Caption         =   "����� �ј� ����"
   ClientHeight    =   5415
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   8565.001
   OleObjectBlob   =   "frmNewCompany.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmNewCompany"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


' In frmNewCompany code:
Option Explicit

Public Cancelled As Boolean
Public companyName As String
Public NationalID As String




Private Sub UserForm_Initialize()
    Cancelled = True
    companyName = ""
    NationalID = ""
End Sub

Private Sub btnOK_Click()
    If Trim(Me.txtCompanyName.value) = "" Then
        MsgBox "��� �ј� �������� ���� ����.", vbExclamation
        Me.txtCompanyName.SetFocus
        Exit Sub
    End If
    
    Cancelled = False
    companyName = Trim(Me.txtCompanyName.value)
    NationalID = Trim(Me.txtNationalID.value)

    
    Me.Hide
End Sub

Private Sub btnCancel_Click()
    Cancelled = True
    Me.Hide
End Sub
