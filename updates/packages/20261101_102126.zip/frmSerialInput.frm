VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmSerialInput 
   Caption         =   "����� ��"
   ClientHeight    =   6420
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   10965
   OleObjectBlob   =   "frmSerialInput.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmSerialInput"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Public serialNumber As String
Public WasCancelled As Boolean

Private lastFirst4 As String
Private lastMiddle6 As String

' Public method to initialize with previous values
Public Sub Initialize(previousFirst4 As String, previousMiddle6 As String)
    ' Store the previous values
    lastFirst4 = previousFirst4
    
    ' Auto-increment the middle 6 digits
    If IsNumeric(previousMiddle6) And Len(previousMiddle6) = 6 Then
        Dim nextValue As Long
        nextValue = CLng(previousMiddle6) + 1
        ' Pad to 6 digits
        lastMiddle6 = Format(nextValue, "000000")
    Else
        lastMiddle6 = previousMiddle6
    End If
End Sub

' Initialize the form
Private Sub UserForm_Initialize()
    Me.Caption = "���� ����� ����� ��"
    Me.Label1.Caption = "����� ����� �� �� ���� ����:" & vbCrLf & _
                        "(4 ��� ��� � 6 ��� ��� ��Ϙ�� �� ����� - ���� ������)" & vbCrLf & _
                        "����� ��� 2 ��� ��� �� ���� ����"
    Me.CommandButton1.Caption = "�����"
    Me.CommandButton2.Caption = "���"
    
    ' Setup TextBox1 (First 4 digits) - Auto-filled, editable
    Me.TextBox1.TextAlign = fmTextAlignCenter
    Me.TextBox1.Font.size = 14
    Me.TextBox1.MaxLength = 4
    Me.TextBox1.BackColor = &HE0E0E0  ' Light gray to show it's pre-filled
    
    ' Setup TextBox2 (Middle 6 digits) - Auto-incremented, editable
    Me.TextBox2.TextAlign = fmTextAlignCenter
    Me.TextBox2.Font.size = 14
    Me.TextBox2.MaxLength = 6
    Me.TextBox2.BackColor = &HE0E0E0  ' Light gray to show it's pre-filled
    
    ' Setup TextBox3 (Last 2 digits) - Manual entry
    Me.TextBox3.TextAlign = fmTextAlignCenter
    Me.TextBox3.Font.size = 14
    Me.TextBox3.MaxLength = 2
    Me.TextBox3.BackColor = &HFFFFFF  ' White - needs user input
    
    WasCancelled = False
End Sub

' Activate - pre-fill and focus last textbox
Private Sub UserForm_Activate()
    ' Pre-fill first 4 digits (from last time)
    Me.TextBox1.text = lastFirst4
    
    ' Pre-fill middle 6 digits (auto-incremented)
    Me.TextBox2.text = lastMiddle6
    
    ' Clear last 2 digits (always manual)
    Me.TextBox3.text = ""
    
    ' Focus on TextBox3 since first two are pre-filled
    Me.TextBox3.SetFocus
End Sub

' TextBox1 - Auto-advance after 4 digits
Private Sub TextBox1_Change()
    ' Convert Persian/Arabic to English
    Dim converted As String
    converted = ConvertPersianToEnglish(Me.TextBox1.text)
    
    If converted <> Me.TextBox1.text Then
        Me.TextBox1.text = converted
        Me.TextBox1.SelStart = Len(Me.TextBox1.text)
    End If
    
    ' Auto-advance when 4 digits entered
    If Len(Me.TextBox1.text) = 4 Then
        Me.TextBox2.SetFocus
    End If
End Sub

' TextBox1 - Focus event (change color when editing)
Private Sub TextBox1_Enter()
    Me.TextBox1.BackColor = &HFFFFFF  ' White when focused
End Sub

Private Sub TextBox1_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Me.TextBox1.BackColor = &HE0E0E0  ' Gray when not focused
End Sub

' TextBox2 - Auto-advance after 6 digits
Private Sub TextBox2_Change()
    ' Convert Persian/Arabic to English
    Dim converted As String
    converted = ConvertPersianToEnglish(Me.TextBox2.text)
    
    If converted <> Me.TextBox2.text Then
        Me.TextBox2.text = converted
        Me.TextBox2.SelStart = Len(Me.TextBox2.text)
    End If
    
    ' Auto-advance when 6 digits entered
    If Len(Me.TextBox2.text) = 6 Then
        Me.TextBox3.SetFocus
    End If
End Sub

' TextBox2 - Focus event (change color when editing)
Private Sub TextBox2_Enter()
    Me.TextBox2.BackColor = &HFFFFFF  ' White when focused
End Sub

Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    Me.TextBox2.BackColor = &HE0E0E0  ' Gray when not focused
End Sub

' TextBox3 - Last 2 digits (manual entry)
Private Sub TextBox3_Change()
    ' Convert Persian/Arabic to English
    Dim converted As String
    converted = ConvertPersianToEnglish(Me.TextBox3.text)
    
    If converted <> Me.TextBox3.text Then
        Me.TextBox3.text = converted
        Me.TextBox3.SelStart = Len(Me.TextBox3.text)
    End If
    
    ' Optional: Auto-submit when 2 digits entered
    ' Uncomment if you want automatic submission:
    ' If Len(Me.TextBox3.Text) = 2 Then CommandButton1_Click
End Sub

' Allow only numbers in TextBox1
Private Sub TextBox1_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    ' Allow Enter to submit
    If KeyAscii = 13 Then
        If Len(Me.TextBox1.text) < 4 Then
            MsgBox "����� 4 ��� ��� �� ���� ���� ����", vbExclamation
            KeyAscii = 0
            Exit Sub
        End If
        CommandButton1_Click
        KeyAscii = 0
        Exit Sub
    End If
    
    ' Allow backspace and delete
    If KeyAscii = 8 Then Exit Sub
    
    ' Allow only digits
    If KeyAscii < 48 Or KeyAscii > 57 Then
        KeyAscii = 0
    End If
End Sub

' Allow only numbers in TextBox2
Private Sub TextBox2_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    ' Allow Enter to submit
    If KeyAscii = 13 Then
        If Len(Me.TextBox2.text) < 6 Then
            MsgBox "����� 6 ��� ��� �� ���� ���� ����", vbExclamation
            KeyAscii = 0
            Exit Sub
        End If
        CommandButton1_Click
        KeyAscii = 0
        Exit Sub
    End If
    
    ' Allow backspace - and auto-focus previous textbox if empty
    If KeyAscii = 8 Then
        If Len(Me.TextBox2.text) = 0 Then
            Me.TextBox1.SetFocus
            Me.TextBox1.SelStart = Len(Me.TextBox1.text)
        End If
        Exit Sub
    End If
    
    ' Allow only digits
    If KeyAscii < 48 Or KeyAscii > 57 Then
        KeyAscii = 0
    End If
End Sub

' Allow only numbers in TextBox3
Private Sub TextBox3_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    ' Allow Enter to submit
    If KeyAscii = 13 Then
        CommandButton1_Click
        KeyAscii = 0
        Exit Sub
    End If
    
    ' Allow backspace - and auto-focus previous textbox if empty
    If KeyAscii = 8 Then
        If Len(Me.TextBox3.text) = 0 Then
            Me.TextBox2.SetFocus
            Me.TextBox2.SelStart = Len(Me.TextBox2.text)
        End If
        Exit Sub
    End If
    
    ' Allow only digits
    If KeyAscii < 48 Or KeyAscii > 57 Then
        KeyAscii = 0
    End If
End Sub

' Confirm button
Private Sub CommandButton1_Click()
    ' Validate all fields are filled
    If Len(Me.TextBox1.text) < 4 Then
        MsgBox "����� 4 ��� ��� �� ���� ����", vbExclamation
        Me.TextBox1.SetFocus
        Exit Sub
    End If
    
    If Len(Me.TextBox2.text) < 6 Then
        MsgBox "����� 6 ��� ��� �� ���� ����", vbExclamation
        Me.TextBox2.SetFocus
        Exit Sub
    End If
    
    If Len(Me.TextBox3.text) < 2 Then
        MsgBox "����� 2 ��� ��� �� ���� ����", vbExclamation
        Me.TextBox3.SetFocus
        Exit Sub
    End If
    
    ' Combine all parts (format: 0000 000000 00)
    serialNumber = Me.TextBox1.text & Me.TextBox2.text & Me.TextBox3.text
    WasCancelled = False
    Me.Hide
End Sub

' Cancel button
Private Sub CommandButton2_Click()
    serialNumber = ""
    WasCancelled = True
    Me.Hide
End Sub

' Convert Persian/Arabic numbers to English
Private Function ConvertPersianToEnglish(ByVal inputText As String) As String
    Dim i As Long
    Dim result As String
    Dim ch As String
    Dim code As Long
    
    result = ""
    
    For i = 1 To Len(inputText)
        ch = Mid(inputText, i, 1)
        code = AscW(ch)
        
        Select Case code
            ' Persian digits �-� (U+06F0 to U+06F9)
            Case 1776 To 1785
                result = result & CStr(code - 1776)
            ' Arabic-Indic digits �-� (U+0660 to U+0669)
            Case 1632 To 1641
                result = result & CStr(code - 1632)
            ' Standard ASCII digits 0-9
            Case 48 To 57
                result = result & ch
            Case Else
                ' Skip non-numeric characters
        End Select
    Next i
    
    ConvertPersianToEnglish = result
End Function

