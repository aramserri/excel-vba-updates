VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmSearchInsurance 
   Caption         =   "�����"
   ClientHeight    =   2863
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   4305
   OleObjectBlob   =   "frmSearchInsurance.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmSearchInsurance"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False





'=====================================================
' UserForm: frmSearchInsurance (Search Unpaid Insurance)
' ��� ������ ������� ������ ����
' WITH: �10 TOLERANCE + SMART SUM SEARCH
'=====================================================
Option Explicit

Public userCenters As Long
Public totalCenters As Long
Public InsuranceTypes As Collection

' Return values - stored in module-level variables
Private m_SelectedYear As String
Private m_SelectedMonth As String
Private m_SelectedInsuranceIndex As Long
Private m_SelectedRemainingAmount As Double
Private m_WasSelected As Boolean
Private m_FormClosed As Boolean

Private m_Initialized As Boolean

Private WithEvents m_btnSearch As MSForms.CommandButton
Attribute m_btnSearch.VB_VarHelpID = -1
Private WithEvents m_btnSelect As MSForms.CommandButton
Attribute m_btnSelect.VB_VarHelpID = -1
Private WithEvents m_btnCancel As MSForms.CommandButton
Attribute m_btnCancel.VB_VarHelpID = -1
Private WithEvents m_txtSearchAmount As MSForms.TextBox
Attribute m_txtSearchAmount.VB_VarHelpID = -1
Private WithEvents m_lstResults As MSForms.ListBox
Attribute m_lstResults.VB_VarHelpID = -1
Private m_lstFundFilter As MSForms.ListBox
Private m_cboPeriodYearFrom As MSForms.ComboBox
Private m_cboPeriodMonthFrom As MSForms.ComboBox
Private m_cboPeriodYearTo As MSForms.ComboBox
Private m_cboPeriodMonthTo As MSForms.ComboBox

' Store search results
Private Type SearchResult
    sheetYear As String
    sheetMonth As String
    insuranceIndex As Long
    InsuranceName As String
    submittedAmount As Double
    paidAmount As Double
    remainingAmount As Double
    matchType As Integer  ' 0=no match, 1=exact, 2=close (�10), 3=sum component
    resultIndex As Long   ' Original index for sum matching
End Type

Private m_Results() As SearchResult
Private m_ResultCount As Long

' Store all unpaid for sum search
Private m_AllUnpaid() As SearchResult
Private m_AllUnpaidCount As Long

' Properties for returning values
Public Property Get selectedYear() As String
    selectedYear = m_SelectedYear
End Property

Public Property Get SelectedMonth() As String
    SelectedMonth = m_SelectedMonth
End Property

Public Property Get SelectedInsuranceIndex() As Long
    SelectedInsuranceIndex = m_SelectedInsuranceIndex
End Property

Public Property Get SelectedRemainingAmount() As Double
    SelectedRemainingAmount = m_SelectedRemainingAmount
End Property

Public Property Get WasSelected() As Boolean
    WasSelected = m_WasSelected
End Property

Public Property Get FormClosed() As Boolean
    FormClosed = m_FormClosed
End Property

'====================================================================================================
'                                    FORM INITIALIZATION
'====================================================================================================

Private Sub UserForm_Initialize()
    Me.Caption = "������ ���� ����"
    Me.Width = 800
    Me.Height = 595
    m_Initialized = False
    m_WasSelected = False
    m_FormClosed = False
    m_SelectedYear = ""
    m_SelectedMonth = ""
    m_SelectedInsuranceIndex = 0
    m_SelectedRemainingAmount = 0
End Sub

Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        m_WasSelected = False
        m_FormClosed = True
        CANCEL = True
        Me.Hide
    End If
End Sub

Private Sub UserForm_Activate()
    If m_Initialized Then
        ' Set focus to search box every time form is activated
        m_txtSearchAmount.SetFocus
        Exit Sub
    End If
    m_Initialized = True
    
    Dim topPos As Single: topPos = 15
    Dim lbl As MSForms.Label
    Dim formWidth As Single: formWidth = Me.InsideWidth
    
    ' ========== Title ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblTitle", True)
    With lbl
        .Caption = "������ ���� �� ������� ����� ����"
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 25
        .Font.Bold = True
        .Font.Size = 13
        .TextAlign = fmTextAlignCenter
    End With
    
    topPos = topPos + 35
    
    ' ========== Search Box ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblSearch", True)
    With lbl
        .Caption = ":���� ���� �����"
        .Top = topPos + 4
        .Left = formWidth - 120
        .Width = 110
        .TextAlign = fmTextAlignLeft
    End With
    
    Set m_txtSearchAmount = Me.Controls.Add("Forms.TextBox.1", "txtSearchAmount", True)
    With m_txtSearchAmount
        .Top = topPos
        .Left = formWidth - 280
        .Width = 150
        .Font.Name = "Tahoma"
        .Font.Size = 11
        .TextAlign = fmTextAlignCenter
        .TabIndex = 0  ' FIRST in tab order
    End With
    
    Set m_btnSearch = Me.Controls.Add("Forms.CommandButton.1", "btnSearch", True)
    With m_btnSearch
        .Caption = "�����"
        .Top = topPos
        .Left = formWidth - 370
        .Width = 80
        .Height = 24
        .TabIndex = 1  ' SECOND in tab order
    End With
    
    ' ========== Help Text ==========
    topPos = topPos + 35
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblHelp", True)
    With lbl
        .Caption = "���� = ��� | ���� (�10) = ��� | ����� = ��� | ���� ��� = ����� ���"
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 18
        .ForeColor = RGB(100, 100, 100)
        .TextAlign = fmTextAlignCenter
    End With
    
    topPos = topPos + 30
    
    ' ========== Optional filters ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblFundFilter", True)
    With lbl
        .Caption = UiText("1589,1606,1583,1608,1602,8204,1607,1575,32,40,1670,1606,1583,32,1575,1606,1578,1582,1575,1576,41")
        .Top = topPos
        .Left = 10
        .Width = 270
        .Height = 16
        .Font.Bold = True
        .TextAlign = fmTextAlignCenter
    End With
    
    Set m_lstFundFilter = Me.Controls.Add("Forms.ListBox.1", "lstFundFilter", True)
    With m_lstFundFilter
        .Top = topPos + 17
        .Left = 10
        .Width = 270
        .Height = 56
        .MultiSelect = fmMultiSelectMulti
        .IntegralHeight = False
        .Font.Name = "Tahoma"
        .Font.Size = 9
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPeriodFilter", True)
    With lbl
        .Caption = UiText("1576,1575,1586,1607,32,1605,1575,1607,32,1576,1740,1605,1607")
        .Top = topPos
        .Left = 300
        .Width = 470
        .Height = 16
        .Font.Bold = True
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPeriodFrom", True)
    With lbl
        .Caption = UiText("1575,1586")
        .Top = topPos + 25
        .Left = 715
        .Width = 25
        .Height = 16
    End With
    Set m_cboPeriodYearFrom = Me.Controls.Add("Forms.ComboBox.1", "cboPeriodYearFrom", True)
    With m_cboPeriodYearFrom
        .Top = topPos + 20
        .Left = 645
        .Width = 65
        .Style = fmStyleDropDownList
        .TextAlign = fmTextAlignCenter
    End With
    Set m_cboPeriodMonthFrom = Me.Controls.Add("Forms.ComboBox.1", "cboPeriodMonthFrom", True)
    With m_cboPeriodMonthFrom
        .Top = topPos + 20
        .Left = 595
        .Width = 45
        .Style = fmStyleDropDownList
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblPeriodTo", True)
    With lbl
        .Caption = UiText("1578,1575")
        .Top = topPos + 25
        .Left = 560
        .Width = 25
        .Height = 16
    End With
    Set m_cboPeriodYearTo = Me.Controls.Add("Forms.ComboBox.1", "cboPeriodYearTo", True)
    With m_cboPeriodYearTo
        .Top = topPos + 20
        .Left = 490
        .Width = 65
        .Style = fmStyleDropDownList
        .TextAlign = fmTextAlignCenter
    End With
    Set m_cboPeriodMonthTo = Me.Controls.Add("Forms.ComboBox.1", "cboPeriodMonthTo", True)
    With m_cboPeriodMonthTo
        .Top = topPos + 20
        .Left = 440
        .Width = 45
        .Style = fmStyleDropDownList
        .TextAlign = fmTextAlignCenter
    End With
    
    PopulateSearchFilters
    topPos = topPos + 82
    
    ' ========== Results ListBox ==========
    Set m_lstResults = Me.Controls.Add("Forms.ListBox.1", "lstResults", True)
    With m_lstResults
        .Top = topPos
        .Left = 10
        .Width = formWidth - 20
        .Height = 220
        .ColumnCount = 7
        .ColumnWidths = "50;50;200;90;90;90;1"
        .Font.Name = "Tahoma"
        .Font.Size = 10
        .TextAlign = fmTextAlignCenter
        .TabIndex = 2  ' THIRD in tab order
    End With
    
    ' Add header
    m_lstResults.AddItem
    m_lstResults.List(0, 0) = "���"
    m_lstResults.List(0, 1) = "���"
    m_lstResults.List(0, 2) = "��� ����"
    m_lstResults.List(0, 3) = "���� ������"
    m_lstResults.List(0, 4) = "������ ���"
    m_lstResults.List(0, 5) = "�����"
    m_lstResults.List(0, 6) = ""
    
    topPos = topPos + 225
    
    ' ========== Legend ==========
    Dim lblLegend As MSForms.Label
    
    Set lblLegend = Me.Controls.Add("Forms.Label.1", "lblLegendExact", True)
    With lblLegend
        .Caption = "  ����  "
        .Top = topPos
        .Left = formWidth - 80
        .Width = 60
        .Height = 18
        .BackColor = RGB(200, 255, 200)
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lblLegend = Me.Controls.Add("Forms.Label.1", "lblLegendClose", True)
    With lblLegend
        .Caption = "  ���� (�10)  "
        .Top = topPos
        .Left = formWidth - 180
        .Width = 90
        .Height = 18
        .BackColor = RGB(255, 255, 150)
        .TextAlign = fmTextAlignCenter
    End With
    
    Set lblLegend = Me.Controls.Add("Forms.Label.1", "lblLegendSum", True)
    With lblLegend
        .Caption = "  �����  "
        .Top = topPos
        .Left = formWidth - 270
        .Width = 80
        .Height = 18
        .BackColor = RGB(200, 220, 255)
        .TextAlign = fmTextAlignCenter
    End With
    
' ========== Result Count (BIGGER) ==========
    Set lbl = Me.Controls.Add("Forms.Label.1", "lblResultCount", True)
    With lbl
        .Caption = ""
        .Top = topPos
        .Left = 10
        .Width = 450
        .Height = 24
        .TextAlign = fmTextAlignLeft
        .ForeColor = RGB(0, 100, 0)
        .Font.Size = 12
        .Font.Bold = True
    End With
    
    topPos = topPos + 30
    
    ' ========== Buttons ==========
    Set m_btnSelect = Me.Controls.Add("Forms.CommandButton.1", "btnSelect", True)
    With m_btnSelect
        .Caption = "������ � ��� ������"
        .Top = topPos
        .Left = formWidth - 150
        .Width = 130
        .Height = 32
        .TabIndex = 3
    End With
    
    Set m_btnCancel = Me.Controls.Add("Forms.CommandButton.1", "btnCancel", True)
    With m_btnCancel
        .Caption = "����"
        .Top = topPos
        .Left = formWidth - 290
        .Width = 130
        .Height = 32
        .TabIndex = 4
    End With
    
    ' Set focus to search box
    m_txtSearchAmount.SetFocus
End Sub
'====================================================================================================
'                                    TEXTBOX EVENTS
'====================================================================================================

Private Sub m_txtSearchAmount_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Then
        Call FormatSearchAmount
        Call m_btnSearch_Click
        KeyCode = 0
    End If
End Sub

Private Sub FormatSearchAmount()
    Dim rawValue As String
    Dim cleanValue As String
    
    rawValue = Trim(m_txtSearchAmount.value)
    If rawValue = "" Then Exit Sub
    
    cleanValue = Replace(rawValue, ",", "")
    cleanValue = Replace(cleanValue, " ", "")
    cleanValue = ConvertPersianNumsToEnglish(cleanValue)
    
    If IsNumeric(cleanValue) Then
        m_txtSearchAmount.value = Format(CDbl(cleanValue), "#,##0")
    End If
End Sub

'====================================================================================================
'                                    SEARCH BUTTON
'====================================================================================================

Private Sub m_btnSearch_Click()
    Call FormatSearchAmount
    
    Dim searchAmount As Double
    Dim amountText As String
    Dim showAll As Boolean
    
    amountText = Trim(m_txtSearchAmount.value)
    amountText = Replace(amountText, ",", "")
    amountText = ConvertPersianNumsToEnglish(amountText)
    
    ' If empty, show all unpaid
    If amountText = "" Then
        showAll = True
        searchAmount = 0
    ElseIf Not IsNumeric(amountText) Then
        MsgBox "����� ���� ����� ���� ����.", vbExclamation, "���"
        Exit Sub
    Else
        searchAmount = CDbl(amountText)
        showAll = (searchAmount = 0)
    End If
    
    Call SearchForAmount(searchAmount, showAll)
End Sub

'====================================================================================================
'                                    MAIN SEARCH FUNCTION
'====================================================================================================


Private Sub SearchForAmount(searchAmount As Double, showAll As Boolean)
    Dim ws As Worksheet
    Dim sheetDate As String
    Dim parts() As String
    Dim sheetYear As String
    Dim sheetMonth As String
    Dim insuranceStartRow As Long
    Dim insuranceCount As Long
    Dim i As Long, col As Long
    Dim submittedAmount As Double
    Dim paidAmount As Double
    Dim remainingAmount As Double
    Dim InsuranceName As String
    Dim cellValue As Variant
    Dim fundRows() As Long
    Dim fundNames() As String
    Dim fundAllowed() As Boolean
    Dim selectedFundCount As Long
    Dim firstFundRow As Long
    Dim lastFundRow As Long
    Dim rowOffset As Long
    Dim sheetValues As Variant
    Dim cleanVal As String
    Dim tempResult As SearchResult
    Dim diffSubmitted As Double
    Dim diffRemaining As Double
    
    ' Tolerances
    Const TOLERANCE_EXACT As Double = 0.5    ' For "exact" match (handles rounding)
    Const TOLERANCE_CLOSE As Double = 10     ' For "close" match (�10)
    
    ' Temporary storage for different match types
    Dim exactResults() As SearchResult
    Dim exactResultCount As Long
    Dim closeResults() As SearchResult
    Dim closeResultCount As Long
    
    exactResultCount = 0
    closeResultCount = 0
    m_AllUnpaidCount = 0
    ReDim exactResults(1 To 500)
    ReDim closeResults(1 To 500)
    ReDim m_AllUnpaid(1 To 500)
    
    insuranceCount = GetInsuranceCount()

    ' Read fund configuration once. These functions rebuild the configuration,
    ' therefore calling them inside every worksheet loop was expensive.
    If insuranceCount > 0 Then
        ReDim fundRows(1 To insuranceCount)
        ReDim fundNames(1 To insuranceCount)
        ReDim fundAllowed(1 To insuranceCount)

        For i = 1 To insuranceCount
            fundRows(i) = InsuranceFundRow(i, userCenters, totalCenters)
            fundNames(i) = GetInsuranceName(i)
            fundAllowed(i) = True
        Next i

        If Not m_lstFundFilter Is Nothing Then
            selectedFundCount = 0
            For i = 0 To m_lstFundFilter.ListCount - 1
                If m_lstFundFilter.Selected(i) Then selectedFundCount = selectedFundCount + 1
            Next i

            If selectedFundCount > 0 Then
                For i = 1 To insuranceCount
                    fundAllowed(i) = False
                Next i
                For i = 0 To m_lstFundFilter.ListCount - 1
                    If m_lstFundFilter.Selected(i) Then
                        If i + 1 <= insuranceCount Then fundAllowed(i + 1) = True
                    End If
                Next i
            End If
        End If

        firstFundRow = 0
        lastFundRow = 0
        For i = 1 To insuranceCount
            If fundAllowed(i) Then
                If firstFundRow = 0 Or fundRows(i) < firstFundRow Then firstFundRow = fundRows(i)
                If fundRows(i) > lastFundRow Then lastFundRow = fundRows(i)
            End If
        Next i

        ' One bulk Value2 read of C:F per monthly sheet replaces individual cell
        ' reads. D:F are the three payment columns used by payment history.
        If firstFundRow > 0 Then
            For Each ws In ThisWorkbook.Worksheets
                On Error Resume Next
                sheetDate = Trim(CStr(ws.Range("B1").Value2))
                On Error GoTo 0

                If IsValidMonthlySheet(sheetDate) Then
                    parts = Split(sheetDate, "/")
                    sheetYear = parts(0)
                    sheetMonth = Format(val(parts(1)), "00")

                    If IsPeriodAllowed(sheetYear, sheetMonth) Then
                        sheetValues = ws.Range(ws.Cells(firstFundRow, 3), ws.Cells(lastFundRow, 6)).Value2

                        For i = 1 To insuranceCount
                            If fundAllowed(i) Then
                                rowOffset = fundRows(i) - firstFundRow + 1
                                cellValue = sheetValues(rowOffset, 1)
                                submittedAmount = 0

                                If Not IsError(cellValue) Then
                                    If Not IsEmpty(cellValue) And cellValue <> "" Then
                                        If IsNumeric(cellValue) Then
                                            submittedAmount = CDbl(cellValue)
                                        Else
                                            cleanVal = ConvertPersianNumsToEnglish(CStr(cellValue))
                                            cleanVal = Replace(cleanVal, ",", "")
                                            cleanVal = Replace(cleanVal, " ", "")
                                            If IsNumeric(cleanVal) Then submittedAmount = CDbl(cleanVal)
                                        End If
                                    End If
                                End If

                                If submittedAmount > 0 Then
                                    paidAmount = 0
                                    For col = 2 To 4
                                        cellValue = sheetValues(rowOffset, col)
                                        If IsEmpty(cellValue) Or cellValue = "" Then Exit For
                                        If Not IsError(cellValue) Then
                                            If IsNumeric(cellValue) Then paidAmount = paidAmount + CDbl(cellValue)
                                        End If
                                    Next col

                                    remainingAmount = submittedAmount - paidAmount
                                    If remainingAmount >= 1 Then
                                        InsuranceName = fundNames(i)
                                        tempResult.sheetYear = sheetYear
                                        tempResult.sheetMonth = sheetMonth
                                        tempResult.insuranceIndex = i
                                        tempResult.InsuranceName = InsuranceName
                                        tempResult.submittedAmount = submittedAmount
                                        tempResult.paidAmount = paidAmount
                                        tempResult.remainingAmount = remainingAmount
                                        tempResult.matchType = 0

                                        m_AllUnpaidCount = m_AllUnpaidCount + 1
                                        If m_AllUnpaidCount > UBound(m_AllUnpaid) Then
                                            ReDim Preserve m_AllUnpaid(1 To m_AllUnpaidCount + 100)
                                        End If
                                        tempResult.resultIndex = m_AllUnpaidCount
                                        m_AllUnpaid(m_AllUnpaidCount) = tempResult

                                        If Not showAll Then
                                            diffSubmitted = Abs(submittedAmount - searchAmount)
                                            diffRemaining = Abs(remainingAmount - searchAmount)

                                            If diffSubmitted <= TOLERANCE_EXACT Or diffRemaining <= TOLERANCE_EXACT Then
                                                exactResultCount = exactResultCount + 1
                                                If exactResultCount > UBound(exactResults) Then
                                                    ReDim Preserve exactResults(1 To exactResultCount + 100)
                                                End If
                                                tempResult.matchType = 1
                                                exactResults(exactResultCount) = tempResult
                                            ElseIf diffSubmitted <= TOLERANCE_CLOSE Or diffRemaining <= TOLERANCE_CLOSE Then
                                                closeResultCount = closeResultCount + 1
                                                If closeResultCount > UBound(closeResults) Then
                                                    ReDim Preserve closeResults(1 To closeResultCount + 100)
                                                End If
                                                tempResult.matchType = 2
                                                closeResults(closeResultCount) = tempResult
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        Next i
                    End If
                End If
            Next ws
        End If
    End If
        ' Clear listbox and prepare results
    m_lstResults.Clear
    m_ResultCount = 0
    ReDim m_Results(1 To 500)
    
    ' Add header
    m_lstResults.AddItem
    m_lstResults.List(0, 0) = "���"
    m_lstResults.List(0, 1) = "���"
    m_lstResults.List(0, 2) = "��� ����"
    m_lstResults.List(0, 3) = "���� ������"
    m_lstResults.List(0, 4) = "������ ���"
    m_lstResults.List(0, 5) = "�����"
    m_lstResults.List(0, 6) = ""
    
    ' Build result label
    Dim resultLabel As String
    Dim j As Long
    
    ' If showing all
    If showAll Then
        resultLabel = "���� ������� ����� ����: " & m_AllUnpaidCount & " ����"
        For j = 1 To m_AllUnpaidCount
            m_ResultCount = m_ResultCount + 1
            m_Results(m_ResultCount) = m_AllUnpaid(j)
            Call AddResultToListBox(m_AllUnpaid(j))
        Next j
        Me.Controls("lblResultCount").Caption = resultLabel
        Me.Controls("lblResultCount").ForeColor = RGB(0, 100, 0)
        Exit Sub
    End If
    
    ' Check if we have exact or close matches
    If exactResultCount > 0 Or closeResultCount > 0 Then
        ' Build label
        If exactResultCount > 0 Then
            resultLabel = exactResultCount & " ���� ����"
            If closeResultCount > 0 Then
                resultLabel = resultLabel & " + " & closeResultCount & " ���� ���� (�10)"
            End If
        Else
            resultLabel = "���� ���� ���� ��� - " & closeResultCount & " ���� ���� (�10)"
        End If
        
        ' Show exact matches first
        For j = 1 To exactResultCount
            m_ResultCount = m_ResultCount + 1
            m_Results(m_ResultCount) = exactResults(j)
            Call AddResultToListBox(exactResults(j))
        Next j
        
        ' Then show close matches
        For j = 1 To closeResultCount
            m_ResultCount = m_ResultCount + 1
            m_Results(m_ResultCount) = closeResults(j)
            Call AddResultToListBox(closeResults(j))
        Next j
        
        ' Auto-select if only one exact match
        If exactResultCount = 1 And closeResultCount = 0 Then
            m_lstResults.listIndex = 1
        End If
        
        Me.Controls("lblResultCount").Caption = resultLabel
        Me.Controls("lblResultCount").ForeColor = RGB(0, 128, 0)
        
    Else
        ' No exact or close match - try SMART SUM SEARCH
        Dim sumIndices() As Long
        Dim sumCount As Long
        Dim foundSum As Boolean
        
        foundSum = FindSumCombination(searchAmount, TOLERANCE_CLOSE, sumIndices, sumCount)
        
        If foundSum And sumCount > 0 Then
            ' Show sum total
            Dim sumTotal As Double
            sumTotal = 0
            For j = 1 To sumCount
                sumTotal = sumTotal + m_AllUnpaid(sumIndices(j)).remainingAmount
            Next j
            
            resultLabel = "������ ������: " & sumCount & " ���� (�����: " & Format(sumTotal, "#,##0") & ")"
            
            ' Mark and show the sum components
            For j = 1 To sumCount
                Dim idx As Long
                idx = sumIndices(j)
                m_AllUnpaid(idx).matchType = 3  ' Sum component
                
                m_ResultCount = m_ResultCount + 1
                m_Results(m_ResultCount) = m_AllUnpaid(idx)
                Call AddResultToListBox(m_AllUnpaid(idx))
            Next j
            
            Me.Controls("lblResultCount").Caption = resultLabel
            Me.Controls("lblResultCount").ForeColor = RGB(0, 80, 180)
        Else
            ' No match at all - show all unpaid
            resultLabel = "���� " & Format(searchAmount, "#,##0") & " ���� ��� - " & m_AllUnpaidCount & " ���� ����� ����:"
            For j = 1 To m_AllUnpaidCount
                m_ResultCount = m_ResultCount + 1
                m_Results(m_ResultCount) = m_AllUnpaid(j)
                Call AddResultToListBox(m_AllUnpaid(j))
            Next j
            
            Me.Controls("lblResultCount").Caption = resultLabel
            Me.Controls("lblResultCount").ForeColor = RGB(150, 0, 0)
        End If
    End If
    
    If m_ResultCount = 0 Then
        MsgBox "����� ���� ���.", vbInformation, "����� �����"
    End If
End Sub
Private Function FindSumCombination(targetAmount As Double, tolerance As Double, _
                                     ByRef resultIndices() As Long, ByRef resultCount As Long) As Boolean
    Dim i As Long, j As Long, k As Long
    Dim pairI As Long, pairJ As Long
    Dim tripleI As Long, tripleJ As Long, tripleK As Long
    Dim maxItems As Long, deepItems As Long
    Dim vals() As Double, sourceIndices() As Long
    Dim pairSums As Object, tripleSums As Object
    Dim pairSum As Double, tripleSum As Double

    FindSumCombination = False
    resultCount = 0
    ReDim resultIndices(1 To 10)
    If m_AllUnpaidCount < 2 Then Exit Function

    ReDim vals(1 To 150)
    ReDim sourceIndices(1 To 150)
    For i = 1 To m_AllUnpaidCount
        If m_AllUnpaid(i).remainingAmount > 0 And m_AllUnpaid(i).remainingAmount <= targetAmount + tolerance Then
            maxItems = maxItems + 1
            vals(maxItems) = m_AllUnpaid(i).remainingAmount
            sourceIndices(maxItems) = i
            If maxItems = 150 Then Exit For
        End If
    Next i
    If maxItems < 2 Then Exit Function

    Application.StatusBar = "Searching payment combinations..."
    DoEvents

    For i = 1 To maxItems - 1
        For j = i + 1 To maxItems
            If Abs(vals(i) + vals(j) - targetAmount) <= tolerance Then
                resultCount = 2
                resultIndices(1) = sourceIndices(i)
                resultIndices(2) = sourceIndices(j)
                FindSumCombination = True
                GoTo CleanExit
            End If
        Next j
    Next i

    For i = 1 To maxItems - 2
        For j = i + 1 To maxItems - 1
            pairSum = vals(i) + vals(j)
            For k = j + 1 To maxItems
                If Abs(pairSum + vals(k) - targetAmount) <= tolerance Then
                    resultCount = 3
                    resultIndices(1) = sourceIndices(i)
                    resultIndices(2) = sourceIndices(j)
                    resultIndices(3) = sourceIndices(k)
                    FindSumCombination = True
                    GoTo CleanExit
                End If
            Next k
        Next j
    Next i

    Set pairSums = CreateObject("Scripting.Dictionary")
    For i = 1 To maxItems - 1
        For j = i + 1 To maxItems
            pairSums(ItemSumKey(vals(i) + vals(j))) = CStr(i) & "|" & CStr(j)
        Next j
    Next i

    For i = 1 To maxItems - 1
        For j = i + 1 To maxItems
            If FindStoredPair(pairSums, targetAmount - vals(i) - vals(j), tolerance, pairI, pairJ) Then
                If pairI <> i And pairI <> j And pairJ <> i And pairJ <> j Then
                    resultCount = 4
                    resultIndices(1) = sourceIndices(i)
                    resultIndices(2) = sourceIndices(j)
                    resultIndices(3) = sourceIndices(pairI)
                    resultIndices(4) = sourceIndices(pairJ)
                    FindSumCombination = True
                    GoTo CleanExit
                End If
            End If
        Next j
    Next i

    deepItems = maxItems
    If deepItems > 80 Then deepItems = 80
    If deepItems < 5 Then GoTo CleanExit

    Set tripleSums = CreateObject("Scripting.Dictionary")
    For i = 1 To deepItems - 2
        For j = i + 1 To deepItems - 1
            pairSum = vals(i) + vals(j)
            For k = j + 1 To deepItems
                tripleSums(ItemSumKey(pairSum + vals(k))) = CStr(i) & "|" & CStr(j) & "|" & CStr(k)
            Next k
        Next j
    Next i

    For i = 1 To deepItems - 1
        For j = i + 1 To deepItems
            If FindStoredTriple(tripleSums, targetAmount - vals(i) - vals(j), tolerance, tripleI, tripleJ, tripleK) Then
                If tripleI <> i And tripleI <> j And tripleJ <> i And tripleJ <> j And tripleK <> i And tripleK <> j Then
                    resultCount = 5
                    resultIndices(1) = sourceIndices(i)
                    resultIndices(2) = sourceIndices(j)
                    resultIndices(3) = sourceIndices(tripleI)
                    resultIndices(4) = sourceIndices(tripleJ)
                    resultIndices(5) = sourceIndices(tripleK)
                    FindSumCombination = True
                    GoTo CleanExit
                End If
            End If
        Next j
    Next i

    For i = 1 To deepItems - 2
        For j = i + 1 To deepItems - 1
            pairSum = vals(i) + vals(j)
            For k = j + 1 To deepItems
                tripleSum = pairSum + vals(k)
                If FindStoredTriple(tripleSums, targetAmount - tripleSum, tolerance, tripleI, tripleJ, tripleK) Then
                    If tripleI <> i And tripleI <> j And tripleI <> k And _
                       tripleJ <> i And tripleJ <> j And tripleJ <> k And _
                       tripleK <> i And tripleK <> j And tripleK <> k Then
                        resultCount = 6
                        resultIndices(1) = sourceIndices(i)
                        resultIndices(2) = sourceIndices(j)
                        resultIndices(3) = sourceIndices(k)
                        resultIndices(4) = sourceIndices(tripleI)
                        resultIndices(5) = sourceIndices(tripleJ)
                        resultIndices(6) = sourceIndices(tripleK)
                        FindSumCombination = True
                        GoTo CleanExit
                    End If
                End If
            Next k
        Next j
    Next i

CleanExit:
    Application.StatusBar = False
End Function

Private Function ItemSumKey(ByVal value As Double) As String
    ItemSumKey = Format$(value, "0")
End Function

Private Function FindStoredPair(ByVal sums As Object, ByVal wanted As Double, ByVal tolerance As Double, _
                                ByRef firstIndex As Long, ByRef secondIndex As Long) As Boolean
    Dim delta As Long, parts() As String, lookupKey As String
    For delta = -CLng(tolerance) - 1 To CLng(tolerance) + 1
        lookupKey = ItemSumKey(wanted + delta)
        If sums.exists(lookupKey) Then
            parts = Split(CStr(sums(lookupKey)), "|")
            firstIndex = CLng(parts(0))
            secondIndex = CLng(parts(1))
            FindStoredPair = True
            Exit Function
        End If
    Next delta
End Function

Private Function FindStoredTriple(ByVal sums As Object, ByVal wanted As Double, ByVal tolerance As Double, _
                                  ByRef firstIndex As Long, ByRef secondIndex As Long, ByRef thirdIndex As Long) As Boolean
    Dim delta As Long, parts() As String, lookupKey As String
    For delta = -CLng(tolerance) - 1 To CLng(tolerance) + 1
        lookupKey = ItemSumKey(wanted + delta)
        If sums.exists(lookupKey) Then
            parts = Split(CStr(sums(lookupKey)), "|")
            firstIndex = CLng(parts(0))
            secondIndex = CLng(parts(1))
            thirdIndex = CLng(parts(2))
            FindStoredTriple = True
            Exit Function
        End If
    Next delta
End Function

Private Sub AddResultToListBox(result As SearchResult)
    Dim rowIndex As Long
    
    m_lstResults.AddItem
    rowIndex = m_lstResults.ListCount - 1
    
    m_lstResults.List(rowIndex, 0) = result.sheetYear
    m_lstResults.List(rowIndex, 1) = result.sheetMonth
    m_lstResults.List(rowIndex, 2) = result.InsuranceName
    m_lstResults.List(rowIndex, 3) = Format(result.submittedAmount, "#,##0")
    m_lstResults.List(rowIndex, 4) = Format(result.paidAmount, "#,##0")
    m_lstResults.List(rowIndex, 5) = Format(result.remainingAmount, "#,##0")
    m_lstResults.List(rowIndex, 6) = result.matchType  ' Store match type in hidden column
End Sub

'====================================================================================================
'                                    LISTBOX SELECTION
'====================================================================================================

Private Sub m_lstResults_Click()
    If m_lstResults.listIndex < 1 Then Exit Sub
    
    Dim selectedIndex As Long
    selectedIndex = m_lstResults.listIndex
    
    If selectedIndex > m_ResultCount Then Exit Sub
    
    Dim matchType As Integer
    matchType = m_Results(selectedIndex).matchType
    
    Select Case matchType
        Case 1
            Me.Controls("lblResultCount").ForeColor = RGB(0, 128, 0)
            Me.Controls("lblResultCount").Caption = "� ����� ���� - ���� �����: " & Format(m_Results(selectedIndex).remainingAmount, "#,##0")
        Case 2
            Me.Controls("lblResultCount").ForeColor = RGB(180, 140, 0)
            Me.Controls("lblResultCount").Caption = "� ����� ���� (�10) - ���� �����: " & Format(m_Results(selectedIndex).remainingAmount, "#,##0")
        Case 3
            Me.Controls("lblResultCount").ForeColor = RGB(0, 80, 180)
            Me.Controls("lblResultCount").Caption = "� ��� ����� - ���� �����: " & Format(m_Results(selectedIndex).remainingAmount, "#,##0")
        Case Else
            Me.Controls("lblResultCount").ForeColor = RGB(100, 100, 100)
            Me.Controls("lblResultCount").Caption = "���� ����� - ���� �����: " & Format(m_Results(selectedIndex).remainingAmount, "#,##0")
    End Select
End Sub

'====================================================================================================
'                                    SELECT BUTTON
'====================================================================================================

'====================================================================================================
'                                    SELECT BUTTON - PROCESS PAYMENTS DIRECTLY
'====================================================================================================

Private Sub m_btnSelect_Click()
    If m_lstResults.listIndex < 1 Then
        MsgBox "����� � ���� �� ������ ����.", vbExclamation, "������"
        Exit Sub
    End If
    
    Dim selectedIndex As Long
    selectedIndex = m_lstResults.listIndex
    
    If selectedIndex < 1 Or selectedIndex > m_ResultCount Then
        MsgBox "��� �� ������.", vbCritical, "���"
        Exit Sub
    End If
    
    ' Check if this is a sum match (matchType = 3) - process all sum items
    Dim matchType As Integer
    matchType = m_Results(selectedIndex).matchType
    
    If matchType = 3 Then
        ' Process ALL sum components
        Call ProcessSumItems
    Else
        ' Process single selected item
        Call ProcessSingleItem(selectedIndex)
    End If
End Sub

'====================================================================================================
'                                    PROCESS SINGLE ITEM
'====================================================================================================

Private Sub ProcessSingleItem(resultIndex As Long)
    Dim frmPayment As frmInsurancePayment
    Set frmPayment = New frmInsurancePayment
    
    frmPayment.targetYear = m_Results(resultIndex).sheetYear
    frmPayment.targetMonth = m_Results(resultIndex).sheetMonth
    Set frmPayment.InsuranceTypes = InsuranceTypes
    frmPayment.userCenters = userCenters
    frmPayment.totalCenters = totalCenters
    frmPayment.PreSelectedInsuranceIndex = m_Results(resultIndex).insuranceIndex
    frmPayment.PreFilledAmount = m_Results(resultIndex).remainingAmount
    
    frmPayment.Show vbModal
    
    On Error Resume Next
    Unload frmPayment
    Set frmPayment = Nothing
    On Error GoTo 0
    
    ' Set flags and close
    m_WasSelected = True
    m_FormClosed = True
    Me.Hide
End Sub

'====================================================================================================
'                                    PROCESS SUM ITEMS (LIKE CALCULATOR)
'====================================================================================================

Private Sub ProcessSumItems()
    ' Count sum items
    Dim sumItemCount As Long
    Dim sumTotal As Double
    Dim i As Long
    
    sumItemCount = 0
    sumTotal = 0
    
    For i = 1 To m_ResultCount
        If m_Results(i).matchType = 3 Then
            sumItemCount = sumItemCount + 1
            sumTotal = sumTotal + m_Results(i).remainingAmount
        End If
    Next i
    
    If sumItemCount = 0 Then
        MsgBox "����� ���� ���.", vbExclamation
        Exit Sub
    End If
    
    ' Confirmation message
    Dim confirmMsg As String
    confirmMsg = "����� " & sumItemCount & " ���� ������ ��� ���." & vbCrLf & _
                 "��� ��: " & Format(sumTotal, "#,##0") & " ����" & vbCrLf & vbCrLf & _
                 "���� �� ���� ��� ��� ������ ��� �� ���." & vbCrLf & _
                 "��� ����� �� ���Ͽ"
    
    If MsgBox(confirmMsg, vbYesNo + vbQuestion, "����� ��� ������ ��") = vbNo Then
        Exit Sub
    End If
    
    ' Process each sum item
    Dim processedCount As Long
    Dim frmPayment As frmInsurancePayment
    
    processedCount = 0
    
    For i = 1 To m_ResultCount
        If m_Results(i).matchType = 3 Then
            ' Open payment form
            Set frmPayment = New frmInsurancePayment
            
            frmPayment.targetYear = m_Results(i).sheetYear
            frmPayment.targetMonth = m_Results(i).sheetMonth
            Set frmPayment.InsuranceTypes = InsuranceTypes
            frmPayment.userCenters = userCenters
            frmPayment.totalCenters = totalCenters
            frmPayment.PreSelectedInsuranceIndex = m_Results(i).insuranceIndex
            frmPayment.PreFilledAmount = m_Results(i).remainingAmount
            
            frmPayment.Show vbModal
            
            On Error Resume Next
            Unload frmPayment
            Set frmPayment = Nothing
            On Error GoTo 0
            
            processedCount = processedCount + 1
            
            ' If more items, ask to continue
            If processedCount < sumItemCount Then
                Dim continueMsg As String
                continueMsg = "������ " & processedCount & " ��� ��." & vbCrLf & _
                             (sumItemCount - processedCount) & " ���� ��� ���� �����." & vbCrLf & vbCrLf & _
                             "����� �� ���Ͽ"
                
                If MsgBox(continueMsg, vbYesNo + vbQuestion, "����� ��� ������") = vbNo Then
                    Exit For
                End If
            End If
        End If
    Next i
    
    MsgBox processedCount & " ������ ��� ��.", vbInformation, "�����"
    
    ' Set flags and close
    m_WasSelected = True
    m_FormClosed = True
    Me.Hide
End Sub


'====================================================================================================
'                                    CANCEL BUTTON
'====================================================================================================

Private Sub m_btnCancel_Click()
    m_WasSelected = False
    m_FormClosed = True
    Me.Hide
End Sub

'====================================================================================================
'                                    HELPER FUNCTIONS
'====================================================================================================

Private Sub PopulateSearchFilters()
    Dim i As Long
    Dim ws As Worksheet
    Dim sheetDate As String
    Dim parts() As String
    Dim years As Object
    Dim yr As Long
    
    Set years = CreateObject("Scripting.Dictionary")
    For Each ws In ThisWorkbook.Worksheets
        On Error Resume Next
        sheetDate = Trim(CStr(ws.Range("B1").value))
        On Error GoTo 0
        If IsValidMonthlySheet(sheetDate) Then
            parts = Split(sheetDate, "/")
            If Not years.exists(CStr(val(parts(0)))) Then years.Add CStr(val(parts(0))), True
        End If
    Next ws
    
    m_lstFundFilter.Clear
    For i = 1 To GetInsuranceCount()
        m_lstFundFilter.AddItem GetInsuranceName(i)
    Next i
    
    m_cboPeriodYearFrom.Clear
    m_cboPeriodYearTo.Clear
    m_cboPeriodYearFrom.AddItem ""
    m_cboPeriodYearTo.AddItem ""
    For yr = 1300 To 1500
        If years.exists(CStr(yr)) Then
            m_cboPeriodYearFrom.AddItem CStr(yr)
            m_cboPeriodYearTo.AddItem CStr(yr)
        End If
    Next yr
    m_cboPeriodYearFrom.listIndex = 0
    m_cboPeriodYearTo.listIndex = 0
    
    m_cboPeriodMonthFrom.Clear
    m_cboPeriodMonthTo.Clear
    m_cboPeriodMonthFrom.AddItem ""
    m_cboPeriodMonthTo.AddItem ""
    For i = 1 To 12
        m_cboPeriodMonthFrom.AddItem Format(i, "00")
        m_cboPeriodMonthTo.AddItem Format(i, "00")
    Next i
    m_cboPeriodMonthFrom.listIndex = 0
    m_cboPeriodMonthTo.listIndex = 0
End Sub

Private Function IsFundAllowed(ByVal insuranceIndex As Long) As Boolean
    Dim i As Long
    Dim hasSelection As Boolean
    
    IsFundAllowed = True
    If m_lstFundFilter Is Nothing Then Exit Function
    For i = 0 To m_lstFundFilter.ListCount - 1
        If m_lstFundFilter.Selected(i) Then
            hasSelection = True
            If i = insuranceIndex - 1 Then Exit Function
        End If
    Next i
    If hasSelection Then IsFundAllowed = False
End Function

Private Function IsPeriodAllowed(ByVal sheetYear As String, ByVal sheetMonth As String) As Boolean
    Dim currentKey As Long
    Dim fromKey As Long
    Dim toKey As Long
    
    IsPeriodAllowed = True
    currentKey = val(sheetYear) * 100 + val(sheetMonth)
    
    If Trim(m_cboPeriodYearFrom.value) <> "" Then
        fromKey = val(m_cboPeriodYearFrom.value) * 100
        If Trim(m_cboPeriodMonthFrom.value) = "" Then
            fromKey = fromKey + 1
        Else
            fromKey = fromKey + val(m_cboPeriodMonthFrom.value)
        End If
        If currentKey < fromKey Then IsPeriodAllowed = False: Exit Function
    End If
    
    If Trim(m_cboPeriodYearTo.value) <> "" Then
        toKey = val(m_cboPeriodYearTo.value) * 100
        If Trim(m_cboPeriodMonthTo.value) = "" Then
            toKey = toKey + 12
        Else
            toKey = toKey + val(m_cboPeriodMonthTo.value)
        End If
        If currentKey > toKey Then IsPeriodAllowed = False
    End If
End Function

Private Function UiText(ByVal codePoints As String) As String
    Dim tokens() As String
    Dim token As Variant
    
    tokens = Split(codePoints, ",")
    For Each token In tokens
        UiText = UiText & ChrW(CLng(token))
    Next token
End Function
Private Function IsValidMonthlySheet(sheetDate As String) As Boolean
    Dim parts() As String
    
    IsValidMonthlySheet = False
    
    If sheetDate = "" Then Exit Function
    If InStr(sheetDate, "/") = 0 Then Exit Function
    
    parts = Split(sheetDate, "/")
    If UBound(parts) < 1 Then Exit Function
    
    If val(parts(0)) < 1300 Or val(parts(0)) > 1500 Then Exit Function
    If val(parts(1)) < 1 Or val(parts(1)) > 12 Then Exit Function
    
    IsValidMonthlySheet = True
End Function

Private Function GetInsuranceStartRow() As Long
    Dim totalRowsPerDayBlock As Long
    Dim fixedSummaryStartRow As Long
    
    totalRowsPerDayBlock = IIf(userCenters = 1, 2, totalCenters) + 1
    fixedSummaryStartRow = 2 + (31 * totalRowsPerDayBlock) + 2
    
    GetInsuranceStartRow = fixedSummaryStartRow + 10 + userCenters + 1
End Function
Private Function GetInsuranceCount() As Long
    GetInsuranceCount = ConfiguredInsuranceFundCount(userCenters, totalCenters)
End Function
Private Function GetInsuranceName(index As Long) As String
    GetInsuranceName = ConfiguredInsuranceFundName(index, userCenters, totalCenters)
End Function
Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String, i As Long
    result = inputText
    For i = 1776 To 1785
        result = Replace(result, ChrW(i), CStr(i - 1776))
    Next i
    For i = 1632 To 1641
        result = Replace(result, ChrW(i), CStr(i - 1632))
    Next i
    ConvertPersianNumsToEnglish = result
End Function




