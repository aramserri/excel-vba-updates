Attribute VB_Name = "modSheetsFormulaEdit"
 '=====================================================
  ' Module: modSheetsFormulaEdit
  ' Edits formulas in already-existing monthly sheets
  '=====================================================
  Option Explicit

  Public Sub SheetsFormulaEdit()
      Dim wb As Workbook
      Dim wsInfo As Worksheet
      Dim editChoice As Variant
      Dim targetYearInput As Variant
      Dim targetYear As Long
      Dim applyAllYears As Boolean

      Set wb = ThisWorkbook
      Set wsInfo = GetInfoSheet(wb)

      If wsInfo Is Nothing Then
          MsgBox "Info sheet not found.", vbCritical
          Exit Sub
      End If

      editChoice = Application.InputBox( _
          "Which formula section do you want to edit?" & vbCrLf & vbCrLf & _
          "1 - Daily cheque sum formula" & vbCrLf & _
          "2 - Cancel", _
          "Formula Editor", _
          Type:=1)

      If VarType(editChoice) = vbBoolean And editChoice = False Then Exit Sub
      If CLng(editChoice) = 2 Then Exit Sub

      targetYearInput = Application.InputBox( _
          "Enter the Persian year to update, for example 1404." & vbCrLf & _
          "Leave empty to update all monthly sheets.", _
          "Target Year", _
          Type:=2)

      If VarType(targetYearInput) = vbBoolean And targetYearInput = False Then Exit Sub

      applyAllYears = Trim(CStr(targetYearInput)) = ""
      If Not applyAllYears Then targetYear = CLng(targetYearInput)

      Application.ScreenUpdating = False
      Application.Calculation = xlCalculationManual

      Select Case CLng(editChoice)
          Case 1
              Call UpdateExistingDailyChequeSumFormulas(wb, wsInfo, targetYear, applyAllYears)
          Case Else
              MsgBox "Invalid choice.", vbExclamation
      End Select

      Application.Calculation = xlCalculationAutomatic
      Application.ScreenUpdating = True

      MsgBox "Formula update finished.", vbInformation
  End Sub

  Private Sub UpdateExistingDailyChequeSumFormulas( _
      wb As Workbook, _
      wsInfo As Worksheet, _
      targetYear As Long, _
      applyAllYears As Boolean)

      Dim ws As Worksheet
      Dim chequesPerDay As Long
      Dim numCenters As Long
      Dim userCenters As Long
      Dim rowsPerDay As Long
      Dim totalRowsPerDayBlock As Long
      Dim firstChequeColIndex As Long
      Dim dailyChequeSumColIndex As Long
      Dim monthDays As Long
      Dim pYear As Long
      Dim pMonth As Long
      Dim dayNum As Long
      Dim dayStartRow As Long
      Dim dayEndRow As Long
      Dim lowerHalfStartRow As Long
      Dim upperHalfRows As Long
      Dim formulaText As String
      Dim j As Long
      Dim colOffset As Long

      On Error Resume Next
      chequesPerDay = wsInfo.Range("cfg_NumCheques").value
      numCenters = wsInfo.Range("cfg_TotalCenters").value
      userCenters = wsInfo.Range("cfg_ActualUserCenters").value
      On Error GoTo 0

      If chequesPerDay = 0 Then chequesPerDay = 5
      If numCenters = 0 Or userCenters = 0 Then
          MsgBox "Center configuration was not found.", vbCritical
          Exit Sub
      End If

      rowsPerDay = IIf(userCenters = 1, 2, numCenters)
      totalRowsPerDayBlock = rowsPerDay + 1

      firstChequeColIndex = 14
      dailyChequeSumColIndex = firstChequeColIndex + (chequesPerDay * 2)

      For Each ws In wb.Worksheets
          If IsMonthlySheet(ws, pYear, pMonth) Then
              If applyAllYears Or pYear = targetYear Then
                  monthDays = GetPersianMonthDays_Edit(pYear, pMonth)

                  For dayNum = 1 To monthDays
                      dayStartRow = 2 + (dayNum - 1) * totalRowsPerDayBlock
                      dayEndRow = dayStartRow + rowsPerDay - 1

                      upperHalfRows = rowsPerDay \ 2
                      lowerHalfStartRow = dayStartRow + upperHalfRows

                      formulaText = "=SUM("

                      For j = 0 To chequesPerDay - 1
                          colOffset = firstChequeColIndex + (j * 2)
                          formulaText = formulaText & ws.Cells(lowerHalfStartRow, colOffset).Address(False, False) & ","
                      Next j

                      If Right(formulaText, 1) = "," Then
                          formulaText = Left(formulaText, Len(formulaText) - 1) & ")"
                      Else
                          formulaText = "0"
                      End If

formulaText = formulaText & "+IFERROR(XLOOKUP($B$1&""/""&TEXT(A" & dayStartRow & ",""00""),'" & wsInfo.Name & "'!U:U,'" & wsInfo.Name & "'!W:W),0)" & _
              "-IFERROR(XLOOKUP($B$1&""/""&TEXT(A" & dayStartRow & ",""00""),'" & wsInfo.Name & "'!U:U,'" & wsInfo.Name & "'!X:X),0)"


                      With ws.Range(ws.Cells(dayStartRow, dailyChequeSumColIndex), ws.Cells(dayEndRow, dailyChequeSumColIndex))
                          .Formula = formulaText
                          .NumberFormat = "#,##0"
                      End With
                  Next dayNum
              End If
          End If
      Next ws
  End Sub

  Private Function IsMonthlySheet(ws As Worksheet, ByRef pYear As Long, ByRef pMonth As Long) As Boolean
      Dim dateText As String
      Dim parts() As String

      IsMonthlySheet = False

      dateText = Trim(CStr(ws.Range("B1").value))

      If InStr(dateText, "/") = 0 Then Exit Function

      parts = Split(dateText, "/")
      If UBound(parts) < 1 Then Exit Function

      If Not IsNumeric(parts(0)) Then Exit Function
      If Not IsNumeric(parts(1)) Then Exit Function

      pYear = CLng(parts(0))
      pMonth = CLng(parts(1))

      If pYear < 1300 Or pYear > 1500 Then Exit Function
      If pMonth < 1 Or pMonth > 12 Then Exit Function

      IsMonthlySheet = True
  End Function

  Private Function GetInfoSheet(wb As Workbook) As Worksheet
      On Error Resume Next

      Set GetInfoSheet = wb.Sheets("�������")

      If GetInfoSheet Is Nothing Then
          Set GetInfoSheet = wb.Sheets("???????")
      End If

      On Error GoTo 0
  End Function

  Private Function GetPersianMonthDays_Edit(pYear As Long, pMonth As Long) As Long
      If pMonth >= 1 And pMonth <= 6 Then
          GetPersianMonthDays_Edit = 31
      ElseIf pMonth >= 7 And pMonth <= 11 Then
          GetPersianMonthDays_Edit = 30
      ElseIf pMonth = 12 Then
          If ((pYear - 1403) Mod 4 = 0) Then
              GetPersianMonthDays_Edit = 30
          Else
              GetPersianMonthDays_Edit = 29
          End If
      Else
          GetPersianMonthDays_Edit = 0
      End If
  End Function
