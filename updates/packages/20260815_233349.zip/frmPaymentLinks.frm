VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmPaymentLinks 
   Caption         =   "����� �ǘ�����"
   ClientHeight    =   9996.001
   ClientLeft      =   91
   ClientTop       =   406
   ClientWidth     =   15918
   OleObjectBlob   =   "frmPaymentLinks.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmPaymentLinks"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
  Option Explicit

  '=========================================================
  ' UserForm: frmPaymentLinks
  ' Controls required:
  '   cmbCompany, lstBatches, lstFactors, lstCheques
  '   lblFactorTotal, lblChequeTotal, lblStatus, cmdRefresh
  '=========================================================

  Private Const LOG_SHEET_NAME As String = "����� �ǐ"

  Private m_Batches As Collection





  Private Sub UserForm_Initialize()
      Set m_Batches = New Collection

      With Me.lstBatches
          .ColumnCount = 7
          .ColumnWidths = "125;150;55;100;55;100;120"
      End With

      With Me.lstFactors
          .ColumnCount = 4
          .ColumnWidths = "85;105;55;160"
      End With

      With Me.lstCheques
          .ColumnCount = 4
          .ColumnWidths = "85;105;100"
      End With



      LoadCompanies
      LoadBatches
  End Sub

  Private Sub cmdRefresh_Click()
      LoadCompanies
      LoadBatches
  End Sub

  Private Sub cmbCompany_Change()
      LoadBatches
  End Sub

  Private Sub lstBatches_Click()
      ShowSelectedBatchDetails
  End Sub

  Private Sub LoadCompanies()
      Dim ws As Worksheet
      Dim dict As Object
      Dim lastRow As Long, r As Long
      Dim companyName As String
      Dim key As Variant
      Dim oldValue As String

      oldValue = Trim(CStr(Me.cmbCompany.value))

      Set ws = GetLogSheet()
      If ws Is Nothing Then Exit Sub

      Set dict = CreateObject("Scripting.Dictionary")
      lastRow = ws.Cells(ws.rows.count, "A").End(xlUp).Row

      For r = 2 To lastRow
          companyName = Trim(CStr(ws.Cells(r, "E").value))
          If companyName <> "" Then
              If Not dict.exists(companyName) Then dict.Add companyName, True
          End If
      Next r

      Me.cmbCompany.Clear
      Me.cmbCompany.AddItem ""

      For Each key In dict.Keys
          Me.cmbCompany.AddItem CStr(key)
      Next key

      Me.cmbCompany.value = oldValue
  End Sub

  Private Sub LoadBatches()
      Dim ws As Worksheet
      Dim lastRow As Long, r As Long
      Dim selectedCompany As String
      Dim companyName As String
      Dim actionText As String

      Dim pendingFactors As Object
      Dim pendingCheques As Object
      Dim factorGroups As Collection
      Dim chequeGroups As Collection

      Set ws = GetLogSheet()
      If ws Is Nothing Then Exit Sub

      selectedCompany = Trim(CStr(Me.cmbCompany.value))

      Set pendingFactors = CreateObject("Scripting.Dictionary")
      Set pendingCheques = CreateObject("Scripting.Dictionary")
      Set factorGroups = New Collection
      Set chequeGroups = New Collection
      Set m_Batches = New Collection

      lastRow = ws.Cells(ws.rows.count, "A").End(xlUp).Row

      For r = 2 To lastRow
          If Trim(CStr(ws.Cells(r, "C").value)) <> "frmChequeManagement" Then GoTo NextRow

          companyName = Trim(CStr(ws.Cells(r, "E").value))
          If companyName = "" Then GoTo NextRow
          If selectedCompany <> "" And companyName <> selectedCompany Then GoTo NextRow

          actionText = NormalizeAction(CStr(ws.Cells(r, "D").value))

          If IsWriteChequeAction(actionText) Then
              AddLogItem pendingCheques, companyName, ReadChequeItem(ws, r)

          ElseIf IsWriteSummaryAction(actionText) Then
              FlushGroup pendingCheques, chequeGroups, companyName, "CHEQUES"

          ElseIf IsPaidFactorAction(actionText) Then
              AddLogItem pendingFactors, companyName, ReadFactorItem(ws, r)

          ElseIf IsPaidSummaryAction(actionText) Then
              FlushGroup pendingFactors, factorGroups, companyName, "FACTORS"
          End If

NextRow:
      Next r

      BuildMatchedBatches factorGroups, chequeGroups
      DisplayBatches
  End Sub

  Private Sub DisplayBatches()
      Dim i As Long
      Dim b As Object

      Me.lstBatches.Clear
      Me.lstFactors.Clear
      Me.lstCheques.Clear
      Me.lblFactorTotal.Caption = ""
      Me.lblChequeTotal.Caption = ""
      Me.lblStatus.Caption = ""

      For i = 1 To m_Batches.count
          Set b = m_Batches(i)

          Me.lstBatches.AddItem b("BatchTimeText")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 1) = b("Company")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 2) = b("FactorCount")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 3) = Format(b("FactorTotal"), "#,##0")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 4) = b("ChequeCount")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 5) = Format(b("ChequeTotal"), "#,##0")
          Me.lstBatches.List(Me.lstBatches.ListCount - 1, 6) = b("Status")
      Next i
  End Sub

  Private Sub ShowSelectedBatchDetails()
      Dim idx As Long
      Dim b As Object
      Dim item As Variant

      idx = Me.lstBatches.listIndex
      If idx < 0 Then Exit Sub

      Set b = m_Batches(idx + 1)

      Me.lstFactors.Clear
      Me.lstCheques.Clear

      For Each item In b("Factors")
          Me.lstFactors.AddItem item("DateText")
          Me.lstFactors.List(Me.lstFactors.ListCount - 1, 1) = Format(item("Amount"), "#,##0")
          Me.lstFactors.List(Me.lstFactors.ListCount - 1, 2) = item("RowNumber")
          Me.lstFactors.List(Me.lstFactors.ListCount - 1, 3) = item("Details")
      Next item

      For Each item In b("Cheques")
          Me.lstCheques.AddItem item("DateText")
          Me.lstCheques.List(Me.lstCheques.ListCount - 1, 1) = Format(item("Amount"), "#,##0")
          Me.lstCheques.List(Me.lstCheques.ListCount - 1, 2) = item("Serial")
'          Me.lstCheques.List(Me.lstCheques.ListCount - 1, 3) = item("Details")
      Next item

      Me.lblFactorTotal.Caption = Format(b("FactorTotal"), "#,##0")
      Me.lblChequeTotal.Caption = Format(b("ChequeTotal"), "#,##0")
      Me.lblStatus.Caption = b("Status")
  End Sub

  Private Sub BuildMatchedBatches(ByVal factorGroups As Collection, ByVal chequeGroups As Collection)
      Dim i As Long, j As Long
      Dim fg As Object, cg As Object
      Dim bestIndex As Long
      Dim bestDistance As Double
      Dim distance As Double

      For i = 1 To factorGroups.count
          Set fg = factorGroups(i)
          bestIndex = 0
          bestDistance = 999999999#

          For j = 1 To chequeGroups.count
              Set cg = chequeGroups(j)

              If Not CBool(cg("Matched")) Then
                  If CStr(cg("Company")) = CStr(fg("Company")) Then
                      If Abs(CDbl(cg("Total")) - CDbl(fg("Total"))) < 0.01 Then
                          distance = Abs(CDbl(cg("EndRow")) - CDbl(fg("EndRow")))
                          If distance < bestDistance Then
                              bestDistance = distance
                              bestIndex = j
                          End If
                      End If
                  End If
              End If
          Next j

          If bestIndex > 0 Then
              Set cg = chequeGroups(bestIndex)
              cg("Matched") = True
              fg("Matched") = True
              AddBatch fg, cg, "Matched"
          Else
              AddBatch fg, Nothing, "No matching cheque group"
          End If
      Next i

      For j = 1 To chequeGroups.count
          Set cg = chequeGroups(j)
          If Not CBool(cg("Matched")) Then
              AddBatch Nothing, cg, "No matching factor group"
          End If
      Next j
  End Sub

  Private Sub AddBatch(ByVal fg As Object, ByVal cg As Object, ByVal statusText As String)
      Dim b As Object
      Dim emptyFactors As Collection
      Dim emptyCheques As Collection

      Set b = CreateObject("Scripting.Dictionary")

      If Not fg Is Nothing Then
          b.Add "Company", fg("Company")
          b.Add "Factors", fg("Items")
          b.Add "FactorCount", fg("Items").count
          b.Add "FactorTotal", fg("Total")
          b.Add "BatchTimeText", fg("EndTimeText")
          b.Add "BatchRow", fg("EndRow")
      Else
          Set emptyFactors = New Collection
          b.Add "Company", cg("Company")
          b.Add "Factors", emptyFactors
          b.Add "FactorCount", 0
          b.Add "FactorTotal", 0
          b.Add "BatchTimeText", cg("EndTimeText")
          b.Add "BatchRow", cg("EndRow")
      End If

      If Not cg Is Nothing Then
          b.Add "Cheques", cg("Items")
          b.Add "ChequeCount", cg("Items").count
          b.Add "ChequeTotal", cg("Total")
          If fg Is Nothing Then
              b("BatchTimeText") = cg("EndTimeText")
              b("BatchRow") = cg("EndRow")
          End If
      Else
          Set emptyCheques = New Collection
          b.Add "Cheques", emptyCheques
          b.Add "ChequeCount", 0
          b.Add "ChequeTotal", 0
      End If

      b.Add "Status", statusText
      m_Batches.Add b
  End Sub

  Private Sub AddLogItem(ByVal pending As Object, ByVal companyName As String, ByVal item As Object)
      Dim col As Collection

      If Not pending.exists(companyName) Then
          Set col = New Collection
          pending.Add companyName, col
      End If

      pending(companyName).Add item
  End Sub

  Private Sub FlushGroup(ByVal pending As Object, ByVal groups As Collection, ByVal companyName As String, ByVal groupType As String)
      Dim col As Collection
      Dim g As Object
      Dim item As Variant
      Dim totalAmount As Double
      Dim startRow As Double
      Dim endRow As Double
      Dim endTimeText As String

      If Not pending.exists(companyName) Then Exit Sub
      Set col = pending(companyName)

      If col.count = 0 Then Exit Sub

      For Each item In col
          totalAmount = totalAmount + CDbl(item("Amount"))

          If startRow = 0 Or CDbl(item("RowNumber")) < startRow Then
              startRow = CDbl(item("RowNumber"))
          End If

          If CDbl(item("RowNumber")) > endRow Then
              endRow = CDbl(item("RowNumber"))
              endTimeText = CStr(item("LogDateTimeText"))
          End If
      Next item

      Set g = CreateObject("Scripting.Dictionary")
      g.Add "Company", companyName
      g.Add "Type", groupType
      g.Add "Items", col
      g.Add "Total", totalAmount
      g.Add "StartRow", startRow
      g.Add "EndRow", endRow
      g.Add "EndTimeText", endTimeText
      g.Add "Matched", False

      groups.Add g
      pending.Remove companyName
  End Sub

  Private Function ReadFactorItem(ByVal ws As Worksheet, ByVal r As Long) As Object
      Dim item As Object
      Set item = CreateObject("Scripting.Dictionary")

      item.Add "RowNumber", r
      item.Add "LogDateTimeText", MakeLogDateTimeText(ws.Cells(r, "A").value, ws.Cells(r, "B").value)
      item.Add "DateText", MakePersianDate(ws.Cells(r, "F").value, ws.Cells(r, "G").value, ws.Cells(r, "H").value)
      item.Add "Amount", ParseAmount(ws.Cells(r, "I").value)
      item.Add "Details", CStr(ws.Cells(r, "K").value)

      Set ReadFactorItem = item
  End Function

  Private Function ReadChequeItem(ByVal ws As Worksheet, ByVal r As Long) As Object
      Dim item As Object
      Set item = CreateObject("Scripting.Dictionary")

      item.Add "RowNumber", r
      item.Add "LogDateTimeText", MakeLogDateTimeText(ws.Cells(r, "A").value, ws.Cells(r, "B").value)
      item.Add "DateText", MakePersianDate(ws.Cells(r, "F").value, ws.Cells(r, "G").value, ws.Cells(r, "H").value)
      item.Add "Amount", ParseAmount(ws.Cells(r, "I").value)
      item.Add "Serial", ExtractSerial(CStr(ws.Cells(r, "K").value))
      item.Add "Details", CStr(ws.Cells(r, "K").value)

      Set ReadChequeItem = item
  End Function

  Private Function GetLogSheet() As Worksheet
      On Error Resume Next
      Set GetLogSheet = ThisWorkbook.Worksheets(LOG_SHEET_NAME)
      On Error GoTo 0

      If GetLogSheet Is Nothing Then
          MsgBox "Sheet not found: " & LOG_SHEET_NAME, vbCritical
      End If
  End Function

  Private Function NormalizeAction(ByVal s As String) As String
      s = Trim(s)
      s = Replace(s, ChrW(8204), "")
      s = Replace(s, " ", "")
      s = Replace(s, "�", "�")
      s = Replace(s, "�", "�")
      s = Replace(s, "�", "�")
      NormalizeAction = s
  End Function

  Private Function IsWriteChequeAction(ByVal s As String) As Boolean
      IsWriteChequeAction = (s = "����䍘")
  End Function

  Private Function IsWriteSummaryAction(ByVal s As String) As Boolean
      IsWriteSummaryAction = (s = "���������䍘")
  End Function

  Private Function IsPaidFactorAction(ByVal s As String) As Boolean
      IsPaidFactorAction = (s = "����ʐ������������")
  End Function

  Private Function IsPaidSummaryAction(ByVal s As String) As Boolean
      IsPaidSummaryAction = (s = "���������ʐ����")
  End Function

  Private Function MakePersianDate(ByVal y As Variant, ByVal m As Variant, ByVal d As Variant) As String
      If Trim(CStr(y)) = "" Or Trim(CStr(m)) = "" Or Trim(CStr(d)) = "" Then
          MakePersianDate = ""
      Else
          MakePersianDate = CStr(y) & "/" & Format(CLng(m), "00") & "/" & Format(CLng(d), "00")
      End If
  End Function

  Private Function MakeLogDateTimeText(ByVal dateValue As Variant, ByVal timeValue As Variant) As String
      MakeLogDateTimeText = Trim(CStr(dateValue)) & " " & Trim(CStr(timeValue))
  End Function

  Private Function ParseAmount(ByVal v As Variant) As Double
      Dim s As String

      s = ConvertDigitsToEnglish(CStr(v))
      s = Replace(s, ",", "")
      s = Replace(s, "�", "")
      s = Replace(s, "�", "")
      s = Replace(s, " ", "")

      If IsNumeric(s) Then
          ParseAmount = CDbl(s)
      Else
          ParseAmount = 0
      End If
  End Function

  Private Function ExtractSerial(ByVal detailsText As String) As String
      Dim s As String

      s = ConvertDigitsToEnglish(detailsText)
      s = Replace(s, "�����:", "")
      s = Replace(s, "�����:", "")
      s = Replace(s, "Serial:", "")
      s = Replace(s, " ", "")

      ExtractSerial = Trim(s)
  End Function

  Private Function ConvertDigitsToEnglish(ByVal s As String) As String
      Dim i As Long

      For i = 1776 To 1785
          s = Replace(s, ChrW(i), CStr(i - 1776))
      Next i

      For i = 1632 To 1641
          s = Replace(s, ChrW(i), CStr(i - 1632))
      Next i

      ConvertDigitsToEnglish = s
  End Function
