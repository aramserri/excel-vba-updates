VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmDayPicker 
   Caption         =   "������ ���"
   ClientHeight    =   3304
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   4455
   OleObjectBlob   =   "frmDayPicker.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmDayPicker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Public selectedDay As String
Public currentYear As Long
Public currentMonth As Long


Private Sub UserForm_Initialize()
    selectedDay = ""
End Sub

Private Sub UserForm_Activate()
    Dim d As Integer
    Dim daysInMonth As Integer
    
    If currentYear = 0 Or currentMonth = 0 Then
        daysInMonth = 31
    Else
        daysInMonth = GetDaysInMonth(currentYear, currentMonth)
    End If

    For d = 1 To 31
        On Error Resume Next
        Dim Btn As MSForms.CommandButton
        Set Btn = Me.Controls("btnDay" & d)
        
        If Not Btn Is Nothing Then
            If d > daysInMonth Then
                Btn.Visible = False
            Else
                Btn.Visible = True
            End If
        End If
        On Error GoTo 0
    Next d
    
    txtDay.value = ""
    txtDay.SetFocus
End Sub

'----------------------------------------
' Handle X button - just clear selection
'----------------------------------------
Private Sub UserForm_QueryClose(CANCEL As Integer, CloseMode As Integer)
    If CloseMode = vbFormControlMenu Then
        selectedDay = ""
    End If
    ' Let it close normally - don't cancel, don't unload
End Sub

'----------------------------------------
' Handle day button clicks
'----------------------------------------
Private Sub SelectDay(d As Integer)
    selectedDay = CStr(d)
    Me.Hide
End Sub

'----------------------------------------
' Cancel button
'----------------------------------------
Private Sub btnCancel_Click()
    selectedDay = ""
    Me.Hide
End Sub

' Day buttons
Private Sub btnDay1_Click(): SelectDay 1: End Sub
Private Sub btnDay2_Click(): SelectDay 2: End Sub
Private Sub btnDay3_Click(): SelectDay 3: End Sub
Private Sub btnDay4_Click(): SelectDay 4: End Sub
Private Sub btnDay5_Click(): SelectDay 5: End Sub
Private Sub btnDay6_Click(): SelectDay 6: End Sub
Private Sub btnDay7_Click(): SelectDay 7: End Sub
Private Sub btnDay8_Click(): SelectDay 8: End Sub
Private Sub btnDay9_Click(): SelectDay 9: End Sub
Private Sub btnDay10_Click(): SelectDay 10: End Sub
Private Sub btnDay11_Click(): SelectDay 11: End Sub
Private Sub btnDay12_Click(): SelectDay 12: End Sub
Private Sub btnDay13_Click(): SelectDay 13: End Sub
Private Sub btnDay14_Click(): SelectDay 14: End Sub
Private Sub btnDay15_Click(): SelectDay 15: End Sub
Private Sub btnDay16_Click(): SelectDay 16: End Sub
Private Sub btnDay17_Click(): SelectDay 17: End Sub
Private Sub btnDay18_Click(): SelectDay 18: End Sub
Private Sub btnDay19_Click(): SelectDay 19: End Sub
Private Sub btnDay20_Click(): SelectDay 20: End Sub
Private Sub btnDay21_Click(): SelectDay 21: End Sub
Private Sub btnDay22_Click(): SelectDay 22: End Sub
Private Sub btnDay23_Click(): SelectDay 23: End Sub
Private Sub btnDay24_Click(): SelectDay 24: End Sub
Private Sub btnDay25_Click(): SelectDay 25: End Sub
Private Sub btnDay26_Click(): SelectDay 26: End Sub
Private Sub btnDay27_Click(): SelectDay 27: End Sub
Private Sub btnDay28_Click(): SelectDay 28: End Sub
Private Sub btnDay29_Click(): SelectDay 29: End Sub
Private Sub btnDay30_Click(): SelectDay 30: End Sub
Private Sub btnDay31_Click(): SelectDay 31: End Sub

'----------------------------------------
' Persian calendar functions
'----------------------------------------
Private Function IsLeapYear(Y As Long) As Boolean
    Dim rem33 As Long
    rem33 = (Y + 2346) Mod 33
    
    Select Case rem33
        Case 1, 5, 9, 13, 17, 22, 26, 30
            IsLeapYear = True
        Case Else
            IsLeapYear = False
    End Select
End Function

Private Function GetDaysInMonth(ByVal Y As Long, ByVal m As Integer) As Integer
    Select Case m
        Case 1 To 6
            GetDaysInMonth = 31
        Case 7 To 11
            GetDaysInMonth = 30
        Case 12
            If IsLeapYear(Y) Then
                GetDaysInMonth = 30
            Else
                GetDaysInMonth = 29
            End If
        Case Else
            GetDaysInMonth = 0
    End Select
End Function

'----------------------------------------
' Keyboard input handling
'----------------------------------------
Private Sub txtDay_KeyDown(ByVal KeyCode As MSForms.ReturnInteger, ByVal Shift As Integer)
    If KeyCode = vbKeyReturn Then
        Call SubmitTypedDay
        KeyCode = 0
    ElseIf KeyCode = vbKeyEscape Then
        selectedDay = ""
        Me.Hide
    End If
End Sub

'Private Sub SubmitTypedDay()
'    Dim typedDay As Long
'    Dim maxDays As Long
'    Dim cleaned As String
'
'    cleaned = Trim(txtDay.value)
'    cleaned = ConvertPersianNumsToEnglish(cleaned)
'
'    If cleaned = "" Or Not IsNumeric(cleaned) Then
'        MsgBox "����� � ��� ����� ���� ����.", vbExclamation, "���"
'        txtDay.SetFocus
'        Exit Sub
'    End If
'
'    typedDay = CLng(cleaned)
'
'    If currentYear > 0 And currentMonth > 0 Then
'        maxDays = GetDaysInMonth(currentYear, currentMonth)
'    Else
'        maxDays = 31
'    End If
'
'    If typedDay < 1 Or typedDay > maxDays Then
'        MsgBox "��� ���� ��� 1 � " & maxDays & " ����.", vbExclamation, "���"
'        txtDay.SetFocus
'        Exit Sub
'    End If
'
'    selectedDay = CStr(typedDay)
'    Me.Hide
'End Sub
Private Sub SubmitTypedDay()
    Dim typedDay As Long
    Dim maxDays As Long
    Dim cleaned As String
    
    cleaned = Trim(txtDay.value)
    cleaned = ConvertPersianNumsToEnglish(cleaned)
    
    ' ����� ����� ���� ���
    If cleaned = "" Or Not IsNumeric(cleaned) Then
        MsgBox "���� � ��� ����� ���� ����.", vbExclamation, "���"
        With txtDay
            .SetFocus
            .SelStart = 0
            .SelLength = Len(.text)
        End With
        Exit Sub
    End If
    
    typedDay = CLng(cleaned)
    
    ' ����� ��ǘ�� ������ ���
    If currentYear > 0 And currentMonth > 0 Then
        maxDays = GetDaysInMonth(currentYear, currentMonth)
    Else
        maxDays = 31
    End If
    
    ' ����� ���� ����� �� ���� ����
    If typedDay < 1 Or typedDay > maxDays Then
        MsgBox "��� ���� ��� 1 � " & maxDays & " ����.", vbExclamation, "���"
        With txtDay
            .SetFocus
            .SelStart = 0
            .SelLength = Len(.text)
        End With
        Exit Sub
    End If
    
    selectedDay = CStr(typedDay)
    Me.Hide
End Sub

Private Function ConvertPersianNumsToEnglish(ByVal inputText As String) As String
    Dim result As String
    Dim i As Long
    result = inputText
    For i = 1776 To 1785: result = Replace(result, ChrW(i), CStr(i - 1776)): Next i
    For i = 1632 To 1641: result = Replace(result, ChrW(i), CStr(i - 1632)): Next i
    For i = 65296 To 65305: result = Replace(result, ChrW(i), CStr(i - 65296)): Next i
    ConvertPersianNumsToEnglish = result
End Function
