VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmChequeCodeInput 
   Caption         =   "���� �� 16 ���� ��"
   ClientHeight    =   5502
   ClientLeft      =   90
   ClientTop       =   405
   ClientWidth     =   7815
   OleObjectBlob   =   "frmChequeCodeInput.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmChequeCodeInput"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

' Public properties to return values
Public First4Digits As String
Public Middle8Digits As String
Public Last4Digits As String
Public FullCode As String
Public WasCancelled As Boolean

' Private variable to track if this is first cheque
Private m_IsFirstCheque As Boolean
Private m_UpdatingTextBox As Boolean  ' Prevent recursive calls

' Initialize with optional parameters
Public Sub Initialize(Optional middleDigits As String = "", Optional lastDigits As String = "", Optional isFirstCheque As Boolean = False)
    m_IsFirstCheque = isFirstCheque
    
    ' Load middle 8 digits from config sheet if not provided
    If middleDigits = "" Then
        On Error Resume Next
        middleDigits = Trim(ThisWorkbook.Sheets("�������").Range("AE3").value)
        On Error GoTo 0
    End If
    
    ' Set middle 8 digits - ALWAYS ENABLED AND EDITABLE
    Me.TextBox2.text = middleDigits
    Me.TextBox2.Enabled = True
    Me.TextBox2.Locked = False
    If middleDigits <> "" And Len(middleDigits) = 8 Then
        Me.TextBox2.BackColor = RGB(240, 240, 240)  ' Gray - pre-filled but editable
    Else
        Me.TextBox2.BackColor = RGB(255, 255, 255)  ' White - empty
    End If
    
    ' Load last 4 digits from config sheet if not provided
    If lastDigits = "" Then
        On Error Resume Next
        lastDigits = Trim(ThisWorkbook.Sheets("�������").Range("AF3").value)
        On Error GoTo 0
    End If
    
    ' Set last 4 digits behavior - ALWAYS ENABLED AND EDITABLE

        If IsNumeric(lastDigits) And Len(lastDigits) = 4 Then
            Dim nextValue As Long
            nextValue = CLng(lastDigits) + 1
            Me.TextBox3.text = Format(nextValue, "0000")
        Else
            Me.TextBox3.text = lastDigits
        End If
        Me.TextBox3.Locked = False
        Me.TextBox3.Enabled = True
        Me.TextBox3.BackColor = RGB(230, 255, 230)  ' Light green - auto-filled but editable
        Me.Label4.Caption = "4 ��� ��� (��Ϙ�� - ���� ������):"
    
    
    Me.TextBox1.text = ""
    Me.TextBox1.SetFocus
    WasCancelled = False
    m_UpdatingTextBox = False
    Call UpdatePreview
End Sub

Private Sub UserForm_Initialize()
    ' Set RTL and Persian interface
    Me.TextBox1.TextAlign = fmTextAlignCenter
    Me.TextBox2.TextAlign = fmTextAlignCenter
    Me.TextBox3.TextAlign = fmTextAlignCenter
    
    Me.Label1.Caption = "����� �� 16 ���� �� �� ���� ����:"
    Me.Label2.Caption = "4 ��� ���:"
    Me.Label3.Caption = "8 ��� ��� (���� ������):"
    Me.Label4.Caption = "4 ��� ���:"
    Me.Label5.Caption = "��ԝ����� ����:"
    Me.CommandButton1.Caption = "�����"
    Me.CommandButton2.Caption = "���"
    
    Me.TextBox1.MaxLength = 4
    Me.TextBox2.MaxLength = 8
    Me.TextBox3.MaxLength = 4
    
    m_UpdatingTextBox = False
End Sub

' ===== CHANGE EVENTS - Update preview AND auto-advance =====
Private Sub TextBox1_Change()
    If m_UpdatingTextBox Then Exit Sub
    
    ' Convert Persian to English
    m_UpdatingTextBox = True
    Dim converted As String
    converted = ConvertPersianNumsToEnglish(Me.TextBox1.text)
    converted = KeepOnlyDigits(converted)
    
    If converted <> Me.TextBox1.text Then
        Me.TextBox1.text = converted
        Me.TextBox1.SelStart = Len(converted)
    End If
    m_UpdatingTextBox = False
    
    Call UpdatePreview
    
    ' Auto-advance when 4 digits entered
    If Len(converted) = 4 Then
        Me.TextBox2.SetFocus
    End If
End Sub

Private Sub TextBox2_Change()
    If m_UpdatingTextBox Then Exit Sub
    
    ' Convert Persian to English
    m_UpdatingTextBox = True
    Dim converted As String
    converted = ConvertPersianNumsToEnglish(Me.TextBox2.text)
    converted = KeepOnlyDigits(converted)
    
    If converted <> Me.TextBox2.text Then
        Me.TextBox2.text = converted
        Me.TextBox2.SelStart = Len(converted)
    End If
    m_UpdatingTextBox = False
    
    Call UpdatePreview
    
    ' Auto-advance when 8 digits entered
    If Len(converted) = 8 Then
        Me.TextBox3.SetFocus
    End If
End Sub

' TextBox2 - Change background to white when user edits
Private Sub TextBox2_Enter()
    Me.TextBox2.BackColor = RGB(255, 255, 255)  ' White when focused
End Sub

Private Sub TextBox2_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    If Len(Me.TextBox2.text) = 8 Then
        Me.TextBox2.BackColor = RGB(240, 240, 240)  ' Gray when done and valid
    End If
End Sub

Private Sub TextBox3_Change()
    If m_UpdatingTextBox Then Exit Sub
    
    ' Convert Persian to English
    m_UpdatingTextBox = True
    Dim converted As String
    converted = ConvertPersianNumsToEnglish(Me.TextBox3.text)
    converted = KeepOnlyDigits(converted)
    
    If converted <> Me.TextBox3.text Then
        Me.TextBox3.text = converted
        Me.TextBox3.SelStart = Len(converted)
    End If
    m_UpdatingTextBox = False
    
    Call UpdatePreview
End Sub

' TextBox3 - Change background to white when user edits
Private Sub textbox3_Enter()
    If Not m_IsFirstCheque Then
        Me.TextBox3.BackColor = RGB(255, 255, 255)  ' White when editing
    End If
End Sub

Private Sub TextBox3_Exit(ByVal CANCEL As MSForms.ReturnBoolean)
    If Not m_IsFirstCheque And Len(Me.TextBox3.text) = 4 Then
        Me.TextBox3.BackColor = RGB(230, 255, 230)  ' Light green when done
    End If
End Sub

' ===== LOSTFOCUS EVENTS - Update when field loses focus =====
Private Sub TextBox1_LostFocus()
    Call UpdatePreview
End Sub

Private Sub TextBox2_LostFocus()
    Call UpdatePreview
End Sub

Private Sub TextBox3_LostFocus()
    Call UpdatePreview
End Sub

' ===== KEYPRESS EVENTS - Handle Enter key and backspace =====
Private Sub TextBox1_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    If KeyAscii = 13 Then ' Enter key
        KeyAscii = 0
        Call UpdatePreview
        Me.TextBox2.SetFocus
    End If
End Sub

Private Sub TextBox2_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    If KeyAscii = 13 Then ' Enter key
        KeyAscii = 0
        Call UpdatePreview
        Me.TextBox3.SetFocus
    ElseIf KeyAscii = 8 Then ' Backspace
        ' If textbox is empty, go back to previous textbox
        If Len(Me.TextBox2.text) = 0 Then
            Me.TextBox1.SetFocus
            Me.TextBox1.SelStart = Len(Me.TextBox1.text)
        End If
    End If
End Sub

Private Sub TextBox3_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    If KeyAscii = 13 Then ' Enter key
        KeyAscii = 0
        Call UpdatePreview
        Me.CommandButton1.SetFocus
    ElseIf KeyAscii = 8 Then ' Backspace
        ' If textbox is empty, go back to previous textbox
        If Len(Me.TextBox3.text) = 0 Then
            Me.TextBox2.SetFocus
            Me.TextBox2.SelStart = Len(Me.TextBox2.text)
        End If
    End If
End Sub

Private Sub UpdatePreview()
    On Error Resume Next
    
    Dim preview As String
    Dim part1 As String, part2 As String, part3 As String
    Dim part2a As String, part2b As String
    
    ' Get current values and convert Persian to English
    part1 = ConvertPersianNumsToEnglish(Me.TextBox1.text)
    part1 = KeepOnlyDigits(part1)
    
    part2 = ConvertPersianNumsToEnglish(Me.TextBox2.text)
    part2 = KeepOnlyDigits(part2)
    
    part3 = ConvertPersianNumsToEnglish(Me.TextBox3.text)
    part3 = KeepOnlyDigits(part3)
    
    ' Pad with underscores for empty parts
    If Len(part1) < 4 Then part1 = part1 & String(4 - Len(part1), "_")
    If Len(part2) < 8 Then part2 = part2 & String(8 - Len(part2), "_")
    If Len(part3) < 4 Then part3 = part3 & String(4 - Len(part3), "_")
    
    ' Split middle 8 into two groups of 4
    part2a = Left(part2, 4)
    part2b = Mid(part2, 5, 4)
    
    ' Build preview in format: XXXX XXXX XXXX XXXX
    preview = part1 & " " & part2a & " " & part2b & " " & part3
    
    Me.Label6.Caption = preview
    Me.Label6.Font.Size = 14
    Me.Label6.Font.Bold = True
End Sub

Private Sub CommandButton1_Click()
    ' Force final update before validation
    Call UpdatePreview
    
    ' Validate first 4 digits
    Dim cleaned1 As String
    cleaned1 = ConvertPersianNumsToEnglish(Me.TextBox1.text)
    cleaned1 = KeepOnlyDigits(cleaned1)
    
    If Len(cleaned1) <> 4 Then
        MsgBox "����� 4 ��� ��� �� �� ����� ���� ����.", vbExclamation
        Me.TextBox1.SetFocus
        Exit Sub
    End If
    
    ' Validate middle 8 digits
    Dim cleaned2 As String
    cleaned2 = ConvertPersianNumsToEnglish(Me.TextBox2.text)
    cleaned2 = KeepOnlyDigits(cleaned2)
    
    If Len(cleaned2) <> 8 Then
        MsgBox "����� 8 ��� ��� �� �� ����� ���� ����.", vbExclamation
        Me.TextBox2.SetFocus
        Exit Sub
    End If
    
    ' Validate last 4 digits
    Dim cleaned3 As String
    cleaned3 = ConvertPersianNumsToEnglish(Me.TextBox3.text)
    cleaned3 = KeepOnlyDigits(cleaned3)
    
    If Len(cleaned3) <> 4 Then
        MsgBox "����� 4 ��� ��� �� �� ����� ���� ����.", vbExclamation
        Me.TextBox3.SetFocus
        Exit Sub
    End If
    
    ' Store values (cleaned)
    First4Digits = cleaned1
    Middle8Digits = cleaned2
    Last4Digits = cleaned3
    
    FullCode = cleaned1 & cleaned2 & cleaned3
    WasCancelled = False
    
    ' Save middle 8 and last 4 digits to config sheet for next time
    On Error Resume Next
    ThisWorkbook.Sheets("�������").Range("AE3").value = cleaned2
    ThisWorkbook.Sheets("�������").Range("AF3").value = cleaned3
    On Error GoTo 0
    
    Me.Hide
End Sub

Private Sub CommandButton2_Click()
    WasCancelled = True
    Me.Hide
End Sub

' Helper functions
Private Function ConvertPersianNumsToEnglish(ByVal s As String) As String
    Dim i As Long, out As String, ch As String, code As Long
    If Len(s) = 0 Then Exit Function
    
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        Select Case code
            Case 1776 To 1785: out = out & CStr(code - 1776)
            Case 1632 To 1641: out = out & CStr(code - 1632)
            Case 48 To 57: out = out & ch
            Case 32: out = out & " "
        End Select
    Next i
    ConvertPersianNumsToEnglish = out
End Function

Private Function KeepOnlyDigits(ByVal s As String) As String
    Dim i As Long, result As String, ch As String
    For i = 1 To Len(s)
        ch = Mid(s, i, 1)
        If ch >= "0" And ch <= "9" Then result = result & ch
    Next i
    KeepOnlyDigits = result
End Function
