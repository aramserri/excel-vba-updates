Attribute VB_Name = "soorat_hesab"
Sub ShowsoorathesabForm()
    soorathesab.Show
End Sub

