Attribute VB_Name = "modLogging"
'========================================
' Module: modLogging (Insert as a new Standard Module)
'========================================
Option Explicit

' Constants for the log sheet
Private Const LOG_SHEET_NAME As String = "����� �ǐ"
Private Const LOG_HEADER_ROW As Long = 1

'----------------------------------------
' Initialize the log sheet if it doesn't exist
'----------------------------------------
Public Sub InitializeLogSheet()
    Dim ws As Worksheet
    Dim exists As Boolean
    Dim sheetName As String
    
    sheetName = LOG_SHEET_NAME
    
    ' Check if log sheet exists
    exists = False
    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(sheetName)
    exists = (Err.Number = 0)
    On Error GoTo 0
    
    ' Create the sheet if it doesn't exist
    If Not exists Then
        Set ws = ThisWorkbook.Sheets.Add(After:=ThisWorkbook.Sheets(ThisWorkbook.Sheets.count))
        ws.Name = sheetName
        
        ' Set right-to-left
        ws.DisplayRightToLeft = True
        
        ' Create headers (right to left: Date, Time, UserForm, Details...)
        With ws
            .Cells(LOG_HEADER_ROW, 1).value = "�����"
            .Cells(LOG_HEADER_ROW, 2).value = "����"
            .Cells(LOG_HEADER_ROW, 3).value = "���"
            .Cells(LOG_HEADER_ROW, 4).value = "������"
            .Cells(LOG_HEADER_ROW, 5).value = "�ј�"
            .Cells(LOG_HEADER_ROW, 6).value = "���"
            .Cells(LOG_HEADER_ROW, 7).value = "���"
            .Cells(LOG_HEADER_ROW, 8).value = "���"
            .Cells(LOG_HEADER_ROW, 9).value = "����"
            .Cells(LOG_HEADER_ROW, 10).value = "��� �� ������"
            .Cells(LOG_HEADER_ROW, 11).value = "������ �����"
            
            ' Format header row
            .rows(LOG_HEADER_ROW).Font.bold = True
            .rows(LOG_HEADER_ROW).Interior.color = RGB(200, 200, 200)
            .rows(LOG_HEADER_ROW).HorizontalAlignment = xlCenter
            
            ' Format time column as text to prevent decimal conversion
            .Columns(2).NumberFormat = "@"
            
            ' Auto-fit columns
            .Columns("A:K").AutoFit
        End With
    End If
End Sub

'----------------------------------------
' Main logging function
'----------------------------------------
Public Sub WriteLog(ByVal userFormName As String, _
                   ByVal operationType As String, _
                   Optional ByVal companyName As String = "", _
                   Optional ByVal yearValue As String = "", _
                   Optional ByVal monthValue As String = "", _
                   Optional ByVal dayValue As String = "", _
                   Optional ByVal AmountValue As String = "", _
                   Optional ByVal daysToPayValue As String = "", _
                   Optional ByVal additionalDetails As String = "")
    
    Dim ws As Worksheet
    Dim lastRow As Long
    Dim currentDate As String
    Dim currentTime As String
    Dim sheetName As String
    
    sheetName = LOG_SHEET_NAME
    
    ' Initialize log sheet if needed
    Call InitializeLogSheet
    
    Set ws = ThisWorkbook.Sheets(sheetName)
    
    ' Find the next empty row
    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row + 1
    
    ' Get current date and time in Persian calendar format
    currentDate = GetPersianDate()
    currentTime = Format(time, "HH:MM:SS")
    
    ' Write log entry
    With ws
        .Cells(lastRow, 1).value = currentDate
        .Cells(lastRow, 2).NumberFormat = "@" ' Format as text
        .Cells(lastRow, 2).value = currentTime
        .Cells(lastRow, 3).value = userFormName
        .Cells(lastRow, 4).value = operationType
        .Cells(lastRow, 5).value = companyName
        .Cells(lastRow, 6).value = yearValue
        .Cells(lastRow, 7).value = monthValue
        .Cells(lastRow, 8).value = dayValue
        .Cells(lastRow, 9).value = AmountValue
        .Cells(lastRow, 10).value = daysToPayValue
        .Cells(lastRow, 11).value = additionalDetails
        
        ' Format the new row
        .rows(lastRow).HorizontalAlignment = xlRight
        
        ' Alternate row colors for better readability
        If lastRow Mod 2 = 0 Then
            .rows(lastRow).Interior.color = RGB(240, 240, 240)
        End If
    End With
End Sub

'----------------------------------------
' Get the last N log entries for a specific userform
'----------------------------------------
Public Function GetRecentLogs(ByVal userFormName As String, _
                             Optional ByVal numberOfEntries As Long = 5) As String
    
    Dim ws As Worksheet
    Dim lastRow As Long, i As Long
    Dim result As String
    Dim counter As Long
    Dim sheetName As String
    
    sheetName = LOG_SHEET_NAME
    
    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(sheetName)
    On Error GoTo 0
    
    If ws Is Nothing Then
        GetRecentLogs = "�� �ǐ� ���� ���."
        Exit Function
    End If
    
    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    
    If lastRow <= LOG_HEADER_ROW Then
        GetRecentLogs = "�� �ǐ� ���� ���."
        Exit Function
    End If
    
    result = "����� �����ʝ��:" & vbCrLf
'    & String(50, "-") & vbCrLf
    counter = 0
    
    ' Loop backwards from the last row to get recent entries
    For i = lastRow To LOG_HEADER_ROW + 1 Step -1
        If ws.Cells(i, 3).value = userFormName Then
            Dim logDate As String, logTime As String
            Dim logOperation As String, logCompany As String
            Dim logYear As String, logMonth As String, logDay As String
            Dim logAmount As String, logDaysToPay As String
            
            ' Get values and ensure they're strings
            logDate = CStr(ws.Cells(i, 1).value)
            logTime = CStr(ws.Cells(i, 2).value)
            logOperation = CStr(ws.Cells(i, 4).value)
            logCompany = CStr(ws.Cells(i, 5).value)
            logYear = CStr(ws.Cells(i, 6).value)
            logMonth = CStr(ws.Cells(i, 7).value)
            logDay = CStr(ws.Cells(i, 8).value)
            
            ' Format amount if numeric
            If IsNumeric(ws.Cells(i, 9).value) Then
                logAmount = Format(ws.Cells(i, 9).value, "#,##0")
            Else
                logAmount = CStr(ws.Cells(i, 9).value)
            End If
            
            ' Get days to pay as string
            logDaysToPay = CStr(ws.Cells(i, 10).value)
            
            result = result & _
                    logDate & " " & logTime & " - " & _
                    logOperation & ": " & _
                    logCompany & " | " & _
                    logYear & "/" & logMonth & "/" & logDay & _
                    " | ����: " & logAmount & _
                    " | ����: " & logDaysToPay & " ���" & _
                    vbCrLf
            
            counter = counter + 1
            If counter >= numberOfEntries Then Exit For
        End If
    Next i
    
    If counter = 0 Then
        result = "�� �ǐ� ���� ��� ��� ���� ���."
    Else
        result = result & String(50, "-") & vbCrLf & _
                 "���� �����ԡ ��� � �� ����� ��� ����."
    End If
    
    GetRecentLogs = result
End Function

'----------------------------------------
' Helper function to get Persian date (Hejri Shamsi)
'----------------------------------------
Private Function GetPersianDate() As String
    Dim gDate As Date
    Dim pYear As Long, pMonth As Long, pDay As Long
    
    gDate = Date ' Current Gregorian date
    
    ' Convert Gregorian to Persian (Jalali)
    Call GregorianToJalali(Year(gDate), Month(gDate), day(gDate), pYear, pMonth, pDay)
    
    ' Format as YYYY/MM/DD
    GetPersianDate = pYear & "/" & Format(pMonth, "00") & "/" & Format(pDay, "00")
End Function

'----------------------------------------
' Gregorian to Jalali (Persian) conversion
'----------------------------------------
Private Sub GregorianToJalali(ByVal gYear As Long, ByVal gMonth As Long, ByVal gDay As Long, _
                              ByRef jYear As Long, ByRef jMonth As Long, ByRef jDay As Long)
    Dim gy As Long, gm As Long, gd As Long
    Dim jy As Long, jm As Long, jd As Long
    Dim gDayNo As Long, jDayNo As Long
    Dim leap As Long
    Dim i As Long
    Dim gMonthDays As Variant
    Dim jMonthDays As Variant
    
    gMonthDays = Array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    jMonthDays = Array(0, 31, 62, 93, 124, 155, 186, 216, 246, 276, 306, 336)
    
    gy = gYear - 1600
    gm = gMonth - 1
    gd = gDay - 1
    
    gDayNo = 365 * gy + Int((gy + 3) / 4) - Int((gy + 99) / 100) + Int((gy + 399) / 400)
    
    gDayNo = gDayNo + gMonthDays(gMonth - 1) + gd
    
    If gMonth > 2 Then
        If ((gYear Mod 4 = 0 And gYear Mod 100 <> 0) Or (gYear Mod 400 = 0)) Then
            gDayNo = gDayNo + 1
        End If
    End If
    
    jDayNo = gDayNo - 79
    
    Dim jNP As Long
    jNP = Int(jDayNo / 12053)
    jDayNo = jDayNo Mod 12053
    
    jy = 979 + 33 * jNP + 4 * Int(jDayNo / 1461)
    jDayNo = jDayNo Mod 1461
    
    If jDayNo >= 366 Then
        jy = jy + Int((jDayNo - 1) / 365)
        jDayNo = (jDayNo - 1) Mod 365
    End If
    
    If jDayNo < 186 Then
        jm = 1 + Int(jDayNo / 31)
        jd = 1 + (jDayNo Mod 31)
    Else
        jm = 7 + Int((jDayNo - 186) / 30)
        jd = 1 + ((jDayNo - 186) Mod 30)
    End If
    
    jYear = jy
    jMonth = jm
    jDay = jd
End Sub

'----------------------------------------
' Clear old logs (optional maintenance function)
'----------------------------------------
Public Sub ClearOldLogs(Optional ByVal daysToKeep As Long = 90)
    Dim ws As Worksheet
    Dim lastRow As Long, i As Long
    Dim cutoffDate As Date
    Dim rowDate As Date
    Dim sheetName As String
    
    sheetName = LOG_SHEET_NAME
    
    On Error Resume Next
    Set ws = ThisWorkbook.Sheets(sheetName)
    On Error GoTo 0
    
    If ws Is Nothing Then Exit Sub
    
    cutoffDate = Date - daysToKeep
    lastRow = ws.Cells(ws.rows.count, 1).End(xlUp).Row
    
    ' Delete rows older than cutoff date (working backwards)
    For i = lastRow To LOG_HEADER_ROW + 1 Step -1
        On Error Resume Next
        rowDate = CDate(ws.Cells(i, 1).value)
        If Err.Number = 0 And rowDate < cutoffDate Then
            ws.rows(i).Delete
        End If
        On Error GoTo 0
    Next i
End Sub

